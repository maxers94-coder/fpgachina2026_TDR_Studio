TDR 生产验收报告数据包

源数据包：TDR_AI_数据包_FW63-PROD-20261102_20261104T094725.zip
SHA-256：40d2697f220747e67a1a4e47972063767559abbb8ad07c563a65727bffd8abc0

包含：
• 可直接给队友使用的 Excel 分析报告
• 报告要点 Markdown
• 82 组统计、执行顺序、测试板性能、距离分组、多异常逐异常 CSV
• 原始逐次 trials/candidates/expected_anomalies CSV
• 6 张真实数据图表 PNG
• validation.json（范围/哈希/关键校验）

注意：PB15 的 EDGE* 在正式统计中按当前规则未计入有效定位；若确认有效，需在报告中注明敏感性口径，不能静默改原始记录。
