@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
echo ============================================================
echo   TDR Measurement Studio
echo   Cable weak impedance anomaly measurement management
echo ============================================================
where py >nul 2>nul
if errorlevel 1 goto try_python
py -3.12 -c "import tkinter" >nul 2>nul
if errorlevel 1 goto try_python
py -3.12 app.py
goto finished
:try_python
where python >nul 2>nul
if errorlevel 1 goto no_python
python -c "import tkinter" >nul 2>nul
if errorlevel 1 goto no_python
python app.py
goto finished
:no_python
echo Python 3.11/3.12 with Tkinter was not found.
pause
exit /b 1
:finished
if errorlevel 1 pause
endlocal
