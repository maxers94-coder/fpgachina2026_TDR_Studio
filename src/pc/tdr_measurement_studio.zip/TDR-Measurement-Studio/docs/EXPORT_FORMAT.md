# 数据导出格式说明

本程序的导出目标是“让另一个工具或 AI 能在不依赖界面、不依赖本程序的情况下重算主要统计指标”。

所有导出默认写入 `exports/`，文件名带本地时间戳。

---

## 1. Excel 工作簿

导出按钮：数据导入导出 → 导出 Excel 工作簿。

至少包含以下工作表：

| 工作表 | 内容 |
|---|---|
| 项目信息 | 项目、软件/数据版本、导出时间、数量、判定规则、口径说明 |
| 测试板 | 代号、类型、阻值、Z0、理论 Γ、极性、PCB、状态等 |
| 线缆 | 线缆资产 |
| 线缆组合 | 每组合的线段与计算位置基础数据 |
| 健康参考 | 参考条件与文件 |
| 实验配置 | 79 组配置的全部计划字段和 data_status |
| 实验运行 | 实际运行条件快照（固件/参考/前端/操作员） |
| 全部逐次记录 | **全部单次记录**，包含未检出/无效/拒判，不是均值 |
| 多异常候选 | 候选、匹配异常号、真实距离、误差、状态 |
| 真实异常 | 每个运行的 expected 定义 |
| 各组统计 | 每组配置的检出率、极性、定位、MAE、RMSE、P95、无效率等 |
| 多异常逐异常统计 | 每个真实异常的检出与定位指标 |
| 总体汇总 | 仅实测数据的总体指标与口径 |
| 批次汇总 | 固件/前端/批次对比 |
| 自动判定 | 每组自动判定与依据摘要 |
| 统计规则 | 本次导出所使用的规则键值 |
| 数据字典 | 关键字段说明 |

注意：Excel 中“未测试”配置的统计行显示 0 条试次，不能解释为“通过”。项目信息中列明“有实测数据的配置数”。

---

## 2. CSV ZIP

压缩包内目录：

```text
TDR_Experiment_Export/
├─ boards.csv
├─ cables.csv
├─ cable_configurations.csv
├─ references.csv
├─ categories.csv
├─ batches.csv
├─ configurations.csv
├─ experiment_runs.csv
├─ experiments.csv
├─ expected_anomalies.csv
├─ trials.csv
├─ detected_candidates.csv
├─ statistics.csv
├─ multi_anomaly.csv
├─ summary.csv
├─ judgements.csv
├─ manifest.json
├─ README.txt
└─ metadata/full_dataset.json
```

### 稳定主键/外键

| 文件 | 主键 | 关联 |
|---|---|---|
| boards.csv | id | code |
| cables.csv | id | code |
| cable_configurations.csv | id | — |
| references.csv | id | config_id |
| configurations.csv | id | category_id, batch_id, board_id, reference_id, cable_config_id |
| experiment_runs.csv | id | config_id, batch_id |
| experiments.csv | experiment_id | configuration_id, session_id |
| expected_anomalies.csv | id | run_id, board_id |
| trials.csv | trial_id | run_id, configuration_id |
| detected_candidates.csv | candidate_id | trial_id, matched_expected_anomaly_id |
| statistics.csv | config_id | 每条对应 configurations |
| multi_anomaly.csv | config_id + anomaly_index | 每个真实异常的统计 |
| judgements.csv | config_id | 判定快照摘要 |

### CSV 编码与空值

- UTF-8（无 BOM）。
- 缺失值 = 空字段。
- 布尔值 = `true` / `false`。
- 复杂字段（如规则）不放入主 CSV，放 JSON。
- 不在 CSV 中放统计图或格式化百分比；`detection_rate` 等为 0–1 数值。

---

## 3. JSON

按钮：导出 JSON 完整数据。

顶层结构：

```json
{
  "metadata": {
    "project_name": "...",
    "software_version": "1.0.0",
    "data_schema_version": "1.0",
    "exported_at": "...",
    "configuration_count": 79,
    "tested_configuration_count": 0,
    "experiment_run_count": 0,
    "trial_count": 0,
    "statistics_rules": {},
    "units": {},
    "data_policy": []
  },
  "boards": [],
  "cables": [],
  "cable_configurations": [],
  "references": [],
  "categories": [],
  "batches": [],
  "configurations": [],
  "experiment_runs": [],
  "expected_anomalies": [],
  "trials": [],
  "detected_candidates": [],
  "statistics": {
    "per_configuration": [],
    "overall": {},
    "by_batch": [],
    "board_performance": [],
    "detection_vs_gamma": [],
    "error_by_distance": [],
    "multi_mapping": [],
    "rules": {},
    "definitions": {}
  },
  "judgements": [],
  "settings": {}
}
```

### JSON 严格规则

- UTF-8。
- 无 `NaN`、`Infinity`；缺失数值为 `null`。
- 理论反射系数额外标注 `gamma_note`，并同时提供原始比例和百分比字段。
- 每条 trial 保留原始字段并附派生字段：
  - `distance_error_m` = measured − true（仅在有真值时）；
  - `within_tolerance` 使用配置容差或全局容差；
  - `quality_usable` 根据 EDGE* 策略；
  - `polarity_correct`。
- 未测试配置的统计有 `data_status = "not_tested"`。

### 单位

| 字段 | 单位 |
|---|---|
| distance_m / true_distance_m / measured_distance_m / mae_m / p95_abs_error_m | 米 (m) |
| nominal_ohm / measured_ohm / z0 | 欧姆 (Ω) |
| gamma_* | 无量纲 -1..+1 |
| *_rate | 0..1 比例 |
| measured_at / created_at / updated_at | ISO-8601 本地时区 |
| sample_rate_msps | MSPS |

---

## 4. AI 分析数据包 ZIP

目录：

```text
TDR_Experiment_Export/
├─ manifest.json
├─ README.txt
├─ metadata/
│  ├─ boards.json
│  ├─ cables.json
│  ├─ cable_configurations.json
│  ├─ references.json
│  ├─ configurations.json
│  ├─ categories.json
│  ├─ batches.json
│  └─ experiment_runs.json
├─ measurements/
│  ├─ trials.csv
│  ├─ candidates.csv
│  ├─ expected_anomalies.csv
│  ├─ multi_anomaly.csv
│  └─ full_dataset.json
├─ statistics/
│  ├─ statistics.csv
│  ├─ multi_anomaly.csv
│  ├─ summary.csv
│  ├─ judgements.csv
│  └─ results.xlsx
├─ figures/
│  ├─ 01_detection_rate_by_board.png
│  ├─ 02_error_distribution.png
│  ├─ 03_error_by_distance.png
│  ├─ 04_detection_vs_gamma.png
│  └─ 05_multi_anomaly_mapping.png
└─ attachments/
   └─ <run_id>/<原始文件>
```

图表只在有真实数据时生成；没有数据时不会伪造图形。

### manifest.json

包含：
- `package_type`、`package_version`；
- `exported_at`；
- 项目、软件版本、数据结构版本、默认固件；
- `experiment_count`（有数据的运行数）；
- `configuration_count`、`tested_configuration_count`、`experiment_run_count`；
- `trial_count`、`candidate_count`、`board_count`、`attachment_count`；
- `attachments_included`；
- 统计规则与单位；
- `files`：每个文件的 `path`、`size_bytes`、`sha256`；
- 注意事项。

`manifest.json` 本身不在 `files` 校验列表中，避免自哈希循环。

---

## 5. 独立重算示例

可直接用 Python 标准库重算单异常检出率与 MAE：

```python
import csv

with open("trials.csv", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))

for config_code in {r["config_code"] for r in rows}:
    group = [r for r in rows if r["config_code"] == config_code and r["mode"] == "single"]
    detected = [r for r in group if r["detection_status"] == "detected"]
    missed = [r for r in group if r["detection_status"] == "not_detected"]
    denom = len(detected) + len(missed)
    detection_rate = len(detected) / denom if denom else None
    errors = [
        abs(float(r["distance_error_m"]))
        for r in detected
        if r["distance_error_m"] and r["quality_usable"].lower() == "true"
    ]
    mae = sum(errors) / len(errors) if errors else None
    print(config_code, detection_rate, mae)
```

本程序还附带一个完全独立的重算脚本（只读导出文件，不导入本程序统计代码）：

```powershell
py -3.12 scripts\recompute_from_export.py exports\TDR_AI_数据包_xxx.zip
```

它会重算每组的检出率、MAE、P95，并与导出中的 `statistics.per_configuration` 对账。

> 多异常统计会按**导出时使用的当前容差**重新匹配；`detected_candidates.csv` 中的匹配字段是保存时的历史快照。原始候选距离与 expected 定义都完整保留，AI 可独立重算。

更多口径见 [STATISTICS.md](STATISTICS.md)。

---

## 6. 导出安全性与未测试配置

- 未测试配置会出现在 `configurations`/`configurations.csv` 和统计清单，但 `data_status=not_tested`，统计值 null/空。
- 总体统计只聚合有实测数据的配置。
- 不把“计划 79 组”写成“完成 79 组”。
- 不导出已删除附件内容，但数据库备份仍保留此前状态。
- 不同批次/固件/参考未自动混合成单一结论；批次对比只按批次分别显示。
