# 软件架构与目录规划

## 1. 技术选型

| 层 | 实现 |
|---|---|
| 运行平台 | Windows 11，Python 3.11/3.12 |
| 图形界面 | Python 标准库 Tkinter/ttk，原生桌面窗口 |
| 数据库 | SQLite 3（stdlib sqlite3），WAL，显式事务 |
| 数据处理 | Python 标准库（统计自行实现），不依赖 pandas/numpy |
| Excel | openpyxl 3.1.5（项目内 `vendor/`，离线可用） |
| 图表 | matplotlib（本机已有；缺失时降级，不影响数据） |
| 导出 | openpyxl + csv + json + zipfile |
| 测试 | unittest（stdlib） |

### 为什么不用 Streamlit

交付环境完全离线，pip 不可用，无法安装 Streamlit 与浏览器依赖。使用 Tkinter：

- 没有本地端口和浏览器会话状态问题；
- 更适合测量现场键盘连续录入；
- 仍然保留严格的分层：UI 只负责展示与交互，业务规则全在 services/repositories；
- openpyxl 直接随项目提供，无需安装；
- 统计/导出/数据库可独立测试。

如未来网络可用，可保留 `tdr_studio/repositories`、`services`、`database.py`、`schema.sql`，仅替换 `ui/` 层为 Streamlit 页面。

---

## 2. 模块划分

```text
tdr_studio/
├─ config.py           路径、枚举、默认规则、颜色
├─ utils.py            时间、数值、JSON、解析
├─ database.py         连接、事务、设置、审计、备份、恢复
├─ schema.sql          SQLite 结构
├─ repositories/
│  ├─ boards.py        测试板 CRUD、反射派生物
│  ├─ cables.py        线缆资产/组合/位置计算
│  ├─ references.py    健康参考、条件一致性
│  ├─ organization.py  类别/批次
│  ├─ experiments.py   配置矩阵、生成、复制、状态、顺序
│  ├─ runs.py          运行实例、expected_anomalies
│  └─ trials.py        试次、候选匹配、编辑/删除/审计
├─ services/
│  ├─ reflection.py    理想集总模型 Γ
│  ├─ statistics.py    单/正常/多/汇总统计
│  ├─ matching.py      一对一最优匹配
│  ├─ judgement.py     自动判定规则引擎
│  ├─ analytics.py     从数据库构建分析视图
│  ├─ excel_import.py  Excel 表头识别/字段映射/测试板/报告
│  ├─ export_service.py Excel/CSV/JSON/ZIP
│  ├─ figures.py       真实数据图表
│  └─ attachments.py   附件复制/SHA-256/校验
└─ ui/
   ├─ app.py           主窗口、导航、状态栏
   ├─ theme.py         科研仪器风格/高 DPI
   ├─ widgets.py       表格、模态框、指标卡、滚动区
   ├─ base.py          页面基类
   └─ pages/           8 个功能页面
```

依赖方向：

```text
ui → services → repositories → database → SQLite
ui → repositories（仅页面查询/触发动作）
services 不导入 ui
repositories 不导入 ui
```

统计服务只接收普通 dict，便于单元测试与从导出文件重算。

---

## 3. 主要流程

### 3.1 Excel 导入

1. 计算源文件 SHA-256，防止同文件重复建组；
2. 扫描工作表定位表头（同义字段）；
3. 行级字段规范化；
4. 解析测试板/端点/多异常表达式；
5. 类别/批次/测试板按需建立（不覆盖已有资产）；
6. 配置代码去重，不丢行；
7. 保存 source_payload 与导入报告；
8. 事务写 import_runs 与审计。

### 3.2 进入工作台

1. 选择配置；
2. `RunRepository.ensure_for_config()` 创建或载入运行；
3. 快照 batch/firmware/reference/frontend/operator；
4. 单异常生成一条 expected；多异常从配置 JSON 生成；
5. 界面实时调用 `run_stats()`。

### 3.3 保存试次

1. 校验模式允许的状态；
2. 检出必须有距离；
3. 未检出距离强制 NULL；
4. 写入 trials；
5. 写审计（create/update/delete）；
6. 更新运行时间、刷新配置状态；
7. 统计不缓存，下次读取重算。

### 3.4 多异常保存

1. 候选过滤空距离；
2. 读取真实异常；
3. 使用容差 + 最大匹配/极性/总误差规则匹配；
4. 写 trials 状态；
5. 写 candidates 匹配结果；
6. 额外候选计数；
7. 审计。

### 3.5 导出

1. 构建 dataset（所有配置、运行、试次、候选，统计逐组）；
2. 未测试配置标记 data_status；
3. 总体只聚合实测；
4. 写 Excel/CSV/JSON/ZIP；
5. manifest 计算每个文件 SHA-256；
6. 校验 JSON 无 NaN/Infinity。

---

## 4. 界面设计

- 左侧固定导航：仪表盘、测试板、线缆与参考、实验计划、实验工作台、数据分析、导入导出、系统设置。
- 主区域浅灰背景、白色卡片、深青主色。
- 中文字体 Microsoft YaHei UI，Tk DPI awareness + scaling。
- 工作台重点：顶部条件、KPI、快速录入、自动判定、试次表、附件。
- 全局快捷键 Ctrl+1..8 导航，F5 刷新，工作台 Ctrl+Enter 保存。

## 5. 扩展点

- 新统计指标：在 `services/statistics.py` 增加并加入导出列；
- 新判定规则：`judgement.py` 的 rules 和 UI 设置；
- 新数据来源：实现导入器返回相同 dataset 结构；
- Streamlit 迁移：复用 service/repo，替换 ui。

## 6. 失败隔离

- UI 捕获异常并在状态栏/弹窗显示，不静默吞掉。
- 保存/编辑/删除均在事务中；异常回滚。
- 导入单行失败记录到报告，不删除原始行。
- 导出失败不删除数据库。
- 图表失败仅影响当前图表。
