# 数据库结构说明

数据库：`data/tdr_studio.db`（SQLite 3）

- WAL 日志模式，`busy_timeout=20000`，`synchronous=NORMAL`。
- 所有写操作使用显式 `BEGIN IMMEDIATE` 事务。
- 外键开启，时间使用本地时区 ISO-8601（含偏移），如 `2026-11-02T19:40:42+08:00`。
- 不把统计平均值写入原始记录表；统计结果按需计算。

---

## 1. 实体关系

```text
experiment_categories 1 ── n experiment_configs
batches               1 ── n experiment_configs
batches               1 ── n experiment_runs
boards                1 ── n experiment_configs
boards                1 ── n expected_anomalies
cable_configs         1 ── n cable_config_items
cable_configs         1 ── n health_references
health_references     1 ── n experiment_configs / experiment_runs

experiment_configs    1 ── 1 experiment_runs
experiment_runs       1 ── n expected_anomalies
experiment_runs       1 ── n trials
experiment_runs       1 ── n attachments
experiment_runs       1 ── n judgements

trials                1 ── n detected_candidates
expected_anomalies    1 ── n detected_candidates (matched_expected_id)
trials                1 ── n attachments (trial_id, 可空)
```

一个计划配置对应一个运行实例（`experiment_runs.config_id UNIQUE`）。同配置不同批次/复测通过复制配置到新批次实现，保证版本数据不混合。

---

## 2. 主要表

### `experiment_categories`
| 字段 | 含义 |
|---|---|
| id | UUID 主键 |
| code | 类别编号，唯一；内置 A–F |
| name / description | 名称、说明 |
| is_builtin | 是否内置 |
| sort_order | 排序 |

类别可编辑/复制/新增/删除；有配置引用时删除被拒绝。

### `batches`
实验批次/版本：`code`、`name`、`firmware_version`、`frontend`、`is_active`。  
不同批次统计默认不混合。

### `boards`
阻抗测试板资产。

| 字段 | 含义 |
|---|---|
| id / code / name | UUID、唯一代号、名称 |
| board_type | normal / series / shunt / open / short / custom |
| nominal_ohm / measured_ohm | 标称/实测电阻 |
| z0 | 特性阻抗，默认 50Ω |
| gamma_override | 自定义反射系数 |
| gamma_nominal / gamma_measured | 按标称/实测电阻算出的**理论** Γ |
| polarity | positive / negative / none |
| pcb_no / component_model / manufacture_date / photo_path | 资产信息 |
| status | available / pending / damaged / retired |

同一阻值可有多个不同 `id/code` 的物理板。

### `cables` / `cable_configs` / `cable_config_items`
- `cables`：线缆资产（物理长度、Z0、速度系数）。
- `cable_configs`：线缆组合头，保存计算后的总长度/连接器数。
- `cable_config_items`：有序线段，`item_type` 为 cable / board / connector / termination，含长度和电气长度修正 `correction_m`。

理论位置按组合顺序使用修正值计算；不是把物理长度当成电气长度。

### `health_references`
健康参考：参考编号、建立时间、线缆组合、模拟前端、固件版本、数据文件、是否有效。  
实验条件不匹配时界面警告；不自动计入正常验收统计。

### `experiment_configs`
计划矩阵中的一组配置。

关键字段：
- `code` 唯一实验编号；
- `category_id`、`batch_id`、`priority`、`mode`；
- `distance_m`、`distance_expr`、`near_expr`、`far_expr`；
- `board_id`、`expected_polarity`、`nominal_gamma`；
- `planned_repeats`、`tolerance_m`；
- `reference_id`、`cable_config_id`、`reference_label`；
- `status`：not_started / in_progress / completed / skipped / failed；
- `expected_anomalies_json`：多异常真实定义快照；
- `source`、`source_row`、`source_payload`：导入追溯；
- 创建/更新时间。

已有试次后，模式、真值距离、测试板和异常定义锁定。

### `experiment_runs`
实际运行实例与条件快照。

| 字段 | 含义 |
|---|---|
| id | experiment_id |
| code | 可读运行编号 |
| config_id | 配置 ID（唯一） |
| batch_id | 批次 |
| session_id | 当前实现等于批次 ID，用于会话分组 |
| firmware_version / reference_id / cable_config_id / frontend / operator | 条件快照 |
| status | active / completed / abandoned |
| created_at / updated_at / notes | 追溯 |

用户需求中的 `experiment_id`、`configuration_id`、`session_id` 均可在导出中找到对应关系。

### `expected_anomalies`
多异常真实定义：`run_id`、`anomaly_index`、`board_id`、`true_distance_m`、`expected_polarity`、`tolerance_m`。  
单异常运行也会生成一条，便于统一。

### `trials`
单次测量记录，核心原始表。

| 字段 | 含义 |
|---|---|
| id | `trial_id` |
| run_id、config_id | 关联 |
| trial_index | 试次号，运行内唯一 |
| true_distance_m | 单异常真值；正常/多异常为 NULL |
| measured_distance_m | 人工录入系统测量距离；未检出为 NULL |
| polarity | positive / negative / none / unknown |
| detection_status | detected / not_detected / normal / false_alarm / invalid / rejected |
| quality_flag | 正常 / EDGE* / PN? / OVERFLOW / LOW / OPEN-LIKE / SHORT-LIKE / 其他 |
| extra_candidate_count | 额外候选数 |
| is_manual | 当前实现为人工录入 |
| notes | 备注 |
| measured_at、created_at、updated_at | 时间 |

约束：`UNIQUE(run_id, trial_index)`。

### `detected_candidates`
多异常候选与匹配：

- `trial_id`、`candidate_index`；
- `measured_distance_m`、`polarity`、`quality_flag`；
- `matched_expected_id`、`match_status`（matched/extra/ambiguous/unreviewed）；
- `polarity_correct`、`distance_error_m`；
- 备注、时间。

一个候选最多绑定一个 expected，一个 expected 最多匹配一个候选。

### `attachments`
附件元数据：`file_name`、`relative_path`（相对 `data/`）、`sha256`、`size_bytes`、`category`、`trial_id`、`uploaded_at`。

文件实际位于 `data/attachments/runs/<run_id>/`；删除记录前界面会确认，并同时删除复制文件。

### `judgements`
判定快照：`decision`、`rules_json`、`metrics_json`、`summary`、`reviewer`、`review_note`、`created_at`。  
人工复核不会修改 trials。

### `audit_log`
| 字段 | 含义 |
|---|---|
| timestamp | 时间 |
| actor | 操作员 |
| action | create/update/delete/status/backup/restore/import_excel/... |
| entity_type / entity_id | 对象 |
| before_json / after_json | 修改前后内容 |
| note | 说明 |

### `import_runs`
Excel 导入记录：源文件、SHA-256、导入时间、数量、警告/错误数、完整报告 JSON。

### `settings`
键值设置（JSON 编码）：项目名、默认固件、容差、判定阈值、EDGE* 有效性、自动备份等。

### `schema_meta`
结构版本与软件版本。

---

## 3. 迁移原则

- `PRAGMA user_version` 未使用；结构版本在 `schema_meta`。
- 初始化使用 `CREATE TABLE IF NOT EXISTS`，新增字段需要显式迁移脚本。
- 新增字段应允许 NULL 或提供默认值。
- 不要直接修改正式数据库；改动前备份。
- 恢复跨版本数据库时，先确认结构版本。

---

## 4. 备份与恢复

### 备份
`Database.backup()` 使用 SQLite Backup API 生成一致快照，不直接复制 WAL 状态。默认文件：

```text
data/backups/tdr_studio_backup_YYYYMMDDTHHMMSS.db
```

启动时如有实测数据且最近备份超过 24 小时，自动备份。

### 恢复
1. 先校验候选文件 `quick_check` 和核心表存在；
2. 自动备份当前库（安全备份）；
3. 清理 `-wal/-shm`；
4. 复制候选数据库；
5. 重新初始化并写审计记录。

附件不在数据库内。完整证据包请同时导出 AI ZIP（含附件）。

---

## 5. 数据正确性约束

- 未检出距离为 NULL，不用 0 表示。
- 理论反射系数和实测反射系数分列；理论值不会被标为仪器实测。
- 正常组没有异常距离。
- 删除前写 `before_json`。
- 修改试次时间且保留审计。
- 统计不写回原始表，始终从 trials 重建。
