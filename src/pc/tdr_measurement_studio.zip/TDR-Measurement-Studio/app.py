"""TDR Measurement Studio 启动入口。"""
from tdr_studio.ui.app import main

if __name__ == "__main__":
    main()
