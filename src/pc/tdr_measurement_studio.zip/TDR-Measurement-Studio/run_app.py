"""兼容启动入口，可被 BAT 直接调用。"""
from tdr_studio.ui.app import main

if __name__ == "__main__":
    main()
