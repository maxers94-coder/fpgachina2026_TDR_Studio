"""界面冒烟测试：创建主窗口并刷新全部页面/标签页。"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

try:
    import tkinter as tk
except Exception:
    tk = None


@unittest.skipIf(tk is None, "当前环境没有 Tkinter")
class UISmokeTests(unittest.TestCase):
    def setUp(self):
        from tdr_studio.database import Database

        self.tempdir = tempfile.TemporaryDirectory(prefix="tdr_ui_")
        self.db = Database(Path(self.tempdir.name) / "ui.db")
        self.db.initialize()

    def tearDown(self):
        self.tempdir.cleanup()

    def test_launch_and_navigate_all_pages(self):
        try:
            root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest(f"无图形显示环境：{exc}")
        root.withdraw()
        try:
            from tdr_studio.ui.app import TDRApp

            app = TDRApp(root, db=self.db)
            root.update()
            for key in ["dashboard", "boards", "cables", "plan", "workbench", "analysis", "transfer", "settings"]:
                app.navigate(key)
                root.update()
                self.assertIsNotNone(app.current_page)
            # 各内部标签页
            cables = app.pages["cables"]
            for index in range(3):
                cables.notebook.select(index)
                root.update()
                cables.refresh_current_tab()
            plan = app.pages["plan"]
            for index in range(4):
                plan.notebook.select(index)
                root.update()
                plan._refresh_current()
            settings = app.pages["settings"]
            for index in range(5):
                settings.notebook.select(index)
                root.update()
                settings.refresh_current()
        finally:
            root.destroy()


if __name__ == "__main__":
    unittest.main()
