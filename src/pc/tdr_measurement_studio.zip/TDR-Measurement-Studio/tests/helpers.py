"""测试夹具。"""
from __future__ import annotations

import tempfile
from pathlib import Path

from tdr_studio.database import Database
from tdr_studio.repositories.boards import BoardRepository
from tdr_studio.repositories.experiments import ExperimentRepository
from tdr_studio.repositories.organization import BatchRepository, CategoryRepository
from tdr_studio.repositories.runs import RunRepository
from tdr_studio.repositories.trials import TrialRepository


class LabFixture:
    def __init__(self):
        self.tempdir = tempfile.TemporaryDirectory(prefix="tdr_case_")
        self.db = Database(Path(self.tempdir.name) / "tdr.db")
        self.db.initialize()
        self.boards_repo = BoardRepository(self.db)
        self.categories = CategoryRepository(self.db)
        self.batches = BatchRepository(self.db)
        self.experiments = ExperimentRepository(self.db)
        self.runs = RunRepository(self.db)
        self.trials = TrialRepository(self.db)
        self.batch = self.batches.get_active()
        self.boards = {}
        definitions = [
            ("A", "27Ω 串联异常", "series", 27.0),
            ("B", "4.7Ω 串联异常", "series", 4.7),
            ("C", "470Ω 并联异常", "shunt", 470.0),
            ("D", "1kΩ 并联异常", "shunt", 1000.0),
            ("E", "Normal 正常参考板", "normal", None),
            ("F", "2Ω 串联异常", "series", 2.0),
        ]
        for code, name, kind, ohm in definitions:
            self.boards[code] = self.boards_repo.create(
                {"code": code, "name": name, "board_type": kind, "nominal_ohm": ohm, "z0": 50.0}
            )

    def close(self):
        self.db.close()
        self.tempdir.cleanup()

    def single_config(self, *, board="F", distance=15.0, repeats=5, category="C"):
        category_row = self.categories.get_by_code(category)
        return self.experiments.create(
            {
                "category_id": category_row["id"],
                "batch_id": self.batch["id"],
                "board_id": self.boards[board]["id"],
                "distance_m": distance,
                "planned_repeats": repeats,
                "priority": "P0",
                "mode": "normal" if board == "E" else "single",
            }
        )

    def multi_config(self, *, repeats=1):
        category = self.categories.get_by_code("E")
        return self.experiments.create(
            {
                "category_id": category["id"],
                "batch_id": self.batch["id"],
                "mode": "multi",
                "planned_repeats": repeats,
                "priority": "P0",
                "distance_expr": "15/25/30/33",
                "expected_anomalies": [
                    {"true_distance_m": 15.0, "board_id": self.boards["D"]["id"], "expected_polarity": "negative"},
                    {"true_distance_m": 25.0, "board_id": self.boards["A"]["id"], "expected_polarity": "positive"},
                    {"true_distance_m": 30.0, "board_id": self.boards["C"]["id"], "expected_polarity": "negative"},
                    {"true_distance_m": 33.0, "board_id": self.boards["B"]["id"], "expected_polarity": "positive"},
                ],
            }
        )
