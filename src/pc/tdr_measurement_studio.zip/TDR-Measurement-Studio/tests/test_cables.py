"""线缆组合位置计算测试。"""
from __future__ import annotations

import unittest

from tests.helpers import LabFixture


class CableLayoutTests(unittest.TestCase):
    def setUp(self):
        self.lab = LabFixture()

    def tearDown(self):
        self.lab.close()

    def test_position_and_correction(self):
        from tdr_studio.repositories.cables import CableRepository

        repo = CableRepository(self.lab.db)
        cables = {c["code"]: c for c in repo.list()}
        items = [
            {"item_type": "cable", "cable_id": cables["C15"]["id"], "label": "C15", "length_m": 15.0, "correction_m": 0.1},
            {"item_type": "board", "board_id": self.lab.boards["D"]["id"], "label": "D", "board_type": "shunt", "board_code": "D", "correction_m": 0.2},
            {"item_type": "cable", "cable_id": cables["C10"]["id"], "label": "C10", "length_m": 10.0, "correction_m": 0.0},
            {"item_type": "board", "board_id": self.lab.boards["A"]["id"], "label": "A", "board_type": "series", "board_code": "A", "correction_m": 0.0},
            {"item_type": "connector", "label": "SMA", "correction_m": 0.05},
        ]
        layout = repo.calculate_layout(items)
        self.assertAlmostEqual(layout["total_length_m"], 25.35)
        self.assertEqual(layout["connector_count"], 1)
        self.assertAlmostEqual(layout["boards"][0]["theoretical_distance_m"], 15.3)
        self.assertAlmostEqual(layout["boards"][1]["theoretical_distance_m"], 25.3)
        self.assertAlmostEqual(layout["intervals"][0]["interval_m"], 10.0)

    def test_normal_board_not_anomaly(self):
        from tdr_studio.repositories.cables import CableRepository

        repo = CableRepository(self.lab.db)
        items = [
            {"item_type": "board", "board_id": self.lab.boards["E"]["id"], "label": "Normal", "board_type": "normal", "board_code": "E"},
        ]
        layout = repo.calculate_layout(items)
        self.assertEqual(layout["boards"], [])
        self.assertEqual(layout["total_length_m"], 0.0)


if __name__ == "__main__":
    unittest.main()
