"""单元测试包。测试数据目录与正式数据目录隔离。"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

_TEST_ROOT = Path(tempfile.mkdtemp(prefix="tdr_tests_"))
os.environ["TDR_DATA_DIR"] = str(_TEST_ROOT / "data")
os.environ["TDR_DB_PATH"] = str(_TEST_ROOT / "data" / "test.db")
os.environ["TDR_EXPORT_DIR"] = str(_TEST_ROOT / "exports")

# 确保 vendor/openpyxl 在测试模块直接 import openpyxl 之前已注入。
import tdr_studio  # noqa: E402,F401
