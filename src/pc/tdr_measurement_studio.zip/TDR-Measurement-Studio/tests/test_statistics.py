"""统计口径与多异常匹配测试。"""
from __future__ import annotations

import unittest

from tdr_studio.services.matching import match_candidates
from tdr_studio.services.statistics import aggregate_stats, summarize_trials


def trial(index, status, distance=None, polarity="unknown", quality="正常", trial_id=None):
    return {
        "id": trial_id or f"t{index}",
        "trial_index": index,
        "detection_status": status,
        "measured_distance_m": distance,
        "true_distance_m": 15.0,
        "polarity": polarity,
        "quality_flag": quality,
    }


class SingleStatsTests(unittest.TestCase):
    def setUp(self):
        self.trials = [
            trial(1, "detected", 15.12, "positive"),
            trial(2, "detected", 14.95, "positive"),
            trial(3, "detected", 15.08, "positive"),
            trial(4, "detected", 15.03, "positive"),
            trial(5, "not_detected", None, "unknown"),
        ]

    def test_acceptance_five_trials(self):
        stats = summarize_trials(
            mode="single", trials=self.trials, planned_trials=5,
            expected_polarity="positive", true_distance_m=15.0,
            rules={"distance_tolerance_m": 0.6},
        )
        self.assertEqual(stats["total_trials"], 5)
        self.assertEqual(stats["resolved_trials"], 5)
        self.assertEqual(stats["detected_count"], 4)
        self.assertEqual(stats["not_detected_count"], 1)
        self.assertAlmostEqual(stats["detection_rate"], 0.8)
        self.assertEqual(stats["distance"]["n"], 4)
        self.assertAlmostEqual(stats["distance"]["mean_distance_m"], 15.045)
        self.assertAlmostEqual(stats["distance"]["mae_m"], 0.07)
        self.assertAlmostEqual(stats["distance"]["mean_signed_error_m"], 0.045)
        self.assertAlmostEqual(stats["polarity_accuracy"], 1.0)
        self.assertAlmostEqual(stats["location_pass_rate"], 1.0)
        self.assertAlmostEqual(stats["comprehensive_success_rate"], 0.8)
        self.assertEqual(stats["comprehensive_success_count"], 4)

    def test_empty(self):
        stats = summarize_trials(
            mode="single", trials=[], planned_trials=5, expected_polarity="positive",
            true_distance_m=15.0,
        )
        self.assertFalse(stats["has_data"])
        self.assertEqual(stats["total_trials"], 0)
        self.assertIsNone(stats["detection_rate"])
        self.assertIsNone(stats["mae_m"] if "mae_m" in stats else stats["distance"]["mae_m"])
        self.assertIsNone(stats["comprehensive_success_rate"])

    def test_all_not_detected_never_zero_distance(self):
        trials = [trial(i, "not_detected") for i in range(1, 5)]
        stats = summarize_trials(
            mode="single", trials=trials, planned_trials=4,
            expected_polarity="positive", true_distance_m=15.0,
        )
        self.assertEqual(stats["total_trials"], 4)
        self.assertEqual(stats["detected_count"], 0)
        self.assertAlmostEqual(stats["detection_rate"], 0.0)
        self.assertEqual(stats["located_count"], 0)
        self.assertIsNone(stats["distance"]["mean_distance_m"])
        self.assertIsNone(stats["distance"]["mae_m"])
        self.assertIsNone(stats["location_pass_rate"])

    def test_invalid_and_rejected_kept_in_total(self):
        trials = self.trials + [
            trial(6, "invalid", quality="PN?"),
            trial(7, "rejected", quality="正常"),
        ]
        stats = summarize_trials(
            mode="single", trials=trials, planned_trials=7,
            expected_polarity="positive", true_distance_m=15.0,
        )
        self.assertEqual(stats["total_trials"], 7)
        self.assertEqual(stats["resolved_trials"], 5)
        self.assertEqual(stats["invalid_count"], 1)
        self.assertEqual(stats["rejected_count"], 1)
        self.assertAlmostEqual(stats["invalid_rate"], 2 / 7)
        self.assertAlmostEqual(stats["detection_rate"], 0.8)

    def test_wrong_polarity_fails_comprehensive(self):
        trials = [trial(i, "detected", 15.0, "negative") for i in range(1, 4)]
        stats = summarize_trials(
            mode="single", trials=trials, planned_trials=3,
            expected_polarity="positive", true_distance_m=15.0,
        )
        self.assertAlmostEqual(stats["polarity_accuracy"], 0.0)
        self.assertEqual(stats["comprehensive_success_count"], 0)

    def test_edge_policy_and_quality(self):
        trials = [trial(i, "detected", 15.0, "positive", "EDGE*") for i in range(1, 4)]
        invalid = summarize_trials(
            mode="single", trials=trials, planned_trials=3, expected_polarity="positive",
            true_distance_m=15.0, rules={"edge_as_valid": False},
        )
        self.assertEqual(invalid["located_count"], 0)
        self.assertEqual(invalid["comprehensive_success_count"], 0)
        valid = summarize_trials(
            mode="single", trials=trials, planned_trials=3, expected_polarity="positive",
            true_distance_m=15.0, rules={"edge_as_valid": True},
        )
        self.assertEqual(valid["comprehensive_success_count"], 3)

    def test_normal_false_alarm(self):
        trials = [
            trial(1, "normal"), trial(2, "normal"), trial(3, "normal"),
            trial(4, "false_alarm", 15.2, quality="正常"),
            trial(5, "invalid"),
        ]
        stats = summarize_trials(mode="normal", trials=trials, planned_trials=5)
        self.assertEqual(stats["total_trials"], 5)
        self.assertEqual(stats["resolved_trials"], 4)
        self.assertEqual(stats["normal_count"], 3)
        self.assertEqual(stats["false_alarm_count"], 1)
        self.assertAlmostEqual(stats["normal_judgement_rate"], 0.75)
        self.assertAlmostEqual(stats["false_alarm_rate"], 0.25)
        self.assertIsNone(stats["detection_rate"])


class MultiStatsTests(unittest.TestCase):
    def make_expected(self):
        return [
            {"id": "e1", "anomaly_index": 1, "true_distance_m": 15.0, "expected_polarity": "negative", "board_code": "D"},
            {"id": "e2", "anomaly_index": 2, "true_distance_m": 25.0, "expected_polarity": "positive", "board_code": "A"},
            {"id": "e3", "anomaly_index": 3, "true_distance_m": 30.0, "expected_polarity": "negative", "board_code": "C"},
            {"id": "e4", "anomaly_index": 4, "true_distance_m": 33.0, "expected_polarity": "positive", "board_code": "B"},
        ]

    def test_matching_four_and_extra(self):
        expected = self.make_expected()
        candidates = [
            {"id": "c1", "candidate_index": 1, "measured_distance_m": 14.95, "polarity": "negative", "quality_flag": "正常"},
            {"id": "c2", "candidate_index": 2, "measured_distance_m": 25.12, "polarity": "positive", "quality_flag": "正常"},
            {"id": "c3", "candidate_index": 3, "measured_distance_m": 30.08, "polarity": "negative", "quality_flag": "正常"},
            {"id": "c4", "candidate_index": 4, "measured_distance_m": 33.14, "polarity": "positive", "quality_flag": "正常"},
        ]
        result = match_candidates(expected, candidates, default_tolerance_m=0.6)
        self.assertEqual(len(result["assignments"]), 4)
        self.assertFalse(result["missed_expected_ids"])
        self.assertFalse(result["extra_candidate_ids"])
        self.assertEqual(result["polarity_correct"], 4)
        candidates.append(
            {"id": "c5", "candidate_index": 5, "measured_distance_m": 10.0, "polarity": "positive", "quality_flag": "正常"}
        )
        result = match_candidates(expected, candidates, default_tolerance_m=0.6)
        self.assertEqual(len(result["assignments"]), 4)
        self.assertEqual(result["extra_candidate_ids"], {"c5"})

    def test_one_to_one_and_missed(self):
        expected = self.make_expected()[:2]
        candidates = [
            {"id": "c1", "candidate_index": 1, "measured_distance_m": 25.01, "polarity": "positive", "quality_flag": "正常"}
        ]
        result = match_candidates(expected, candidates, default_tolerance_m=0.6)
        self.assertEqual(len(result["assignments"]), 1)
        self.assertEqual(result["assignments"][0]["expected_id"], "e2")
        self.assertEqual(result["missed_expected_ids"], {"e1"})

    def test_wrong_polarity_still_matches_but_flags(self):
        expected = self.make_expected()[:1]
        candidates = [
            {"id": "c1", "candidate_index": 1, "measured_distance_m": 15.0, "polarity": "positive", "quality_flag": "正常"}
        ]
        result = match_candidates(expected, candidates, default_tolerance_m=0.6)
        self.assertEqual(len(result["assignments"]), 1)
        self.assertFalse(result["assignments"][0]["polarity_correct"])

    def test_ambiguous_symmetric_result(self):
        expected = [
            {"id": "e1", "anomaly_index": 1, "true_distance_m": 15.0, "expected_polarity": "positive"},
            {"id": "e2", "anomaly_index": 2, "true_distance_m": 15.2, "expected_polarity": "positive"},
        ]
        candidates = [
            {"id": "c1", "candidate_index": 1, "measured_distance_m": 15.1, "polarity": "positive", "quality_flag": "正常"},
            {"id": "c2", "candidate_index": 2, "measured_distance_m": 15.1, "polarity": "positive", "quality_flag": "正常"},
        ]
        result = match_candidates(expected, candidates, default_tolerance_m=0.6)
        self.assertEqual(len(result["assignments"]), 2)
        self.assertTrue(result["ambiguous"])

    def test_multi_stats_extra_and_missing(self):
        expected = self.make_expected()
        candidates = [
            {"id": "c1", "candidate_index": 1, "measured_distance_m": 14.95, "polarity": "negative",
             "quality_flag": "正常", "matched_expected_id": "e1", "match_status": "matched", "distance_error_m": -0.05},
            {"id": "c2", "candidate_index": 2, "measured_distance_m": 25.12, "polarity": "positive",
             "quality_flag": "正常", "matched_expected_id": "e2", "match_status": "matched", "distance_error_m": 0.12},
            {"id": "c3", "candidate_index": 3, "measured_distance_m": 30.08, "polarity": "negative",
             "quality_flag": "正常", "matched_expected_id": "e3", "match_status": "matched", "distance_error_m": 0.08},
            {"id": "c5", "candidate_index": 5, "measured_distance_m": 10.0, "polarity": "positive",
             "quality_flag": "正常", "matched_expected_id": None, "match_status": "extra"},
        ]
        trials = [{"id": "t1", "trial_index": 1, "detection_status": "detected", "quality_flag": "正常"}]
        stats = summarize_trials(
            mode="multi", trials=trials, planned_trials=1,
            expected_anomalies=expected, candidates_by_trial={"t1": candidates},
            rules={"distance_tolerance_m": 0.6},
        )
        self.assertEqual(stats["resolved_trials"], 1)
        self.assertEqual(stats["matched_anomaly_count"], 3)
        self.assertEqual(stats["missed_anomaly_count"] if "missed_anomaly_count" in stats else 1, 1)
        self.assertAlmostEqual(stats["average_extra_candidates"], 1.0)
        self.assertAlmostEqual(stats["average_missed_anomalies"], 1.0)
        self.assertEqual(stats["strict_complete_count"], 0)
        self.assertEqual(stats["per_anomaly"][3]["detected_count"], 0)
        self.assertEqual(stats["located_count"], 3)
        self.assertEqual(stats["within_tolerance_count"], 3)
        self.assertAlmostEqual(stats["location_pass_rate"], 1.0)
        self.assertAlmostEqual(stats["polarity_accuracy"], 1.0)

    def test_candidate_count_not_success(self):
        expected = self.make_expected()
        candidates = [
            {"id": f"c{i}", "candidate_index": i, "measured_distance_m": 5.0 + i, "polarity": "positive",
             "quality_flag": "正常", "matched_expected_id": None, "match_status": "extra"}
            for i in range(1, 5)
        ]
        trials = [{"id": "t1", "trial_index": 1, "detection_status": "not_detected", "quality_flag": "正常"}]
        stats = summarize_trials(
            mode="multi", trials=trials, planned_trials=1,
            expected_anomalies=expected, candidates_by_trial={"t1": candidates},
        )
        self.assertEqual(stats["detected_count"], 0)
        self.assertEqual(stats["strict_complete_count"], 0)
        self.assertAlmostEqual(stats["average_extra_candidates"], 4.0)


class AggregateTests(unittest.TestCase):
    def test_aggregate_mixed_modes(self):
        single = summarize_trials(
            mode="single",
            trials=[trial(1, "detected", 15.02, "positive"), trial(2, "not_detected")],
            planned_trials=2, expected_polarity="positive", true_distance_m=15.0,
        )
        normal = summarize_trials(
            mode="normal",
            trials=[trial(1, "normal"), trial(2, "false_alarm")],
            planned_trials=2,
        )
        aggregate = aggregate_stats([single, normal])
        self.assertEqual(aggregate["total_trials"], 4)
        self.assertEqual(aggregate["anomaly_detection_rate"], 0.5)
        self.assertEqual(aggregate["false_alarm_rate"], 0.5)
        self.assertAlmostEqual(aggregate["distance"]["mae_m"], 0.02)


if __name__ == "__main__":
    unittest.main()
