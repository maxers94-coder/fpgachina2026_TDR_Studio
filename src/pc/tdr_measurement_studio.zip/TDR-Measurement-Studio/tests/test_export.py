"""Excel / CSV / JSON / AI ZIP 导出回读测试。"""
from __future__ import annotations

import csv
import io
import json
import unittest
import zipfile
from pathlib import Path

from openpyxl import load_workbook

from tests.helpers import LabFixture
from tdr_studio.services.export_service import (
    build_dataset,
    export_ai_package,
    export_csv_zip,
    export_excel,
    export_json,
)


class ExportTests(unittest.TestCase):
    def setUp(self):
        self.lab = LabFixture()
        self.config_row = self.lab.single_config(distance=15.0, repeats=5)
        self.run = self.lab.runs.ensure_for_config(self.config_row["id"])
        for index, distance in enumerate([15.12, 14.95, 15.08, 15.03], start=1):
            self.lab.trials.create(
                self.run["id"], measured_distance_m=distance, polarity="positive",
                detection_status="detected", quality_flag="正常", trial_index=index,
            )
        self.lab.trials.create(
            self.run["id"], measured_distance_m=None, polarity="unknown",
            detection_status="not_detected", quality_flag="正常", trial_index=5,
        )
        self.multi_config = self.lab.multi_config()
        multi_run = self.lab.runs.ensure_for_config(self.multi_config["id"])
        self.lab.trials.save_multi_trial(
            multi_run["id"], trial_index=1,
            candidates=[
                {"measured_distance_m": 14.95, "polarity": "negative", "quality_flag": "正常"},
                {"measured_distance_m": 25.12, "polarity": "positive", "quality_flag": "正常"},
                {"measured_distance_m": 30.08, "polarity": "negative", "quality_flag": "正常"},
                {"measured_distance_m": 33.14, "polarity": "positive", "quality_flag": "正常"},
            ],
        )
        # 一组未测试配置，验证不会被当作结果
        self.untested = self.lab.single_config(distance=5.0, repeats=3)
        self.out = Path(self.lab.tempdir.name) / "out"
        self.out.mkdir()

    def tearDown(self):
        self.lab.close()

    def test_dataset_statistics(self):
        dataset = build_dataset(self.lab.db)
        self.assertEqual(dataset["metadata"]["configuration_count"], 3)
        self.assertEqual(dataset["metadata"]["tested_configuration_count"], 2)
        self.assertEqual(dataset["metadata"]["trial_count"], 6)
        self.assertEqual(len(dataset["trials"]), 6)
        self.assertEqual(len(dataset["detected_candidates"]), 4)
        c02 = next(s for s in dataset["statistics"]["per_configuration"] if s["config_code"] == self.config_row["code"])
        self.assertEqual(c02["total_trials"], 5)
        self.assertEqual(c02["detected_count"], 4)
        self.assertEqual(c02["not_detected_count"], 1)
        self.assertAlmostEqual(c02["detection_rate"], 0.8)
        self.assertAlmostEqual(c02["distance"]["mean_distance_m"], 15.045)
        untested = next(s for s in dataset["statistics"]["per_configuration"] if s["config_id"] == self.untested["id"])
        self.assertEqual(untested["data_status"], "not_tested")
        self.assertEqual(dataset["statistics"]["overall"]["total_trials"], 6)
        self.assertEqual(dataset["metadata"]["tested_configuration_count"], 2)

    def test_excel_roundtrip_preserves_trials(self):
        path = export_excel(self.lab.db, self.out / "export.xlsx")
        workbook = load_workbook(path, data_only=True)
        required = {
            "项目信息", "测试板", "线缆", "健康参考", "实验配置", "实验运行",
            "全部逐次记录", "多异常候选", "真实异常", "各组统计", "总体汇总",
            "自动判定", "批次汇总", "统计规则", "数据字典",
        }
        self.assertTrue(required.issubset(set(workbook.sheetnames)))
        sheet = workbook["全部逐次记录"]
        headers = [cell.value for cell in sheet[1]]
        self.assertIn("试次ID", headers)
        self.assertEqual(sheet.max_row - 1, 6)
        status_col = headers.index("检测状态") + 1
        statuses = [sheet.cell(row=row, column=status_col).value for row in range(2, sheet.max_row + 1)]
        self.assertIn("not_detected", statuses)
        ids = [sheet.cell(row=row, column=1).value for row in range(2, sheet.max_row + 1)]
        self.assertTrue(all(ids))
        # 未测试配置出现在配置表但统计行为 0
        stat_sheet = workbook["各组统计"]
        stat_headers = [cell.value for cell in stat_sheet[1]]
        total_col = stat_headers.index("总试次") + 1
        code_col = stat_headers.index("实验编号") + 1
        rows = {
            stat_sheet.cell(row=row, column=code_col).value: stat_sheet.cell(row=row, column=total_col).value
            for row in range(2, stat_sheet.max_row + 1)
        }
        self.assertEqual(rows[self.untested["code"]], 0)

    def test_json_is_strict_and_recomputable(self):
        path = export_json(self.lab.db, self.out / "export.json")
        text = path.read_text(encoding="utf-8")
        self.assertNotIn("NaN", text)
        self.assertNotIn("Infinity", text)
        data = json.loads(text)
        self.assertEqual(len(data["trials"]), 6)
        c02_trials = [t for t in data["trials"] if t["config_code"] == self.config_row["code"]]
        self.assertEqual(len(c02_trials), 5)
        self.assertEqual(sum(1 for t in c02_trials if t["detection_status"] == "detected"), 4)
        self.assertEqual(sum(1 for t in c02_trials if t["detection_status"] == "not_detected"), 1)
        detected_distances = [t["measured_distance_m"] for t in c02_trials if t["detection_status"] == "detected"]
        self.assertAlmostEqual(sum(detected_distances) / 4, 15.045)
        self.assertTrue(any(t["measured_distance_m"] is None for t in c02_trials))

    def test_csv_zip(self):
        path = export_csv_zip(self.lab.db, self.out / "csv.zip")
        with zipfile.ZipFile(path) as archive:
            names = set(archive.namelist())
            self.assertIn("TDR_Experiment_Export/trials.csv", names)
            self.assertIn("TDR_Experiment_Export/configurations.csv", names)
            self.assertIn("TDR_Experiment_Export/statistics.csv", names)
            trials_text = archive.read("TDR_Experiment_Export/trials.csv").decode("utf-8")
            rows = list(csv.DictReader(io.StringIO(trials_text)))
            self.assertEqual(len(rows), 6)
            self.assertTrue(any(row["detection_status"] == "not_detected" for row in rows))
            self.assertTrue(all(row["trial_id"] for row in rows))

    def test_ai_package_manifest_and_files(self):
        path = export_ai_package(
            self.lab.db, self.out / "ai.zip", include_attachments=False, include_figures=True
        )
        with zipfile.ZipFile(path) as archive:
            names = set(archive.namelist())
            prefix = "TDR_Experiment_Export/"
            self.assertIn(prefix + "manifest.json", names)
            self.assertIn(prefix + "measurements/full_dataset.json", names)
            self.assertIn(prefix + "measurements/trials.csv", names)
            self.assertIn(prefix + "statistics/results.xlsx", names)
            self.assertIn(prefix + "README.txt", names)
            manifest = json.loads(archive.read(prefix + "manifest.json"))
            self.assertEqual(manifest["trial_count"], 6)
            self.assertEqual(manifest["tested_configuration_count"], 2)
            self.assertTrue(manifest["files"])
            for entry in manifest["files"]:
                self.assertEqual(len(entry["sha256"]), 64)
                self.assertIn(prefix + entry["path"], names)


if __name__ == "__main__":
    unittest.main()
