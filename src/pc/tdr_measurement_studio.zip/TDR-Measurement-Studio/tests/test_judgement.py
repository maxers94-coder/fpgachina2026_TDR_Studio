"""自动判定状态测试。"""
from __future__ import annotations

import unittest

from tdr_studio.services.judgement import evaluate_judgement
from tdr_studio.services.statistics import summarize_trials


def make_trial(i, status="detected", distance=15.0, polarity="positive", quality="正常"):
    return {
        "id": f"t{i}", "trial_index": i, "detection_status": status,
        "measured_distance_m": distance, "true_distance_m": 15.0,
        "polarity": polarity, "quality_flag": quality,
    }


class JudgementTests(unittest.TestCase):
    rules = {
        "distance_tolerance_m": 0.6,
        "min_detection_rate": 0.95,
        "max_false_alarm_rate": 0.05,
        "require_polarity": True,
        "edge_as_valid": False,
        "min_trials_for_judgement": 1,
        "max_invalid_rate": 0.2,
        "hardware_error_fails": True,
        "min_location_rate": 0.9,
    }

    def test_not_tested_is_not_pass(self):
        stats = summarize_trials(mode="single", trials=[], planned_trials=5,
                                 expected_polarity="positive", true_distance_m=15.0)
        judgement = evaluate_judgement(stats, self.rules, planned_trials=5)
        self.assertEqual(judgement["decision"], "not_tested")
        self.assertNotEqual(judgement["decision"], "pass")

    def test_insufficient_is_not_pass(self):
        trials = [make_trial(i) for i in range(1, 4)]
        stats = summarize_trials(mode="single", trials=trials, planned_trials=5,
                                 expected_polarity="positive", true_distance_m=15.0)
        judgement = evaluate_judgement(stats, self.rules, planned_trials=5)
        self.assertEqual(judgement["decision"], "insufficient")
        self.assertIn("数据不足", judgement["label"])

    def test_detection_fail(self):
        trials = [make_trial(i) for i in range(1, 5)] + [make_trial(5, "not_detected")]
        stats = summarize_trials(mode="single", trials=trials, planned_trials=5,
                                 expected_polarity="positive", true_distance_m=15.0)
        judgement = evaluate_judgement(stats, self.rules, planned_trials=5)
        self.assertEqual(judgement["decision"], "fail")

    def test_pass_all_rules(self):
        trials = [make_trial(i, distance=15.0 + (i % 2) * 0.05) for i in range(1, 6)]
        stats = summarize_trials(mode="single", trials=trials, planned_trials=5,
                                 expected_polarity="positive", true_distance_m=15.0)
        judgement = evaluate_judgement(stats, self.rules, planned_trials=5)
        self.assertEqual(judgement["decision"], "pass")
        self.assertTrue(all(rule["passed"] in (True, None) for rule in judgement["rules"]))

    def test_invalid_rate_fail(self):
        trials = [make_trial(i) for i in range(1, 5)] + [make_trial(5, "invalid"), make_trial(6, "invalid")]
        stats = summarize_trials(mode="single", trials=trials, planned_trials=6,
                                 expected_polarity="positive", true_distance_m=15.0)
        judgement = evaluate_judgement(stats, self.rules, planned_trials=6)
        self.assertEqual(judgement["decision"], "fail")
        self.assertTrue(any("无效率" in reason for reason in judgement["reasons"]))

    def test_hardware_error_fail(self):
        trials = [make_trial(i, quality="PN?") for i in range(1, 6)]
        stats = summarize_trials(mode="single", trials=trials, planned_trials=5,
                                 expected_polarity="positive", true_distance_m=15.0)
        judgement = evaluate_judgement(stats, self.rules, planned_trials=5)
        self.assertEqual(judgement["decision"], "fail")

    def test_normal_false_alarm_fail(self):
        trials = [
            {"id": f"n{i}", "trial_index": i, "detection_status": "normal", "quality_flag": "正常"}
            for i in range(1, 5)
        ] + [{"id": "n5", "trial_index": 5, "detection_status": "false_alarm", "quality_flag": "正常"}]
        stats = summarize_trials(mode="normal", trials=trials, planned_trials=5)
        judgement = evaluate_judgement(stats, self.rules, planned_trials=5)
        self.assertEqual(stats["false_alarm_rate"], 0.2)
        self.assertEqual(judgement["decision"], "fail")


if __name__ == "__main__":
    unittest.main()
