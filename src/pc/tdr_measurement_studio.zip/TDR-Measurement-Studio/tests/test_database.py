"""数据库事务、持久化、审计、备份恢复和附件测试。"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tests.helpers import LabFixture
from tdr_studio.database import Database


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.lab = LabFixture()

    def tearDown(self):
        self.lab.close()

    def test_persistence_after_reopen(self):
        config_row = self.lab.single_config(distance=15.0, repeats=3)
        run = self.lab.runs.ensure_for_config(config_row["id"])
        self.lab.trials.create(
            run["id"], measured_distance_m=15.04, polarity="positive",
            detection_status="detected", quality_flag="正常",
        )
        # New Database instance -> same file
        other = Database(self.lab.db.path)
        other.initialize()
        self.assertEqual(other.scalar("SELECT COUNT(*) FROM trials"), 1)
        self.assertEqual(
            other.scalar("SELECT COUNT(*) FROM experiment_configs WHERE code=?", (config_row["code"],)),
            1,
        )
        self.assertIsNotNone(other.query_one("SELECT * FROM experiment_configs WHERE id=?", (config_row["id"],)))

    def test_trial_update_audit_retains_before_and_after(self):
        config_row = self.lab.single_config(repeats=1)
        run = self.lab.runs.ensure_for_config(config_row["id"])
        trial = self.lab.trials.create(
            run["id"], measured_distance_m=15.1, polarity="positive",
            detection_status="detected", quality_flag="正常",
        )
        self.lab.trials.update(
            trial["id"],
            {"measured_distance_m": 15.0, "detection_status": "detected",
             "polarity": "positive", "quality_flag": "正常", "notes": "复核修正"},
        )
        audit = self.lab.db.query_one(
            "SELECT * FROM audit_log WHERE entity_type='trial' AND action='update' ORDER BY id DESC LIMIT 1"
        )
        self.assertIsNotNone(audit)
        self.assertIn("15.1", audit["before_json"])
        self.assertIn("复核修正", audit["after_json"])
        self.assertIn("15.0", audit["after_json"])

    def test_backup_and_restore(self):
        self.lab.single_config()
        backup = self.lab.db.backup(Path(self.lab.tempdir.name) / "manual_backup.db", note="test")
        self.assertTrue(backup.exists())
        before_count = self.lab.db.scalar("SELECT COUNT(*) FROM experiment_configs")
        self.lab.boards_repo.create(
            {"code": "TEST-RESTORE", "name": "恢复测试板", "board_type": "normal"}
        )
        self.assertGreater(
            self.lab.db.scalar("SELECT COUNT(*) FROM boards"),
            self.lab.db.scalar("SELECT COUNT(*) FROM boards WHERE code='TEST-RESTORE'") - 1,
        )
        safety = self.lab.db.replace_from(backup)
        self.assertTrue(safety.exists())
        self.lab.db.initialize()
        self.assertEqual(self.lab.db.scalar("SELECT COUNT(*) FROM experiment_configs"), before_count)
        self.assertIsNone(
            self.lab.db.query_one("SELECT * FROM boards WHERE code='TEST-RESTORE'")
        )
        ok, message = self.lab.db.integrity_check()
        self.assertTrue(ok, message)
        self.assertEqual(self.lab.db.foreign_key_check(), [])

    def test_delete_protection_for_category_and_config(self):
        config_row = self.lab.single_config()
        run = self.lab.runs.ensure_for_config(config_row["id"])
        self.lab.trials.create(
            run["id"], measured_distance_m=15.0, polarity="positive",
            detection_status="detected", quality_flag="正常",
        )
        with self.assertRaises(ValueError):
            self.lab.experiments.delete(config_row["id"])
        # Category with config cannot be deleted
        with self.assertRaises(ValueError):
            self.lab.categories.delete(config_row["category_id"])

    def test_attachment_hash_and_delete(self):
        from tdr_studio.services.attachments import AttachmentService

        config_row = self.lab.single_config()
        run = self.lab.runs.ensure_for_config(config_row["id"])
        source = Path(self.lab.tempdir.name) / "uart.log"
        source.write_text("PN_RESULT distance=15.02\n", encoding="utf-8")
        service = AttachmentService(self.lab.db)
        attachment = service.add(run["id"], str(source), category="UART 日志")
        ok, message = service.verify(attachment)
        self.assertTrue(ok, message)
        self.assertTrue(service.path(attachment).exists())
        service.delete(attachment["id"])
        self.assertIsNone(service.get(attachment["id"]))


if __name__ == "__main__":
    unittest.main()
