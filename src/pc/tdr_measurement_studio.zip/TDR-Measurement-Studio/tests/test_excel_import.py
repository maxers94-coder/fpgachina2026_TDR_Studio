"""Excel 79 组矩阵导入测试。"""
from __future__ import annotations

import json
import unittest
from pathlib import Path

from openpyxl import Workbook

from tests.helpers import LabFixture
from tdr_studio import config
from tdr_studio.services.excel_import import import_workbook


class ExcelImportTests(unittest.TestCase):
    def setUp(self):
        self.lab = LabFixture()

    def tearDown(self):
        self.lab.close()

    def test_import_fw63_79_groups(self):
        report = import_workbook(self.lab.db, config.DEFAULT_WORKBOOK)
        self.assertFalse(report["already_imported"])
        self.assertEqual(report["imported_count"], 79)
        self.assertEqual(report["skipped_count"], 0)
        self.assertEqual(report["error_count"], 0)
        self.assertEqual(report["planned_trials"], 149)
        self.assertEqual(self.lab.db.scalar("SELECT COUNT(*) FROM experiment_configs"), 79)
        self.assertEqual(self.lab.db.scalar("SELECT COUNT(*) FROM trials"), 0)
        self.assertEqual(self.lab.db.scalar("SELECT COUNT(*) FROM experiment_categories"), 6)
        self.assertGreaterEqual(self.lab.db.scalar("SELECT COUNT(*) FROM boards"), 11)
        e06 = self.lab.db.query_one("SELECT * FROM experiment_configs WHERE code='E06'")
        self.assertIsNotNone(e06)
        self.assertEqual(e06["mode"], "multi")
        expected = json.loads(e06["expected_anomalies_json"])
        self.assertEqual(len(expected), 4)
        self.assertEqual([e["true_distance_m"] for e in expected], [15.0, 25.0, 30.0, 33.0])
        a01 = self.lab.db.query_one("SELECT * FROM experiment_configs WHERE code='A01'")
        self.assertEqual(a01["mode"], "normal")
        b01 = self.lab.db.query_one("SELECT * FROM experiment_configs WHERE code='B01'")
        self.assertEqual(b01["expected_polarity"], "positive")
        self.assertEqual(b01["reference_label"], "REF-END-3m")
        self.assertTrue(Path(report["report_path"]).exists())
        self.assertEqual(self.lab.db.scalar("SELECT COUNT(*) FROM import_runs"), 1)

    def test_duplicate_import_is_blocked_and_can_be_forced(self):
        first = import_workbook(self.lab.db, config.DEFAULT_WORKBOOK)
        second = import_workbook(self.lab.db, config.DEFAULT_WORKBOOK)
        self.assertTrue(second["already_imported"])
        self.assertEqual(self.lab.db.scalar("SELECT COUNT(*) FROM experiment_configs"), 79)
        third = import_workbook(self.lab.db, config.DEFAULT_WORKBOOK, allow_repeat=True)
        self.assertEqual(third["imported_count"], 79)
        self.assertEqual(self.lab.db.scalar("SELECT COUNT(*) FROM experiment_configs"), 158)
        self.assertGreater(third["warning_count"], 0)
        self.assertGreaterEqual(len(third["warnings"]), 79)

    def test_duplicate_codes_are_preserved_not_dropped(self):
        workbook = Workbook()
        ws = workbook.active
        ws.title = "矩阵"
        ws.append(["测试说明"])
        ws.append([])
        ws.append(["编号", "优先", "组", "真值点位(m)", "当前长度(m)", "剩余长度(m)",
                   "试件/端点", "Γ理论(%)", "预期响应", "末端负载", "计划测量次数",
                   "参考/基线ID", "操作说明"])
        ws.append(["DUP01", "P0", "C", 5, 5, "", "S2（2Ω串联）", 1.96, "异常", "50Ω", 2, "REF-X", "测试"])
        ws.append(["DUP01", "P1", "C", 15, 15, "", "P1000（1kΩ并联）", -2.44, "异常", "50Ω", 3, "REF-Y", "重复编号"])
        path = Path(self.lab.tempdir.name) / "duplicate.xlsx"
        workbook.save(path)
        report = import_workbook(self.lab.db, path)
        self.assertEqual(report["imported_count"], 2)
        self.assertEqual(report["skipped_count"], 0)
        codes = [row["code"] for row in self.lab.db.query("SELECT code FROM experiment_configs ORDER BY code")]
        self.assertEqual(len(codes), len(set(codes)))
        self.assertTrue(any(code.startswith("DUP01-I") for code in codes))
        self.assertEqual(self.lab.db.scalar("SELECT COUNT(*) FROM trials"), 0)


if __name__ == "__main__":
    unittest.main()
