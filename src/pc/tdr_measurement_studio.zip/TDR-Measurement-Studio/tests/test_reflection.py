"""理论反射系数与距离统计基础测试。"""
from __future__ import annotations

import unittest

from tdr_studio.services.reflection import (
    ReflectionError,
    calculate_gamma,
    polarity_from_gamma,
    reflection_strength,
)
from tdr_studio.services.statistics import distance_metrics, percentile_linear


class ReflectionTests(unittest.TestCase):
    def test_two_ohm_series(self):
        result = calculate_gamma("series", nominal_ohm=2.0, z0=50.0)
        self.assertAlmostEqual(result["gamma_nominal"], 2.0 / 102.0, places=12)
        self.assertAlmostEqual(result["gamma_nominal"] * 100, 1.9607843137, places=8)
        self.assertEqual(result["polarity"], "positive")
        self.assertTrue(result["is_theoretical"])
        self.assertIsNone(result["gamma_measured"])

    def test_one_kohm_shunt(self):
        result = calculate_gamma("shunt", nominal_ohm=1000.0, z0=50.0)
        self.assertAlmostEqual(result["gamma_nominal"], -50.0 / 2050.0, places=12)
        self.assertAlmostEqual(result["gamma_nominal"] * 100, -2.43902439, places=7)
        self.assertEqual(result["polarity"], "negative")

    def test_documented_values(self):
        cases = [
            ("series", 27.0, 0.2125984252),
            ("series", 4.7, 0.0448901624),
            ("series", 1.0, 0.0099009901),
            ("shunt", 470.0, -0.0505050505),
            ("shunt", 2000.0, -0.0123456790),
        ]
        for kind, ohm, expected in cases:
            result = calculate_gamma(kind, nominal_ohm=ohm)
            self.assertAlmostEqual(result["gamma_nominal"], expected, places=9)

    def test_normal_open_short(self):
        self.assertEqual(calculate_gamma("normal")["gamma_nominal"], 0.0)
        self.assertEqual(calculate_gamma("open")["polarity"], "positive")
        self.assertAlmostEqual(calculate_gamma("open")["gamma_nominal"], 1.0)
        self.assertEqual(calculate_gamma("short")["polarity"], "negative")
        self.assertAlmostEqual(calculate_gamma("short")["gamma_nominal"], -1.0)

    def test_measured_ohm_uses_same_formula(self):
        result = calculate_gamma("series", nominal_ohm=2.0, measured_ohm=2.2)
        self.assertAlmostEqual(result["gamma_measured"], 2.2 / 102.2, places=12)
        self.assertNotAlmostEqual(result["gamma_measured"], result["gamma_nominal"])

    def test_custom_and_invalid(self):
        result = calculate_gamma("custom", gamma_override=-0.123)
        self.assertAlmostEqual(result["gamma_nominal"], -0.123)
        with self.assertRaises(ReflectionError):
            calculate_gamma("custom")
        with self.assertRaises(ReflectionError):
            calculate_gamma("series", nominal_ohm=0)
        with self.assertRaises(ReflectionError):
            calculate_gamma("series", nominal_ohm=2, z0=0)

    def test_sign_and_strength(self):
        self.assertEqual(polarity_from_gamma(0.1), "positive")
        self.assertEqual(polarity_from_gamma(-0.1), "negative")
        self.assertEqual(polarity_from_gamma(0.0), "none")
        self.assertEqual(reflection_strength(0.0196)[0], "weak")
        self.assertEqual(reflection_strength(-0.05)[0], "medium")
        self.assertEqual(reflection_strength(0.2)[0], "strong")


class DistanceMetricTests(unittest.TestCase):
    def test_empty(self):
        metrics = distance_metrics([])
        self.assertEqual(metrics["n"], 0)
        self.assertIsNone(metrics["mae_m"])
        self.assertIsNone(metrics["mean_distance_m"])

    def test_single_has_no_sample_std(self):
        metrics = distance_metrics([0.1], [15.1])
        self.assertEqual(metrics["n"], 1)
        self.assertIsNone(metrics["std_error_m"])
        self.assertAlmostEqual(metrics["mae_m"], 0.1)
        self.assertAlmostEqual(metrics["rmse_m"], 0.1)

    def test_two_sample_std(self):
        metrics = distance_metrics([1.0, 3.0])
        self.assertAlmostEqual(metrics["mean_signed_error_m"], 2.0)
        self.assertAlmostEqual(metrics["std_error_m"], 2 ** 0.5)
        self.assertAlmostEqual(metrics["mae_m"], 2.0)

    def test_percentile(self):
        self.assertEqual(percentile_linear([1, 2, 3, 4], 0.5), 2.5)
        self.assertAlmostEqual(percentile_linear([1, 2, 3, 4], 0.95), 3.85)


if __name__ == "__main__":
    unittest.main()
