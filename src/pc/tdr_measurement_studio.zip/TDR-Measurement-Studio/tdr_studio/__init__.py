"""TDR Measurement Studio 内部包。"""
from . import config  # noqa: F401  (导入时注入 vendor 路径)

__version__ = config.APP_VERSION
