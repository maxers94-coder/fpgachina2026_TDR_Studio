"""通用小工具：时间、ID、数值格式化与安全 JSON。"""
from __future__ import annotations

import json
import math
import re
import uuid
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any


def now_iso() -> str:
    """本地时区 ISO-8601 时间（带偏移），便于实验追溯。"""
    return datetime.now().astimezone().isoformat(timespec="seconds")


def new_id(prefix: str = "") -> str:
    raw = uuid.uuid4().hex
    return f"{prefix}-{raw}" if prefix else raw


def safe_float(value: Any) -> float | None:
    """把界面/Excel 值转换为 float；空值返回 None。"""
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
            return None
        return float(value)
    text = str(value).strip()
    if not text or text.lower() in {"none", "null", "nan", "无", "不适用", "—", "-"}:
        return None
    # 允许全角负号、末尾单位 Ω/m
    text = text.replace("−", "-").replace("–", "-").replace("，", ".")
    match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        number = float(match.group(0))
        if math.isnan(number) or math.isinf(number):
            return None
        return number
    except ValueError:
        return None


def safe_int(value: Any, default: int | None = None) -> int | None:
    number = safe_float(value)
    if number is None:
        return default
    return int(round(number))


def to_decimal(value: Any) -> Decimal | None:
    try:
        if value is None or str(value).strip() == "":
            return None
        return Decimal(str(value).strip())
    except (InvalidOperation, ValueError):
        return None


def format_number(value: Any, digits: int = 3, empty: str = "—", signed: bool = False) -> str:
    if value is None or value == "":
        return empty
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if math.isnan(number) or math.isinf(number):
        return empty
    if signed:
        return f"{number:+.{digits}f}"
    return f"{number:.{digits}f}"


def format_percent(value: Any, digits: int = 2, empty: str = "—") -> str:
    if value is None:
        return empty
    try:
        return f"{float(value) * 100:.{digits}f}%"
    except (TypeError, ValueError):
        return empty


def format_gamma(value: Any, digits: int = 2) -> str:
    if value is None:
        return "—"
    return f"{float(value) * 100:+.{digits}f}%"


def json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str, allow_nan=False)


def json_loads(value: Any, default: Any = None) -> Any:
    if value is None or value == "":
        return default
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def sanitize_json(value: Any) -> Any:
    """递归移除 NaN/Infinity，转换为 null，满足严格 JSON 要求。"""
    if isinstance(value, dict):
        return {str(k): sanitize_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [sanitize_json(v) for v in value]
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime,)):
        return value.isoformat()
    return value


def clean_filename(name: str, fallback: str = "file") -> str:
    name = (name or "").strip().replace("\\", "_").replace("/", "_")
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name)
    name = re.sub(r"\s+", " ", name).strip(" .")
    return name[:180] or fallback


def human_size(size: int | None) -> str:
    if not size:
        return "0 B"
    units = ["B", "KB", "MB", "GB"]
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"


def parse_distance_list(text: str) -> list[float]:
    """解析 '5、15、25 m' 或 '5,15,25'。保留输入顺序并去重。"""
    if not text:
        return []
    cleaned = text.replace("，", ",").replace("、", ",").replace("；", ",").replace(";", ",")
    numbers: list[float] = []
    for token in re.split(r"[,\s]+", cleaned):
        if not token:
            continue
        number = safe_float(token)
        if number is not None and number > 0:
            if number not in numbers:
                numbers.append(number)
    return numbers


def split_multi_value(value: Any) -> list[str]:
    if value is None:
        return []
    text = str(value).replace("，", ",").replace("、", ",").replace("；", ",").replace(";", ",")
    return [part.strip() for part in text.split(",") if part.strip()]
