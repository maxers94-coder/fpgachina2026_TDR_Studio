"""SQLite 数据访问基础设施。

所有写操作都在显式事务中完成；连接按操作创建，避免 UI 线程/长连接问题。
"""
from __future__ import annotations

import json
import shutil
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from . import config
from .utils import json_dumps, json_loads, new_id, now_iso


class DatabaseError(RuntimeError):
    pass


class Database:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path or config.DB_PATH).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ 连接
    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=20, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 20000")
        try:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
        except sqlite3.DatabaseError:
            pass
        return conn

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        """只读连接上下文，退出时确保关闭，避免 Windows 文件锁。"""
        conn = self.connect()
        try:
            yield conn
        finally:
            conn.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.execute("COMMIT")
        except Exception:
            try:
                conn.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
        finally:
            conn.close()

    def query(self, sql: str, params: tuple | dict = ()) -> list[dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    def query_one(self, sql: str, params: tuple | dict = ()) -> dict[str, Any] | None:
        with self.connection() as conn:
            row = conn.execute(sql, params).fetchone()
        return dict(row) if row else None

    def execute(self, sql: str, params: tuple | dict = ()) -> int:
        with self.transaction() as conn:
            cur = conn.execute(sql, params)
            return int(cur.lastrowid or 0)

    def scalar(self, sql: str, params: tuple | dict = (), default: Any = None) -> Any:
        with self.connection() as conn:
            row = conn.execute(sql, params).fetchone()
        if row is None:
            return default
        return row[0]

    # ------------------------------------------------------------------ 初始化
    def initialize(self) -> None:
        config.ensure_runtime_dirs()
        schema_path = Path(__file__).with_name("schema.sql")
        schema_sql = schema_path.read_text(encoding="utf-8")
        with self.connection() as conn:
            conn.executescript(schema_sql)
            conn.execute(
                "INSERT OR REPLACE INTO schema_meta(key,value) VALUES('schema_version',?)",
                (config.DATA_SCHEMA_VERSION,),
            )
            conn.execute(
                "INSERT OR REPLACE INTO schema_meta(key,value) VALUES('app_version',?)",
                (config.APP_VERSION,),
            )
        self._seed()
        self._verify_integrity()

    def _seed(self) -> None:
        timestamp = now_iso()
        with self.transaction() as conn:
            for code, name, desc, order in config.BUILTIN_CATEGORIES:
                conn.execute(
                    """INSERT OR IGNORE INTO experiment_categories
                    (id,code,name,description,is_builtin,sort_order,created_at,updated_at)
                    VALUES(?,?,?,?,1,?,?,?)""",
                    (f"CAT-{code}", code, name, desc, order, timestamp, timestamp),
                )
            # 默认批次：便于首次打开即可建实验；用户可改名或新增批次。
            conn.execute(
                """INSERT OR IGNORE INTO batches
                (id,code,name,firmware_version,frontend,description,is_active,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    "BATCH-FW63-V1",
                    "FW63-V1.0",
                    "FW63 V1.0 初步验收",
                    "FW63 V1.0",
                    "resistive_divider",
                    "系统内置默认批次，可编辑；所有批次内数据独立统计。",
                    1,
                    timestamp,
                    timestamp,
                ),
            )
            # 1/3/5/10/15 m 五段同轴线（34 m 主干所需）
            cables = [
                ("C1", "1 m 同轴线", 1.0),
                ("C3", "3 m 同轴线", 3.0),
                ("C5", "5 m 同轴线", 5.0),
                ("C10", "10 m 同轴线", 10.0),
                ("C15", "15 m 同轴线", 15.0),
            ]
            for code, name, length in cables:
                conn.execute(
                    """INSERT OR IGNORE INTO cables
                    (id,code,name,physical_length_m,model,z0,velocity_factor,notes,status,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,'available',?,?)""",
                    (
                        f"CABLE-{code}",
                        code,
                        name,
                        length,
                        "50Ω 同轴",
                        50.0,
                        0.66,
                        "系统预置线缆，可按实测结果修改。",
                        timestamp,
                        timestamp,
                    ),
                )
            for key, value in config.DEFAULT_SETTINGS.items():
                conn.execute(
                    "INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES(?,?,?)",
                    (key, json_dumps(value), timestamp),
                )

    def _verify_integrity(self) -> None:
        result = self.scalar("PRAGMA quick_check", default="unknown")
        if str(result).lower() != "ok":
            raise DatabaseError(f"数据库完整性检查失败：{result}")

    # ------------------------------------------------------------------ 设置
    def get_setting(self, key: str, default: Any = None) -> Any:
        row = self.query_one("SELECT value FROM settings WHERE key=?", (key,))
        if not row:
            return config.DEFAULT_SETTINGS.get(key, default)
        try:
            return json.loads(row["value"])
        except (TypeError, ValueError):
            return row["value"]

    def get_all_settings(self) -> dict[str, Any]:
        result = dict(config.DEFAULT_SETTINGS)
        for row in self.query("SELECT key,value FROM settings"):
            try:
                result[row["key"]] = json.loads(row["value"])
            except (TypeError, ValueError):
                result[row["key"]] = row["value"]
        return result

    def set_setting(self, key: str, value: Any, conn: sqlite3.Connection | None = None) -> None:
        timestamp = now_iso()
        encoded = json_dumps(value)
        if conn is not None:
            conn.execute(
                """INSERT INTO settings(key,value,updated_at) VALUES(?,?,?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                (key, encoded, timestamp),
            )
        else:
            self.execute(
                """INSERT INTO settings(key,value,updated_at) VALUES(?,?,?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                (key, encoded, timestamp),
            )

    def set_settings(self, values: dict[str, Any], actor: str = "") -> None:
        with self.transaction() as conn:
            before = {}
            for key in values:
                row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
                before[key] = json_loads(row["value"], None) if row else None
            timestamp = now_iso()
            for key, value in values.items():
                conn.execute(
                    """INSERT INTO settings(key,value,updated_at) VALUES(?,?,?)
                    ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                    (key, json_dumps(value), timestamp),
                )
            self.audit(
                conn,
                action="update",
                entity_type="settings",
                entity_id="global",
                before=before,
                after=values,
                actor=actor,
                note="保存系统设置",
            )

    # ------------------------------------------------------------------ 审计
    def audit(
        self,
        conn: sqlite3.Connection,
        *,
        action: str,
        entity_type: str,
        entity_id: str,
        before: Any = None,
        after: Any = None,
        actor: str = "",
        note: str = "",
    ) -> None:
        if not actor:
            try:
                actor = str(self.get_setting("operator", ""))
            except Exception:
                actor = ""
        conn.execute(
            """INSERT INTO audit_log(timestamp,actor,action,entity_type,entity_id,before_json,after_json,note)
            VALUES(?,?,?,?,?,?,?,?)""",
            (
                now_iso(),
                actor,
                action,
                entity_type,
                str(entity_id),
                json_dumps(before) if before is not None else None,
                json_dumps(after) if after is not None else None,
                note,
            ),
        )

    def log_action(
        self,
        action: str,
        entity_type: str,
        entity_id: str,
        *,
        before: Any = None,
        after: Any = None,
        actor: str = "",
        note: str = "",
    ) -> None:
        with self.transaction() as conn:
            self.audit(
                conn,
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                before=before,
                after=after,
                actor=actor,
                note=note,
            )

    def audit_rows(self, limit: int = 500) -> list[dict[str, Any]]:
        return self.query("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))

    # ------------------------------------------------------------------ 备份
    def backup(self, destination: str | Path, note: str = "") -> Path:
        destination = Path(destination).resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        src = self.connect()
        dst = sqlite3.connect(destination)
        try:
            src.backup(dst)
            dst.commit()
        finally:
            dst.close()
            src.close()
        self.log_action(
            "backup",
            "database",
            self.path.name,
            after={"backup_file": destination.name, "size_bytes": destination.stat().st_size},
            note=note or "手动数据库备份",
        )
        return destination

    def backup_default(self, note: str = "") -> Path:
        stamp = now_iso().replace("-", "").replace(":", "").replace("+", "_")[:15]
        target = config.BACKUPS_DIR / f"tdr_studio_backup_{stamp}.db"
        index = 2
        while target.exists():
            target = config.BACKUPS_DIR / f"tdr_studio_backup_{stamp}_{index}.db"
            index += 1
        return self.backup(target, note=note)

    def latest_backup(self) -> Path | None:
        backups = sorted(
            config.BACKUPS_DIR.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True
        )
        return backups[0] if backups else None

    def maybe_auto_backup(self) -> Path | None:
        """有实测数据且超过 24 小时未备份时，启动时自动保存一份。"""
        if not bool(self.get_setting("auto_backup_daily", True)):
            return None
        trials = int(self.scalar("SELECT COUNT(*) FROM trials", default=0) or 0)
        if trials == 0:
            return None
        latest = self.latest_backup()
        if latest is not None:
            age_seconds = __import__("time").time() - latest.stat().st_mtime
            if age_seconds < 24 * 3600:
                return None
        return self.backup_default(note="启动时自动备份（超过24小时）")

    def integrity_check(self) -> tuple[bool, str]:
        result = self.scalar("PRAGMA integrity_check", default="unknown")
        return str(result).lower() == "ok", str(result)

    def foreign_key_check(self) -> list[dict[str, Any]]:
        return self.query("PRAGMA foreign_key_check")

    def counts(self) -> dict[str, int]:
        tables = [
            "boards",
            "cables",
            "cable_configs",
            "health_references",
            "experiment_configs",
            "experiment_runs",
            "trials",
            "detected_candidates",
            "expected_anomalies",
            "attachments",
            "audit_log",
        ]
        result: dict[str, int] = {}
        with self.connection() as conn:
            for table in tables:
                result[table] = int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
        return result

    def replace_from(self, backup_file: str | Path) -> Path:
        """恢复数据库前自动保存安全副本，再原子替换。"""
        backup_file = Path(backup_file).resolve()
        if not backup_file.exists():
            raise DatabaseError("备份文件不存在")
        # 验证候选备份是有效 SQLite 数据库
        test = sqlite3.connect(backup_file)
        try:
            check = test.execute("PRAGMA quick_check").fetchone()
            if not check or str(check[0]).lower() != "ok":
                raise DatabaseError(f"备份数据库校验失败：{check}")
            has_schema = test.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='experiment_configs'"
            ).fetchone()[0]
            if not has_schema:
                raise DatabaseError("所选文件不是本程序的数据库备份")
        finally:
            test.close()
        safety = self.backup_default(note="恢复前自动安全备份")
        # 清理 WAL/SHM，避免旧日志覆盖新数据库
        for suffix in ("-wal", "-shm"):
            candidate = Path(str(self.path) + suffix)
            if candidate.exists():
                candidate.unlink()
        shutil.copy2(backup_file, self.path)
        self.log_action(
            "restore",
            "database",
            self.path.name,
            before={"safety_backup": safety.name},
            after={"restored_from": backup_file.name},
            note="从备份恢复数据库",
        )
        return safety

    def close(self) -> None:
        # 每个操作使用独立连接，此方法保留以兼容调用方。
        return None
