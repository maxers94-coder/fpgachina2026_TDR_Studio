"""全局配置、路径与显示常量。

本模块不导入任何第三方库，保证程序在完全离线的 Windows 环境可启动。
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "TDR Measurement Studio"
APP_NAME_CN = "线缆弱阻抗异常检测与定位系统实验管理平台"
APP_VERSION = "1.0.0"
DATA_SCHEMA_VERSION = "1.0"
SOFTWARE_STAGE = "第一阶段 + 第二阶段核心功能"

# 项目根目录（兼容 PyInstaller 打包后的运行方式）
if getattr(sys, "frozen", False):
    PROJECT_ROOT = Path(sys.executable).resolve().parent
else:
    PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_DIR = Path(os.environ.get("TDR_DATA_DIR", PROJECT_ROOT / "data")).resolve()
DB_PATH = Path(os.environ.get("TDR_DB_PATH", DATA_DIR / "tdr_studio.db")).resolve()
ATTACHMENTS_DIR = DATA_DIR / "attachments"
BACKUPS_DIR = DATA_DIR / "backups"
IMPORT_REPORTS_DIR = DATA_DIR / "import_reports"
EXPORTS_DIR = Path(os.environ.get("TDR_EXPORT_DIR", PROJECT_ROOT / "exports")).resolve()
SAMPLE_DATA_DIR = PROJECT_ROOT / "sample_data"
DEFAULT_WORKBOOK = SAMPLE_DATA_DIR / "FW63_V1.0_测量专项初验完整表_20261102.xlsx"

# 表格/导出中的枚举中文标签。数据库内部统一存英文枚举，避免统计口径漂移。
BOARD_TYPE_LABELS = {
    "normal": "正常",
    "series": "串联",
    "shunt": "并联",
    "open": "开路",
    "short": "短路",
    "custom": "自定义",
}
BOARD_STATUS_LABELS = {
    "available": "可用",
    "pending": "待制作",
    "damaged": "损坏",
    "retired": "停用",
}
POLARITY_LABELS = {
    "positive": "正",
    "negative": "负",
    "none": "无",
    "unknown": "不确定",
    "": "—",
}
POLARITY_FROM_LABEL = {v: k for k, v in POLARITY_LABELS.items()}
TRIAL_STATUS_LABELS = {
    "detected": "检出",
    "not_detected": "未检出",
    "normal": "正常判定",
    "false_alarm": "误报",
    "invalid": "无效",
    "rejected": "拒判",
}
TRIAL_STATUS_FROM_LABEL = {v: k for k, v in TRIAL_STATUS_LABELS.items()}
QUALITY_FLAGS = ["正常", "弱", "EDGE*", "PN?", "OVERFLOW", "LOW", "OPEN-LIKE", "SHORT-LIKE", "其他"]
CONFIG_STATUS_LABELS = {
    "not_started": "未开始",
    "in_progress": "进行中",
    "completed": "已完成",
    "skipped": "已跳过",
    "failed": "失败",
}
CONFIG_STATUS_FROM_LABEL = {v: k for k, v in CONFIG_STATUS_LABELS.items()}
MODE_LABELS = {"normal": "正常参考", "single": "单异常", "multi": "多异常"}
FRONTEND_LABELS = {
    "resistive_divider": "电阻功分器",
    "swr_bridge": "SWR 电桥",
    "custom": "自定义",
}
JUDGEMENT_LABELS = {
    "pass": "通过",
    "fail": "未通过",
    "insufficient": "数据不足",
    "not_tested": "未测试",
    "review": "需要人工复核",
}

BUILTIN_CATEGORIES = [
    ("A", "正常参考与误报测试", "健康参考、Normal 对照、重复重接与误报检查", 1),
    ("B", "开路与短路检测", "端点开路/短路检测和标定长度验证", 2),
    ("C", "单个阻抗异常检测", "单个串联/并联弱阻抗异常的距离、极性检测", 3),
    ("D", "最小与最大检测距离", "近端与远端检测边界专项", 4),
    ("E", "多异常同时定位", "两个及以上异常同时存在时的候选匹配", 5),
    ("F", "重复性、漂移和连续测量", "重复性、稳定性、连续测量与漂移观察", 6),
]

DEFAULT_SETTINGS = {
    "project_name": APP_NAME_CN,
    "firmware_version": "FW63 V1.0",
    "operator": "",
    "distance_tolerance_m": 0.60,
    "min_detection_rate": 0.95,
    "max_false_alarm_rate": 0.05,
    "require_polarity": True,
    "edge_as_valid": False,
    "min_trials_for_judgement": 1,
    "max_invalid_rate": 0.20,
    "hardware_error_fails": True,
    "min_location_rate": 0.90,
    "z0_default": 50.0,
    "sample_rate_msps": 200.0,
    "pn_sequence": "PN127",
    "chip_rate_mchip": 50.0,
    "reference_conditions_strict": True,
    "auto_backup_daily": True,
}

# 图表配色（科研仪器风格）
COLORS = {
    "bg": "#F4F6F8",
    "sidebar": "#0B2B36",
    "sidebar_active": "#14576A",
    "sidebar_text": "#DCE8EC",
    "card": "#FFFFFF",
    "border": "#D9E1E5",
    "text": "#172A33",
    "muted": "#63747D",
    "primary": "#0F6E6E",
    "primary_hover": "#0B5656",
    "accent": "#D97706",
    "success": "#1B7F4B",
    "danger": "#B42318",
    "warning": "#B54708",
    "info": "#175CD3",
    "grid": "#E7ECEF",
}


def ensure_runtime_dirs() -> None:
    for path in (
        DATA_DIR,
        DB_PATH.parent,
        ATTACHMENTS_DIR,
        BACKUPS_DIR,
        IMPORT_REPORTS_DIR,
        EXPORTS_DIR,
    ):
        path.mkdir(parents=True, exist_ok=True)


if str(PROJECT_ROOT / "vendor") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "vendor"))
