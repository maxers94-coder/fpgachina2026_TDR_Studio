"""Tkinter 主题：科研仪器风格、中文高 DPI。"""
from __future__ import annotations

import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

from ..config import COLORS

FONT_FAMILY = "Microsoft YaHei UI"
MONO_FAMILY = "Consolas"


def apply_theme(root: tk.Tk) -> dict[str, tkfont.Font]:
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    base = tkfont.nametofont("TkDefaultFont")
    base.configure(family=FONT_FAMILY, size=10)
    text = tkfont.nametofont("TkTextFont")
    text.configure(family=FONT_FAMILY, size=10)
    fixed = tkfont.nametofont("TkFixedFont")
    fixed.configure(family=MONO_FAMILY, size=10)
    heading = tkfont.nametofont("TkHeadingFont")
    heading.configure(family=FONT_FAMILY, size=10, weight="bold")

    fonts = {
        "body": tkfont.Font(root, family=FONT_FAMILY, size=10),
        "small": tkfont.Font(root, family=FONT_FAMILY, size=9),
        "tiny": tkfont.Font(root, family=FONT_FAMILY, size=8),
        "bold": tkfont.Font(root, family=FONT_FAMILY, size=10, weight="bold"),
        "h1": tkfont.Font(root, family=FONT_FAMILY, size=21, weight="bold"),
        "h2": tkfont.Font(root, family=FONT_FAMILY, size=15, weight="bold"),
        "h3": tkfont.Font(root, family=FONT_FAMILY, size=12, weight="bold"),
        "metric": tkfont.Font(root, family=FONT_FAMILY, size=22, weight="bold"),
        "metric_small": tkfont.Font(root, family=FONT_FAMILY, size=17, weight="bold"),
        "mono": tkfont.Font(root, family=MONO_FAMILY, size=10),
        "nav": tkfont.Font(root, family=FONT_FAMILY, size=11, weight="bold"),
    }

    root.configure(bg=COLORS["bg"])
    style.configure(".", font=fonts["body"], background=COLORS["bg"], foreground=COLORS["text"])
    style.configure("TFrame", background=COLORS["bg"])
    style.configure("Card.TFrame", background=COLORS["card"])
    style.configure("TLabel", background=COLORS["bg"], foreground=COLORS["text"])
    style.configure("Card.TLabel", background=COLORS["card"], foreground=COLORS["text"])
    style.configure("Muted.TLabel", background=COLORS["bg"], foreground=COLORS["muted"])
    style.configure("CardMuted.TLabel", background=COLORS["card"], foreground=COLORS["muted"])
    style.configure("Title.TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=fonts["h1"])
    style.configure("H2.TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=fonts["h2"])
    style.configure("H3.TLabel", background=COLORS["bg"], foreground=COLORS["text"], font=fonts["h3"])
    style.configure("CardH3.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=fonts["h3"])
    style.configure("Metric.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=fonts["metric"])
    style.configure("MetricSmall.TLabel", background=COLORS["card"], foreground=COLORS["text"], font=fonts["metric_small"])
    style.configure("Success.TLabel", background=COLORS["card"], foreground=COLORS["success"], font=fonts["bold"])
    style.configure("Danger.TLabel", background=COLORS["card"], foreground=COLORS["danger"], font=fonts["bold"])
    style.configure("Warning.TLabel", background=COLORS["card"], foreground=COLORS["warning"], font=fonts["bold"])

    style.configure(
        "TButton",
        font=fonts["body"],
        padding=(12, 7),
        background=COLORS["card"],
        foreground=COLORS["text"],
        borderwidth=1,
        relief="flat",
    )
    style.map(
        "TButton",
        background=[("active", "#E8EFF1"), ("disabled", "#F0F2F3")],
        foreground=[("disabled", "#9AA6AB")],
    )
    style.configure(
        "Primary.TButton",
        background=COLORS["primary"],
        foreground="#FFFFFF",
        font=fonts["bold"],
        padding=(15, 8),
        borderwidth=0,
    )
    style.map(
        "Primary.TButton",
        background=[("active", COLORS["primary_hover"]), ("disabled", "#9ABDBD")],
    )
    style.configure(
        "Danger.TButton",
        background=COLORS["danger"],
        foreground="#FFFFFF",
        font=fonts["bold"],
        padding=(13, 8),
        borderwidth=0,
    )
    style.map("Danger.TButton", background=[("active", "#8F1B12")])
    style.configure(
        "Ghost.TButton",
        background=COLORS["card"],
        foreground=COLORS["primary"],
        borderwidth=1,
        padding=(10, 6),
    )
    style.map("Ghost.TButton", background=[("active", "#EAF4F4")])
    style.configure(
        "Nav.TButton",
        font=fonts["nav"],
        background=COLORS["sidebar"],
        foreground=COLORS["sidebar_text"],
        borderwidth=0,
        padding=(18, 12),
        anchor="w",
    )
    style.map(
        "Nav.TButton",
        background=[("active", COLORS["sidebar_active"]), ("pressed", COLORS["sidebar_active"])],
        foreground=[("active", "#FFFFFF")],
    )
    style.configure("NavActive.TButton", font=fonts["nav"], background=COLORS["sidebar_active"],
                    foreground="#FFFFFF", borderwidth=0, padding=(18, 12), anchor="w")

    style.configure("TEntry", fieldbackground="#FFFFFF", bordercolor=COLORS["border"], padding=7)
    style.map("TEntry", bordercolor=[("focus", COLORS["primary"])])
    style.configure("TCombobox", fieldbackground="#FFFFFF", padding=5, arrowsize=16)
    style.map(
        "TCombobox",
        fieldbackground=[("readonly", "#FFFFFF")],
        bordercolor=[("focus", COLORS["primary"])],
    )
    style.configure("TSpinbox", fieldbackground="#FFFFFF", padding=5)
    style.configure("TNotebook", background=COLORS["bg"], borderwidth=0)
    style.configure("TNotebook.Tab", font=fonts["bold"], padding=(16, 9),
                    background="#E8EEF0", foreground=COLORS["muted"])
    style.map(
        "TNotebook.Tab",
        background=[("selected", COLORS["card"])],
        foreground=[("selected", COLORS["primary"])],
    )
    style.configure(
        "Treeview",
        font=fonts["body"],
        rowheight=29,
        background="#FFFFFF",
        fieldbackground="#FFFFFF",
        foreground=COLORS["text"],
        bordercolor=COLORS["border"],
    )
    style.configure(
        "Treeview.Heading",
        font=fonts["bold"],
        background="#E9F0F2",
        foreground=COLORS["text"],
        relief="flat",
        padding=(8, 8),
    )
    style.map("Treeview.Heading", background=[("active", "#DCE8EA")])
    style.map("Treeview", background=[("selected", COLORS["sidebar_active"])],
              foreground=[("selected", "#FFFFFF")])
    style.configure("TCheckbutton", background=COLORS["bg"], font=fonts["body"])
    style.configure("Card.TCheckbutton", background=COLORS["card"], font=fonts["body"])
    style.configure("TRadiobutton", background=COLORS["card"], font=fonts["body"])
    style.configure("Horizontal.TProgressbar", troughcolor="#E8EEF0", background=COLORS["primary"],
                    thickness=10)
    style.configure("TSeparator", background=COLORS["border"])
    style.configure("TScrollbar", background="#C9D5DA", troughcolor=COLORS["bg"], borderwidth=0)
    return fonts


def card(parent, **kwargs) -> tk.Frame:
    options = {
        "bg": COLORS["card"],
        "highlightbackground": COLORS["border"],
        "highlightthickness": 1,
        "bd": 0,
    }
    options.update(kwargs)
    return tk.Frame(parent, **options)


def primary_button(parent, text: str, command, **kwargs) -> ttk.Button:
    return ttk.Button(parent, text=text, command=command, style="Primary.TButton", **kwargs)


def danger_button(parent, text: str, command, **kwargs) -> ttk.Button:
    return ttk.Button(parent, text=text, command=command, style="Danger.TButton", **kwargs)
