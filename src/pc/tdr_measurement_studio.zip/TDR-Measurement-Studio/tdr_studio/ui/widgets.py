"""可复用的 Tkinter 界面组件。"""
from __future__ import annotations

import os
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any, Callable, Iterable

from ..config import COLORS
from ..utils import format_number, format_percent
from .theme import card


class ScrollableFrame(tk.Frame):
    """垂直滚动容器；高 DPI 下自动填充宽度。"""

    def __init__(self, parent, bg: str | None = None, **kwargs):
        super().__init__(parent, bg=bg or COLORS["bg"], **kwargs)
        self.canvas = tk.Canvas(self, bg=bg or COLORS["bg"], highlightthickness=0, bd=0)
        self.vbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.vbar.grid(row=0, column=1, sticky="ns")
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.inner = tk.Frame(self.canvas, bg=bg or COLORS["bg"])
        self._window = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind("<Enter>", self._bind_wheel)
        self.canvas.bind("<Leave>", self._unbind_wheel)

    def _on_inner_configure(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfigure(self._window, width=event.width)

    def _bind_wheel(self, _event=None):
        self.canvas.bind_all("<MouseWheel>", self._on_wheel)

    def _unbind_wheel(self, _event=None):
        self.canvas.unbind_all("<MouseWheel>")

    def _on_wheel(self, event):
        if self.inner.winfo_height() <= self.canvas.winfo_height():
            return
        self.canvas.yview_scroll(int(-event.delta / 120), "units")

    def scroll_to_top(self):
        self.canvas.yview_moveto(0)


def page_header(parent, title: str, subtitle: str = "", actions: Iterable[tuple[str, Callable, str]] | None = None):
    container = tk.Frame(parent, bg=COLORS["bg"])
    text_frame = tk.Frame(container, bg=COLORS["bg"])
    text_frame.pack(side="left", fill="x", expand=True)
    tk.Label(text_frame, text=title, bg=COLORS["bg"], fg=COLORS["text"],
             font=("Microsoft YaHei UI", 21, "bold"), anchor="w").pack(anchor="w")
    if subtitle:
        tk.Label(text_frame, text=subtitle, bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w", pady=(3, 0))
    if actions:
        button_frame = tk.Frame(container, bg=COLORS["bg"])
        button_frame.pack(side="right", anchor="ne")
        for text, command, style in actions:
            ttk.Button(button_frame, text=text, command=command, style=style).pack(side="left", padx=(6, 0))
    return container


def section_card(parent, title: str, subtitle: str = "", *, pad: int = 16, bg: str | None = None):
    outer = card(parent, bg=bg or COLORS["card"])
    header = tk.Frame(outer, bg=bg or COLORS["card"])
    header.pack(fill="x", padx=pad, pady=(pad, 6))
    tk.Label(header, text=title, bg=bg or COLORS["card"], fg=COLORS["text"],
             font=("Microsoft YaHei UI", 12, "bold"), anchor="w").pack(side="left")
    if subtitle:
        tk.Label(header, text=subtitle, bg=bg or COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(side="left", padx=(10, 0))
    body = tk.Frame(outer, bg=bg or COLORS["card"])
    body.pack(fill="both", expand=True, padx=pad, pady=(0, pad))
    return outer, body


class MetricCard(tk.Frame):
    def __init__(self, parent, title: str, value: str = "—", note: str = "", accent: str | None = None):
        super().__init__(parent, bg=COLORS["card"], highlightbackground=COLORS["border"], highlightthickness=1)
        self.accent = tk.Frame(self, bg=accent or COLORS["primary"], width=4)
        self.accent.pack(side="left", fill="y")
        inner = tk.Frame(self, bg=COLORS["card"])
        inner.pack(side="left", fill="both", expand=True, padx=14, pady=12)
        tk.Label(inner, text=title, bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
        self.value_label = tk.Label(inner, text=value, bg=COLORS["card"], fg=COLORS["text"],
                                    font=("Microsoft YaHei UI", 20, "bold"), anchor="w")
        self.value_label.pack(anchor="w", pady=(2, 1))
        self.note_label = tk.Label(inner, text=note, bg=COLORS["card"], fg=COLORS["muted"],
                                   font=("Microsoft YaHei UI", 8), anchor="w", justify="left")
        self.note_label.pack(anchor="w")

    def update_value(self, value: str, note: str = "", color: str | None = None):
        self.value_label.configure(text=value, fg=color or COLORS["text"])
        self.note_label.configure(text=note)


class DataTable(tk.Frame):
    """带排序、滚动条、空状态的 Treeview 封装。

    columns: [{"key":..., "label":..., "width":..., "percent":bool, "digits":int,
               "formatter":callable, "anchor":...}]
    """

    def __init__(self, parent, columns: list[dict[str, Any]], *, height: int = 12,
                 selectmode: str = "browse", on_double_click=None, bg: str | None = None):
        super().__init__(parent, bg=bg or COLORS["card"])
        self.columns = columns
        self._rows: list[dict[str, Any]] = []
        self._sort_key: str | None = None
        self._sort_reverse = False
        keys = [column["key"] for column in columns]
        self.tree = ttk.Treeview(self, columns=keys, show="headings", height=height, selectmode=selectmode)
        for column in columns:
            self.tree.heading(
                column["key"], text=column.get("label", column["key"]),
                command=lambda key=column["key"]: self._sort_by(key),
            )
            self.tree.column(
                column["key"], width=column.get("width", 110),
                minwidth=column.get("minwidth", 50),
                anchor=column.get("anchor", "w"),
                stretch=column.get("stretch", False),
            )
        self.vbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.hbar = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=self.vbar.set, xscrollcommand=self.hbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.vbar.grid(row=0, column=1, sticky="ns")
        self.hbar.grid(row=1, column=0, sticky="ew")
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.tree.tag_configure("odd", background="#F8FAFB")
        self.tree.tag_configure("warn", background="#FFF7E8")
        self.tree.tag_configure("bad", background="#FDECEA")
        self.tree.tag_configure("ok", background="#EFF8F2")
        self.tree.tag_configure("muted", foreground="#7A898F")
        if on_double_click:
            self.tree.bind("<Double-1>", lambda event: on_double_click(self.selected_row()))
        self.empty_label = tk.Label(self, text="暂无数据", bg=bg or COLORS["card"],
                                    fg=COLORS["muted"], font=("Microsoft YaHei UI", 10))
        self.empty_label.place(relx=0.5, rely=0.45, anchor="center")

    def _format(self, column: dict[str, Any], value: Any) -> str:
        formatter = column.get("formatter")
        if formatter:
            return str(formatter(value))
        if value is None or value == "":
            return "—"
        if isinstance(value, bool):
            return "是" if value else "否"
        if column.get("percent"):
            return format_percent(value, int(column.get("digits", 2)))
        if isinstance(value, float):
            return format_number(value, int(column.get("digits", 3)))
        return str(value)

    def _item_values(self, row: dict[str, Any]) -> list[str]:
        return [self._format(column, row.get(column["key"])) for column in self.columns]

    def set_rows(self, rows: Iterable[dict[str, Any]]):
        self._rows = [dict(row) for row in rows]
        self.tree.delete(*self.tree.get_children())
        if self._sort_key:
            self._rows.sort(key=self._row_sort_value, reverse=self._sort_reverse)
        for index, row in enumerate(self._rows):
            iid = str(row.get("_iid") or row.get("id") or row.get("code") or f"row-{index}")
            base = iid
            suffix = 2
            while self.tree.exists(iid):
                iid = f"{base}-{suffix}"
                suffix += 1
            row["_iid"] = iid
            tag = row.get("_tag") or ("odd" if index % 2 else "")
            tags = [tag] if tag else []
            if row.get("_status_tag"):
                tags.append(row["_status_tag"])
            self.tree.insert("", "end", iid=iid, values=self._item_values(row), tags=tuple(tags))
        if self._rows:
            self.empty_label.place_forget()
        else:
            self.empty_label.place(relx=0.5, rely=0.45, anchor="center")

    def row_sort_value(self, row):
        return self._row_sort_value(row)

    def _row_sort_value(self, row):
        value = row.get(self._sort_key)
        if value is None:
            return (1, "")
        if isinstance(value, (int, float)):
            return (0, value)
        return (0, str(value).lower())

    def _sort_by(self, key: str):
        if self._sort_key == key:
            self._sort_reverse = not self._sort_reverse
        else:
            self._sort_key = key
            self._sort_reverse = False
        self.set_rows(self._rows)

    def selected_rows(self) -> list[dict[str, Any]]:
        selected = set(self.tree.selection())
        return [row for row in self._rows if row.get("_iid") in selected]

    def selected_row(self) -> dict[str, Any] | None:
        rows = self.selected_rows()
        return rows[0] if rows else None

    def selected_id(self) -> str | None:
        row = self.selected_row()
        if not row:
            return None
        return row.get("id") or row.get("code")

    def clear_selection(self):
        self.tree.selection_remove(self.tree.selection())


class ModalDialog(tk.Toplevel):
    """模态对话框基类。子类实现 build_body() 和 on_save()。"""

    def __init__(self, parent, title: str, *, width: int = 720, height: int = 640, resizable: bool = False):
        super().__init__(parent)
        self.parent = parent
        self.result: Any = None
        self.title(title)
        self.configure(bg=COLORS["bg"])
        self.geometry(f"{width}x{height}")
        self.resizable(resizable, resizable)
        self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.bind("<Escape>", lambda event: self.cancel())
        self.update_idletasks()
        self._center(parent, width, height)
        header = tk.Frame(self, bg=COLORS["bg"])
        header.pack(fill="x", padx=20, pady=(16, 8))
        tk.Label(header, text=title, bg=COLORS["bg"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 15, "bold"), anchor="w").pack(side="left")
        # 底部按钮先固定在窗口底部，再让表单区域占用剩余空间。
        # 内容超出时只滚动表单，避免“确定/取消”被内容挤出屏幕。
        footer = tk.Frame(self, bg=COLORS["bg"])
        footer.pack(side="bottom", fill="x", padx=20, pady=(8, 16))
        self.footer = footer
        ttk.Button(footer, text="取消", command=self.cancel).pack(side="right")
        self.save_button = ttk.Button(footer, text="保存", command=self.try_save, style="Primary.TButton")
        self.save_button.pack(side="right", padx=(0, 8))
        self._body_scroll = ScrollableFrame(self)
        self._body_scroll.pack(fill="both", expand=True, padx=(20, 10), pady=(0, 4))
        self.body = self._body_scroll.inner
        self.build_body(self.body)
        self.after(80, self._grab)

    def _grab(self):
        try:
            self.grab_set()
            self.focus_set()
        except tk.TclError:
            pass

    def _center(self, parent, width: int, height: int):
        parent.update_idletasks()
        x = parent.winfo_rootx() + max(0, (parent.winfo_width() - width) // 2)
        y = parent.winfo_rooty() + max(0, (parent.winfo_height() - height) // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")

    def build_body(self, parent):
        raise NotImplementedError

    def on_save(self) -> bool:
        raise NotImplementedError

    def try_save(self):
        try:
            if self.on_save():
                self.grab_release()
                self.destroy()
        except Exception as exc:
            messagebox.showerror("保存失败", str(exc), parent=self)

    def cancel(self):
        self.result = None
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()

    def add_footer_button(self, text: str, command, style: str = "TButton"):
        button = ttk.Button(self.footer, text=text, command=command, style=style)
        button.pack(side="left", padx=(0, 8))
        return button

    def show(self):
        self.wait_window(self)
        return self.result


def labeled_entry(parent, label: str, variable, *, row: int, column: int = 0,
                  width: int = 32, hint: str = "", values: list[str] | None = None,
                  show: str | None = None):
    container = tk.Frame(parent, bg=parent.cget("bg"))
    container.grid(row=row, column=column, sticky="ew", padx=(0, 18), pady=5)
    tk.Label(container, text=label, bg=container.cget("bg"), fg=COLORS["muted"],
             font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
    if values is not None:
        widget = ttk.Combobox(container, textvariable=variable, values=values, state="readonly", width=width)
    else:
        widget = ttk.Entry(container, textvariable=variable, width=width, show=show)
    widget.pack(fill="x", pady=(2, 0))
    if hint:
        tk.Label(container, text=hint, bg=container.cget("bg"), fg="#87969C",
                 font=("Microsoft YaHei UI", 8), anchor="w", justify="left").pack(anchor="w")
    return widget


def labeled_text(parent, label: str, text_widget, *, row: int, column: int = 0, hint: str = ""):
    container = tk.Frame(parent, bg=parent.cget("bg"))
    container.grid(row=row, column=column, sticky="nsew", padx=(0, 18), pady=5)
    tk.Label(container, text=label, bg=container.cget("bg"), fg=COLORS["muted"],
             font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
    text_widget.pack(in_=container, fill="both", expand=True, pady=(2, 0))
    if hint:
        tk.Label(container, text=hint, bg=container.cget("bg"), fg="#87969C",
                 font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
    return container


def separator(parent, pady: int = 8):
    ttk.Separator(parent, orient="horizontal").pack(fill="x", pady=pady)


def empty_state(parent, title: str, detail: str = "", action_text: str | None = None, command=None):
    frame = tk.Frame(parent, bg=COLORS["card"])
    tk.Label(frame, text=title, bg=COLORS["card"], fg=COLORS["text"],
             font=("Microsoft YaHei UI", 12, "bold")).pack(pady=(30, 4))
    if detail:
        tk.Label(frame, text=detail, bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), wraplength=620, justify="center").pack(pady=(0, 12))
    if action_text and command:
        ttk.Button(frame, text=action_text, command=command, style="Primary.TButton").pack()
    return frame


def info_badge(parent, text: str, color: str, bg: str | None = None):
    return tk.Label(
        parent, text=text, bg=bg or "#EAF4F4", fg=color, padx=9, pady=3,
        font=("Microsoft YaHei UI", 8, "bold"),
    )


def open_local_path(path: str | Path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"路径不存在：{path}")
    os.startfile(str(path))  # type: ignore[attr-defined]


def center_on_parent(window, parent, width: int, height: int):
    parent.update_idletasks()
    x = parent.winfo_rootx() + max(0, (parent.winfo_width() - width) // 2)
    y = parent.winfo_rooty() + max(0, (parent.winfo_height() - height) // 2)
    window.geometry(f"{width}x{height}+{x}+{y}")


def status_tag_for(status: str) -> str:
    return {
        "completed": "ok", "pass": "ok", "available": "ok", "normal": "ok",
        "failed": "bad", "fail": "bad", "damaged": "bad", "false_alarm": "bad",
        "in_progress": "warn", "pending": "warn", "review": "warn",
        "insufficient": "warn", "not_started": "muted", "skipped": "muted",
        "invalid": "warn", "rejected": "warn",
    }.get(status, "")
