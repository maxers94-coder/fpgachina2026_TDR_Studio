"""仪表盘。"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...config import COLORS, CONFIG_STATUS_LABELS
from ...services.analytics import dashboard_data, load_rules
from ...utils import format_number, format_percent
from ..base import BasePage
from ..widgets import DataTable, MetricCard, ScrollableFrame, page_header, section_card


class DashboardPage(BasePage):
    key = "dashboard"
    title = "仪表盘"
    subtitle = "项目进度、实验质量与数据完整性总览"

    def build(self):
        self.scroll = ScrollableFrame(self)
        self.scroll.pack(fill="both", expand=True)
        self.inner = self.scroll.inner
        self.header = page_header(
            self.inner,
            "实验总览",
            "所有数字均由本地 SQLite 原始记录实时计算，不使用演示数据。",
            actions=[
                ("刷新", self.safe_refresh, "Ghost.TButton"),
                ("开始录入", lambda: self.app.navigate("workbench"), "Primary.TButton"),
            ],
        )
        self.header.pack(fill="x", pady=(4, 16))

        # 指标卡
        cards = tk.Frame(self.inner, bg=COLORS["bg"])
        cards.pack(fill="x")
        self.metric_cards: dict[str, MetricCard] = {}
        specs = [
            ("progress", "实验进度", "0 / 0", "已完成配置"),
            ("trials", "测量试次", "0 / 0", "已完成 / 计划"),
            ("detection", "异常检出率", "不适用", "未检出保留在分母"),
            ("false_alarm", "正常误报率", "不适用", "正常参考组"),
            ("mae", "定位 MAE", "不适用", "仅有效定位"),
        ]
        for index, (key, title, value, note) in enumerate(specs):
            card = MetricCard(cards, title, value, note)
            card.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 8, 0))
            cards.grid_columnconfigure(index, weight=1)
            self.metric_cards[key] = card

        # 主体两列
        columns = tk.Frame(self.inner, bg=COLORS["bg"])
        columns.pack(fill="both", expand=True, pady=(16, 0))
        left = tk.Frame(columns, bg=COLORS["bg"])
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        right = tk.Frame(columns, bg=COLORS["bg"], width=340)
        right.pack(side="right", fill="y")
        right.pack_propagate(False)

        cat_card, cat_body = section_card(left, "六大实验类别进度", "按计划试次与已完成试次统计")
        cat_card.pack(fill="both", expand=True)
        self.category_table = DataTable(
            cat_body,
            [
                {"key": "code", "label": "组", "width": 42, "anchor": "center"},
                {"key": "name", "label": "实验类别", "width": 190},
                {"key": "config_count", "label": "配置", "width": 55, "anchor": "center"},
                {"key": "planned", "label": "计划", "width": 55, "anchor": "center"},
                {"key": "actual", "label": "已测", "width": 55, "anchor": "center"},
                {"key": "progress", "label": "进度", "width": 72, "anchor": "center"},
                {"key": "completed", "label": "完成", "width": 55, "anchor": "center"},
                {"key": "in_progress", "label": "进行中", "width": 62, "anchor": "center"},
                {"key": "not_started", "label": "未开始", "width": 62, "anchor": "center"},
            ],
            height=8,
        )
        self.category_table.pack(fill="both", expand=True)
        quick = tk.Frame(cat_body, bg=COLORS["card"])
        quick.pack(fill="x", pady=(10, 0))
        ttk.Button(quick, text="管理实验矩阵", command=lambda: self.app.navigate("plan"),
                   style="Ghost.TButton").pack(side="left")
        ttk.Button(quick, text="查看数据分析", command=lambda: self.app.navigate("analysis"),
                   style="Ghost.TButton").pack(side="left", padx=(8, 0))
        ttk.Button(quick, text="导入 / 导出", command=lambda: self.app.navigate("transfer"),
                   style="Ghost.TButton").pack(side="left", padx=(8, 0))

        health_card, health_body = section_card(right, "项目检查", "需要关注的事项")
        health_card.pack(fill="x")
        self.health_labels: dict[str, tk.Label] = {}
        for key, label in [
            ("data", "数据状态"),
            ("current", "当前实验"),
            ("reference", "参考条件"),
            ("backup", "最近备份"),
            ("criteria", "当前判定标准"),
        ]:
            row = tk.Frame(health_body, bg=COLORS["card"])
            row.pack(fill="x", pady=5)
            tk.Label(row, text=label, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8), width=9, anchor="w").pack(side="left", anchor="n")
            value = tk.Label(row, text="—", bg=COLORS["card"], fg=COLORS["text"],
                             font=("Microsoft YaHei UI", 9), anchor="w", justify="left",
                             wraplength=230)
            value.pack(side="left", fill="x", expand=True)
            self.health_labels[key] = value

        ttk.Separator(health_body).pack(fill="x", pady=10)
        ttk.Button(health_body, text="立即备份数据库", command=self._backup_now,
                   style="Ghost.TButton").pack(fill="x")
        ttk.Button(health_body, text="打开数据目录", command=self.app.open_data_dir,
                   style="Ghost.TButton").pack(fill="x", pady=(6, 0))

        recent_card, recent_body = section_card(left, "最近测量记录", "最新 12 条，包含未检出与无效记录")
        recent_card.pack(fill="both", expand=True, pady=(16, 0))
        self.recent_table = DataTable(
            recent_body,
            [
                {"key": "updated_at", "label": "时间", "width": 135},
                {"key": "config_code", "label": "实验", "width": 58},
                {"key": "trial_index", "label": "试次", "width": 45, "anchor": "center"},
                {"key": "status_label", "label": "状态", "width": 68},
                {"key": "measured_distance_m", "label": "测量距离 m", "width": 96, "digits": 3},
                {"key": "polarity_label", "label": "极性", "width": 50, "anchor": "center"},
                {"key": "quality_flag", "label": "质量", "width": 75},
            ],
            height=8,
            on_double_click=self._open_recent,
        )
        self.recent_table.pack(fill="both", expand=True)
        self._recent_rows = []

    def _open_recent(self, row):
        if not row:
            return
        self.app.open_workbench(row["config_id"])

    def _backup_now(self):
        try:
            path = self.db.backup_default(note="仪表盘手动备份")
            self.app.notify(f"备份完成：{path.name}", "success")
            self.refresh()
        except Exception as exc:
            self.app.show_error("备份失败", exc)

    def refresh(self):
        try:
            data = dashboard_data(self.db)
        except Exception as exc:
            self.app.notify(f"仪表盘读取失败：{exc}", "error")
            return
        settings = self.db.get_all_settings()
        counts = data["config_counts"]
        total = counts["total"]
        completed = counts["completed"]
        progress = completed / total if total else 0
        self.metric_cards["progress"].update_value(
            f"{completed} / {total}", f"完成 {format_percent(progress)} · 进行中 {counts['in_progress']}", COLORS["primary"]
        )
        planned = data["total_planned"]
        actual = data["total_trials"]
        self.metric_cards["trials"].update_value(
            f"{actual} / {planned}", f"完成 {format_percent(actual / planned if planned else None)}", COLORS["primary"]
        )
        stats = data["stats"]
        detection = stats.get("anomaly_detection_rate")
        self.metric_cards["detection"].update_value(
            format_percent(detection) if detection is not None else "不适用",
            f"检出 {stats.get('detected_count', 0)} / 未检出 {stats.get('not_detected_count', 0)}",
            COLORS["success"] if detection is not None and detection >= 0.95 else COLORS["warning"] if detection is not None else COLORS["muted"],
        )
        fa = stats.get("false_alarm_rate")
        self.metric_cards["false_alarm"].update_value(
            format_percent(fa) if fa is not None else "不适用",
            f"正常判定 {stats.get('normal_count', 0)} / 误报 {stats.get('false_alarm_count', 0)}",
            COLORS["success"] if fa is not None and fa <= settings.get("max_false_alarm_rate", 0.05) else COLORS["warning"] if fa is not None else COLORS["muted"],
        )
        mae = stats["distance"].get("mae_m")
        self.metric_cards["mae"].update_value(
            format_number(mae, 3) if mae is not None else "不适用",
            f"有效定位 {stats.get('located_count', 0)} · P95 {format_number(stats['distance'].get('p95_abs_error_m'), 3)} m",
            COLORS["success"] if mae is not None and mae <= 0.30 else COLORS["warning"] if mae is not None else COLORS["muted"],
        )

        category_rows = []
        for category in data["categories"]:
            planned_cat = int(category["planned"] or 0)
            actual_cat = int(category["actual"] or 0)
            category_rows.append(
                {
                    "code": category["code"],
                    "name": category["name"],
                    "config_count": int(category["config_count"] or 0),
                    "planned": planned_cat,
                    "actual": actual_cat,
                    "progress": format_percent(actual_cat / planned_cat if planned_cat else None, 0),
                    "completed": int(category["completed"] or 0),
                    "in_progress": int(category["in_progress"] or 0),
                    "not_started": int(category["not_started"] or 0),
                }
            )
        self.category_table.set_rows(category_rows)

        recent_rows = []
        for trial in data["recent_trials"]:
            status = trial.get("detection_status", "")
            recent_rows.append(
                {
                    "id": trial["id"],
                    "config_id": trial["config_id"],
                    "updated_at": str(trial.get("updated_at", ""))[:19].replace("T", " "),
                    "config_code": trial.get("config_code"),
                    "trial_index": trial.get("trial_index"),
                    "status_label": {
                        "detected": "检出", "not_detected": "未检出", "normal": "正常判定",
                        "false_alarm": "误报", "invalid": "无效", "rejected": "拒判",
                    }.get(status, status),
                    "measured_distance_m": trial.get("measured_distance_m"),
                    "polarity_label": {"positive": "正", "negative": "负", "none": "无", "unknown": "不确定"}.get(trial.get("polarity"), "—"),
                    "quality_flag": trial.get("quality_flag"),
                    "_status_tag": {"false_alarm": "bad", "not_detected": "warn", "invalid": "warn", "rejected": "warn"}.get(status, ""),
                }
            )
        self.recent_table.set_rows(recent_rows)

        # 项目检查
        if total == 0:
            self.health_labels["data"].configure(
                text="尚无实验配置。请到“实验计划”导入 79 组矩阵或生成新矩阵。",
                fg=COLORS["warning"],
            )
        elif actual == 0:
            self.health_labels["data"].configure(
                text=f"{total} 组配置已就绪，但尚无实测记录。未测试不会被当作通过。",
                fg=COLORS["warning"],
            )
        else:
            pending = counts["not_started"] + counts["in_progress"]
            self.health_labels["data"].configure(
                text=f"{total} 组配置 · {actual} 条原始记录 · {pending} 组待完成。",
                fg=COLORS["success"],
            )
        if self.app.current_config_id:
            config_row = self.db.query_one(
                "SELECT code,name FROM experiment_configs WHERE id=?", (self.app.current_config_id,)
            )
            self.health_labels["current"].configure(
                text=f"{config_row['code']}｜{config_row['name']}" if config_row else "—",
                fg=COLORS["text"],
            )
        else:
            self.health_labels["current"].configure(text="尚未选择；到“实验工作台”选择配置。", fg=COLORS["muted"])
        mismatches = 0
        for run in self.db.query("SELECT id FROM experiment_runs"):
            if self.app.repos.runs.reference_condition_issues(self.app.repos.runs.get(run["id"]) or {}):
                mismatches += 1
        if mismatches:
            self.health_labels["reference"].configure(
                text=f"{mismatches} 个实验运行存在参考条件不匹配，统计时需单独说明。",
                fg=COLORS["warning"],
            )
        else:
            self.health_labels["reference"].configure(text="未发现参考条件不匹配。", fg=COLORS["success"])
        backups = sorted(self.db.path.parent.joinpath("backups").glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        if backups:
            from datetime import datetime

            self.health_labels["backup"].configure(
                text=f"{backups[0].name}\n{datetime.fromtimestamp(backups[0].stat().st_mtime).strftime('%Y-%m-%d %H:%M')}",
                fg=COLORS["text"],
            )
        else:
            self.health_labels["backup"].configure(text="尚未备份，建议立即创建数据库备份。", fg=COLORS["warning"])
        rules = load_rules(self.db)
        self.health_labels["criteria"].configure(
            text=f"容差 ±{rules['distance_tolerance_m']:.2f} m\n检出率 ≥{format_percent(rules['min_detection_rate'])}\n"
                 f"误报率 ≤{format_percent(rules['max_false_alarm_rate'])}\nEDGE* {'有效' if rules['edge_as_valid'] else '不计有效'}",
            fg=COLORS["text"],
        )
