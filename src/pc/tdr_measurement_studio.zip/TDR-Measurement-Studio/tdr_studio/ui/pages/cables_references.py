"""线缆资产、线缆组合与健康参考管理。"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from ... import config
from ...config import COLORS, FRONTEND_LABELS
from ...utils import format_number, now_iso, safe_float
from ..base import BasePage
from ..theme import card
from ..widgets import DataTable, ModalDialog, page_header, section_card


class CableDialog(ModalDialog):
    def __init__(self, parent, repo, cable=None):
        self.repo = repo
        self.cable = cable
        super().__init__(parent, "编辑线缆" if cable else "新增线缆", width=680, height=580)

    def build_body(self, parent):
        cable = self.cable or {}
        self.code_var = tk.StringVar(value=cable.get("code", ""))
        self.name_var = tk.StringVar(value=cable.get("name", ""))
        self.length_var = tk.StringVar(value=str(cable.get("physical_length_m", "")))
        self.model_var = tk.StringVar(value=cable.get("model", "50Ω 同轴"))
        self.z0_var = tk.StringVar(value=str(cable.get("z0", 50)))
        self.velocity_var = tk.StringVar(value=str(cable.get("velocity_factor", 0.66)))
        self.status_var = tk.StringVar(value={"available": "可用", "damaged": "损坏", "retired": "停用"}.get(cable.get("status"), "可用"))
        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="both", expand=True)
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        self._field(form, "线缆代号 *", self.code_var, 0, 0, "唯一代号，如 C1")
        self._field(form, "名称 *", self.name_var, 0, 1, "如 1 m 同轴线")
        self._field(form, "物理长度 (m) *", self.length_var, 1, 0, "物理长度，不是电气长度")
        self._field(form, "电缆型号", self.model_var, 1, 1)
        self._field(form, "特性阻抗 Z0 (Ω)", self.z0_var, 2, 0)
        self._field(form, "传播速度系数", self.velocity_var, 2, 1, "典型同轴 0.66；仅记录，用于后续换算")
        frame = tk.Frame(form, bg=COLORS["bg"])
        frame.grid(row=3, column=0, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text="状态", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Combobox(frame, textvariable=self.status_var, values=["可用", "损坏", "停用"], state="readonly").pack(fill="x", pady=(2, 0))
        tk.Label(form, text="备注", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).grid(row=4, column=0, columnspan=2, sticky="w", pady=(8, 2))
        self.notes = tk.Text(form, height=4, wrap="word", relief="solid", bd=1, font=("Microsoft YaHei UI", 9))
        self.notes.grid(row=5, column=0, columnspan=2, sticky="nsew")
        self.notes.insert("1.0", cable.get("notes", ""))
        tk.Label(form, text="提示：线缆物理长度与电气长度可能不同；组合允许对每段输入修正值。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8), justify="left",
                 wraplength=600).grid(row=6, column=0, columnspan=2, sticky="w", pady=(10, 0))

    def _field(self, parent, label, var, row, col, hint=""):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
        ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))
        if hint:
            tk.Label(frame, text=hint, bg=COLORS["bg"], fg="#87969C", font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")

    def on_save(self):
        status = {"可用": "available", "损坏": "damaged", "停用": "retired"}.get(self.status_var.get(), "available")
        data = {
            "code": self.code_var.get().strip(), "name": self.name_var.get().strip(),
            "physical_length_m": self.length_var.get().strip(), "model": self.model_var.get().strip(),
            "z0": self.z0_var.get().strip(), "velocity_factor": self.velocity_var.get().strip(),
            "notes": self.notes.get("1.0", "end").strip(), "status": status,
        }
        self.result = self.repo.update(self.cable["id"], data) if self.cable else self.repo.create(data)
        return True


class ReferenceDialog(ModalDialog):
    def __init__(self, parent, repo, cable_repo, reference=None):
        self.repo = repo
        self.cable_repo = cable_repo
        self.reference = reference
        self.configs = cable_repo.list_configs()
        self.file_source: str | None = None
        super().__init__(parent, "编辑健康参考" if reference else "新建健康参考", width=760, height=680)

    def build_body(self, parent):
        ref = self.reference or {}
        self.ref_no_var = tk.StringVar(value=ref.get("ref_no", ""))
        self.date_var = tk.StringVar(value=str(ref.get("created_at_ref") or now_iso())[:19].replace("T", " "))
        self.frontend_var = tk.StringVar(value=FRONTEND_LABELS.get(ref.get("frontend", "resistive_divider"), "电阻功分器"))
        self.firmware_var = tk.StringVar(value=ref.get("firmware_version", self.db_setting("firmware_version", "FW63 V1.0")))
        self.file_var = tk.StringVar(value=ref.get("file_path", ""))
        self.valid_var = tk.BooleanVar(value=bool(ref.get("is_valid", 1)))
        options = ["（不绑定）"] + [f"{c['code']}｜{c['name']}" for c in self.configs]
        current = next((f"{c['code']}｜{c['name']}" for c in self.configs if c["id"] == ref.get("config_id")), "（不绑定）")
        self.config_var = tk.StringVar(value=current)
        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="both", expand=True)
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        self._field(form, "参考编号 *", self.ref_no_var, 0, 0, "如 REF-15m-34m；必须唯一")
        self._field(form, "建立日期时间", self.date_var, 0, 1, "ISO 时间或 YYYY-MM-DD HH:MM:SS")
        self._combo(form, "对应线缆组合", self.config_var, options, 1, 0)
        self._combo(form, "模拟前端", self.frontend_var, list(FRONTEND_LABELS.values()), 1, 1)
        self._field(form, "固件版本", self.firmware_var, 2, 0)
        valid_frame = tk.Frame(form, bg=COLORS["bg"])
        valid_frame.grid(row=2, column=1, sticky="w", pady=5)
        tk.Checkbutton(valid_frame, text="参考有效", variable=self.valid_var, bg=COLORS["bg"],
                       activebackground=COLORS["bg"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        file_frame = tk.Frame(form, bg=COLORS["bg"])
        file_frame.grid(row=3, column=0, columnspan=2, sticky="ew", pady=6)
        tk.Label(file_frame, text="相关数据文件", bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
        row = tk.Frame(file_frame, bg=COLORS["bg"])
        row.pack(fill="x", pady=(2, 0))
        ttk.Entry(row, textvariable=self.file_var, state="readonly").pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="选择…", command=self._choose_file).pack(side="left", padx=(6, 0))
        tk.Label(form, text="备注", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).grid(row=4, column=0, columnspan=2, sticky="w", pady=(8, 2))
        self.notes = tk.Text(form, height=5, wrap="word", relief="solid", bd=1, font=("Microsoft YaHei UI", 9))
        self.notes.grid(row=5, column=0, columnspan=2, sticky="nsew", pady=(0, 4))
        self.notes.insert("1.0", ref.get("notes", ""))
        tk.Label(form, text="参考条件不匹配时程序仍允许保存诊断数据，但会提示并在统计中单独标注。",
                 bg=COLORS["bg"], fg=COLORS["warning"], font=("Microsoft YaHei UI", 8),
                 justify="left", wraplength=650).grid(row=6, column=0, columnspan=2, sticky="w", pady=(8, 0))

    def db_setting(self, key, default):
        try:
            return self.master.db.get_setting(key, default)
        except Exception:
            return default

    def _field(self, parent, label, var, row, col, hint=""):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))
        if hint:
            tk.Label(frame, text=hint, bg=COLORS["bg"], fg="#87969C", font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")

    def _combo(self, parent, label, var, values, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Combobox(frame, textvariable=var, values=values, state="readonly").pack(fill="x", pady=(2, 0))

    def _choose_file(self):
        path = filedialog.askopenfilename(parent=self, title="选择健康参考数据文件")
        if path:
            self.file_source = path
            self.file_var.set(path)

    def on_save(self):
        config_id = None
        label = self.config_var.get()
        if label != "（不绑定）":
            config_id = next((c["id"] for c in self.configs if f"{c['code']}｜{c['name']}" == label), None)
        file_path = self.file_var.get().strip()
        if self.file_source:
            file_path = self.repo.save_file(self.ref_no_var.get().strip() or "reference", self.file_source)
        data = {
            "ref_no": self.ref_no_var.get().strip(), "created_at_ref": self.date_var.get().strip(),
            "config_id": config_id,
            "frontend": next((k for k, v in FRONTEND_LABELS.items() if v == self.frontend_var.get()), "resistive_divider"),
            "firmware_version": self.firmware_var.get().strip(), "notes": self.notes.get("1.0", "end").strip(),
            "file_path": file_path, "is_valid": self.valid_var.get(),
        }
        self.result = self.repo.update(self.reference["id"], data) if self.reference else self.repo.create(data)
        return True


class ComboEditor(ModalDialog):
    def __init__(self, parent, repo, combo=None):
        self.repo = repo
        self.combo = combo or {}
        self.items: list[dict] = []
        self.cable_choices = self.repo.db.query("SELECT id,code,name,physical_length_m FROM cables WHERE status!='retired' ORDER BY physical_length_m,code")
        self.board_choices = self.repo.db.query("SELECT id,code,name,board_type FROM boards WHERE status!='retired' ORDER BY code")
        if combo:
            self.items = [
                {
                    "item_type": item["item_type"], "cable_id": item.get("cable_id"),
                    "board_id": item.get("board_id"), "label": item.get("label"),
                    "length_m": float(item.get("length_m") or 0), "correction_m": float(item.get("correction_m") or 0),
                    "board_type": item.get("board_type"), "board_code": item.get("board_code"),
                    "notes": item.get("notes", ""),
                }
                for item in combo.get("items", [])
            ]
        super().__init__(parent, "编辑线缆组合" if combo else "新建线缆组合", width=940, height=780)

    def build_body(self, parent):
        meta = tk.Frame(parent, bg=COLORS["bg"])
        meta.pack(fill="x")
        meta.grid_columnconfigure(0, weight=1)
        meta.grid_columnconfigure(1, weight=2)
        self.code_var = tk.StringVar(value=self.combo.get("code", ""))
        self.name_var = tk.StringVar(value=self.combo.get("name", ""))
        self.desc_var = tk.StringVar(value=self.combo.get("description", ""))
        for col, (label, var) in enumerate([("组合代号 *", self.code_var), ("组合名称 *", self.name_var), ("描述", self.desc_var)]):
            frame = tk.Frame(meta, bg=COLORS["bg"])
            frame.grid(row=0, column=col, sticky="ew", padx=(0, 12), pady=4)
            tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
            ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))

        add = tk.Frame(parent, bg=COLORS["bg"])
        add.pack(fill="x", pady=(10, 6))
        tk.Label(add, text="添加线段", bg=COLORS["bg"], fg=COLORS["text"], font=("Microsoft YaHei UI", 9, "bold")).pack(side="left")
        cable_values = [f"{c['code']}｜{c['name']}（{c['physical_length_m']:g} m）" for c in self.cable_choices]
        self.cable_var = tk.StringVar(value=cable_values[0] if cable_values else "")
        self.cable_combo = ttk.Combobox(add, textvariable=self.cable_var,
                                        values=cable_values, state="readonly", width=27)
        self.cable_combo.pack(side="left", padx=(8, 4))
        ttk.Button(add, text="+ 线缆", command=self._add_cable, style="Ghost.TButton").pack(side="left", padx=(0, 8))
        board_values = [f"{b['code']}｜{b['name']}" for b in self.board_choices]
        self.board_var = tk.StringVar(value=board_values[0] if board_values else "")
        ttk.Combobox(add, textvariable=self.board_var, values=board_values, state="readonly", width=25).pack(side="left", padx=(0, 4))
        ttk.Button(add, text="+ 测试板", command=self._add_board, style="Ghost.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(add, text="+ 连接器", command=lambda: self._add_simple("connector", "连接器 / 转接头"),
                   style="Ghost.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(add, text="+ 终端", command=lambda: self._add_simple("termination", "50Ω 终端"),
                   style="Ghost.TButton").pack(side="left")

        table_frame = tk.Frame(parent, bg=COLORS["bg"])
        table_frame.pack(fill="both", expand=True)
        self.table = DataTable(
            table_frame,
            [
                {"key": "order", "label": "序", "width": 38, "anchor": "center"},
                {"key": "type_label", "label": "类型", "width": 70},
                {"key": "label", "label": "内容", "width": 300},
                {"key": "length_m", "label": "长度 m", "width": 80, "digits": 3, "anchor": "e"},
                {"key": "correction_m", "label": "修正 m", "width": 80, "digits": 3, "anchor": "e"},
            ],
            height=9,
            on_double_click=lambda row: self._edit_item(),
        )
        self.table.pack(fill="both", expand=True)
        actions = tk.Frame(table_frame, bg=COLORS["bg"])
        actions.pack(fill="x", pady=(6, 0))
        for text, command in [("编辑参数", self._edit_item), ("上移", lambda: self._move(-1)),
                              ("下移", lambda: self._move(1)), ("移除", self._remove_item)]:
            ttk.Button(actions, text=text, command=command, style="Ghost.TButton").pack(side="left", padx=(0, 6))

        self.layout_label = tk.Label(
            parent, text="", bg="#EAF4F4", fg=COLORS["primary"], font=("Microsoft YaHei UI", 9),
            anchor="w", justify="left", padx=10, pady=8, wraplength=860,
        )
        self.layout_label.pack(fill="x", pady=(8, 0))
        tk.Label(parent, text="顺序从 DUT 近端向远端排列。测试板/连接器修正值影响其自身及后续位置；物理长度不等于电气长度。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8),
                 wraplength=880, justify="left").pack(fill="x", pady=(4, 0))
        self._refresh_items()

    def _add_cable(self):
        value = self.cable_combo.get()
        if not value:
            return
        code = value.split("｜", 1)[0]
        cable = next((c for c in self.cable_choices if c["code"] == code), None)
        if not cable:
            return
        self.items.append(
            {
                "item_type": "cable", "cable_id": cable["id"], "board_id": None,
                "label": f"线缆 {cable['code']}｜{cable['name']}",
                "length_m": float(cable["physical_length_m"]), "correction_m": 0.0,
            }
        )
        self._refresh_items()

    def _add_board(self):
        value = self.board_var.get()
        if not value:
            return
        code = value.split("｜", 1)[0]
        board = next((b for b in self.board_choices if b["code"] == code), None)
        if not board:
            return
        self.items.append(
            {
                "item_type": "board", "cable_id": None, "board_id": board["id"],
                "label": f"测试板 {board['code']}｜{board['name']}",
                "length_m": 0.0, "correction_m": 0.0,
                "board_type": board["board_type"], "board_code": board["code"],
            }
        )
        self._refresh_items()

    def _add_simple(self, item_type, label):
        self.items.append(
            {
                "item_type": item_type, "cable_id": None, "board_id": None,
                "label": label, "length_m": 0.0, "correction_m": 0.0,
            }
        )
        self._refresh_items()

    def _selected_item(self):
        row = self.table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请先选择一行", parent=self)
            return None
        return row.get("_index")

    def _edit_item(self):
        index = self._selected_item()
        if index is None:
            return
        item = self.items[index]
        length_var = tk.StringVar(value=str(item.get("length_m") or 0))
        correction_var = tk.StringVar(value=str(item.get("correction_m") or 0))
        top = tk.Toplevel(self)
        top.title("编辑线段参数")
        top.configure(bg=COLORS["bg"])
        top.transient(self)
        top.grab_set()
        top.geometry("480x260")
        tk.Label(top, text=item["label"], bg=COLORS["bg"], font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=20, pady=(16, 10))
        row = tk.Frame(top, bg=COLORS["bg"])
        row.pack(fill="x", padx=20)
        tk.Label(row, text="长度 (m)", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).grid(row=0, column=0, sticky="w")
        ttk.Entry(row, textvariable=length_var).grid(row=1, column=0, sticky="ew", pady=(2, 8))
        tk.Label(row, text="电气长度修正 (m)", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).grid(row=2, column=0, sticky="w")
        ttk.Entry(row, textvariable=correction_var).grid(row=3, column=0, sticky="ew", pady=(2, 8))
        row.grid_columnconfigure(0, weight=1)

        def save():
            try:
                length = safe_float(length_var.get())
                correction = safe_float(correction_var.get())
                if length is None or length < 0 or correction is None:
                    raise ValueError("长度须为非负数，修正须为数字")
                self.items[index]["length_m"] = length
                self.items[index]["correction_m"] = correction
                top.destroy()
                self._refresh_items()
            except Exception as exc:
                messagebox.showerror("参数无效", str(exc), parent=top)

        buttons = tk.Frame(top, bg=COLORS["bg"])
        buttons.pack(fill="x", padx=20, pady=12)
        ttk.Button(buttons, text="取消", command=top.destroy).pack(side="right")
        ttk.Button(buttons, text="确定", command=save, style="Primary.TButton").pack(side="right", padx=(0, 8))

    def _move(self, delta):
        index = self._selected_item()
        if index is None:
            return
        new_index = index + delta
        if new_index < 0 or new_index >= len(self.items):
            return
        self.items[index], self.items[new_index] = self.items[new_index], self.items[index]
        self._refresh_items()
        self.table.tree.selection_set(self.table.tree.get_children()[new_index])

    def _remove_item(self):
        index = self._selected_item()
        if index is None:
            return
        self.items.pop(index)
        self._refresh_items()

    def _refresh_items(self):
        rows = []
        type_labels = {"cable": "线缆", "board": "测试板", "connector": "连接器", "termination": "终端"}
        for index, item in enumerate(self.items):
            rows.append(
                {
                    "_index": index,
                    "_iid": f"item-{index}",
                    "order": index + 1,
                    "type_label": type_labels.get(item["item_type"], item["item_type"]),
                    "label": item.get("label", ""),
                    "length_m": item.get("length_m", 0),
                    "correction_m": item.get("correction_m", 0),
                }
            )
        self.table.set_rows(rows)
        layout = self.repo.calculate_layout(self.items)
        positions = "；".join(
            f"{b['board_code']} @ {b['theoretical_distance_m']:.3f} m" for b in layout["boards"]
        ) or "无异常测试板"
        self.layout_label.configure(
            text=f"总长度：{layout['total_length_m']:.3f} m　连接器：{layout['connector_count']} 个　"
                 f"测试板位置：{positions}"
        )

    def on_save(self):
        data = {
            "code": self.code_var.get().strip(), "name": self.name_var.get().strip(),
            "description": self.desc_var.get().strip(),
        }
        self.result = self.repo.save_config(
            data, self.items, config_id=self.combo.get("id") if self.combo else None
        )
        return True


class CablesReferencesPage(BasePage):
    key = "cables"
    title = "线缆与参考"
    subtitle = "维护线缆资产、线缆组合、健康参考及条件一致性"

    def build(self):
        header = page_header(
            self, "线缆与健康参考", "健康参考必须与实际线缆拓扑、前端和固件条件对应。"
        )
        header.pack(fill="x", pady=(4, 12))
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)
        self.tab_cables = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_combos = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_refs = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.notebook.add(self.tab_cables, text="  线缆资产  ")
        self.notebook.add(self.tab_combos, text="  线缆组合  ")
        self.notebook.add(self.tab_refs, text="  健康参考  ")
        self._build_cables()
        self._build_combos()
        self._build_refs()
        self.notebook.bind("<<NotebookTabChanged>>", lambda event: self.refresh_current_tab())

    def _build_cables(self):
        toolbar = tk.Frame(self.tab_cables, bg=COLORS["bg"])
        toolbar.pack(fill="x", pady=(12, 8))
        ttk.Button(toolbar, text="新增线缆", command=self._new_cable, style="Primary.TButton").pack(side="left")
        ttk.Button(toolbar, text="编辑", command=self._edit_cable, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(toolbar, text="删除", command=self._delete_cable, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.cable_count = tk.Label(toolbar, text="", bg=COLORS["bg"], fg=COLORS["muted"],
                                    font=("Microsoft YaHei UI", 9))
        self.cable_count.pack(side="right")
        self.cable_table = DataTable(
            self.tab_cables,
            [
                {"key": "code", "label": "代号", "width": 72},
                {"key": "name", "label": "名称", "width": 180},
                {"key": "physical_length_m", "label": "物理长度 m", "width": 95, "digits": 2, "anchor": "e"},
                {"key": "model", "label": "型号", "width": 140},
                {"key": "z0", "label": "Z0 Ω", "width": 70, "digits": 1, "anchor": "e"},
                {"key": "velocity_factor", "label": "速度系数", "width": 80, "digits": 2, "anchor": "e"},
                {"key": "status_label", "label": "状态", "width": 60},
                {"key": "notes", "label": "备注", "width": 260},
            ],
            height=14, on_double_click=lambda row: self._edit_cable(row),
        )
        self.cable_table.pack(fill="both", expand=True)

    def _build_combos(self):
        toolbar = tk.Frame(self.tab_combos, bg=COLORS["bg"])
        toolbar.pack(fill="x", pady=(12, 8))
        ttk.Button(toolbar, text="新建组合", command=self._new_combo, style="Primary.TButton").pack(side="left")
        ttk.Button(toolbar, text="编辑组合", command=self._edit_combo, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(toolbar, text="删除", command=self._delete_combo, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.combo_count = tk.Label(toolbar, text="", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9))
        self.combo_count.pack(side="right")
        self.combo_table = DataTable(
            self.tab_combos,
            [
                {"key": "code", "label": "代号", "width": 85},
                {"key": "name", "label": "名称", "width": 200},
                {"key": "total_length_m", "label": "计算总长 m", "width": 110, "digits": 3, "anchor": "e"},
                {"key": "connector_count", "label": "连接器", "width": 70, "anchor": "center"},
                {"key": "item_count", "label": "线段数", "width": 65, "anchor": "center"},
                {"key": "config_count", "label": "引用实验", "width": 75, "anchor": "center"},
                {"key": "description", "label": "描述", "width": 300},
            ],
            height=14, on_double_click=lambda row: self._edit_combo(row),
        )
        self.combo_table.pack(fill="both", expand=True)
        hint = tk.Label(self.tab_combos, text="组合用于自动计算各测试板理论位置和异常间距；实际电气长度可通过每段修正值调整。",
                        bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8), anchor="w")
        hint.pack(fill="x", pady=(8, 0))

    def _build_refs(self):
        toolbar = tk.Frame(self.tab_refs, bg=COLORS["bg"])
        toolbar.pack(fill="x", pady=(12, 8))
        ttk.Button(toolbar, text="新建参考", command=self._new_ref, style="Primary.TButton").pack(side="left")
        ttk.Button(toolbar, text="编辑", command=self._edit_ref, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(toolbar, text="无效 / 有效", command=self._toggle_ref, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(toolbar, text="打开数据文件", command=self._open_ref_file, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(toolbar, text="删除", command=self._delete_ref, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.ref_count = tk.Label(toolbar, text="", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9))
        self.ref_count.pack(side="right")
        self.ref_table = DataTable(
            self.tab_refs,
            [
                {"key": "ref_no", "label": "参考编号", "width": 145},
                {"key": "created_at_ref", "label": "建立时间", "width": 150},
                {"key": "cable_config", "label": "线缆组合", "width": 160},
                {"key": "frontend_label", "label": "模拟前端", "width": 105},
                {"key": "firmware_version", "label": "固件", "width": 90},
                {"key": "valid_label", "label": "有效性", "width": 65},
                {"key": "config_count", "label": "引用", "width": 55, "anchor": "center"},
                {"key": "notes", "label": "备注", "width": 250},
            ],
            height=14, on_double_click=lambda row: self._edit_ref(row),
        )
        self.ref_table.pack(fill="both", expand=True)
        tk.Label(self.tab_refs, text="参考条件（线缆组合/前端/固件）与实验不一致时，工作台会提示；不匹配数据不会被自动计入正常验收统计。",
                 bg=COLORS["bg"], fg=COLORS["warning"], font=("Microsoft YaHei UI", 8), anchor="w",
                 justify="left", wraplength=900).pack(fill="x", pady=(8, 0))

    def refresh(self):
        self.refresh_current_tab()

    def refresh_current_tab(self):
        try:
            index = self.notebook.index(self.notebook.select()) if self.notebook.select() else 0
        except tk.TclError:
            index = 0
        if index == 0:
            self._refresh_cables()
        elif index == 1:
            self._refresh_combos()
        else:
            self._refresh_refs()

    def _refresh_cables(self):
        cables = self.app.repos.cables.list()
        rows = []
        for cable in cables:
            rows.append(
                {
                    **cable,
                    "status_label": {"available": "可用", "damaged": "损坏", "retired": "停用"}.get(cable["status"], cable["status"]),
                    "_status_tag": {"damaged": "bad", "retired": "muted"}.get(cable["status"], ""),
                }
            )
        self.cable_table.set_rows(rows)
        self.cable_count.configure(text=f"共 {len(rows)} 段")

    def _refresh_combos(self):
        combos = self.app.repos.cables.list_configs()
        self.combo_table.set_rows(combos)
        self.combo_count.configure(text=f"共 {len(combos)} 个组合")

    def _refresh_refs(self):
        refs = self.app.repos.references.list()
        rows = []
        for ref in refs:
            rows.append(
                {
                    **ref,
                    "cable_config": f"{ref.get('cable_config_code') or '—'}｜{ref.get('cable_config_name') or ''}".strip("｜"),
                    "frontend_label": FRONTEND_LABELS.get(ref.get("frontend"), ref.get("frontend")),
                    "valid_label": "有效" if ref.get("is_valid") else "无效",
                    "_status_tag": "" if ref.get("is_valid") else "muted",
                }
            )
        self.ref_table.set_rows(rows)
        self.ref_count.configure(text=f"共 {len(rows)} 个参考")

    def _new_cable(self):
        dialog = CableDialog(self, self.app.repos.cables)
        if dialog.show():
            self._refresh_cables()
            self.app.notify("线缆已新增", "success")

    def _edit_cable(self, row=None):
        row = row or self.cable_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择线缆", parent=self)
            return
        cable = self.app.repos.cables.get(row["id"])
        if not cable:
            return
        dialog = CableDialog(self, self.app.repos.cables, cable)
        if dialog.show():
            self._refresh_cables()
            self.app.notify("线缆已保存", "success")

    def _delete_cable(self):
        row = self.cable_table.selected_row()
        if not row:
            return
        if not messagebox.askyesno("删除线缆", f"确定删除 {row['code']}？\n若被组合引用将拒绝删除。", parent=self):
            return
        try:
            self.app.repos.cables.delete(row["id"])
            self._refresh_cables()
            self.app.notify("线缆已删除", "success")
        except Exception as exc:
            self.app.show_error("删除失败", exc)

    def _new_combo(self):
        dialog = ComboEditor(self, self.app.repos.cables)
        if dialog.show():
            self._refresh_combos()
            self.app.notify("线缆组合已创建", "success")

    def _edit_combo(self, row=None):
        row = row or self.combo_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择线缆组合", parent=self)
            return
        combo = self.app.repos.cables.get_config(row["id"])
        if not combo:
            return
        dialog = ComboEditor(self, self.app.repos.cables, combo)
        if dialog.show():
            self._refresh_combos()
            self.app.notify("线缆组合已保存", "success")

    def _delete_combo(self):
        row = self.combo_table.selected_row()
        if not row:
            return
        if not messagebox.askyesno("删除线缆组合", f"确定删除 {row['code']}？", parent=self):
            return
        try:
            self.app.repos.cables.delete_config(row["id"])
            self._refresh_combos()
            self.app.notify("线缆组合已删除", "success")
        except Exception as exc:
            self.app.show_error("删除失败", exc)

    def _new_ref(self):
        dialog = ReferenceDialog(self, self.app.repos.references, self.app.repos.cables)
        if dialog.show():
            self._refresh_refs()
            self.app.notify("健康参考已创建", "success")

    def _edit_ref(self, row=None):
        row = row or self.ref_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择健康参考", parent=self)
            return
        ref = self.app.repos.references.get(row["id"])
        if not ref:
            return
        dialog = ReferenceDialog(self, self.app.repos.references, self.app.repos.cables, ref)
        if dialog.show():
            self._refresh_refs()
            self.app.notify("健康参考已保存", "success")

    def _toggle_ref(self):
        row = self.ref_table.selected_row()
        if not row:
            return
        try:
            self.app.repos.references.set_valid(row["id"], not bool(row["is_valid"]))
            self._refresh_refs()
            self.app.notify("参考有效性已更新", "success")
        except Exception as exc:
            self.app.show_error("操作失败", exc)

    def _open_ref_file(self):
        row = self.ref_table.selected_row()
        if not row:
            return
        ref = self.app.repos.references.get(row["id"])
        if not ref or not ref.get("file_path"):
            messagebox.showinfo("提示", "该参考没有关联文件", parent=self)
            return
        from ..widgets import open_local_path

        try:
            open_local_path(config.DATA_DIR / ref["file_path"])
        except Exception as exc:
            self.app.show_error("无法打开文件", exc)

    def _delete_ref(self):
        row = self.ref_table.selected_row()
        if not row:
            return
        if not messagebox.askyesno("删除健康参考", f"确定删除参考 {row['ref_no']}？\n若被实验引用将拒绝删除。", parent=self):
            return
        try:
            self.app.repos.references.delete(row["id"])
            self._refresh_refs()
            self.app.notify("健康参考已删除", "success")
        except Exception as exc:
            self.app.show_error("删除失败", exc)
