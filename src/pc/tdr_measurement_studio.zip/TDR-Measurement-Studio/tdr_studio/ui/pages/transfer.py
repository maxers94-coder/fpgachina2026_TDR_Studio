"""数据导入导出页面。"""
from __future__ import annotations

import os
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from ... import config
from ...config import COLORS
from ...services.excel_import import import_workbook, list_import_reports
from ...services.export_service import (
    export_ai_package,
    export_csv_zip,
    export_excel,
    export_json,
)
from ..base import BasePage
from ..theme import card
from ..widgets import page_header, section_card, open_local_path


class TransferPage(BasePage):
    key = "transfer"
    title = "数据导入导出"
    subtitle = "Excel 计划导入、单次原始数据导出与 AI 分析数据包"

    def build(self):
        header = page_header(self, "数据导入导出", "所有导出均为本地文件；AI 数据包包含完整单次记录、结构说明与校验信息。")
        header.pack(fill="x", pady=(4, 10))
        self.scroll_holder = tk.Frame(self, bg=COLORS["bg"])
        self.scroll_holder.pack(fill="both", expand=True)
        # 使用普通 Grid 让两个主要卡片自适应，底部报告可滚动
        columns = tk.Frame(self.scroll_holder, bg=COLORS["bg"])
        columns.pack(fill="both", expand=True)
        left = tk.Frame(columns, bg=COLORS["bg"], width=470)
        left.pack(side="left", fill="both", padx=(0, 8))
        left.pack_propagate(False)
        right = tk.Frame(columns, bg=COLORS["bg"])
        right.pack(side="left", fill="both", expand=True)

        import_card, import_body = section_card(left, "Excel 测量矩阵导入", "FW63 初验 79 组")
        import_card.pack(fill="both", expand=True)
        tk.Label(import_body, text="来源文件", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
        path_row = tk.Frame(import_body, bg=COLORS["card"])
        path_row.pack(fill="x", pady=(2, 8))
        self.path_var = tk.StringVar(value=str(config.DEFAULT_WORKBOOK))
        ttk.Entry(path_row, textvariable=self.path_var).pack(side="left", fill="x", expand=True)
        ttk.Button(path_row, text="浏览…", command=self._browse, style="Ghost.TButton").pack(side="left", padx=(5, 0))
        ttk.Button(import_body, text="使用内置 FW63 矩阵", command=lambda: self.path_var.set(str(config.DEFAULT_WORKBOOK)),
                   style="Ghost.TButton").pack(anchor="w")
        self.allow_repeat = tk.BooleanVar(value=False)
        ttk.Checkbutton(import_body, text="允许重复导入同一文件",
                        variable=self.allow_repeat).pack(anchor="w", pady=(10, 2))
        tk.Label(import_body, text="默认按 SHA-256 阻止重复建组；勾选后生成新副本。",
                 bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(0, 4))
        ttk.Button(import_body, text="开始导入", command=self._do_import,
                   style="Primary.TButton").pack(fill="x", pady=(8, 4))
        tk.Label(import_body, text="导入仅建立计划与测试板资产，不把 Excel 中的实测字段当作正式结果。\n"
                                   "重复编号会自动加后缀并写入导入报告；不会静默丢弃。",
                 bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8),
                 justify="left", wraplength=380).pack(anchor="w", pady=(6, 0))
        self.import_summary = tk.Label(import_body, text="", bg="#EAF4F4", fg=COLORS["primary"],
                                       font=("Microsoft YaHei UI", 9), anchor="w", justify="left",
                                       padx=10, pady=8, wraplength=370)
        self.import_summary.pack(fill="x", pady=(10, 0))
        self.import_summary.configure(text="尚未执行导入。\n内置矩阵路径：" + config.DEFAULT_WORKBOOK.name)

        export_card, export_body = section_card(right, "数据导出", "原始记录不丢失；JSON 无 NaN/Infinity")
        export_card.pack(fill="both", expand=True)
        self.data_summary = tk.Label(export_body, text="", bg="#F4F8F9", fg=COLORS["text"],
                                     font=("Microsoft YaHei UI", 9), anchor="w", justify="left",
                                     padx=10, pady=8)
        self.data_summary.pack(fill="x", pady=(0, 10))
        buttons = [
            ("导出 Excel 工作簿", "含项目信息、全部试次、候选、统计与判定", self._export_excel),
            ("导出 CSV 数据集（ZIP）", "规范化表结构，保留 ID 关联", self._export_csv),
            ("导出 JSON 完整数据", "UTF-8、缺失值 null、单位与规则齐全", self._export_json),
        ]
        for text, hint, command in buttons:
            row = tk.Frame(export_body, bg=COLORS["card"])
            row.pack(fill="x", pady=3)
            ttk.Button(row, text=text, command=command, style="Ghost.TButton", width=26).pack(side="left")
            tk.Label(row, text=hint, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(10, 0))
        tk.Frame(export_body, bg=COLORS["border"], height=1).pack(fill="x", pady=10)
        tk.Label(export_body, text="AI 分析数据包", bg=COLORS["card"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w")
        self.include_attachments = tk.BooleanVar(value=True)
        self.include_figures = tk.BooleanVar(value=True)
        ttk.Checkbutton(export_body, text="包含原始日志/截图附件", variable=self.include_attachments).pack(anchor="w")
        ttk.Checkbutton(export_body, text="包含由真实数据生成的 PNG 图表", variable=self.include_figures).pack(anchor="w")
        ttk.Button(export_body, text="导出 AI 分析数据包", command=self._export_ai,
                   style="Primary.TButton").pack(fill="x", pady=(8, 4))
        tk.Label(export_body, text="目录：TDR_Experiment_Export/\n"
                                   "manifest.json、metadata/、measurements/、statistics/、figures/、attachments/。\n"
                                   "manifest 含数据版本、试次数量与各文件 SHA-256。",
                 bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8),
                 justify="left", wraplength=480).pack(anchor="w", pady=(6, 0))
        path_row2 = tk.Frame(export_body, bg=COLORS["card"])
        path_row2.pack(fill="x", pady=(10, 0))
        ttk.Button(path_row2, text="打开导出目录", command=lambda: self._open(config.EXPORTS_DIR),
                   style="Ghost.TButton").pack(side="left")
        ttk.Button(path_row2, text="打开数据目录", command=lambda: self._open(config.DATA_DIR),
                   style="Ghost.TButton").pack(side="left", padx=(6, 0))

        report_card, report_body = section_card(self.scroll_holder, "最近导入报告", "字段映射、警告、错误与逐行结果")
        report_card.pack(fill="both", expand=True, pady=(10, 0))
        self.report_text = tk.Text(report_body, height=12, wrap="word", font=("Microsoft YaHei UI", 9),
                                   relief="solid", bd=1, bg="#FBFCFC")
        scroll = ttk.Scrollbar(report_body, orient="vertical", command=self.report_text.yview)
        self.report_text.configure(yscrollcommand=scroll.set)
        self.report_text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.report_text.insert("1.0", "尚无导入报告。\n")
        self.report_text.configure(state="disabled")
        self.last_export: Path | None = None
        self._report_loaded = False

    def refresh(self):
        counts = self.db.counts()
        tested = int(self.db.scalar("SELECT COUNT(*) FROM experiment_runs r WHERE EXISTS(SELECT 1 FROM trials t WHERE t.run_id=r.id)", default=0) or 0)
        self.data_summary.configure(
            text=f"实验配置：{counts['experiment_configs']} 组\n"
                 f"有实测数据的实验：{tested} 次运行 · 原始试次：{counts['trials']} 条\n"
                 f"检测候选：{counts['detected_candidates']} 条 · 附件：{counts['attachments']} 个\n"
                 f"未测试配置不会被计入总体统计。"
        )
        reports = list_import_reports(self.db, limit=3)
        if reports:
            latest = reports[0]
            report = latest.get("report", {})
            self.import_summary.configure(
                text=f"最近导入：{latest['imported_at'][:19].replace('T', ' ')}\n"
                     f"{Path(report.get('source_name') or latest['source_file']).name}\n"
                     f"导入 {latest['imported_count']} 组 · 警告 {latest['warning_count']} · 错误 {latest['error_count']}"
            )
            if not self._report_loaded:
                self._show_report(report)
                self._report_loaded = True

    def _browse(self):
        path = filedialog.askopenfilename(
            parent=self, title="选择 Excel 测量矩阵",
            filetypes=[("Excel 工作簿", "*.xlsx *.xlsm"), ("所有文件", "*.*")],
        )
        if path:
            self.path_var.set(path)

    def _do_import(self):
        path = self.path_var.get().strip()
        if not path:
            messagebox.showinfo("提示", "请选择 Excel 文件", parent=self)
            return
        if not messagebox.askyesno(
            "确认导入",
            "将导入测量矩阵和必要的测试板资产。\n不会导入 Excel 中的实测结果为正式数据。\n继续？",
            parent=self,
        ):
            return
        self.app.root.configure(cursor="watch")
        self.app.root.update_idletasks()
        try:
            report = import_workbook(self.db, path, allow_repeat=self.allow_repeat.get())
        except Exception as exc:
            self.app.show_error("导入失败", exc)
            return
        finally:
            self.app.root.configure(cursor="")
        self._show_report(report)
        self._report_loaded = True
        if report.get("already_imported"):
            self.app.notify("该文件已导入过，本次未写入", "warning")
        else:
            self.app.notify(
                f"导入完成：{report.get('imported_count', 0)} 组配置，"
                f"{report.get('warning_count', 0)} 条警告，{report.get('error_count', 0)} 条错误",
                "success" if not report.get("error_count") else "warning",
            )
        # 新配置加入后，工作台下次打开重新装载
        self.app.current_config_id = None
        self.refresh()

    def _show_report(self, report: dict):
        lines = []
        if report.get("already_imported"):
            lines.append("该文件 SHA-256 已存在，本次未重复导入。\n")
        lines.append(f"来源：{report.get('source_name') or report.get('source_file')}")
        lines.append(f"工作表：{report.get('sheet', '—')}　表头行：{report.get('header_row', '—')}")
        lines.append(f"扫描行数：{report.get('rows_scanned', 0)}　导入：{report.get('imported_count', 0)}　"
                     f"跳过：{report.get('skipped_count', 0)}　警告：{report.get('warning_count', 0)}　错误：{report.get('error_count', 0)}")
        lines.append(f"批次：{report.get('batch_name', '—')}　计划试次：{report.get('planned_trials', 0)}")
        if report.get("warnings"):
            lines.append("\n警告：")
            lines.extend(f"  • {w}" for w in report["warnings"])
        if report.get("errors"):
            lines.append("\n错误：")
            lines.extend(f"  • {e}" for e in report["errors"])
        if report.get("field_map"):
            lines.append("\n字段映射：")
            for key, value in report["field_map"].items():
                lines.append(f"  {key} ← {value}")
        lines.append("\n逐行结果（前 120 行）：")
        for row in report.get("row_reports", [])[:120]:
            lines.append(f"  第 {row.get('row')} 行  {row.get('source_code')} → {row.get('imported_code') or '未导入'}  [{row.get('status')}]")
        self.report_text.configure(state="normal")
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", "\n".join(lines))
        self.report_text.configure(state="disabled")

    def _ensure_data(self):
        if int(self.db.scalar("SELECT COUNT(*) FROM trials", default=0) or 0) == 0:
            if not messagebox.askyesno(
                "没有实测数据",
                "当前数据库没有实测试次。导出仍可生成配置清单与统计规则，但所有统计值将为 null。\n继续导出？",
                parent=self,
            ):
                return False
        return True

    def _do_export(self, func, label: str, **kwargs):
        if not self._ensure_data():
            return
        self.app.root.configure(cursor="watch")
        self.app.root.update_idletasks()
        try:
            path = func(self.db, **kwargs)
        except Exception as exc:
            self.app.show_error(f"{label}失败", exc)
            return
        finally:
            self.app.root.configure(cursor="")
        self.last_export = Path(path)
        self.app.notify(f"{label}完成：{path.name}", "success")
        if messagebox.askyesno("导出完成", f"已生成：\n{path}\n\n是否打开所在目录？", parent=self):
            self._open(Path(path).parent)

    def _export_excel(self):
        self._do_export(export_excel, "Excel 导出")

    def _export_csv(self):
        self._do_export(export_csv_zip, "CSV 数据集导出")

    def _export_json(self):
        self._do_export(export_json, "JSON 导出")

    def _export_ai(self):
        self._do_export(
            export_ai_package, "AI 数据包导出",
            include_attachments=self.include_attachments.get(),
            include_figures=self.include_figures.get(),
        )

    def _open(self, path):
        try:
            open_local_path(path)
        except Exception as exc:
            self.app.show_error("无法打开目录", exc)
