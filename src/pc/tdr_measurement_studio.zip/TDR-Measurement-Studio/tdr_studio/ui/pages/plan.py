"""实验计划：配置矩阵、类别、批次。"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any

from ...config import (
    COLORS,
    CONFIG_STATUS_LABELS,
    FRONTEND_LABELS,
    MODE_LABELS,
    POLARITY_LABELS,
)
from ...utils import format_number, format_percent, json_loads, parse_distance_list, safe_float, safe_int
from ..base import BasePage
from ..theme import card
from ..widgets import DataTable, ModalDialog, page_header, section_card


def mode_label(code: str) -> str:
    return MODE_LABELS.get(code, code)


def mode_code(label: str) -> str:
    return next((k for k, v in MODE_LABELS.items() if v == label), "single")


class CategoryDialog(ModalDialog):
    def __init__(self, parent, repo, category=None):
        self.repo = repo
        self.category = category
        super().__init__(parent, "编辑实验类别" if category else "新增实验类别", width=620, height=430)

    def build_body(self, parent):
        data = self.category or {}
        self.code_var = tk.StringVar(value=data.get("code", ""))
        self.name_var = tk.StringVar(value=data.get("name", ""))
        self.sort_var = tk.StringVar(value=str(data.get("sort_order", 99)))
        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="both", expand=True)
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        self._field(form, "类别编号 *", self.code_var, 0, 0)
        self._field(form, "类别名称 *", self.name_var, 0, 1)
        self._field(form, "排序值", self.sort_var, 1, 0)
        tk.Label(form, text="说明", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).grid(row=2, column=0, columnspan=2, sticky="w", pady=(8, 2))
        self.desc = tk.Text(form, height=5, wrap="word", relief="solid", bd=1, font=("Microsoft YaHei UI", 9))
        self.desc.grid(row=3, column=0, columnspan=2, sticky="nsew")
        self.desc.insert("1.0", data.get("description", ""))
        tk.Label(form, text="类别可自由增删改；删除仅在没有实验配置引用时允许。", bg=COLORS["bg"],
                 fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).grid(row=4, column=0, columnspan=2, sticky="w", pady=(10, 0))

    def _field(self, parent, label, var, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))

    def on_save(self):
        data = {
            "code": self.code_var.get().strip(), "name": self.name_var.get().strip(),
            "description": self.desc.get("1.0", "end").strip(),
            "sort_order": safe_int(self.sort_var.get(), 99),
        }
        self.result = self.repo.update(self.category["id"], data) if self.category else self.repo.create(data)
        return True


class BatchDialog(ModalDialog):
    def __init__(self, parent, repo, batch=None):
        self.repo = repo
        self.batch = batch
        super().__init__(parent, "编辑实验批次" if batch else "新增实验批次", width=700, height=540)

    def build_body(self, parent):
        data = self.batch or {}
        self.code_var = tk.StringVar(value=data.get("code", ""))
        self.name_var = tk.StringVar(value=data.get("name", ""))
        self.fw_var = tk.StringVar(value=data.get("firmware_version", ""))
        self.frontend_var = tk.StringVar(value=FRONTEND_LABELS.get(data.get("frontend"), "电阻功分器"))
        self.active_var = tk.BooleanVar(value=bool(data.get("is_active", 0)))
        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="both", expand=True)
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        self._field(form, "批次代号 *", self.code_var, 0, 0, "如 FW64-RETEST")
        self._field(form, "批次名称 *", self.name_var, 0, 1, "如 FW64 修改后复测")
        self._field(form, "固件版本", self.fw_var, 1, 0, "例如 FW63 V1.0 / FW64")
        frame = tk.Frame(form, bg=COLORS["bg"])
        frame.grid(row=1, column=1, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text="模拟前端", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Combobox(frame, textvariable=self.frontend_var, values=list(FRONTEND_LABELS.values()), state="readonly").pack(fill="x", pady=(2, 0))
        tk.Checkbutton(form, text="设为当前批次", variable=self.active_var, bg=COLORS["bg"],
                       activebackground=COLORS["bg"], font=("Microsoft YaHei UI", 9)).grid(
            row=2, column=0, sticky="w", pady=6
        )
        tk.Label(form, text="说明", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).grid(row=3, column=0, columnspan=2, sticky="w", pady=(8, 2))
        self.desc = tk.Text(form, height=6, wrap="word", relief="solid", bd=1, font=("Microsoft YaHei UI", 9))
        self.desc.grid(row=4, column=0, columnspan=2, sticky="nsew")
        self.desc.insert("1.0", data.get("description", ""))
        tk.Label(form, text="不同批次不自动混合统计；可在数据分析中手动选择多个批次对比。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).grid(
            row=5, column=0, columnspan=2, sticky="w", pady=(10, 0)
        )

    def _field(self, parent, label, var, row, col, hint=""):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))
        if hint:
            tk.Label(frame, text=hint, bg=COLORS["bg"], fg="#87969C", font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")

    def on_save(self):
        data = {
            "code": self.code_var.get().strip(), "name": self.name_var.get().strip(),
            "firmware_version": self.fw_var.get().strip(),
            "frontend": next((k for k, v in FRONTEND_LABELS.items() if v == self.frontend_var.get()), "resistive_divider"),
            "description": self.desc.get("1.0", "end").strip(),
            "is_active": self.active_var.get(),
        }
        self.result = self.repo.update(self.batch["id"], data) if self.batch else self.repo.create(data)
        return True


class ConfigDialog(ModalDialog):
    def __init__(self, parent, app, config=None):
        self.app = app
        self.repo = app.repos.experiments
        self.config = config
        self.categories = app.repos.categories.list()
        self.batches = app.repos.batches.list()
        self.boards = app.repos.boards.list()
        self.refs = app.repos.references.list(valid_only=False)
        self.cable_configs = app.repos.cables.list_configs()
        self.expected: list[dict[str, Any]] = []
        if config:
            self.expected = json_loads(config.get("expected_anomalies_json"), [])
        self._editing_expected: int | None = None
        super().__init__(parent, "编辑实验配置" if config else "新增临时实验", width=900, height=840, resizable=True)

    def build_body(self, parent):
        data = self.config or {}
        self.code_var = tk.StringVar(value=data.get("code", ""))
        self.name_var = tk.StringVar(value=data.get("name", ""))
        category_label = next((f"{c['code']}｜{c['name']}" for c in self.categories if c["id"] == data.get("category_id")), "")
        batch_label = next((f"{b['code']}｜{b['name']}" for b in self.batches if b["id"] == data.get("batch_id")), "")
        self.category_var = tk.StringVar(value=category_label)
        self.batch_var = tk.StringVar(value=batch_label)
        self.mode_var = tk.StringVar(value=MODE_LABELS.get(data.get("mode"), "单异常"))
        self.priority_var = tk.StringVar(value=data.get("priority", "P1"))
        self.distance_var = tk.StringVar(value="" if data.get("distance_m") is None else str(data.get("distance_m")))
        self.distance_expr_var = tk.StringVar(value=data.get("distance_expr", ""))
        self.repeats_var = tk.StringVar(value=str(data.get("planned_repeats", 5)))
        self.tolerance_var = tk.StringVar(value="" if data.get("tolerance_m") is None else str(data.get("tolerance_m")))
        self.status_var = tk.StringVar(value=CONFIG_STATUS_LABELS.get(data.get("status"), "未开始"))
        self.reference_label_var = tk.StringVar(value=data.get("reference_label", ""))
        board_label = next((f"{b['code']}｜{b['name']}" for b in self.boards if b["id"] == data.get("board_id")), "（不指定）")
        self.board_var = tk.StringVar(value=board_label)
        ref_options = ["（不关联实际参考）"] + [f"{r['ref_no']}｜{r.get('firmware_version') or ''}" for r in self.refs]
        self.ref_var = tk.StringVar(value=next((f"{r['ref_no']}｜{r.get('firmware_version') or ''}" for r in self.refs if r["id"] == data.get("reference_id")), "（不关联实际参考）"))
        combo_options = ["（不绑定线缆组合）"] + [f"{c['code']}｜{c['name']}" for c in self.cable_configs]
        self.combo_var = tk.StringVar(value=next((f"{c['code']}｜{c['name']}" for c in self.cable_configs if c["id"] == data.get("cable_config_id")), "（不绑定线缆组合）"))
        if not self.category_var.get() and self.categories:
            self.category_var.set(f"{self.categories[0]['code']}｜{self.categories[0]['name']}")
        if not self.batch_var.get():
            active = self.app.repos.batches.get_active()
            if active:
                self.batch_var.set(f"{active['code']}｜{active['name']}")

        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="x")
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        form.grid_columnconfigure(2, weight=1)
        self._field(form, "实验编号（留空自动）", self.code_var, 0, 0)
        self._field(form, "实验名称（留空自动）", self.name_var, 1, 0)
        self._combo(form, "实验类别 *", self.category_var, [f"{c['code']}｜{c['name']}" for c in self.categories], 0, 1)
        self._combo(form, "实验批次 *", self.batch_var, [f"{b['code']}｜{b['name']}" for b in self.batches], 1, 1)
        self._combo(form, "实验模式", self.mode_var, list(MODE_LABELS.values()), 0, 2)
        self._combo(form, "优先级", self.priority_var, ["P0", "P1", "P2"], 1, 2)
        self._combo(form, "测试板", self.board_var, ["（不指定）"] + [f"{b['code']}｜{b['name']}" for b in self.boards], 2, 0)
        self._field(form, "真实距离 (m)", self.distance_var, 2, 1)
        self._field(form, "真值表达式", self.distance_expr_var, 2, 2)
        self._field(form, "计划重复次数", self.repeats_var, 3, 0)
        self._field(form, "距离容差 (m，留空用全局)", self.tolerance_var, 3, 1)
        self._combo(form, "状态", self.status_var, list(CONFIG_STATUS_LABELS.values()), 3, 2)
        self._combo(form, "关联健康参考", self.ref_var, ref_options, 4, 0)
        self._combo(form, "线缆组合", self.combo_var, combo_options, 4, 1)
        self._field(form, "参考/基线标识（计划文本）", self.reference_label_var, 4, 2)
        self.mode_var.trace_add("write", lambda *args: self._update_multi_state())
        self.board_var.trace_add("write", lambda *args: self._update_expected_polarity())
        tk.Label(form, text="说明", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).grid(row=5, column=0, columnspan=3, sticky="w", pady=(8, 2))
        self.notes = tk.Text(form, height=3, wrap="word", relief="solid", bd=1, font=("Microsoft YaHei UI", 9))
        self.notes.grid(row=6, column=0, columnspan=3, sticky="ew")
        self.notes.insert("1.0", data.get("notes", ""))

        self.multi_frame = card(parent)
        self.multi_frame.pack(fill="both", expand=True, pady=(12, 0))
        header = tk.Frame(self.multi_frame, bg=COLORS["card"])
        header.pack(fill="x", padx=12, pady=(10, 4))
        tk.Label(header, text="多异常真实定义", bg=COLORS["card"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 10, "bold")).pack(side="left")
        tk.Label(header, text="仅多异常模式使用；单异常由测试板+真值距离自动生成。", bg=COLORS["card"],
                 fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(8, 0))
        add_row = tk.Frame(self.multi_frame, bg=COLORS["card"])
        add_row.pack(fill="x", padx=12, pady=4)
        self.exp_board_var = tk.StringVar(value="")
        self.exp_distance_var = tk.StringVar()
        self.exp_polarity_var = tk.StringVar(value="不确定")
        self.exp_tolerance_var = tk.StringVar()
        board_values = [f"{b['code']}｜{b['name']}" for b in self.boards]
        self.exp_board_combo = ttk.Combobox(add_row, textvariable=self.exp_board_var, values=board_values, state="readonly", width=22)
        self.exp_board_combo.pack(side="left")
        self.exp_board_combo.bind("<<ComboboxSelected>>", lambda event: self._update_expected_polarity())
        ttk.Entry(add_row, textvariable=self.exp_distance_var, width=10).pack(side="left", padx=(6, 0))
        tk.Label(add_row, text="m", bg=COLORS["card"], fg=COLORS["muted"]).pack(side="left", padx=(2, 6))
        ttk.Combobox(add_row, textvariable=self.exp_polarity_var, values=["正", "负", "无", "不确定"], state="readonly", width=7).pack(side="left")
        tk.Label(add_row, text="容差", bg=COLORS["card"], fg=COLORS["muted"]).pack(side="left", padx=(8, 2))
        ttk.Entry(add_row, textvariable=self.exp_tolerance_var, width=8).pack(side="left")
        ttk.Button(add_row, text="添加 / 更新", command=self._add_expected, style="Ghost.TButton").pack(side="left", padx=(8, 0))
        ttk.Button(add_row, text="移除选中", command=self._remove_expected, style="Ghost.TButton").pack(side="left", padx=(4, 0))
        self.exp_table = DataTable(
            self.multi_frame,
            [
                {"key": "anomaly_index", "label": "异常号", "width": 52, "anchor": "center"},
                {"key": "board_code", "label": "测试板", "width": 70},
                {"key": "true_distance_m", "label": "真实距离 m", "width": 100, "digits": 3, "anchor": "e"},
                {"key": "polarity_label", "label": "预期极性", "width": 75, "anchor": "center"},
                {"key": "tolerance_m", "label": "容差 m", "width": 75, "digits": 2, "anchor": "e"},
            ],
            height=5, on_double_click=lambda row: self._load_expected(row),
        )
        self.exp_table.pack(fill="both", expand=True, padx=12, pady=(2, 8))
        tk.Label(parent, text="已有试次时，不允许修改模式、真实距离和测试板；计划重复次数可继续调整且不会删除已录入数据。",
                 bg=COLORS["bg"], fg=COLORS["warning"], font=("Microsoft YaHei UI", 8),
                 justify="left", wraplength=820).pack(fill="x", pady=(8, 0))
        self._refresh_expected()
        self._update_multi_state()

    def _field(self, parent, label, var, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 12), pady=4)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(1, 0))

    def _combo(self, parent, label, var, values, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 12), pady=4)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        ttk.Combobox(frame, textvariable=var, values=values, state="readonly").pack(fill="x", pady=(1, 0))

    def _update_multi_state(self):
        enabled = self.mode_var.get() == "多异常"
        state = "normal" if enabled else "disabled"
        for widget in getattr(self, "multi_frame", []).winfo_children() if hasattr(self, "multi_frame") else []:
            pass
        try:
            self.exp_board_combo.configure(state="readonly" if enabled else "disabled")
        except Exception:
            pass
        # 子控件递归设置
        def set_state(widget):
            try:
                if isinstance(widget, ttk.Entry):
                    widget.configure(state=state)
                elif isinstance(widget, ttk.Button):
                    widget.configure(state=state)
            except Exception:
                pass
            for child in widget.winfo_children():
                set_state(child)
        if hasattr(self, "multi_frame"):
            set_state(self.multi_frame)

    def _selected_category(self):
        label = self.category_var.get()
        return next((c for c in self.categories if f"{c['code']}｜{c['name']}" == label), None)

    def _selected_batch(self):
        label = self.batch_var.get()
        return next((b for b in self.batches if f"{b['code']}｜{b['name']}" == label), None)

    def _selected_board(self):
        label = self.board_var.get()
        return next((b for b in self.boards if f"{b['code']}｜{b['name']}" == label), None)

    def _selected_exp_board(self):
        label = self.exp_board_var.get()
        return next((b for b in self.boards if f"{b['code']}｜{b['name']}" == label), None)

    def _update_expected_polarity(self):
        board = self._selected_exp_board()
        if board:
            self.exp_polarity_var.set(POLARITY_LABELS.get(board.get("polarity"), "不确定"))
        # 单异常模式自动同步测试板极性别无必要显示

    def _refresh_expected(self):
        rows = []
        for index, anomaly in enumerate(self.expected):
            board = next((b for b in self.boards if b["id"] == anomaly.get("board_id")), None)
            rows.append(
                {
                    "_iid": f"exp-{index}",
                    "_index": index,
                    "anomaly_index": index + 1,
                    "board_code": board["code"] if board else anomaly.get("board_code", ""),
                    "true_distance_m": anomaly.get("true_distance_m"),
                    "polarity_label": POLARITY_LABELS.get(anomaly.get("expected_polarity"), "不确定"),
                    "tolerance_m": anomaly.get("tolerance_m"),
                }
            )
        self.exp_table.set_rows(rows)

    def _add_expected(self):
        board = self._selected_exp_board()
        if not board:
            raise ValueError("请选择异常测试板")
        distance = safe_float(self.exp_distance_var.get())
        if distance is None or distance <= 0:
            raise ValueError("请输入有效的真实距离")
        tolerance = safe_float(self.exp_tolerance_var.get())
        polarity = next((k for k, v in POLARITY_LABELS.items() if v == self.exp_polarity_var.get()), "none")
        anomaly = {
            "board_id": board["id"], "board_code": board["code"], "board_name": board["name"],
            "true_distance_m": distance, "expected_polarity": polarity, "tolerance_m": tolerance,
        }
        if self._editing_expected is not None:
            self.expected[self._editing_expected] = anomaly
            self._editing_expected = None
        else:
            self.expected.append(anomaly)
            self.expected.sort(key=lambda x: float(x["true_distance_m"]))
        self.exp_distance_var.set("")
        self._refresh_expected()
        self.result = None

    def _remove_expected(self):
        row = self.exp_table.selected_row()
        if not row:
            return
        index = row.get("_index")
        if index is not None and 0 <= index < len(self.expected):
            self.expected.pop(index)
            self._refresh_expected()

    def _load_expected(self, row):
        if not row:
            return
        index = row.get("_index")
        if index is None:
            return
        anomaly = self.expected[index]
        board = next((b for b in self.boards if b["id"] == anomaly.get("board_id")), None)
        if board:
            self.exp_board_var.set(f"{board['code']}｜{board['name']}")
        self.exp_distance_var.set(str(anomaly.get("true_distance_m", "")))
        self.exp_polarity_var.set(POLARITY_LABELS.get(anomaly.get("expected_polarity"), "不确定"))
        self.exp_tolerance_var.set("" if anomaly.get("tolerance_m") is None else str(anomaly.get("tolerance_m")))
        self._editing_expected = index

    def on_save(self):
        category = self._selected_category()
        batch = self._selected_batch()
        if not category or not batch:
            raise ValueError("请选择实验类别和批次")
        mode = mode_code(self.mode_var.get())
        board = self._selected_board()
        ref_label = self.ref_var.get()
        reference_id = next((r["id"] for r in self.refs if f"{r['ref_no']}｜{r.get('firmware_version') or ''}" == ref_label), None)
        combo_label = self.combo_var.get()
        cable_config_id = next((c["id"] for c in self.cable_configs if f"{c['code']}｜{c['name']}" == combo_label), None)
        data = {
            "code": self.code_var.get().strip(), "name": self.name_var.get().strip(),
            "category_id": category["id"], "batch_id": batch["id"], "mode": mode,
            "priority": self.priority_var.get(), "distance_m": self.distance_var.get().strip() or None,
            "distance_expr": self.distance_expr_var.get().strip(),
            "planned_repeats": safe_int(self.repeats_var.get(), 5),
            "tolerance_m": self.tolerance_var.get().strip() or None,
            "board_id": board["id"] if board else None,
            "reference_id": reference_id, "cable_config_id": cable_config_id,
            "reference_label": self.reference_label_var.get().strip(),
            "status": next((k for k, v in CONFIG_STATUS_LABELS.items() if v == self.status_var.get()), "not_started"),
            "notes": self.notes.get("1.0", "end").strip(),
            "expected_anomalies": self.expected if mode == "multi" else [],
        }
        if mode == "multi" and len(self.expected) < 1:
            raise ValueError("多异常模式至少需要一条真实异常定义")
        self.result = self.repo.update(self.config["id"], data) if self.config else self.repo.create(data)
        return True


class MatrixGeneratorDialog(ModalDialog):
    def __init__(self, parent, app):
        self.app = app
        self.categories = app.repos.categories.list()
        self.batches = app.repos.batches.list()
        self.boards = app.repos.boards.list()
        self.refs = app.repos.references.list(valid_only=False)
        self.combos = app.repos.cables.list_configs()
        super().__init__(parent, "批量生成实验矩阵", width=860, height=760)

    def build_body(self, parent):
        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="x")
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        self.category_var = tk.StringVar(value=f"{self.categories[0]['code']}｜{self.categories[0]['name']}" if self.categories else "")
        active = self.app.repos.batches.get_active()
        self.batch_var = tk.StringVar(value=f"{active['code']}｜{active['name']}" if active else "")
        self.distance_var = tk.StringVar(value="5, 15, 25")
        self.repeats_var = tk.StringVar(value="5")
        self.priority_var = tk.StringVar(value="P0")
        self.tolerance_var = tk.StringVar(value="")
        ref_options = ["（不关联实际参考）"] + [f"{r['ref_no']}｜{r.get('firmware_version') or ''}" for r in self.refs]
        self.ref_var = tk.StringVar(value=ref_options[0])
        combo_options = ["（不绑定线缆组合）"] + [f"{c['code']}｜{c['name']}" for c in self.combos]
        self.combo_var = tk.StringVar(value=combo_options[0])
        self.notes_var = tk.StringVar()
        self._combo(form, "实验类别 *", self.category_var, [f"{c['code']}｜{c['name']}" for c in self.categories], 0, 0)
        self._combo(form, "实验批次 *", self.batch_var, [f"{b['code']}｜{b['name']}" for b in self.batches], 0, 1)
        self._field(form, "测试距离 (m，逗号分隔) *", self.distance_var, 1, 0, "例如 5, 15, 25")
        self._field(form, "每组重复次数 *", self.repeats_var, 1, 1, "每个距离×板组合的重复次数")
        self._combo(form, "优先级", self.priority_var, ["P0", "P1", "P2"], 2, 0)
        self._field(form, "距离容差 (m，留空用全局)", self.tolerance_var, 2, 1)
        self._combo(form, "健康参考", self.ref_var, ref_options, 3, 0)
        self._combo(form, "线缆组合", self.combo_var, combo_options, 3, 1)
        self._field(form, "备注", self.notes_var, 4, 0)
        tk.Label(parent, text="选择测试板（可多选，Ctrl/Shift 多选） *", bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", pady=(10, 3))
        list_frame = tk.Frame(parent, bg=COLORS["bg"])
        list_frame.pack(fill="both", expand=True)
        self.board_list = tk.Listbox(
            list_frame, selectmode="multiple", height=7, font=("Microsoft YaHei UI", 9),
            bg="white", activestyle="none", selectbackground=COLORS["sidebar_active"], exportselection=False,
        )
        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.board_list.yview)
        self.board_list.configure(yscrollcommand=scroll.set)
        self.board_list.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        for board in self.boards:
            self.board_list.insert("end", f"{board['code']}｜{board['name']}｜{board['board_type']}")
        buttons = tk.Frame(parent, bg=COLORS["bg"])
        buttons.pack(fill="x", pady=(6, 0))
        ttk.Button(buttons, text="全选", command=lambda: self.board_list.selection_set(0, "end"), style="Ghost.TButton").pack(side="left")
        ttk.Button(buttons, text="清空选择", command=lambda: self.board_list.selection_clear(0, "end"), style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.preview = tk.Label(parent, text="", bg="#EAF4F4", fg=COLORS["primary"],
                                font=("Microsoft YaHei UI", 9), anchor="w", padx=12, pady=9)
        self.preview.pack(fill="x", pady=(10, 0))
        for var in (self.distance_var, self.repeats_var):
            var.trace_add("write", lambda *args: self._update_preview())
        self.board_list.bind("<<ListboxSelect>>", lambda event: self._update_preview())
        self._update_preview()
        tk.Label(parent, text="生成后每组仍可单独修改重复次数、优先级、状态，或复制/跳过。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(6, 0))

    def _field(self, parent, label, var, row, col, hint=""):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))
        if hint:
            tk.Label(frame, text=hint, bg=COLORS["bg"], fg="#87969C", font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")

    def _combo(self, parent, label, var, values, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Combobox(frame, textvariable=var, values=values, state="readonly").pack(fill="x", pady=(2, 0))

    def _selected_boards(self):
        return [self.boards[index] for index in self.board_list.curselection()]

    def _update_preview(self):
        try:
            distances = parse_distance_list(self.distance_var.get())
            repeats = safe_int(self.repeats_var.get(), 0) or 0
            count = len(self._selected_boards()) * len(distances)
            self.preview.configure(text=f"将生成 {count} 组实验配置，共 {count * repeats} 个计划试次。")
        except Exception:
            self.preview.configure(text="参数不完整")

    def _selected_category(self):
        return next((c for c in self.categories if f"{c['code']}｜{c['name']}" == self.category_var.get()), None)

    def _selected_batch(self):
        return next((b for b in self.batches if f"{b['code']}｜{b['name']}" == self.batch_var.get()), None)

    def on_save(self):
        category = self._selected_category()
        batch = self._selected_batch()
        boards = self._selected_boards()
        distances = parse_distance_list(self.distance_var.get())
        repeats = safe_int(self.repeats_var.get(), 0) or 0
        if not category or not batch:
            raise ValueError("请选择类别和批次")
        if not boards:
            raise ValueError("请至少选择一块测试板")
        if not distances:
            raise ValueError("请输入至少一个有效距离")
        if repeats <= 0:
            raise ValueError("重复次数必须大于 0")
        ref_label = self.ref_var.get()
        reference_id = next((r["id"] for r in self.refs if f"{r['ref_no']}｜{r.get('firmware_version') or ''}" == ref_label), None)
        combo_label = self.combo_var.get()
        cable_config_id = next((c["id"] for c in self.combos if f"{c['code']}｜{c['name']}" == combo_label), None)
        try:
            self.result = self.app.repos.experiments.generate_matrix(
                category_id=category["id"], batch_id=batch["id"],
                board_ids=[b["id"] for b in boards], distances=distances,
                planned_repeats=repeats, priority=self.priority_var.get(),
                tolerance_m=safe_float(self.tolerance_var.get()),
                reference_id=reference_id, cable_config_id=cable_config_id,
                notes=self.notes_var.get().strip(),
            )
        except Exception:
            raise
        return True


class ImportReportDialog(ModalDialog):
    def __init__(self, parent, report: dict[str, Any]):
        self.report = report
        super().__init__(parent, "Excel 导入结果", width=820, height=700, resizable=True)

    def build_body(self, parent):
        self.save_button.configure(text="关闭", command=self.cancel)
        report = self.report
        summary = (
            f"来源：{report.get('source_name') or report.get('source_file')}\n"
            f"导入配置：{report.get('imported_count', 0)}　跳过：{report.get('skipped_count', 0)}　"
            f"警告：{report.get('warning_count', 0)}　错误：{report.get('error_count', 0)}\n"
            f"批次：{report.get('batch_name', '')}　计划试次：{report.get('planned_trials', 0)}"
        )
        tk.Label(parent, text=summary, bg=COLORS["bg"], fg=COLORS["text"], justify="left",
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(fill="x", pady=(0, 8))
        text = tk.Text(parent, wrap="word", font=("Microsoft YaHei UI", 9), relief="solid", bd=1)
        text.pack(fill="both", expand=True)
        lines = []
        if report.get("warnings"):
            lines.append("警告：")
            lines.extend(f"• {item}" for item in report["warnings"])
            lines.append("")
        if report.get("errors"):
            lines.append("错误：")
            lines.extend(f"• {item}" for item in report["errors"])
            lines.append("")
        lines.append("字段映射：")
        for key, value in report.get("field_map", {}).items():
            lines.append(f"• {key} ← {value}")
        lines.append("")
        lines.append("逐行结果：")
        for row in report.get("row_reports", []):
            lines.append(
                f"第 {row.get('row')} 行 {row.get('source_code')} → {row.get('imported_code') or '未导入'} "
                f"[{row.get('status')}]"
            )
        text.insert("1.0", "\n".join(lines) if lines else "无警告和错误。")
        text.configure(state="disabled")

    def on_save(self):
        return False


class PlanPage(BasePage):
    key = "plan"
    title = "实验计划"
    subtitle = "管理实验类别、批次、79 组初验矩阵与自动生成规则"

    def build(self):
        header = page_header(
            self, "实验计划", "原始 Excel 矩阵可导入并随时编辑；自动生成矩阵不会覆盖已有配置。",
            actions=[("批量生成矩阵", self._generate_matrix, "Primary.TButton")],
        )
        header.pack(fill="x", pady=(4, 12))
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)
        self.tab_configs = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_categories = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_batches = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_imports = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.notebook.add(self.tab_configs, text="  实验配置  ")
        self.notebook.add(self.tab_categories, text="  实验类别  ")
        self.notebook.add(self.tab_batches, text="  实验批次  ")
        self.notebook.add(self.tab_imports, text="  导入记录  ")
        self._build_configs()
        self._build_categories()
        self._build_batches()
        self._build_imports()
        self.notebook.bind("<<NotebookTabChanged>>", lambda event: self._refresh_current())

    def _build_configs(self):
        # 汇总条
        summary = tk.Frame(self.tab_configs, bg=COLORS["bg"])
        summary.pack(fill="x", pady=(10, 8))
        self.summary_labels: dict[str, tk.Label] = {}
        for key, label in [("total", "全部"), ("not_started", "未开始"), ("in_progress", "进行中"),
                           ("completed", "已完成"), ("skipped", "已跳过"), ("failed", "失败")]:
            frame = card(summary)
            frame.pack(side="left", padx=(0, 8))
            tk.Label(frame, text=label, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=12, pady=(7, 0))
            value = tk.Label(frame, text="0", bg=COLORS["card"], fg=COLORS["text"],
                             font=("Microsoft YaHei UI", 16, "bold"))
            value.pack(anchor="w", padx=12, pady=(0, 6))
            self.summary_labels[key] = value
        self.planned_label = tk.Label(summary, text="", bg=COLORS["bg"], fg=COLORS["muted"],
                                      font=("Microsoft YaHei UI", 9))
        self.planned_label.pack(side="right")

        filters = card(self.tab_configs)
        filters.pack(fill="x", pady=(0, 8))
        row = tk.Frame(filters, bg=COLORS["card"])
        row.pack(fill="x", padx=12, pady=8)
        self.filter_batch = tk.StringVar(value="全部批次")
        self.filter_category = tk.StringVar(value="全部类别")
        self.filter_status = tk.StringVar(value="全部状态")
        self.filter_priority = tk.StringVar(value="全部优先级")
        self.search_var = tk.StringVar()
        for label, var, width in [
            ("批次", self.filter_batch, 17), ("类别", self.filter_category, 15),
            ("状态", self.filter_status, 9), ("优先级", self.filter_priority, 10),
        ]:
            tk.Label(row, text=label, bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(side="left")
            combo = ttk.Combobox(row, textvariable=var, state="readonly", width=width)
            combo.pack(side="left", padx=(3, 7))
            var._combo = combo  # 仅用于 refresh 时填值
        tk.Label(row, text="搜索", bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(side="left")
        ttk.Entry(row, textvariable=self.search_var, width=16).pack(side="left", padx=(3, 4))
        ttk.Button(row, text="筛选", command=self._refresh_configs, style="Ghost.TButton").pack(side="left", padx=(2, 4))
        ttk.Button(row, text="重置", command=self._reset_filters, style="Ghost.TButton").pack(side="left")

        actions = tk.Frame(self.tab_configs, bg=COLORS["bg"])
        actions.pack(fill="x", pady=(0, 4))
        for text, command in [
            ("生成矩阵", self._generate_matrix), ("新建临时实验", self._new_config),
            ("编辑", self._edit_config), ("复制", self._duplicate_config),
            ("打开工作台", self._open_workbench),
        ]:
            ttk.Button(actions, text=text, command=command,
                       style="Primary.TButton" if text == "生成矩阵" else "Ghost.TButton").pack(side="left", padx=(0, 5))
        actions2 = tk.Frame(self.tab_configs, bg=COLORS["bg"])
        actions2.pack(fill="x", pady=(0, 6))
        for text, command in [
            ("跳过", self._skip_selected), ("恢复待测", self._reset_selected), ("删除", self._delete_config),
            ("上移", lambda: self._move_selected(-1)), ("下移", lambda: self._move_selected(1)),
        ]:
            ttk.Button(actions2, text=text, command=command, style="Ghost.TButton").pack(side="left", padx=(0, 5))
        tk.Label(actions2, text="批量优先级：", bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(10, 2))
        ttk.Button(actions2, text="P0", command=lambda: self._bulk_priority("P0"), style="Ghost.TButton").pack(side="left", padx=(0, 4))
        ttk.Button(actions2, text="P1", command=lambda: self._bulk_priority("P1"), style="Ghost.TButton").pack(side="left", padx=(0, 4))
        ttk.Button(actions2, text="P2", command=lambda: self._bulk_priority("P2"), style="Ghost.TButton").pack(side="left")

        self.config_table = DataTable(
            self.tab_configs,
            [
                {"key": "code", "label": "编号", "width": 58},
                {"key": "priority", "label": "优先", "width": 44, "anchor": "center"},
                {"key": "category_code", "label": "组", "width": 34, "anchor": "center"},
                {"key": "mode_label", "label": "模式", "width": 56},
                {"key": "distance_label", "label": "距离 / 表达式", "width": 90},
                {"key": "board_code", "label": "测试板", "width": 55},
                {"key": "gamma", "label": "理论 Γ", "width": 68, "percent": True, "anchor": "e"},
                {"key": "planned_repeats", "label": "计划", "width": 44, "anchor": "center"},
                {"key": "actual_count", "label": "已测", "width": 44, "anchor": "center"},
                {"key": "status_label", "label": "状态", "width": 58},
                {"key": "batch_code", "label": "批次", "width": 80},
                {"key": "name", "label": "实验名称", "width": 225},
                {"key": "reference_label", "label": "参考标识", "width": 95},
            ],
            height=15, selectmode="extended",
            on_double_click=lambda row: self._open_workbench(row),
        )
        self.config_table.pack(fill="both", expand=True)

    def _build_categories(self):
        bar = tk.Frame(self.tab_categories, bg=COLORS["bg"])
        bar.pack(fill="x", pady=(12, 8))
        ttk.Button(bar, text="新增类别", command=self._new_category, style="Primary.TButton").pack(side="left")
        ttk.Button(bar, text="编辑", command=self._edit_category, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(bar, text="复制", command=self._duplicate_category, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(bar, text="删除", command=self._delete_category, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.category_count = tk.Label(bar, text="", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9))
        self.category_count.pack(side="right")
        self.category_table = DataTable(
            self.tab_categories,
            [
                {"key": "code", "label": "编号", "width": 70},
                {"key": "name", "label": "名称", "width": 250},
                {"key": "config_count", "label": "实验配置", "width": 80, "anchor": "center"},
                {"key": "planned_trials", "label": "计划试次", "width": 85, "anchor": "center"},
                {"key": "trial_count", "label": "已测试次", "width": 85, "anchor": "center"},
                {"key": "is_builtin_label", "label": "内置", "width": 55, "anchor": "center"},
                {"key": "description", "label": "说明", "width": 420},
            ],
            height=15, on_double_click=lambda row: self._edit_category(row),
        )
        self.category_table.pack(fill="both", expand=True)

    def _build_batches(self):
        bar = tk.Frame(self.tab_batches, bg=COLORS["bg"])
        bar.pack(fill="x", pady=(12, 8))
        ttk.Button(bar, text="新增批次", command=self._new_batch, style="Primary.TButton").pack(side="left")
        ttk.Button(bar, text="编辑", command=self._edit_batch, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(bar, text="设为当前", command=self._activate_batch, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(bar, text="删除", command=self._delete_batch, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.batch_count = tk.Label(bar, text="", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9))
        self.batch_count.pack(side="right")
        self.batch_table = DataTable(
            self.tab_batches,
            [
                {"key": "code", "label": "批次代号", "width": 120},
                {"key": "name", "label": "名称", "width": 260},
                {"key": "firmware_version", "label": "固件版本", "width": 110},
                {"key": "frontend_label", "label": "模拟前端", "width": 115},
                {"key": "config_count", "label": "配置数", "width": 70, "anchor": "center"},
                {"key": "trial_count", "label": "试次数", "width": 70, "anchor": "center"},
                {"key": "active_label", "label": "当前", "width": 55, "anchor": "center"},
                {"key": "description", "label": "说明", "width": 330},
            ],
            height=15, on_double_click=lambda row: self._edit_batch(row),
        )
        self.batch_table.pack(fill="both", expand=True)

    def _build_imports(self):
        bar = tk.Frame(self.tab_imports, bg=COLORS["bg"])
        bar.pack(fill="x", pady=(12, 8))
        ttk.Button(bar, text="前往导入 Excel", command=lambda: self.app.navigate("transfer"),
                   style="Primary.TButton").pack(side="left")
        ttk.Button(bar, text="查看详情", command=self._view_import, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.import_table = DataTable(
            self.tab_imports,
            [
                {"key": "imported_at", "label": "导入时间", "width": 150},
                {"key": "source_name", "label": "来源文件", "width": 330},
                {"key": "imported_count", "label": "配置数", "width": 65, "anchor": "center"},
                {"key": "warning_count", "label": "警告", "width": 55, "anchor": "center"},
                {"key": "error_count", "label": "错误", "width": 55, "anchor": "center"},
                {"key": "batch_name", "label": "批次", "width": 230},
            ],
            height=14, on_double_click=lambda row: self._view_import(row),
        )
        self.import_table.pack(fill="both", expand=True)
        tk.Label(self.tab_imports, text="重复导入同一 SHA-256 文件默认不会重复建组；可在导入页勾选允许重复。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(fill="x", pady=(8, 0))
        self._import_reports: dict[str, dict] = {}

    def refresh(self):
        self._refresh_current()

    def _refresh_current(self):
        try:
            index = self.notebook.index(self.notebook.select())
        except tk.TclError:
            index = 0
        if index == 0:
            self._fill_filter_values()
            self._refresh_configs()
        elif index == 1:
            self._refresh_categories()
        elif index == 2:
            self._refresh_batches()
        else:
            self._refresh_imports()

    def _fill_filter_values(self):
        categories = self.app.repos.categories.list()
        batches = self.app.repos.batches.list()
        self.filter_batch._combo.configure(values=["全部批次"] + [f"{b['code']}｜{b['name']}" for b in batches])
        self.filter_category._combo.configure(values=["全部类别"] + [f"{c['code']}｜{c['name']}" for c in categories])
        self.filter_status._combo.configure(values=["全部状态"] + list(CONFIG_STATUS_LABELS.values()))
        self.filter_priority._combo.configure(values=["全部优先级", "P0", "P1", "P2"])
        if not getattr(self, "_batch_default_applied", False):
            active = self.app.repos.batches.get_active()
            if active:
                self.filter_batch.set(f"{active['code']}｜{active['name']}")
            self._batch_default_applied = True

    def _reset_filters(self):
        self.filter_batch.set("全部批次")
        self.filter_category.set("全部类别")
        self.filter_status.set("全部状态")
        self.filter_priority.set("全部优先级")
        self.search_var.set("")
        self._refresh_configs()

    def _current_filters(self):
        batch = next((b["id"] for b in self.app.repos.batches.list()
                      if f"{b['code']}｜{b['name']}" == self.filter_batch.get()), None)
        category = next((c["id"] for c in self.app.repos.categories.list()
                         if f"{c['code']}｜{c['name']}" == self.filter_category.get()), None)
        status = next((k for k, v in CONFIG_STATUS_LABELS.items() if v == self.filter_status.get()), None)
        priority = self.filter_priority.get() if self.filter_priority.get() in {"P0", "P1", "P2"} else None
        return batch, category, status, priority

    def _refresh_configs(self):
        batch, category, status, priority = self._current_filters()
        configs = self.app.repos.experiments.list(
            batch_id=batch, category_id=category, status=status, priority=priority,
            search=self.search_var.get().strip(),
        )
        counts = self.app.repos.experiments.counts(batch_id=batch)
        for key, label in self.summary_labels.items():
            label.configure(text=str(counts.get(key, 0)))
        planned = sum(int(c.get("planned_repeats") or 0) for c in configs)
        actual = sum(int(c.get("trial_count") or 0) for c in configs)
        self.planned_label.configure(text=f"当前筛选：{len(configs)} 组 · 计划 {planned} 试次 · 已测 {actual} 试次")
        rows = []
        for config in configs:
            distance = config.get("distance_m")
            rows.append(
                {
                    **config,
                    "mode_label": mode_label(config["mode"]),
                    "distance_label": config.get("distance_expr") or (f"{distance:g} m" if distance is not None else "—"),
                    "status_label": CONFIG_STATUS_LABELS.get(config["status"], config["status"]),
                    "actual_count": config.get("trial_count", 0),
                    "gamma": config.get("gamma_nominal"),
                    "_status_tag": {"completed": "ok", "in_progress": "warn", "failed": "bad", "skipped": "muted"}.get(config["status"], ""),
                }
            )
        self.config_table.set_rows(rows)

    def _refresh_categories(self):
        rows = []
        categories = self.app.repos.categories.list()
        for category in categories:
            rows.append({**category, "is_builtin_label": "是" if category["is_builtin"] else "否"})
        self.category_table.set_rows(rows)
        self.category_count.configure(text=f"共 {len(rows)} 个类别")

    def _refresh_batches(self):
        rows = []
        batches = self.app.repos.batches.list()
        for batch in batches:
            rows.append(
                {
                    **batch,
                    "frontend_label": FRONTEND_LABELS.get(batch["frontend"], batch["frontend"]),
                    "active_label": "当前" if batch["is_active"] else "",
                    "_status_tag": "ok" if batch["is_active"] else "",
                }
            )
        self.batch_table.set_rows(rows)
        self.batch_count.configure(text=f"共 {len(rows)} 个批次")

    def _refresh_imports(self):
        rows = []
        self._import_reports = {}
        from ...services.excel_import import list_import_reports

        for item in list_import_reports(self.db):
            report = item.get("report", {})
            self._import_reports[item["id"]] = report
            rows.append(
                {
                    "id": item["id"],
                    "imported_at": str(item["imported_at"])[:19].replace("T", " "),
                    "source_name": Path(report.get("source_name") or item["source_file"]).name,
                    "imported_count": item["imported_count"],
                    "warning_count": item["warning_count"],
                    "error_count": item["error_count"],
                    "batch_name": report.get("batch_name", ""),
                }
            )
        self.import_table.set_rows(rows)

    # ------------------------------------------------------------- 配置动作
    def _selected_config(self):
        row = self.config_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请先选择一个实验配置", parent=self)
            return None
        return self.app.repos.experiments.get(row["id"])

    def _new_config(self):
        dialog = ConfigDialog(self, self.app)
        if dialog.show():
            self._refresh_configs()
            self.app.notify(f"已新增实验 {dialog.result['code']}", "success")

    def _generate_matrix(self):
        dialog = MatrixGeneratorDialog(self, self.app)
        result = dialog.show()
        if result:
            self._refresh_configs()
            self.app.notify(f"已生成 {len(result)} 组实验配置", "success")

    def _edit_config(self):
        config = self._selected_config()
        if not config:
            return
        dialog = ConfigDialog(self, self.app, config)
        if dialog.show():
            self._refresh_configs()
            self.app.notify("实验配置已保存", "success")

    def _duplicate_config(self):
        config = self._selected_config()
        if not config:
            return
        try:
            created = self.app.repos.experiments.duplicate(config["id"])
            self._refresh_configs()
            self.app.notify(f"已复制为 {created['code']}", "success")
        except Exception as exc:
            self.app.show_error("复制失败", exc)

    def _open_workbench(self, row=None):
        row = row or self.config_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择实验配置", parent=self)
            return
        self.app.open_workbench(row["id"])

    def _selected_config_ids(self):
        return [row["id"] for row in self.config_table.selected_rows()]

    def _skip_selected(self):
        ids = self._selected_config_ids()
        if not ids:
            return
        if not messagebox.askyesno("跳过实验", f"将 {len(ids)} 组配置标记为已跳过。\n不会删除已录入数据。", parent=self):
            return
        try:
            self.app.repos.experiments.bulk_set(ids, "status", "skipped")
            self._refresh_configs()
            self.app.notify("已标记跳过", "success")
        except Exception as exc:
            self.app.show_error("操作失败", exc)

    def _reset_selected(self):
        ids = self._selected_config_ids()
        if not ids:
            return
        try:
            self.app.repos.experiments.bulk_set(ids, "status", "not_started")
            self._refresh_configs()
            self.app.notify("已恢复为待测（原始数据未改动）", "success")
        except Exception as exc:
            self.app.show_error("操作失败", exc)

    def _bulk_priority(self, priority):
        ids = self._selected_config_ids()
        if not ids:
            return
        try:
            self.app.repos.experiments.bulk_set(ids, "priority", priority)
            self._refresh_configs()
            self.app.notify(f"已设为 {priority}", "success")
        except Exception as exc:
            self.app.show_error("操作失败", exc)

    def _move_selected(self, delta: int):
        row = self.config_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择要调整顺序的实验配置", parent=self)
            return
        try:
            self.app.repos.experiments.move(row["id"], delta)
            self._refresh_configs()
            self.app.notify("执行顺序已调整", "success")
        except Exception as exc:
            self.app.show_error("调整顺序失败", exc)

    def _delete_config(self):
        ids = self._selected_config_ids()
        if not ids:
            return
        if not messagebox.askyesno("删除实验配置", f"确定删除 {len(ids)} 组配置？\n仅有未测量配置允许删除；原始记录会被保护。", parent=self):
            return
        errors = []
        for config_id in ids:
            try:
                self.app.repos.experiments.delete(config_id)
            except Exception as exc:
                errors.append(str(exc))
        self._refresh_configs()
        if errors:
            messagebox.showwarning("部分未删除", "\n".join(errors), parent=self)
        else:
            self.app.notify("已删除未测量配置", "success")

    # ------------------------------------------------------------- 类别动作
    def _new_category(self):
        dialog = CategoryDialog(self, self.app.repos.categories)
        if dialog.show():
            self._refresh_categories()
            self._fill_filter_values()
            self.app.notify("类别已新增", "success")

    def _edit_category(self, row=None):
        row = row or self.category_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择类别", parent=self)
            return
        category = self.app.repos.categories.get(row["id"])
        dialog = CategoryDialog(self, self.app.repos.categories, category)
        if dialog.show():
            self._refresh_categories()
            self._fill_filter_values()
            self.app.notify("类别已保存", "success")

    def _duplicate_category(self):
        row = self.category_table.selected_row()
        if not row:
            return
        try:
            created = self.app.repos.categories.duplicate(row["id"])
            self._refresh_categories()
            self.app.notify(f"已复制为 {created['code']}", "success")
        except Exception as exc:
            self.app.show_error("复制失败", exc)

    def _delete_category(self):
        row = self.category_table.selected_row()
        if not row:
            return
        if not messagebox.askyesno("删除类别", f"确定删除类别 {row['code']}？", parent=self):
            return
        try:
            self.app.repos.categories.delete(row["id"])
            self._refresh_categories()
            self._fill_filter_values()
            self.app.notify("类别已删除", "success")
        except Exception as exc:
            self.app.show_error("删除失败", exc)

    # ------------------------------------------------------------- 批次动作
    def _new_batch(self):
        dialog = BatchDialog(self, self.app.repos.batches)
        if dialog.show():
            self._refresh_batches()
            self._fill_filter_values()
            self.app.notify("批次已新增", "success")

    def _edit_batch(self, row=None):
        row = row or self.batch_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择批次", parent=self)
            return
        batch = self.app.repos.batches.get(row["id"])
        dialog = BatchDialog(self, self.app.repos.batches, batch)
        if dialog.show():
            self._refresh_batches()
            self._fill_filter_values()
            self.app.notify("批次已保存", "success")

    def _activate_batch(self):
        row = self.batch_table.selected_row()
        if not row:
            return
        try:
            self.app.repos.batches.set_active(row["id"])
            self._refresh_batches()
            self.app.notify("已设为当前批次", "success")
        except Exception as exc:
            self.app.show_error("操作失败", exc)

    def _delete_batch(self):
        row = self.batch_table.selected_row()
        if not row:
            return
        if not messagebox.askyesno("删除批次", f"确定删除批次 {row['code']}？", parent=self):
            return
        try:
            self.app.repos.batches.delete(row["id"])
            self._refresh_batches()
            self._fill_filter_values()
            self.app.notify("批次已删除", "success")
        except Exception as exc:
            self.app.show_error("删除失败", exc)

    def _view_import(self, row=None):
        row = row or self.import_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择导入记录", parent=self)
            return
        report = self._import_reports.get(row["id"])
        if not report:
            return
        ImportReportDialog(self, report).show()
