"""实验工作台：逐次录入、多异常候选、附件与自动判定。"""
from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
from typing import Any

from ... import config
from ...config import (
    COLORS,
    CONFIG_STATUS_LABELS,
    FRONTEND_LABELS,
    MODE_LABELS,
    POLARITY_LABELS,
    QUALITY_FLAGS,
    TRIAL_STATUS_FROM_LABEL,
    TRIAL_STATUS_LABELS,
)
from ...services.attachments import ATTACHMENT_CATEGORIES
from ...services.analytics import load_rules, run_stats
from ...services.judgement import evaluate_judgement
from ...utils import format_number, format_percent, json_dumps, json_loads, new_id, now_iso, safe_float, safe_int
from ..base import BasePage
from ..theme import card
from ..widgets import DataTable, ModalDialog, MetricCard, ScrollableFrame, page_header, section_card


STATUS_OPTIONS = {
    "single": ["检出", "未检出", "无效", "拒判"],
    "normal": ["正常判定", "误报", "无效", "拒判"],
    "multi": ["检出", "未检出", "无效", "拒判"],
}
POLARITY_OPTIONS = ["正", "负", "无", "不确定"]
POLARITY_TO_CODE = {"正": "positive", "负": "negative", "无": "none", "不确定": "unknown"}
CODE_TO_POLARITY = {v: k for k, v in POLARITY_TO_CODE.items()}


class TrialEditDialog(ModalDialog):
    def __init__(self, parent, repo, trial, mode):
        self.repo = repo
        self.trial = trial
        self.mode = mode
        super().__init__(parent, "编辑单次测量", width=620, height=540)

    def build_body(self, parent):
        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="both", expand=True)
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        self.index_var = tk.StringVar(value=str(self.trial["trial_index"]))
        self.status_var = tk.StringVar(value=TRIAL_STATUS_LABELS.get(self.trial["detection_status"], "检出"))
        self.distance_var = tk.StringVar(
            value="" if self.trial.get("measured_distance_m") is None else str(self.trial["measured_distance_m"])
        )
        self.polarity_var = tk.StringVar(value=CODE_TO_POLARITY.get(self.trial.get("polarity"), "不确定"))
        self.quality_var = tk.StringVar(value=self.trial.get("quality_flag") or "正常")
        self.notes_var = tk.StringVar(value=self.trial.get("notes", ""))
        self._field(form, "试次号", self.index_var, 0, 0)
        self._combo(form, "检测状态", self.status_var, STATUS_OPTIONS[self.mode], 0, 1)
        self._field(form, "系统测量距离 (m)", self.distance_var, 1, 0)
        self._combo(form, "检测极性", self.polarity_var, POLARITY_OPTIONS, 1, 1)
        self._combo(form, "质量标记", self.quality_var, QUALITY_FLAGS, 2, 0)
        self._field(form, "备注", self.notes_var, 2, 1)
        self.status_var.trace_add("write", lambda *args: self._toggle())
        self._toggle()
        tk.Label(parent, text="修改会写入审计日志，并保留修改前后内容；原始试次 ID 不变。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(10, 0))

    def _field(self, parent, label, var, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=6)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))

    def _combo(self, parent, label, var, values, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=6)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Combobox(frame, textvariable=var, values=values, state="readonly").pack(fill="x", pady=(2, 0))

    def _toggle(self):
        enabled = self.status_var.get() == "检出"
        # 查找距离 entry 略复杂；保持可输入即可，由保存校验。

    def on_save(self):
        status = TRIAL_STATUS_FROM_LABEL.get(self.status_var.get())
        if not status:
            raise ValueError("检测状态无效")
        data = {
            "trial_index": safe_int(self.index_var.get()),
            "detection_status": status,
            "measured_distance_m": self.distance_var.get().strip() or None,
            "polarity": POLARITY_TO_CODE.get(self.polarity_var.get(), "unknown"),
            "quality_flag": self.quality_var.get(),
            "notes": self.notes_var.get().strip(),
        }
        self.result = self.repo.update(self.trial["id"], data)
        return True


class MultiTrialDialog(ModalDialog):
    def __init__(self, parent, repo, trial, candidates):
        self.repo = repo
        self.trial = trial
        self.candidates = [
            {
                "measured_distance_m": c.get("measured_distance_m"),
                "polarity": c.get("polarity"),
                "quality_flag": c.get("quality_flag"),
                "notes": c.get("notes", ""),
            }
            for c in candidates
        ]
        super().__init__(parent, "编辑多异常测量", width=860, height=720, resizable=True)

    def build_body(self, parent):
        top = tk.Frame(parent, bg=COLORS["bg"])
        top.pack(fill="x")
        self.index_var = tk.StringVar(value=str(self.trial["trial_index"]))
        self.status_var = tk.StringVar(value=(TRIAL_STATUS_LABELS.get(self.trial["detection_status"], "检出")))
        self.quality_var = tk.StringVar(value=self.trial.get("quality_flag") or "正常")
        self.notes_var = tk.StringVar(value=self.trial.get("notes", ""))
        for label, var, values in [
            ("试次号", self.index_var, None), ("质量标记", self.quality_var, QUALITY_FLAGS),
            ("状态覆盖", self.status_var, ["自动判定", "检出", "未检出", "无效", "拒判"]),
            ("备注", self.notes_var, None),
        ]:
            frame = tk.Frame(top, bg=COLORS["bg"])
            frame.pack(side="left", fill="x", expand=True, padx=(0, 8))
            tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(anchor="w")
            if values:
                ttk.Combobox(frame, textvariable=var, values=values, state="readonly").pack(fill="x", pady=(2, 0))
            else:
                ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))
        tk.Label(parent, text="候选列表", bg=COLORS["bg"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", pady=(10, 3))
        self.table = DataTable(
            parent,
            [
                {"key": "candidate_index", "label": "候选", "width": 50, "anchor": "center"},
                {"key": "measured_distance_m", "label": "距离 m", "width": 110, "digits": 3, "anchor": "e"},
                {"key": "polarity_label", "label": "极性", "width": 60},
                {"key": "quality_flag", "label": "质量", "width": 90},
                {"key": "notes", "label": "备注", "width": 260},
            ],
            height=8,
        )
        self.table.pack(fill="both", expand=True)
        add = tk.Frame(parent, bg=COLORS["bg"])
        add.pack(fill="x", pady=(6, 0))
        self.dist_var = tk.StringVar()
        self.pol_var = tk.StringVar(value="不确定")
        self.qual_var = tk.StringVar(value="正常")
        self.note_var = tk.StringVar()
        ttk.Entry(add, textvariable=self.dist_var, width=12).pack(side="left")
        ttk.Combobox(add, textvariable=self.pol_var, values=POLARITY_OPTIONS, state="readonly", width=7).pack(side="left", padx=(6, 0))
        ttk.Combobox(add, textvariable=self.qual_var, values=QUALITY_FLAGS, state="readonly", width=10).pack(side="left", padx=(6, 0))
        ttk.Entry(add, textvariable=self.note_var, width=24).pack(side="left", padx=(6, 0))
        ttk.Button(add, text="添加候选", command=self._add, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(add, text="移除选中", command=self._remove, style="Ghost.TButton").pack(side="left", padx=(4, 0))
        self._refresh_table()

    def _refresh_table(self):
        rows = []
        for index, cand in enumerate(self.candidates, start=1):
            rows.append(
                {
                    "_iid": f"c-{index}",
                    "_index": index - 1,
                    "candidate_index": index,
                    "measured_distance_m": cand["measured_distance_m"],
                    "polarity_label": CODE_TO_POLARITY.get(cand.get("polarity"), "不确定"),
                    "quality_flag": cand.get("quality_flag"),
                    "notes": cand.get("notes", ""),
                }
            )
        self.table.set_rows(rows)

    def _add(self):
        distance = safe_float(self.dist_var.get())
        if distance is None or distance < 0:
            raise ValueError("候选距离必须是非负数字")
        self.candidates.append(
            {
                "measured_distance_m": distance,
                "polarity": POLARITY_TO_CODE.get(self.pol_var.get(), "unknown"),
                "quality_flag": self.qual_var.get(),
                "notes": self.note_var.get().strip(),
            }
        )
        self.dist_var.set("")
        self.note_var.set("")
        self._refresh_table()

    def _remove(self):
        row = self.table.selected_row()
        if not row:
            return
        self.candidates.pop(row["_index"])
        self._refresh_table()

    def on_save(self):
        override = self.status_var.get()
        status = None if override == "自动判定" else TRIAL_STATUS_FROM_LABEL.get(override)
        self.result = self.repo.update_multi_trial(
            self.trial["id"], trial_index=safe_int(self.index_var.get()) or 1,
            candidates=self.candidates, quality_flag=self.quality_var.get(),
            notes=self.notes_var.get().strip(), status_override=status,
        )
        return True


class ConditionsDialog(ModalDialog):
    def __init__(self, parent, app, run):
        self.app = app
        self.run = run
        self.refs = app.repos.references.list(valid_only=False)
        self.combos = app.repos.cables.list_configs()
        super().__init__(parent, "实验条件与健康参考", width=760, height=620)

    def build_body(self, parent):
        run = self.run
        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="both", expand=True)
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        self.fw_var = tk.StringVar(value=run.get("firmware_version", ""))
        self.operator_var = tk.StringVar(value=run.get("operator", ""))
        self.frontend_var = tk.StringVar(value=FRONTEND_LABELS.get(run.get("frontend"), "电阻功分器"))
        ref_options = ["（不关联）"] + [f"{r['ref_no']}｜{r.get('firmware_version') or ''}" for r in self.refs]
        self.ref_var = tk.StringVar(value=next((f"{r['ref_no']}｜{r.get('firmware_version') or ''}" for r in self.refs if r["id"] == run.get("reference_id")), "（不关联）"))
        combo_options = ["（不绑定）"] + [f"{c['code']}｜{c['name']}" for c in self.combos]
        self.combo_var = tk.StringVar(value=next((f"{c['code']}｜{c['name']}" for c in self.combos if c["id"] == run.get("cable_config_id")), "（不绑定）"))
        self._field(form, "固件版本", self.fw_var, 0, 0)
        self._field(form, "操作员", self.operator_var, 0, 1)
        self._combo(form, "模拟前端", self.frontend_var, list(FRONTEND_LABELS.values()), 1, 0)
        self._combo(form, "关联健康参考", self.ref_var, ref_options, 1, 1)
        self._combo(form, "线缆组合", self.combo_var, combo_options, 2, 0)
        tk.Label(form, text="实验备注", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).grid(row=3, column=0, columnspan=2, sticky="w", pady=(8, 2))
        self.notes = tk.Text(form, height=5, wrap="word", relief="solid", bd=1, font=("Microsoft YaHei UI", 9))
        self.notes.grid(row=4, column=0, columnspan=2, sticky="nsew")
        self.notes.insert("1.0", run.get("notes", ""))
        issues = self.app.repos.runs.reference_condition_issues(run)
        text = "当前参考条件问题：" + ("；".join(issues) if issues else "无")
        tk.Label(form, text=text, bg=COLORS["bg"], fg=COLORS["warning"] if issues else COLORS["success"],
                 font=("Microsoft YaHei UI", 8), justify="left", wraplength=660).grid(row=5, column=0, columnspan=2, sticky="w", pady=(10, 0))
        tk.Label(form, text="参考条件不匹配时仍可保存诊断数据；分析中会单独标注，不自动计入正常验收统计。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8), justify="left",
                 wraplength=660).grid(row=6, column=0, columnspan=2, sticky="w", pady=(4, 0))

    def _field(self, parent, label, var, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Entry(frame, textvariable=var).pack(fill="x", pady=(2, 0))

    def _combo(self, parent, label, var, values, row, col):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=col, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Combobox(frame, textvariable=var, values=values, state="readonly").pack(fill="x", pady=(2, 0))

    def on_save(self):
        ref_label = self.ref_var.get()
        ref_id = next((r["id"] for r in self.refs if f"{r['ref_no']}｜{r.get('firmware_version') or ''}" == ref_label), None)
        combo_label = self.combo_var.get()
        combo_id = next((c["id"] for c in self.combos if f"{c['code']}｜{c['name']}" == combo_label), None)
        frontend = next((k for k, v in FRONTEND_LABELS.items() if v == self.frontend_var.get()), "resistive_divider")
        self.result = self.app.repos.runs.update(
            self.run["id"],
            {
                "firmware_version": self.fw_var.get().strip(), "reference_id": ref_id,
                "cable_config_id": combo_id, "frontend": frontend,
                "operator": self.operator_var.get().strip(), "status": self.run["status"],
                "notes": self.notes.get("1.0", "end").strip(),
            },
        )
        return True


class AttachmentDialog(ModalDialog):
    def __init__(self, parent, service, run_id, trial_id=None):
        self.service = service
        self.run_id = run_id
        self.trial_id = trial_id
        self.path_var = tk.StringVar()
        super().__init__(parent, "上传实验附件", width=620, height=420)

    def build_body(self, parent):
        self.category_var = tk.StringVar(value="UART 日志")
        self.notes_var = tk.StringVar()
        tk.Label(parent, text="文件路径", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        row = tk.Frame(parent, bg=COLORS["bg"])
        row.pack(fill="x", pady=(2, 8))
        ttk.Entry(row, textvariable=self.path_var).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="选择…", command=self._choose).pack(side="left", padx=(6, 0))
        tk.Label(parent, text="附件类别", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Combobox(parent, textvariable=self.category_var, values=ATTACHMENT_CATEGORIES, state="readonly").pack(fill="x", pady=(2, 8))
        tk.Label(parent, text="备注", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Entry(parent, textvariable=self.notes_var).pack(fill="x", pady=(2, 8))
        tk.Label(parent, text="文件会复制到项目 data/attachments 目录，并记录 SHA-256；不会修改原始文件。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8), justify="left",
                 wraplength=560).pack(anchor="w", pady=(8, 0))

    def _choose(self):
        path = filedialog.askopenfilename(parent=self, title="选择附件")
        if path:
            self.path_var.set(path)

    def on_save(self):
        path = self.path_var.get().strip()
        if not path:
            raise ValueError("请选择附件文件")
        self.result = self.service.add(
            self.run_id, path, category=self.category_var.get(),
            notes=self.notes_var.get().strip(), trial_id=self.trial_id,
        )
        return True


class StatisticsDetailDialog(ModalDialog):
    def __init__(self, parent, stats):
        self.stats = stats
        super().__init__(parent, "本组统计详情", width=720, height=650, resizable=True)

    def build_body(self, parent):
        self.save_button.configure(text="关闭", command=self.cancel)
        s = self.stats
        d = s.get("distance") or {}
        rows = [
            ("总试次", s.get("total_trials")),
            ("有效检测分母（检出+未检出）", s.get("resolved_trials")),
            ("检出", s.get("detected_count")),
            ("未检出", s.get("not_detected_count")),
            ("检出率", format_percent(s.get("detection_rate")) if s.get("detection_rate") is not None else "不适用"),
            ("正常判定 / 误报", f"{s.get('normal_count', 0)} / {s.get('false_alarm_count', 0)}"),
            ("极性正确 / 错误 / 未知", f"{s.get('polarity_correct_count', 0)} / {s.get('polarity_wrong_count', 0)} / {s.get('polarity_unknown_count', 0)}"),
            ("极性正确率", format_percent(s.get("polarity_accuracy")) if s.get("polarity_accuracy") is not None else "不适用"),
            ("有效定位次数", s.get("located_count")),
            ("容差内次数", s.get("within_tolerance_count")),
            ("定位合格率", format_percent(s.get("location_pass_rate")) if s.get("location_pass_rate") is not None else "不适用"),
            ("综合成功次数", s.get("comprehensive_success_count")),
            ("综合成功率", format_percent(s.get("comprehensive_success_rate")) if s.get("comprehensive_success_rate") is not None else "不适用"),
            ("无效率 / 拒判率", format_percent(s.get("invalid_rate")) if s.get("invalid_rate") is not None else "不适用"),
            ("平均测量距离 (m)", format_number(d.get("mean_distance_m"), 4) if d.get("mean_distance_m") is not None else "不适用"),
            ("平均有符号误差 (m)", format_number(d.get("mean_signed_error_m"), 4, signed=True) if d.get("mean_signed_error_m") is not None else "不适用"),
            ("MAE (m)", format_number(d.get("mae_m"), 4) if d.get("mae_m") is not None else "不适用"),
            ("最大绝对误差 (m)", format_number(d.get("max_abs_error_m"), 4) if d.get("max_abs_error_m") is not None else "不适用"),
            ("最小绝对误差 (m)", format_number(d.get("min_abs_error_m"), 4) if d.get("min_abs_error_m") is not None else "不适用"),
            ("标准差 (m)", format_number(d.get("std_error_m"), 4) if d.get("std_error_m") is not None else "不适用（n<2）"),
            ("RMSE (m)", format_number(d.get("rmse_m"), 4) if d.get("rmse_m") is not None else "不适用"),
            ("中位绝对误差 (m)", format_number(d.get("median_abs_error_m"), 4) if d.get("median_abs_error_m") is not None else "不适用"),
            ("P95 绝对误差 (m)", format_number(d.get("p95_abs_error_m"), 4) if d.get("p95_abs_error_m") is not None else "不适用"),
        ]
        table = DataTable(
            parent,
            [
                {"key": "metric", "label": "指标", "width": 260},
                {"key": "value", "label": "数值", "width": 220},
            ],
            height=16,
        )
        table.pack(fill="both", expand=True)
        table.set_rows([{"metric": key, "value": value} for key, value in rows])
        tk.Label(parent, text="未检出、无效、拒判不参与距离统计；标准差为样本标准差，n<2 时显示不适用。"
                              "当前距离容差见规则：" + f"{s.get('rules', {}).get('distance_tolerance_m', 0.6):.2f} m。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8), justify="left",
                 wraplength=650).pack(fill="x", pady=(8, 0))

    def on_save(self):
        return False


class CandidateDetailDialog(ModalDialog):
    def __init__(self, parent, expected, candidates, trial):
        self.expected = expected
        self.candidates = candidates
        self.trial = trial
        super().__init__(parent, f"第 {trial['trial_index']} 次候选匹配详情", width=900, height=620, resizable=True)

    def build_body(self, parent):
        self.save_button.configure(text="关闭", command=self.cancel)
        exp_text = "；".join(
            f"异常{e['anomaly_index']}：{e.get('board_code') or '—'} @ {format_number(e['true_distance_m'], 3)} m "
            f"（{POLARITY_LABELS.get(e.get('expected_polarity'), '')}）"
            for e in self.expected
        )
        tk.Label(parent, text="真实异常：" + exp_text, bg=COLORS["bg"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 9), justify="left", anchor="w", wraplength=820).pack(
            fill="x", pady=(0, 6)
        )
        table = DataTable(
            parent,
            [
                {"key": "candidate_index", "label": "候选", "width": 48, "anchor": "center"},
                {"key": "measured_distance_m", "label": "候选距离 m", "width": 90, "digits": 3, "anchor": "e"},
                {"key": "polarity_label", "label": "极性", "width": 50, "anchor": "center"},
                {"key": "quality_flag", "label": "质量", "width": 78},
                {"key": "matched_anomaly_index", "label": "匹配异常", "width": 70, "anchor": "center"},
                {"key": "matched_true_distance_m", "label": "真值 m", "width": 75, "digits": 3, "anchor": "e"},
                {"key": "distance_error_m", "label": "误差 m", "width": 72, "digits": 3, "anchor": "e"},
                {"key": "match_status_label", "label": "匹配状态", "width": 75},
                {"key": "polarity_correct_label", "label": "极性正确", "width": 65, "anchor": "center"},
            ],
            height=9,
        )
        table.pack(fill="both", expand=True)
        status_label = {"matched": "已匹配", "extra": "额外候选", "ambiguous": "歧义", "unreviewed": "未复核"}
        rows = []
        for cand in self.candidates:
            rows.append(
                {
                    **cand,
                    "polarity_label": CODE_TO_POLARITY.get(cand.get("polarity"), "不确定"),
                    "match_status_label": status_label.get(cand.get("match_status"), cand.get("match_status")),
                    "polarity_correct_label": (
                        "—" if cand.get("polarity_correct") is None
                        else "是" if cand.get("polarity_correct") else "否"
                    ),
                }
            )
        table.set_rows(rows)
        tk.Label(parent, text="此页展示保存时的匹配快照。统计页面会按当前设置的容差重新匹配，"
                              "因此调整容差后统计可能与此快照不同；原始候选不会被改写。\n"
                              "匹配规则：距离容差内一对一匹配；优先匹配数量，其次极性正确数，再次总距离误差。"
                              "有歧义的匹配会标记为“歧义”，可人工复核但不得篡改原始候选。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8), justify="left",
                 wraplength=820).pack(fill="x", pady=(8, 0))

    def on_save(self):
        return False


class ManualReviewDialog(ModalDialog):
    def __init__(self, parent, judgement):
        self.judgement = judgement
        super().__init__(parent, "保存人工复核结论", width=580, height=430)

    def build_body(self, parent):
        self.decision_var = tk.StringVar(value="需要人工复核")
        self.reviewer_var = tk.StringVar(value=self.master.app.db.get_setting("operator", "") if hasattr(self.master, "app") else "")
        self.note_var = tk.StringVar()
        tk.Label(parent, text=f"自动判定：{self.judgement.get('label')}", bg=COLORS["bg"],
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", pady=(2, 8))
        tk.Label(parent, text="人工结论（不覆盖原始测量记录）", bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Combobox(parent, textvariable=self.decision_var,
                     values=["通过", "未通过", "需要人工复核", "数据不足", "未测试"], state="readonly").pack(fill="x", pady=(2, 8))
        tk.Label(parent, text="复核人", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        ttk.Entry(parent, textvariable=self.reviewer_var).pack(fill="x", pady=(2, 8))
        tk.Label(parent, text="复核说明", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        self.note = tk.Text(parent, height=6, wrap="word", relief="solid", bd=1, font=("Microsoft YaHei UI", 9))
        self.note.pack(fill="both", expand=True, pady=(2, 0))

    def on_save(self):
        decision = {"通过": "pass", "未通过": "fail", "需要人工复核": "review",
                    "数据不足": "insufficient", "未测试": "not_tested"}.get(self.decision_var.get(), "review")
        self.result = {
            "decision": decision, "reviewer": self.reviewer_var.get().strip(),
            "review_note": self.note.get("1.0", "end").strip(),
        }
        return True


class WorkbenchPage(BasePage):
    key = "workbench"
    title = "实验工作台"
    subtitle = "逐次录入测量、质量标记、附件与自动判定"

    def build(self):
        header = page_header(
            self, "实验工作台", "一条试次一条记录；保存后立即写入 SQLite，未检出不会当作 0 m。",
        )
        header.pack(fill="x", pady=(4, 10))

        selector_card = card(self)
        selector_card.pack(fill="x", pady=(0, 10))
        sel = tk.Frame(selector_card, bg=COLORS["card"])
        sel.pack(fill="x", padx=14, pady=10)
        sel.grid_columnconfigure(1, weight=1)
        tk.Label(sel, text="当前实验配置", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9)).grid(row=0, column=0, sticky="w")
        self.config_var = tk.StringVar()
        self.config_combo = ttk.Combobox(sel, textvariable=self.config_var, state="readonly")
        self.config_combo.grid(row=0, column=1, sticky="ew", padx=(8, 10))
        self.config_combo.bind("<<ComboboxSelected>>", lambda event: self._on_config_change())
        control_buttons = tk.Frame(sel, bg=COLORS["card"])
        control_buttons.grid(row=0, column=2, sticky="e")
        ttk.Button(control_buttons, text="实验条件", command=self._edit_conditions, style="Ghost.TButton").pack(side="left", padx=(0, 4))
        ttk.Button(control_buttons, text="调整次数", command=self._change_planned, style="Ghost.TButton").pack(side="left", padx=(0, 4))
        ttk.Button(control_buttons, text="完成本组", command=self._complete_group, style="Ghost.TButton").pack(side="left")
        self.config_hint = tk.Label(sel, text="", bg=COLORS["card"], fg=COLORS["muted"],
                                    font=("Microsoft YaHei UI", 8))
        self.config_hint.grid(row=1, column=0, columnspan=3, sticky="w", pady=(4, 0))

        self.scroll = ScrollableFrame(self)
        self.scroll.pack(fill="both", expand=True)
        self.inner = self.scroll.inner
        self._configs: list[dict] = []
        self._config_id: str | None = None
        self._run: dict | None = None
        self._stats: dict | None = None
        self._judgement: dict | None = None
        self._candidate_rows: list[dict] = []
        self._last_saved_trial_id: str | None = None
        self._want_focus = True
        self.bind_all("<Control-Return>", self._ctrl_save, add="+")

    def _ctrl_save(self, _event=None):
        if not self.winfo_ismapped() or not self._run:
            return
        row = self._config_row()
        if not row:
            return
        if row["mode"] == "multi":
            self._save_multi()
        else:
            self._save_single()

    # ------------------------------------------------------------------ 数据装载
    def refresh(self):
        # 工作台默认只显示“当前批次”，避免把历史初验批次和生产批次混在一起录入。
        active_batch = self.app.repos.batches.get_active()
        if active_batch:
            configs = self.app.repos.experiments.list(batch_id=active_batch["id"])
        else:
            configs = self.app.repos.experiments.list()
        self._configs = configs
        values = [f"{c['code']}｜{c['name']}" for c in configs]
        self.config_combo.configure(values=values)
        if not configs:
            self._config_id = None
            self._run = None
            self._render_empty()
            self.config_hint.configure(text="未找到实验配置")
            return
        by_id = {c["id"]: c for c in configs}
        selected_id = self.app.current_config_id or self._config_id
        if selected_id not in by_id:
            in_progress = next((c for c in configs if c["status"] == "in_progress"), None)
            p0 = next((c for c in configs if c["priority"] == "P0" and c["status"] not in {"completed", "skipped"}), None)
            selected = in_progress or p0 or configs[0]
            selected_id = selected["id"]
        selected = by_id[selected_id]
        self._config_id = selected_id
        self.app.current_config_id = selected_id
        self.config_var.set(f"{selected['code']}｜{selected['name']}")
        self.config_hint.configure(
            text=f"{selected.get('category_code') or ''} · {selected.get('batch_code') or ''} · "
                 f"优先级 {selected.get('priority')} · 计划 {selected.get('planned_repeats')} 次"
        )
        try:
            self._run = self.app.repos.runs.ensure_for_config(selected_id)
            self.app.current_run_id = self._run["id"]
            self._stats = run_stats(self.db, self._run["id"])
            self._judgement = evaluate_judgement(
                self._stats, self._stats.get("rules") or load_rules(self.db),
                planned_trials=selected.get("planned_repeats") or 0,
            )
        except Exception as exc:
            self._run = None
            self._stats = None
            self.app.notify(f"无法打开实验：{exc}", "error")
            self._render_error(str(exc))
            return
        self._render_experiment()

    def _on_config_change(self):
        label = self.config_var.get()
        config_id = next((c["id"] for c in self._configs if f"{c['code']}｜{c['name']}" == label), None)
        if not config_id:
            return
        self._config_id = config_id
        self.app.current_config_id = config_id
        self._candidate_rows = []
        self.refresh()

    def _destroy_children(self, widget):
        for child in widget.winfo_children():
            child.destroy()

    def _render_empty(self):
        self._destroy_children(self.inner)
        frame = tk.Frame(self.inner, bg=COLORS["bg"])
        frame.pack(fill="both", expand=True, pady=80)
        tk.Label(frame, text="还没有实验配置", bg=COLORS["bg"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 16, "bold")).pack()
        tk.Label(frame, text="请先到“实验计划”导入 79 组矩阵或生成新的实验矩阵。", bg=COLORS["bg"],
                 fg=COLORS["muted"], font=("Microsoft YaHei UI", 10)).pack(pady=(6, 14))
        ttk.Button(frame, text="前往实验计划", command=lambda: self.app.navigate("plan"),
                   style="Primary.TButton").pack()

    def _render_error(self, message: str):
        self._destroy_children(self.inner)
        frame = tk.Frame(self.inner, bg=COLORS["bg"])
        frame.pack(fill="x", pady=50)
        tk.Label(frame, text="无法加载该实验", bg=COLORS["bg"], fg=COLORS["danger"],
                 font=("Microsoft YaHei UI", 14, "bold")).pack()
        tk.Label(frame, text=message, bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), wraplength=760, justify="left").pack(pady=6)

    def _render_experiment(self):
        self._destroy_children(self.inner)
        config_row = self._config_row()
        stats = self._stats
        if not config_row or not self._run or not stats:
            return
        # 上下文
        context_card = card(self.inner)
        context_card.pack(fill="x", pady=(0, 10))
        head = tk.Frame(context_card, bg=COLORS["card"])
        head.pack(fill="x", padx=16, pady=(13, 6))
        tk.Label(head, text=f"{config_row['code']}｜{config_row['name']}", bg=COLORS["card"],
                 fg=COLORS["text"], font=("Microsoft YaHei UI", 15, "bold")).pack(side="left")
        self._badge(head, config_row["priority"], "#FFF3E0", COLORS["warning"]).pack(side="left", padx=(10, 0))
        self._badge(head, MODE_LABELS.get(config_row["mode"], config_row["mode"]), "#EAF4F4", COLORS["primary"]).pack(side="left", padx=(6, 0))
        self._badge(head, CONFIG_STATUS_LABELS.get(config_row["status"], config_row["status"]), "#EEF2F4", COLORS["muted"]).pack(side="left", padx=(6, 0))
        tk.Label(head, text=f"运行 {self._run['code']}", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8)).pack(side="right")
        info = tk.Frame(context_card, bg=COLORS["card"])
        info.pack(fill="x", padx=16, pady=(4, 12))
        for col in range(4):
            info.grid_columnconfigure(col, weight=1)
        detail = {
            "类别 / 批次": f"{config_row.get('category_code')} {config_row.get('category_name')}  ·  {self._run.get('batch_name')}",
            "测试板": (
                f"{config_row.get('board_code') or '—'}｜{config_row.get('board_name') or '未指定'}"
                + (f"  Γ={format_percent(config_row.get('gamma_nominal'))}" if config_row.get("gamma_nominal") is not None else "")
            ),
            "真值 / 计划": (
                (f"{format_number(config_row.get('distance_m'), 3)} m" if config_row.get("distance_m") is not None else
                 ( config_row.get("distance_expr") or "见真实异常定义"))
                + f"　计划 {config_row.get('planned_repeats')} 次"
            ),
            "健康参考": (
                self._run.get("reference_no")
                if self._run.get("reference_no")
                else (f"未关联实际参考（计划标识 {config_row.get('reference_label')}）"
                      if config_row.get("reference_label") else "未关联")
            ),
            "固件 / 前端": f"{self._run.get('firmware_version') or '—'}  ·  {FRONTEND_LABELS.get(self._run.get('frontend'), self._run.get('frontend'))}",
            "线缆组合": self._run.get("cable_config_name") or "未绑定",
            "操作员": self._run.get("operator") or "未填写",
            "已完成": f"{stats['total_trials']} / {config_row.get('planned_repeats')} 次",
        }
        for index, (key, value) in enumerate(detail.items()):
            row = index // 4
            column = index % 4
            item = tk.Frame(info, bg=COLORS["card"])
            item.grid(row=row, column=column, sticky="nw", padx=(0, 18), pady=4)
            tk.Label(item, text=key, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
            tk.Label(item, text=value, bg=COLORS["card"], fg=COLORS["text"],
                     font=("Microsoft YaHei UI", 9, "bold"), anchor="w", justify="left",
                     wraplength=320).pack(anchor="w")
        issues = stats.get("reference_issues") or []
        if issues:
            banner = tk.Frame(context_card, bg="#FFF4E5")
            banner.pack(fill="x", padx=16, pady=(0, 12))
            tk.Label(banner, text="参考条件不匹配：" + "；".join(issues) + "。数据可保存，但不应自动计入正常验收统计。",
                     bg="#FFF4E5", fg=COLORS["warning"], font=("Microsoft YaHei UI", 8, "bold"),
                     anchor="w", padx=10, pady=6, wraplength=1100, justify="left").pack(fill="x")

        # 统计
        metric_row = tk.Frame(self.inner, bg=COLORS["bg"])
        metric_row.pack(fill="x", pady=(0, 10))
        cards = {}
        specs = [
            ("total", "已完成试次", f"{stats['total_trials']} / {config_row['planned_repeats']}", "保存后自动统计"),
            ("detect", "检出率 / 正常判定率", "不适用", "见下方统计口径"),
            ("polarity", "极性正确率", "不适用", "已记录极性的检出"),
            ("location", "定位合格率", "不适用", "容差内 / 有效定位"),
            ("mae", "定位 MAE", "不适用", "仅有效定位结果"),
        ]
        for index, (key, title, value, note) in enumerate(specs):
            card_widget = MetricCard(metric_row, title, value, note)
            card_widget.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 7, 0))
            metric_row.grid_columnconfigure(index, weight=1)
            cards[key] = card_widget
        if config_row["mode"] == "normal":
            rate = stats.get("normal_judgement_rate")
            value = format_percent(rate) if rate is not None else "不适用"
            note = f"正常 {stats.get('normal_count', 0)} / 误报 {stats.get('false_alarm_count', 0)}"
        else:
            rate = stats.get("detection_rate")
            value = format_percent(rate) if rate is not None else "不适用"
            note = f"检出 {stats.get('detected_count', 0)} / 未检出 {stats.get('not_detected_count', 0)}"
        cards["detect"].update_value(value, note, COLORS["success"] if value != "不适用" else COLORS["muted"])
        cards["polarity"].update_value(
            format_percent(stats.get("polarity_accuracy")) if stats.get("polarity_accuracy") is not None else "不适用",
            "仅检出且已记录极性",
        )
        cards["location"].update_value(
            format_percent(stats.get("location_pass_rate")) if stats.get("location_pass_rate") is not None else "不适用",
            f"有效定位 {stats.get('located_count', 0)} 次",
        )
        mae = stats["distance"].get("mae_m")
        cards["mae"].update_value(format_number(mae, 3) if mae is not None else "不适用",
                                  f"P95 绝对误差 {format_number(stats['distance'].get('p95_abs_error_m'), 3)} m")
        cards["total"].update_value(f"{stats['total_trials']} / {config_row['planned_repeats']}",
                                    f"剩余 {max(0, int(config_row['planned_repeats']) - stats['total_trials'])} 次")

        main = tk.Frame(self.inner, bg=COLORS["bg"])
        main.pack(fill="x", pady=(0, 10))
        main.grid_columnconfigure(0, weight=3)
        main.grid_columnconfigure(1, weight=2)
        entry_outer = card(main)
        entry_outer.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self._build_entry_panel(entry_outer, config_row)
        judge_outer = card(main)
        judge_outer.grid(row=0, column=1, sticky="nsew")
        self._build_judgement_panel(judge_outer, config_row)

        self._build_trials_panel(config_row)
        self._build_attachments_panel()

        if self._want_focus:
            self.after(150, self._focus_entry)

    def _badge(self, parent, text, bg, fg):
        return tk.Label(parent, text=text, bg=bg, fg=fg, padx=8, pady=2,
                        font=("Microsoft YaHei UI", 8, "bold"))

    def _config_row(self):
        return next((c for c in self._configs if c["id"] == self._config_id), None)

    # ------------------------------------------------------------------ 录入面板
    def _build_entry_panel(self, outer, config_row):
        header = tk.Frame(outer, bg=COLORS["card"])
        header.pack(fill="x", padx=16, pady=(13, 4))
        tk.Label(header, text="快速录入", bg=COLORS["card"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 12, "bold")).pack(side="left")
        next_index = self.app.repos.trials.next_index(self._run["id"])
        tk.Label(header, text=f"下一次：第 {next_index} 次　|　Ctrl+Enter 保存", bg=COLORS["card"],
                 fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(side="right")
        body = tk.Frame(outer, bg=COLORS["card"])
        body.pack(fill="both", expand=True, padx=16, pady=(4, 14))
        mode = config_row["mode"]
        if mode == "multi":
            self._build_multi_entry(body, config_row)
        else:
            self._build_single_entry(body, config_row)

    def _build_single_entry(self, body, config_row):
        mode = config_row["mode"]
        self.entry_status_var = tk.StringVar(value=STATUS_OPTIONS[mode][0])
        self.entry_distance_var = tk.StringVar()
        expected_pol = config_row.get("expected_polarity")
        self.entry_polarity_var = tk.StringVar(value=CODE_TO_POLARITY.get(expected_pol, "不确定"))
        self.entry_quality_var = tk.StringVar(value="正常")
        self.entry_note_var = tk.StringVar()
        if self.entry_status_var.get() not in STATUS_OPTIONS[mode]:
            self.entry_status_var.set(STATUS_OPTIONS[mode][0])
        row1 = tk.Frame(body, bg=COLORS["card"])
        row1.pack(fill="x")
        for col in range(4):
            row1.grid_columnconfigure(col, weight=1)
        self._form_combo(row1, "检测状态", self.entry_status_var, STATUS_OPTIONS[mode], 0)
        self.distance_entry = self._form_entry(row1, "系统测量距离 (m)", self.entry_distance_var, 1,
                                               enabled=(mode != "normal"))
        self.polarity_combo = self._form_combo(row1, "检测极性", self.entry_polarity_var, POLARITY_OPTIONS, 2,
                                               enabled=(mode != "normal"))
        self._form_combo(row1, "质量标记", self.entry_quality_var, QUALITY_FLAGS, 3)
        row2 = tk.Frame(body, bg=COLORS["card"])
        row2.pack(fill="x", pady=(7, 0))
        tk.Label(row2, text="备注", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8)).pack(side="left")
        ttk.Entry(row2, textvariable=self.entry_note_var).pack(side="left", fill="x", expand=True, padx=(8, 0))
        if mode == "normal":
            tk.Label(
                body,
                text="正常参考组不需要录入距离或极性：请选择“正常判定/误报/无效/拒判”后点击保存。"
                     "若要测量异常距离，请到上方“当前实验配置”切换到 C/D 等单异常实验。",
                bg="#FFF7E8", fg=COLORS["warning"], font=("Microsoft YaHei UI", 8),
                anchor="w", justify="left", padx=8, pady=5,
            ).pack(fill="x", pady=(8, 0))
        else:
            tk.Label(
                body,
                text="“检出”必须填写系统测量距离；未检出/无效不参与距离统计，也不会当作 0 m。",
                bg="#F4F8F9", fg=COLORS["muted"], font=("Microsoft YaHei UI", 8),
                anchor="w", justify="left", padx=8, pady=5,
            ).pack(fill="x", pady=(8, 0))
        self.entry_status_var.trace_add("write", lambda *args: self._update_entry_state(mode))
        self._update_entry_state(mode)
        buttons = tk.Frame(body, bg=COLORS["card"])
        buttons.pack(fill="x", pady=(10, 0))
        row_a = tk.Frame(buttons, bg=COLORS["card"])
        row_a.pack(fill="x")
        ttk.Button(row_a, text="保存本次", command=self._save_single, style="Primary.TButton").pack(side="left")
        if mode == "normal":
            ttk.Button(row_a, text="标记误报", command=lambda: self._save_quick_normal("false_alarm"),
                       style="Ghost.TButton").pack(side="left", padx=(6, 0))
        else:
            ttk.Button(row_a, text="标记未检出", command=lambda: self._save_quick_status("not_detected"),
                       style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(row_a, text="标记无效", command=lambda: self._save_quick_status("invalid"),
                   style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(row_a, text="复制上次", command=self._copy_last, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        row_b = tk.Frame(buttons, bg=COLORS["card"])
        row_b.pack(fill="x", pady=(6, 0))
        if mode != "normal":
            ttk.Button(row_b, text="批量粘贴", command=self._batch_paste, style="Ghost.TButton").pack(side="left")
        ttk.Button(row_b, text="上传日志", command=self._upload_attachment, style="Ghost.TButton").pack(side="left", padx=(0 if mode == "normal" else 6, 0))
        ttk.Button(row_b, text="统计详情", command=self._show_statistics_detail, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        tk.Label(row_b, text="保存后自动进入下一次；回车保存，Ctrl+Enter 通用快捷键。",
                 bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(side="right")
        if self.distance_entry:
            self.distance_entry.bind("<Return>", lambda event: self._save_single())

    def _update_entry_state(self, mode):
        status_label = self.entry_status_var.get()
        if mode == "normal":
            self.distance_entry.configure(state="disabled")
            self.polarity_combo.configure(state="disabled")
            return
        enabled = status_label == "检出"
        self.distance_entry.configure(state="normal" if enabled else "disabled")
        self.polarity_combo.configure(state="readonly" if enabled else "disabled")

    def _form_entry(self, parent, label, var, col, enabled=True):
        frame = tk.Frame(parent, bg=COLORS["card"])
        frame.grid(row=0, column=col, sticky="ew", padx=(0, 10))
        tk.Label(frame, text=label, bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
        entry = ttk.Entry(frame, textvariable=var)
        entry.pack(fill="x", pady=(2, 0))
        if not enabled:
            entry.configure(state="disabled")
        return entry

    def _form_combo(self, parent, label, var, values, col, enabled=True):
        frame = tk.Frame(parent, bg=COLORS["card"])
        frame.grid(row=0, column=col, sticky="ew", padx=(0, 10))
        tk.Label(frame, text=label, bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
        combo = ttk.Combobox(frame, textvariable=var, values=values, state="readonly")
        combo.pack(fill="x", pady=(2, 0))
        if not enabled:
            combo.configure(state="disabled")
        return combo

    def _save_single(self, forced_status: str | None = None):
        if not self._run:
            return
        config_row = self._config_row()
        mode = config_row["mode"]
        status_label = forced_status or self.entry_status_var.get()
        if not status_label:
            status_label = "正常判定" if mode == "normal" else "检出"
            self.entry_status_var.set(status_label)
        if forced_status == "not_detected":
            status_label = "未检出"
            distance = None
            polarity = "unknown"
        elif forced_status == "invalid":
            status_label = "无效"
            distance = self.entry_distance_var.get().strip() or None
            polarity = POLARITY_TO_CODE.get(self.entry_polarity_var.get(), "unknown")
        else:
            distance = self.entry_distance_var.get().strip() or None
            polarity = POLARITY_TO_CODE.get(self.entry_polarity_var.get(), "unknown")
        if isinstance(status_label, str) and status_label in TRIAL_STATUS_FROM_LABEL:
            status = TRIAL_STATUS_FROM_LABEL[status_label]
        else:
            status = status_label
        if mode == "normal" and status == "detected":
            status = "normal"
        if mode == "normal":
            distance = None
            polarity = "none"
        try:
            trial = self.app.repos.trials.create(
                self._run["id"],
                measured_distance_m=distance,
                polarity=polarity,
                detection_status=status,
                quality_flag=self.entry_quality_var.get(),
                notes=self.entry_note_var.get().strip(),
            )
            self._last_saved_trial_id = trial["id"]
            self.app.notify(f"已保存第 {trial['trial_index']} 次测量", "success")
            self._want_focus = True
            self.refresh()
        except Exception as exc:
            self.app.show_error("保存失败", exc)

    def _save_quick_status(self, status):
        self.entry_status_var.set({"not_detected": "未检出", "invalid": "无效"}.get(status, "未检出"))
        self._save_single(status)

    def _save_quick_normal(self, status_code: str):
        label = {"false_alarm": "误报", "normal": "正常判定", "invalid": "无效"}.get(status_code, "正常判定")
        self.entry_status_var.set(label)
        self._save_single(status_code)

    def _copy_last(self):
        last = self.app.repos.trials.last_trial(self._run["id"])
        if not last:
            messagebox.showinfo("提示", "还没有可复制的测量记录", parent=self)
            return
        if self._config_row()["mode"] == "multi":
            self._candidate_rows = [
                {
                    "measured_distance_m": c.get("measured_distance_m"),
                    "polarity": c.get("polarity"),
                    "quality_flag": c.get("quality_flag"),
                    "notes": c.get("notes", ""),
                }
                for c in self.app.repos.trials.candidates(last["id"])
            ]
            self.refresh()
            return
        self.entry_status_var.set(TRIAL_STATUS_LABELS.get(last["detection_status"], "检出"))
        self.entry_distance_var.set("" if last.get("measured_distance_m") is None else str(last["measured_distance_m"]))
        self.entry_polarity_var.set(CODE_TO_POLARITY.get(last.get("polarity"), "不确定"))
        self.entry_quality_var.set(last.get("quality_flag") or "正常")
        self.entry_note_var.set(last.get("notes") or "")
        self._focus_entry()

    def _show_statistics_detail(self):
        if not self._stats:
            return
        StatisticsDetailDialog(self, self._stats).show()

    def _focus_entry(self):
        if self._config_row() and self._config_row()["mode"] == "multi":
            try:
                self.candidate_distance_entry.focus_set()
            except Exception:
                pass
        else:
            try:
                if str(self.distance_entry.cget("state")) != "disabled":
                    self.distance_entry.focus_set()
            except Exception:
                pass

    def _batch_paste(self):
        if self._config_row()["mode"] == "normal":
            messagebox.showinfo("提示", "批量粘贴仅用于异常组；正常组请逐次录入。", parent=self)
            return
        dialog = BatchPasteDialog(self, self._run, self._config_row())
        if dialog.show():
            self.refresh()
            self.app.notify(f"已批量保存 {dialog.result} 条试次", "success")

    # ------------------------------------------------------------------ 多异常
    def _build_multi_entry(self, body, config_row):
        expected = self.app.repos.runs.expected_anomalies(self._run["id"])
        tk.Label(body, text="真实异常定义", bg=COLORS["card"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="w")
        exp_text = "；".join(
            f"{e['anomaly_index']}. {e.get('board_code') or ''} @ {format_number(e['true_distance_m'], 3)} m"
            f"（{POLARITY_LABELS.get(e.get('expected_polarity'), '')}）"
            for e in expected
        )
        tk.Label(body, text=exp_text, bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8), anchor="w", justify="left", wraplength=620).pack(anchor="w", pady=(2, 6))

        self.candidate_table = DataTable(
            body,
            [
                {"key": "candidate_index", "label": "候选", "width": 48, "anchor": "center"},
                {"key": "measured_distance_m", "label": "距离 m", "width": 95, "digits": 3, "anchor": "e"},
                {"key": "polarity_label", "label": "极性", "width": 55},
                {"key": "quality_flag", "label": "质量", "width": 80},
                {"key": "notes", "label": "备注", "width": 180},
            ],
            height=4,
        )
        self.candidate_table.pack(fill="x", pady=(0, 4))
        self._refresh_candidate_table()

        add = tk.Frame(body, bg=COLORS["card"])
        add.pack(fill="x", pady=(2, 0))
        self.candidate_distance_var = tk.StringVar()
        self.candidate_polarity_var = tk.StringVar(value="不确定")
        self.candidate_quality_var = tk.StringVar(value="正常")
        self.candidate_note_var = tk.StringVar()
        ttk.Entry(add, textvariable=self.candidate_distance_var, width=12).pack(side="left")
        ttk.Combobox(add, textvariable=self.candidate_polarity_var, values=POLARITY_OPTIONS,
                     state="readonly", width=7).pack(side="left", padx=(5, 0))
        ttk.Combobox(add, textvariable=self.candidate_quality_var, values=QUALITY_FLAGS,
                     state="readonly", width=10).pack(side="left", padx=(5, 0))
        ttk.Entry(add, textvariable=self.candidate_note_var, width=22).pack(side="left", padx=(5, 0))
        ttk.Button(add, text="添加候选", command=self._add_candidate, style="Ghost.TButton").pack(side="left", padx=(5, 0))
        ttk.Button(add, text="移除选中", command=self._remove_candidate, style="Ghost.TButton").pack(side="left", padx=(4, 0))
        self.candidate_distance_entry = add.winfo_children()[0]

        bottom = tk.Frame(body, bg=COLORS["card"])
        bottom.pack(fill="x", pady=(8, 0))
        tk.Label(bottom, text="质量", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8)).pack(side="left")
        self.multi_quality_var = tk.StringVar(value="正常")
        ttk.Combobox(bottom, textvariable=self.multi_quality_var, values=QUALITY_FLAGS,
                     state="readonly", width=10).pack(side="left", padx=(4, 12))
        tk.Label(bottom, text="状态覆盖", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8)).pack(side="left")
        self.multi_status_var = tk.StringVar(value="自动判定")
        ttk.Combobox(bottom, textvariable=self.multi_status_var,
                     values=["自动判定", "未检出", "无效", "拒判"], state="readonly", width=10).pack(side="left", padx=(4, 12))
        self.multi_note_var = tk.StringVar()
        ttk.Entry(bottom, textvariable=self.multi_note_var).pack(side="left", fill="x", expand=True, padx=(0, 8))
        ttk.Button(bottom, text="保存本次", command=self._save_multi, style="Primary.TButton").pack(side="left")
        ttk.Button(bottom, text="复制上次候选", command=self._copy_last, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(bottom, text="清空候选", command=self._clear_candidates, style="Ghost.TButton").pack(side="left", padx=(6, 0))

    def _refresh_candidate_table(self):
        rows = []
        for index, cand in enumerate(self._candidate_rows, start=1):
            rows.append(
                {
                    "_iid": f"cand-{index}",
                    "_index": index - 1,
                    "candidate_index": index,
                    "measured_distance_m": cand.get("measured_distance_m"),
                    "polarity_label": CODE_TO_POLARITY.get(cand.get("polarity"), "不确定"),
                    "quality_flag": cand.get("quality_flag"),
                    "notes": cand.get("notes", ""),
                }
            )
        self.candidate_table.set_rows(rows)

    def _add_candidate(self):
        distance = safe_float(self.candidate_distance_var.get())
        if distance is None or distance < 0:
            messagebox.showwarning("候选无效", "请输入非负的候选距离", parent=self)
            return
        self._candidate_rows.append(
            {
                "measured_distance_m": distance,
                "polarity": POLARITY_TO_CODE.get(self.candidate_polarity_var.get(), "unknown"),
                "quality_flag": self.candidate_quality_var.get(),
                "notes": self.candidate_note_var.get().strip(),
            }
        )
        self.candidate_distance_var.set("")
        self.candidate_note_var.set("")
        self._refresh_candidate_table()
        self._focus_entry()

    def _remove_candidate(self):
        row = self.candidate_table.selected_row()
        if not row:
            return
        index = row.get("_index")
        if index is not None:
            self._candidate_rows.pop(index)
            self._refresh_candidate_table()

    def _clear_candidates(self):
        self._candidate_rows = []
        self._refresh_candidate_table()

    def _save_multi(self):
        override_label = self.multi_status_var.get()
        override = None
        if override_label != "自动判定":
            override = TRIAL_STATUS_FROM_LABEL.get(override_label)
        try:
            trial = self.app.repos.trials.save_multi_trial(
                self._run["id"], trial_index=None, candidates=self._candidate_rows,
                quality_flag=self.multi_quality_var.get(), notes=self.multi_note_var.get().strip(),
                status_override=override,
            )
            self._last_saved_trial_id = trial["id"]
            self._candidate_rows = []
            self.multi_note_var.set("")
            self.app.notify(f"已保存第 {trial['trial_index']} 次多异常测量", "success")
            self._want_focus = True
            self.refresh()
        except Exception as exc:
            self.app.show_error("保存失败", exc)

    # ------------------------------------------------------------------ 判定
    def _build_judgement_panel(self, outer, config_row):
        header = tk.Frame(outer, bg=COLORS["card"])
        header.pack(fill="x", padx=16, pady=(13, 6))
        tk.Label(header, text="自动判定", bg=COLORS["card"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 12, "bold")).pack(side="left")
        judgement = self._judgement or {}
        decision = judgement.get("decision", "not_tested")
        colors = {"pass": COLORS["success"], "fail": COLORS["danger"], "review": COLORS["warning"],
                  "insufficient": COLORS["warning"], "not_tested": COLORS["muted"]}
        self._badge(header, judgement.get("label", "未测试"), "#F4F6F8", colors.get(decision, COLORS["muted"])).pack(side="right")
        tk.Label(outer, text=judgement.get("summary", ""), bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), justify="left", wraplength=420, anchor="w").pack(
            fill="x", padx=16, pady=(0, 8)
        )
        table_frame = tk.Frame(outer, bg=COLORS["card"])
        table_frame.pack(fill="both", expand=True, padx=16, pady=(0, 8))
        rules = judgement.get("rules", [])
        rule_table = DataTable(
            table_frame,
            [
                {"key": "label", "label": "规则", "width": 180},
                {"key": "actual_text", "label": "实际", "width": 80},
                {"key": "threshold_text", "label": "阈值", "width": 75},
                {"key": "result", "label": "结果", "width": 55},
            ],
            height=min(8, max(3, len(rules))),
        )
        rule_table.pack(fill="both", expand=True)
        rule_rows = []
        for rule in rules:
            result = "通过" if rule.get("passed") else "未通过" if rule.get("passed") is False else "—"
            rule_rows.append(
                {
                    "label": rule.get("label"), "actual_text": rule.get("actual_text"),
                    "threshold_text": rule.get("threshold_text"), "result": result,
                    "_status_tag": "bad" if rule.get("passed") is False else "ok" if rule.get("passed") else "",
                }
            )
        rule_table.set_rows(rule_rows)
        saved = self.db.query_one(
            "SELECT * FROM judgements WHERE run_id=? ORDER BY created_at DESC LIMIT 1", (self._run["id"],)
        )
        info = "已保存判定快照：" + (saved["created_at"][:19].replace("T", " ") if saved else "暂无")
        tk.Label(outer, text=info, bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(
            fill="x", padx=16
        )
        buttons = tk.Frame(outer, bg=COLORS["card"])
        buttons.pack(fill="x", padx=16, pady=(6, 14))
        ttk.Button(buttons, text="保存判定快照", command=self._save_judgement, style="Ghost.TButton").pack(side="left")
        ttk.Button(buttons, text="人工复核", command=self._manual_review, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        tk.Label(outer, text="判定阈值可在系统设置修改；结论基于当前统计规则。", bg=COLORS["card"],
                 fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(fill="x", padx=16, pady=(0, 12))

    def _save_judgement(self):
        if not self._judgement:
            return
        try:
            self._insert_judgement(
                self._judgement["decision"], self._stats,
                reviewer="", review_note="", summary=self._judgement.get("summary", ""),
                rules=self._judgement.get("rules", []),
            )
            self.app.notify("判定快照已保存（原始记录未改变）", "success")
            self.refresh()
        except Exception as exc:
            self.app.show_error("保存判定失败", exc)

    def _insert_judgement(self, decision, stats, reviewer, review_note, summary, rules):
        judgement_id = new_id("JUD")
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO judgements
                (id,run_id,decision,rules_json,metrics_json,summary,reviewer,review_note,created_at)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    judgement_id, self._run["id"], decision, json_dumps(rules),
                    json_dumps({k: v for k, v in stats.items() if not str(k).startswith("_")}),
                    summary, reviewer, review_note, now_iso(),
                ),
            )
            self.db.audit(
                conn, action="judgement", entity_type="experiment_run", entity_id=self._run["id"],
                after={"decision": decision, "reviewer": reviewer, "review_note": review_note},
                note="保存实验判定快照",
            )

    def _manual_review(self):
        if not self._judgement:
            return
        dialog = ManualReviewDialog(self, self._judgement)
        if dialog.show():
            data = dialog.result
            try:
                self._insert_judgement(
                    data["decision"], self._stats, reviewer=data["reviewer"],
                    review_note=data["review_note"],
                    summary=f"人工复核：{data['review_note'] or '无说明'}", rules=self._judgement.get("rules", []),
                )
                self.app.notify("人工复核结论已保存，原始记录未被修改", "success")
                self.refresh()
            except Exception as exc:
                self.app.show_error("保存失败", exc)

    # ------------------------------------------------------------------ 试次表格
    def _build_trials_panel(self, config_row):
        outer, body = section_card(self.inner, "逐次测量记录", "双击编辑；删除会写入审计日志并保留修改前快照")
        outer.pack(fill="both", expand=True, pady=(0, 10))
        self.trial_table = DataTable(
            body,
            [
                {"key": "trial_index", "label": "次数", "width": 48, "anchor": "center"},
                {"key": "status_label", "label": "状态", "width": 70},
                {"key": "measured_distance_m", "label": "测量距离 m", "width": 100, "digits": 3, "anchor": "e"},
                {"key": "true_distance_m", "label": "真值 m", "width": 75, "digits": 3, "anchor": "e"},
                {"key": "error", "label": "误差 m", "width": 75, "digits": 3, "anchor": "e"},
                {"key": "polarity_label", "label": "极性", "width": 50, "anchor": "center"},
                {"key": "quality_flag", "label": "质量", "width": 80},
                {"key": "candidate_count", "label": "候选/匹配", "width": 80, "anchor": "center"},
                {"key": "notes", "label": "备注", "width": 230},
                {"key": "measured_at", "label": "测量时间", "width": 150},
            ],
            height=9, on_double_click=lambda row: self._edit_trial(row),
        )
        self.trial_table.pack(fill="both", expand=True)
        self._trial_rows: list[dict] = []
        trials = self.app.repos.trials.list_for_run(self._run["id"])
        rows = []
        for trial in trials:
            error = None
            if trial.get("measured_distance_m") is not None and trial.get("true_distance_m") is not None:
                error = float(trial["measured_distance_m"]) - float(trial["true_distance_m"])
            rows.append(
                {
                    **trial,
                    "status_label": TRIAL_STATUS_LABELS.get(trial["detection_status"], trial["detection_status"]),
                    "polarity_label": CODE_TO_POLARITY.get(trial.get("polarity"), "—"),
                    "error": error,
                    "candidate_count": (
                        f"{trial.get('candidate_count', 0)} / {trial.get('matched_count', 0)}"
                        if config_row["mode"] == "multi" else "—"
                    ),
                    "measured_at": str(trial.get("measured_at", ""))[:19].replace("T", " "),
                    "_status_tag": {"false_alarm": "bad", "not_detected": "warn", "invalid": "warn", "rejected": "warn"}.get(trial["detection_status"], ""),
                }
            )
        self._trial_rows = trials
        self.trial_table.set_rows(rows)
        actions = tk.Frame(body, bg=COLORS["card"])
        actions.pack(fill="x", pady=(8, 0))
        ttk.Button(actions, text="编辑选中", command=self._edit_selected, style="Ghost.TButton").pack(side="left")
        ttk.Button(actions, text="删除选中", command=self._delete_selected, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(actions, text="复制测量值", command=self._copy_selected_values, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(actions, text="候选匹配详情", command=self._candidate_detail, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(actions, text="为此试次上传附件", command=self._upload_for_trial, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.trial_count_label = tk.Label(actions, text=f"共 {len(rows)} 条", bg=COLORS["card"],
                                          fg=COLORS["muted"], font=("Microsoft YaHei UI", 8))
        self.trial_count_label.pack(side="right")

    def _selected_trial(self):
        row = self.trial_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择一个试次", parent=self)
            return None
        return self.app.repos.trials.get(row["id"])

    def _edit_trial(self, row=None):
        row = row or self.trial_table.selected_row()
        if not row:
            return
        trial = self.app.repos.trials.get(row["id"])
        if not trial:
            return
        mode = self._config_row()["mode"]
        if mode == "multi":
            candidates = self.app.repos.trials.candidates(trial["id"])
            dialog = MultiTrialDialog(self, self.app.repos.trials, trial, candidates)
        else:
            dialog = TrialEditDialog(self, self.app.repos.trials, trial, mode)
        if dialog.show():
            self.app.notify("测量记录已更新（审计留痕）", "success")
            self.refresh()

    def _edit_selected(self):
        self._edit_trial()

    def _delete_selected(self):
        trial = self._selected_trial()
        if not trial:
            return
        if not messagebox.askyesno(
            "删除测量记录",
            f"确定删除第 {trial['trial_index']} 次记录？\n"
            "该操作会写入审计日志，但不会自动恢复；建议先备份数据库。",
            parent=self,
        ):
            return
        try:
            self.app.repos.trials.delete(trial["id"])
            self.app.notify("测量记录已删除", "success")
            self.refresh()
        except Exception as exc:
            self.app.show_error("删除失败", exc)

    def _copy_selected_values(self):
        trial = self._selected_trial()
        if not trial:
            return
        if self._config_row()["mode"] == "multi":
            self._candidate_rows = [
                {
                    "measured_distance_m": c.get("measured_distance_m"),
                    "polarity": c.get("polarity"),
                    "quality_flag": c.get("quality_flag"),
                    "notes": c.get("notes", ""),
                }
                for c in self.app.repos.trials.candidates(trial["id"])
            ]
            self.refresh()
        else:
            self.entry_status_var.set(TRIAL_STATUS_LABELS.get(trial["detection_status"], "检出"))
            self.entry_distance_var.set("" if trial.get("measured_distance_m") is None else str(trial["measured_distance_m"]))
            self.entry_polarity_var.set(CODE_TO_POLARITY.get(trial.get("polarity"), "不确定"))
            self.entry_quality_var.set(trial.get("quality_flag") or "正常")
            self.entry_note_var.set(trial.get("notes") or "")
            self._focus_entry()

    def _candidate_detail(self):
        trial = self._selected_trial()
        if not trial:
            return
        if self._config_row()["mode"] != "multi":
            messagebox.showinfo("提示", "当前实验不是多异常模式。", parent=self)
            return
        candidates = self.app.repos.trials.candidates(trial["id"])
        expected = self.app.repos.runs.expected_anomalies(self._run["id"])
        CandidateDetailDialog(self, expected, candidates, trial).show()

    # ------------------------------------------------------------------ 附件
    def _build_attachments_panel(self):
        outer, body = section_card(self.inner, "原始日志与附件", "UART / RAW / CORR / 截图，复制入本地数据目录并计算 SHA-256")
        outer.pack(fill="both", expand=True, pady=(0, 10))
        self.attachment_table = DataTable(
            body,
            [
                {"key": "file_name", "label": "文件名", "width": 260},
                {"key": "category", "label": "类别", "width": 110},
                {"key": "size_label", "label": "大小", "width": 75, "anchor": "e"},
                {"key": "sha_short", "label": "SHA-256（前16位）", "width": 160},
                {"key": "uploaded_at", "label": "上传时间", "width": 150},
                {"key": "notes", "label": "备注", "width": 220},
            ],
            height=5,
        )
        self.attachment_table.pack(fill="x")
        self._attachments = self.app.repos.attachments.list(self._run["id"])
        rows = []
        for att in self._attachments:
            rows.append(
                {
                    **att,
                    "size_label": _human_size(att["size_bytes"]),
                    "sha_short": att["sha256"][:16],
                    "uploaded_at": str(att["uploaded_at"])[:19].replace("T", " "),
                }
            )
        self.attachment_table.set_rows(rows)
        actions = tk.Frame(body, bg=COLORS["card"])
        actions.pack(fill="x", pady=(8, 0))
        ttk.Button(actions, text="上传附件", command=self._upload_attachment, style="Primary.TButton").pack(side="left")
        ttk.Button(actions, text="校验 SHA-256", command=self._verify_attachment, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(actions, text="打开文件", command=self._open_attachment, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(actions, text="删除附件", command=self._delete_attachment, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        tk.Label(actions, text="附件删除只在确认后进行，原始文件也会移除；数据库备份不受影响。",
                 bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(side="right")

    def _selected_attachment(self):
        row = self.attachment_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择附件", parent=self)
            return None
        return next((a for a in self._attachments if a["id"] == row["id"]), None)

    def _upload_attachment(self):
        dialog = AttachmentDialog(self, self.app.repos.attachments, self._run["id"])
        if dialog.show():
            self.app.notify("附件已复制并登记", "success")
            self.refresh()

    def _upload_for_trial(self):
        trial = self._selected_trial()
        if not trial:
            return
        dialog = AttachmentDialog(self, self.app.repos.attachments, self._run["id"], trial["id"])
        if dialog.show():
            self.app.notify("试次附件已上传", "success")
            self.refresh()

    def _verify_attachment(self):
        att = self._selected_attachment()
        if not att:
            return
        ok, message = self.app.repos.attachments.verify(att)
        messagebox.showinfo("附件校验", message, parent=self)

    def _open_attachment(self):
        att = self._selected_attachment()
        if not att:
            return
        from ..widgets import open_local_path

        try:
            open_local_path(self.app.repos.attachments.path(att))
        except Exception as exc:
            self.app.show_error("无法打开附件", exc)

    def _delete_attachment(self):
        att = self._selected_attachment()
        if not att:
            return
        if not messagebox.askyesno("删除附件", f"确定删除附件 {att['file_name']}？\n数据库记录和原始文件均会删除。", parent=self):
            return
        try:
            self.app.repos.attachments.delete(att["id"])
            self.app.notify("附件已删除", "success")
            self.refresh()
        except Exception as exc:
            self.app.show_error("删除失败", exc)

    # ------------------------------------------------------------------ 条件/计划
    def _edit_conditions(self):
        if not self._run:
            return
        dialog = ConditionsDialog(self, self.app, self._run)
        if dialog.show():
            self.app.notify("实验条件已保存", "success")
            self.refresh()

    def _change_planned(self):
        if not self._config_id:
            return
        current = self._config_row()["planned_repeats"]
        value = simpledialog.askinteger("调整计划重复次数", "输入新的计划重复次数（不会删除已录入数据）：",
                                        initialvalue=current, minvalue=1, maxvalue=9999, parent=self)
        if not value:
            return
        try:
            self.app.repos.experiments.set_planned_repeats(self._config_id, value)
            self.app.notify("计划重复次数已更新", "success")
            self.refresh()
        except Exception as exc:
            self.app.show_error("修改失败", exc)

    def _complete_group(self):
        if not self._config_id:
            return
        done = self._stats["total_trials"] if self._stats else 0
        planned = self._config_row()["planned_repeats"]
        extra = "\n当前已完成次数少于计划，自动判定仍可能显示“数据不足”。" if done < planned else ""
        if not messagebox.askyesno("完成本组实验", f"将本组标记为已完成？\n已完成 {done} / {planned} 次。{extra}", parent=self):
            return
        try:
            self.app.repos.experiments.set_status(self._config_id, "completed")
            self.app.notify("本组已标记完成", "success")
            self.refresh()
        except Exception as exc:
            self.app.show_error("操作失败", exc)


class BatchPasteDialog(ModalDialog):
    def __init__(self, parent, run, config_row):
        self.run = run
        self.config_row = config_row
        self.count = 0
        super().__init__(parent, "批量粘贴试次", width=700, height=600)

    def build_body(self, parent):
        tk.Label(parent, text="每行一条，字段用逗号或 Tab 分隔：测量距离, 极性(正/负/无), 质量标记, 备注",
                 bg=COLORS["bg"], fg=COLORS["text"], font=("Microsoft YaHei UI", 9), anchor="w").pack(fill="x")
        tk.Label(parent, text="距离留空视为未检出。所有行都会作为独立试次保存，不覆盖已有数据。",
                 bg=COLORS["bg"], fg=COLORS["warning"], font=("Microsoft YaHei UI", 8), anchor="w").pack(fill="x", pady=(2, 8))
        self.text = tk.Text(parent, height=16, wrap="none", font=("Consolas", 10), relief="solid", bd=1)
        self.text.pack(fill="both", expand=True)
        self.status = tk.Label(parent, text="", bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8))
        self.status.pack(fill="x", pady=(6, 0))

    def on_save(self):
        lines = [line for line in self.text.get("1.0", "end").splitlines() if line.strip()]
        if not lines:
            raise ValueError("没有可导入的内容")
        inserted = 0
        errors = []
        for line_no, line in enumerate(lines, start=1):
            parts = [p.strip() for p in line.replace("\t", ",").split(",")]
            distance_text = parts[0] if parts else ""
            polarity_label = parts[1] if len(parts) > 1 else "不确定"
            quality = parts[2] if len(parts) > 2 and parts[2] else "正常"
            note = ",".join(parts[3:]) if len(parts) > 3 else ""
            if not distance_text or distance_text in {"-", "—", "未检出"}:
                status = "not_detected"
                distance = None
                polarity = "unknown"
            else:
                distance = safe_float(distance_text)
                if distance is None:
                    errors.append(f"第 {line_no} 行距离无效")
                    continue
                status = "detected"
                polarity = POLARITY_TO_CODE.get(polarity_label, "unknown")
            try:
                self.parent.app.repos.trials.create(
                    self.run["id"], measured_distance_m=distance, polarity=polarity,
                    detection_status=status, quality_flag=quality, notes=note,
                )
                inserted += 1
            except Exception as exc:
                errors.append(f"第 {line_no} 行：{exc}")
        if errors:
            self.status.configure(text=f"已保存 {inserted} 条，{len(errors)} 条失败；" + "；".join(errors[:4]))
            if inserted == 0:
                raise ValueError("全部行保存失败：" + "；".join(errors[:4]))
        self.result = inserted
        return True


def _human_size(size: int) -> str:
    value = float(size or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"
