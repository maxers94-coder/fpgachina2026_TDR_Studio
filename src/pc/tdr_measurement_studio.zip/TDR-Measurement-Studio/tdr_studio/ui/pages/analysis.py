"""数据分析与可视化页面。"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Any

from ...config import COLORS, MODE_LABELS
from ...services.analytics import (
    batch_comparison,
    board_performance,
    detection_vs_gamma,
    error_by_distance,
    load_rules,
    multi_anomaly_summary,
    multi_mapping,
    scope_runs,
    scope_stats,
    run_stats,
)
from ..widgets import DataTable
from ...utils import format_number, format_percent
from ..base import BasePage
from ..theme import card
from ..widgets import MetricCard, page_header, section_card

try:
    import matplotlib

    matplotlib.use("TkAgg")
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
    from matplotlib.figure import Figure

    matplotlib.rcParams["font.sans-serif"] = [
        "Microsoft YaHei UI", "Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "DejaVu Sans",
    ]
    matplotlib.rcParams["axes.unicode_minus"] = False
    MATPLOTLIB_AVAILABLE = True
except Exception:
    MATPLOTLIB_AVAILABLE = False


class AnalysisPage(BasePage):
    key = "analysis"
    title = "数据分析"
    subtitle = "从原始试次重建统计与六类图表"

    def build(self):
        header = page_header(self, "数据分析", "筛选条件决定统计口径；图表全部由数据库真实记录生成。")
        header.pack(fill="x", pady=(4, 10))
        filter_card = card(self)
        filter_card.pack(fill="x", pady=(0, 10))
        row = tk.Frame(filter_card, bg=COLORS["card"])
        row.pack(fill="x", padx=14, pady=9)
        self.filter_batch = tk.StringVar(value="全部批次")
        self.filter_category = tk.StringVar(value="全部类别")
        self.filter_board = tk.StringVar(value="全部测试板")
        self.filter_mode = tk.StringVar(value="全部模式")
        self._combos = {}
        for label, variable, width in [
            ("批次", self.filter_batch, 20), ("类别", self.filter_category, 18),
            ("测试板", self.filter_board, 18), ("模式", self.filter_mode, 10),
        ]:
            tk.Label(row, text=label, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8)).pack(side="left")
            combo = ttk.Combobox(row, textvariable=variable, state="readonly", width=width)
            combo.pack(side="left", padx=(3, 8))
            self._combos[label] = combo
        ttk.Button(row, text="应用筛选", command=self.refresh, style="Primary.TButton").pack(side="left")
        ttk.Button(row, text="重置", command=self._reset, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.count_label = tk.Label(row, text="", bg=COLORS["card"], fg=COLORS["muted"],
                                    font=("Microsoft YaHei UI", 8))
        self.count_label.pack(side="right")

        self.metric_row = tk.Frame(self, bg=COLORS["bg"])
        self.metric_row.pack(fill="x", pady=(0, 10))
        self.metrics: dict[str, MetricCard] = {}
        for index, (key, title, note) in enumerate([
            ("trials", "有效试次", "已保存记录"),
            ("detection", "异常检出率", "未检出在分母"),
            ("location", "定位合格率", "容差内 / 有效定位"),
            ("mae", "定位 MAE", "仅有效定位"),
            ("false_alarm", "正常误报率", "正常参考组"),
        ]):
            metric = MetricCard(self.metric_row, title, "不适用", note)
            metric.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 7, 0))
            self.metric_row.grid_columnconfigure(index, weight=1)
            self.metrics[key] = metric

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)
        self.tabs: dict[str, tk.Frame] = {}
        for key, label in [
            ("repeat", "重复定位"), ("error", "误差分布"), ("distance", "误差随距离"),
            ("gamma", "检出率-反射系数"), ("board", "测试板对比"), ("multi", "多异常定位"),
            ("versions", "批次/版本对比"),
        ]:
            tab = tk.Frame(self.notebook, bg=COLORS["bg"])
            self.notebook.add(tab, text=f"  {label}  ")
            self.tabs[key] = tab
        self.notebook.bind("<<NotebookTabChanged>>", lambda event: self._render_current_tab())
        self._data: dict[str, Any] = {}
        self._figures: dict[str, Any] = {}
        self._fig = None
        self._canvas = None
        self._current_tab = "repeat"
        self._selected_run_id: str | None = None

    def _reset(self):
        self.filter_batch.set("全部批次")
        self.filter_category.set("全部类别")
        self.filter_board.set("全部测试板")
        self.filter_mode.set("全部模式")
        self.refresh()

    def _fill_filters(self):
        batches = self.app.repos.batches.list()
        categories = self.app.repos.categories.list()
        boards = self.app.repos.boards.list()
        self._combos["批次"].configure(values=["全部批次"] + [f"{b['code']}｜{b['name']}" for b in batches])
        self._combos["类别"].configure(values=["全部类别"] + [f"{c['code']}｜{c['name']}" for c in categories])
        self._combos["测试板"].configure(values=["全部测试板"] + [f"{b['code']}｜{b['name']}" for b in boards])
        self._combos["模式"].configure(values=["全部模式"] + list(MODE_LABELS.values()))

    def _filters(self):
        batch = next((b["id"] for b in self.app.repos.batches.list()
                      if f"{b['code']}｜{b['name']}" == self.filter_batch.get()), None)
        category = next((c["id"] for c in self.app.repos.categories.list()
                         if f"{c['code']}｜{c['name']}" == self.filter_category.get()), None)
        board = next((b["id"] for b in self.app.repos.boards.list()
                      if f"{b['code']}｜{b['name']}" == self.filter_board.get()), None)
        mode = next((k for k, v in MODE_LABELS.items() if v == self.filter_mode.get()), None)
        return batch, category, board, mode

    def refresh(self):
        self._fill_filters()
        batch, category, board, mode = self._filters()
        try:
            overall, stats_list = scope_stats(
                self.db, batch_id=batch, category_id=category, board_id=board, mode=mode
            )
            self._data = {
                "overall": overall,
                "stats_list": stats_list,
                "batch_id": batch,
                "category_id": category,
                "board_id": board,
                "mode": mode,
                "runs": scope_runs(self.db, batch_id=batch, category_id=category, board_id=board, mode=mode),
            }
        except Exception as exc:
            self.app.notify(f"分析数据加载失败：{exc}", "error")
            return
        self._update_metrics(overall)
        self.count_label.configure(text=f"实测配置 {len(stats_list)} 组 · 试次 {overall.get('total_trials', 0)} 条")
        self._selected_run_id = None
        self._render_current_tab()

    def _update_metrics(self, stats):
        self.metrics["trials"].update_value(str(stats.get("total_trials", 0)),
                                            f"无效/拒判 {stats.get('invalid_count', 0) + stats.get('rejected_count', 0)}")
        detection = stats.get("anomaly_detection_rate")
        self.metrics["detection"].update_value(
            format_percent(detection) if detection is not None else "不适用",
            f"检出 {stats.get('detected_count', 0)} / 未检出 {stats.get('not_detected_count', 0)}",
        )
        location = stats.get("location_pass_rate")
        self.metrics["location"].update_value(
            format_percent(location) if location is not None else "不适用",
            f"有效定位 {stats.get('located_count', 0)} 次，规则容差 {load_rules(self.db)['distance_tolerance_m']:.2f} m",
        )
        mae = stats["distance"].get("mae_m")
        self.metrics["mae"].update_value(
            format_number(mae, 3) if mae is not None else "不适用",
            f"P95 {format_number(stats['distance'].get('p95_abs_error_m'), 3)} m",
        )
        false_alarm = stats.get("false_alarm_rate")
        self.metrics["false_alarm"].update_value(
            format_percent(false_alarm) if false_alarm is not None else "不适用",
            f"正常 {stats.get('normal_count', 0)} / 误报 {stats.get('false_alarm_count', 0)}",
        )

    def _current_tab_key(self):
        try:
            index = self.notebook.index(self.notebook.select())
        except tk.TclError:
            index = 0
        return list(self.tabs.keys())[index] if 0 <= index < len(self.tabs) else "repeat"

    def _render_current_tab(self):
        key = self._current_tab_key()
        self._current_tab = key
        self._figures.pop(key, None)
        self._fig = None
        for tab in self.tabs.values():
            for child in tab.winfo_children():
                child.destroy()
        if not MATPLOTLIB_AVAILABLE:
            self._message(self.tabs[key], "当前环境缺少 matplotlib，无法显示图表。统计表和 Excel 导出不受影响。")
            return
        try:
            if key == "repeat":
                self._render_repeat()
            elif key == "error":
                self._render_error()
            elif key == "distance":
                self._render_distance()
            elif key == "gamma":
                self._render_gamma()
            elif key == "board":
                self._render_board()
            elif key == "versions":
                self._render_versions()
            else:
                self._render_multi()
        except Exception as exc:
            self._message(self.tabs[key], f"绘图失败：{exc}")

    def _message(self, parent, text: str):
        tk.Label(parent, text=text, bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 11), wraplength=850, justify="center").pack(pady=80)

    def _chart_frame(self, parent):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.pack(fill="both", expand=True, padx=4, pady=4)
        return frame

    def _show_figure(self, figure, parent, *, toolbar=False):
        buttons = tk.Frame(parent, bg=COLORS["bg"])
        buttons.pack(fill="x", pady=(4, 2))
        ttk.Button(buttons, text="导出当前图 PNG", command=lambda: self._export_figure("png"),
                   style="Ghost.TButton").pack(side="left")
        ttk.Button(buttons, text="导出当前图 SVG", command=lambda: self._export_figure("svg"),
                   style="Ghost.TButton").pack(side="left", padx=(6, 0))
        tk.Label(buttons, text="图像由真实数据生成；可调整窗口后导出当前画布。",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8)).pack(side="right")
        canvas = FigureCanvasTkAgg(figure, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        if toolbar:
            toolbar_frame = tk.Frame(parent, bg=COLORS["bg"])
            toolbar_frame.pack(fill="x")
            NavigationToolbar2Tk(canvas, toolbar_frame).update()
        self._fig = figure
        self._canvas = canvas
        self._figures[self._current_tab] = figure

    def _new_figure(self, width=9.5, height=4.15):
        fig = Figure(figsize=(width, height), dpi=100, facecolor="#FFFFFF")
        ax = fig.add_subplot(111)
        ax.set_facecolor("#FFFFFF")
        ax.grid(True, alpha=0.25)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
        return fig, ax

    def _render_repeat(self):
        tab = self.tabs["repeat"]
        runs = [r for r in self._data.get("runs", [])]
        tested = []
        for row in runs:
            stats = next((s for s in self._data["stats_list"] if s["run_id"] == row["run_id"]), None)
            if stats and stats["mode"] in {"single", "multi"} and stats["total_trials"]:
                tested.append(stats)
        if not tested:
            self._message(tab, "当前筛选下没有已测量的异常组。")
            return
        control = tk.Frame(tab, bg=COLORS["bg"])
        control.pack(fill="x", padx=4, pady=(4, 0))
        tk.Label(control, text="选择实验", bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9)).pack(side="left")
        labels = [f"{s['config_code']}｜{s['config_name']}" for s in tested]
        var = tk.StringVar(value=labels[0])
        combo = ttk.Combobox(control, textvariable=var, values=labels, state="readonly", width=62)
        combo.pack(side="left", padx=(6, 0))
        chart = self._chart_frame(tab)

        def draw(*args):
            index = labels.index(var.get()) if var.get() in labels else 0
            stats = tested[index]
            for child in chart.winfo_children():
                child.destroy()
            fig, ax = self._new_figure()
            trials = stats.get("_trials", [])
            if stats["mode"] == "multi":
                self._message(chart, "多异常组请使用“多异常定位”页查看真实位置与候选对应关系。")
                return
            measured = [t for t in trials if t.get("measured_distance_m") is not None]
            if not measured:
                self._message(chart, "该组没有有效测量距离（可能全部未检出）。")
                return
            xs = [t["trial_index"] for t in measured]
            ys = [t["measured_distance_m"] for t in measured]
            ax.plot(xs, ys, "o-", color="#0F6E6E", label="系统测量距离")
            truth = stats.get("distance_m")
            if truth is not None:
                ax.axhline(truth, color="#B42318", linestyle="--", linewidth=1.2, label=f"真实距离 {truth:.3f} m")
            tolerance = stats["rules"]["distance_tolerance_m"]
            if truth is not None:
                ax.fill_between([min(xs) - 0.5, max(xs) + 0.5], truth - tolerance, truth + tolerance,
                                color="#D97706", alpha=0.08, label=f"±{tolerance:.2f} m 容差")
            ax.set_xlabel("重复测量次数")
            ax.set_ylabel("系统报告距离 (m)")
            ax.set_title(f"重复定位结果分布 — {stats['config_code']}")
            ax.legend(fontsize=8)
            fig.tight_layout()
            self._show_figure(fig, chart)

        combo.bind("<<ComboboxSelected>>", draw)
        draw()

    def _render_error(self):
        tab = self.tabs["error"]
        errors = []
        for stats in self._data["stats_list"]:
            errors.extend(stats.get("_errors", []))
        if not errors:
            self._message(tab, "当前筛选下没有有效定位误差数据。未检出试次不会被当作 0 m。")
            return
        frame = self._chart_frame(tab)
        fig, ax = self._new_figure()
        ax.hist(errors, bins=min(24, max(5, len(errors) // 2)), color="#0F6E6E",
                edgecolor="white", alpha=0.88)
        mean = sum(errors) / len(errors)
        abs_errors = [abs(e) for e in errors]
        mae = sum(abs_errors) / len(abs_errors)
        std = (sum((e - mean) ** 2 for e in errors) / len(errors)) ** 0.5
        ax.axvline(0, color="#63747D", linewidth=1)
        ax.axvline(mean, color="#D97706", linestyle="--", linewidth=1.2, label=f"均值 {mean:+.3f} m")
        ax.axvline(mean - std, color="#B42318", linestyle=":", linewidth=1, label=f"±1σ {std:.3f} m")
        ax.axvline(mean + std, color="#B42318", linestyle=":", linewidth=1)
        ax.set_xlabel("定位误差（测量 − 真值, m）")
        ax.set_ylabel("次数")
        ax.set_title(f"定位误差分布（n={len(errors)}，MAE={mae:.3f} m）")
        ax.legend(fontsize=8)
        fig.tight_layout()
        self._show_figure(fig, frame)

    def _render_distance(self):
        tab = self.tabs["distance"]
        batch, category, board, _mode = self._filters()
        rows = error_by_distance(self.db, batch_id=batch, board_id=board, category_id=category)
        if not rows:
            self._message(tab, "当前筛选下没有单异常有效定位数据。")
            return
        frame = self._chart_frame(tab)
        fig, ax = self._new_figure()
        distances = [r["distance_m"] for r in rows]
        ax.plot(distances, [r["mae_m"] for r in rows], "o-", color="#0F6E6E", label="MAE")
        ax.plot(distances, [r["rmse_m"] for r in rows], "s--", color="#D97706", label="RMSE")
        for row in rows:
            ax.annotate(f"{row['board_code']} n={row['n']}", (row["distance_m"], row["mae_m"]),
                        textcoords="offset points", xytext=(4, 6), fontsize=7, color="#63747D")
        ax.set_xlabel("真实距离 (m)")
        ax.set_ylabel("误差 (m)")
        ax.set_title("定位误差随距离变化（按测试板距离分组）")
        ax.legend(fontsize=8)
        fig.tight_layout()
        self._show_figure(fig, frame)

    def _render_gamma(self):
        tab = self.tabs["gamma"]
        batch, category, _board, _mode = self._filters()
        rows = detection_vs_gamma(self.db, batch_id=batch, category_id=category)
        rows = [r for r in rows if r.get("abs_gamma") is not None and r.get("detection_rate") is not None]
        if not rows:
            self._message(tab, "当前筛选下没有可用的理论反射系数与检出率组合。")
            return
        frame = self._chart_frame(tab)
        fig, ax = self._new_figure()
        for polarity, color, marker, label in [
            ("positive", "#B42318", "o", "正反射"), ("negative", "#175CD3", "s", "负反射"),
        ]:
            subset = [r for r in rows if r["polarity"] == polarity]
            if subset:
                ax.scatter([r["abs_gamma"] for r in subset], [r["detection_rate"] for r in subset],
                           color=color, marker=marker, s=60, label=label)
                for r in subset:
                    ax.annotate(r.get("board_code") or "", (r["abs_gamma"], r["detection_rate"]),
                                textcoords="offset points", xytext=(5, 5), fontsize=8)
        ax.set_xlabel("|理论反射系数|")
        ax.set_ylabel("检出率")
        ax.set_ylim(-0.02, 1.05)
        ax.set_title("检出率与理论反射系数（理想模型理论值）")
        ax.legend(fontsize=8)
        fig.tight_layout()
        self._show_figure(fig, frame)

    def _render_board(self):
        tab = self.tabs["board"]
        batch, category, _board, _mode = self._filters()
        rows = board_performance(self.db, batch_id=batch, category_id=category)
        if not rows:
            self._message(tab, "当前筛选下没有测试板性能数据。")
            return
        frame = self._chart_frame(tab)
        fig = Figure(figsize=(9.5, 4.15), dpi=100, facecolor="#FFFFFF")
        ax1, ax2 = fig.subplots(1, 2)
        for ax in (ax1, ax2):
            ax.set_facecolor("#FFFFFF")
            ax.grid(True, alpha=0.25)
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
        labels = [r["board_code"] for r in rows]
        detection = [r["detection_rate"] or 0 for r in rows]
        mae = [r["mae_m"] or 0 for r in rows]
        colors = ["#0F6E6E" if (r["detection_rate"] or 0) >= 0.95 else "#B42318" for r in rows]
        bars = ax1.bar(labels, detection, color=colors, width=0.55)
        for bar, row in zip(bars, rows):
            value = row["detection_rate"]
            ax1.text(bar.get_x() + bar.get_width() / 2, min(1.0, bar.get_height() + 0.02),
                     "—" if value is None else f"{value * 100:.1f}%", ha="center", fontsize=7)
        ax1.set_ylim(0, 1.08)
        ax1.set_ylabel("检出率")
        ax1.set_title("检出率")
        ax1.tick_params(axis="x", labelsize=8)
        bars2 = ax2.bar(labels, mae, color="#D97706", width=0.55)
        for bar, row in zip(bars2, rows):
            ax2.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.002,
                     f"{row['mae_m']:.3f}" if row["mae_m"] is not None else "—", ha="center", fontsize=7)
        ax2.set_ylabel("MAE (m)")
        ax2.set_title("定位 MAE")
        ax2.tick_params(axis="x", labelsize=8)
        fig.tight_layout()
        self._show_figure(fig, frame)

    def _render_versions(self):
        tab = self.tabs["versions"]
        rows = batch_comparison(self.db)
        container = tk.Frame(tab, bg=COLORS["bg"])
        container.pack(fill="both", expand=True, padx=4, pady=4)
        tk.Label(container, text="不同固件 / 模拟前端 / 批次的性能对比（未测量项显示为 —，不填假设值）",
                 bg=COLORS["bg"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 9), anchor="w").pack(
            fill="x", pady=(0, 5)
        )
        table = DataTable(
            container,
            [
                {"key": "batch_name", "label": "批次", "width": 220},
                {"key": "firmware_version", "label": "固件", "width": 105},
                {"key": "frontend_label", "label": "前端", "width": 100},
                {"key": "config_count", "label": "配置", "width": 55, "anchor": "center"},
                {"key": "total_trials", "label": "试次", "width": 55, "anchor": "center"},
                {"key": "detection_rate", "label": "检出率", "width": 75, "percent": True, "anchor": "e"},
                {"key": "mae_m", "label": "MAE m", "width": 75, "digits": 3, "anchor": "e"},
                {"key": "p95_abs_error_m", "label": "P95 m", "width": 75, "digits": 3, "anchor": "e"},
                {"key": "false_alarm_rate", "label": "正常误报率", "width": 90, "percent": True, "anchor": "e"},
                {"key": "polarity_accuracy", "label": "极性正确率", "width": 95, "percent": True, "anchor": "e"},
                {"key": "comprehensive_success_rate", "label": "综合成功率", "width": 95, "percent": True, "anchor": "e"},
            ],
            height=12,
        )
        table.pack(fill="both", expand=True)
        display = []
        for row in rows:
            item = dict(row)
            item["frontend_label"] = {
                "resistive_divider": "电阻功分器", "swr_bridge": "SWR 电桥", "custom": "自定义",
            }.get(row.get("frontend"), row.get("frontend"))
            display.append(item)
        table.set_rows(display)

    def _render_multi(self):
        tab = self.tabs["multi"]
        batch, category, _board, _mode = self._filters()
        rows = multi_mapping(self.db, batch_id=batch)
        allowed_runs = {r["run_id"] for r in self._data.get("runs", [])}
        rows = [r for r in rows if r.get("run_id") in allowed_runs]
        summary = multi_anomaly_summary(self.db, batch_id=batch, category_id=category)
        if not rows and not summary:
            self._message(tab, "当前筛选下没有多异常记录。")
            return
        main = tk.Frame(tab, bg=COLORS["bg"])
        main.pack(fill="both", expand=True)
        chart_area = tk.Frame(main, bg=COLORS["bg"])
        chart_area.pack(fill="both", expand=True)
        table_area = tk.Frame(main, bg=COLORS["bg"], height=235)
        table_area.pack(fill="x", pady=(4, 0))
        table_area.pack_propagate(False)
        if rows:
            frame = self._chart_frame(chart_area)
            fig, ax = self._new_figure(height=3.05)
            xs = [r["true_distance_m"] for r in rows]
            ys = [r["measured_distance_m"] for r in rows]
            ax.scatter(xs, ys, color="#0F6E6E", s=45, alpha=0.85)
            low = min(xs + ys) - 1
            high = max(xs + ys) + 1
            ax.plot([low, high], [low, high], color="#B42318", linestyle="--", linewidth=1, label="理想 y=x")
            ax.set_xlabel("真实异常距离 (m)")
            ax.set_ylabel("匹配候选距离 (m)")
            ax.set_title(f"多异常真实位置与识别位置（n={len(rows)} 个匹配对）")
            ax.legend(fontsize=8)
            fig.tight_layout()
            self._show_figure(fig, frame)
        else:
            self._message(chart_area, "当前多异常记录中没有成功匹配的候选对。")
        tk.Label(table_area, text="逐真实异常统计（按配置区分；无匹配时仍显示检出率）", bg=COLORS["bg"],
                 fg=COLORS["muted"], font=("Microsoft YaHei UI", 8), anchor="w").pack(fill="x", padx=4)
        table = DataTable(
            table_area,
            [
                {"key": "config_code", "label": "实验", "width": 62},
                {"key": "anomaly_index", "label": "异常", "width": 45, "anchor": "center"},
                {"key": "board_code", "label": "板", "width": 45, "anchor": "center"},
                {"key": "true_distance_m", "label": "真值 m", "width": 75, "digits": 3, "anchor": "e"},
                {"key": "expected_polarity_label", "label": "极性", "width": 48, "anchor": "center"},
                {"key": "resolved_trials", "label": "有效次数", "width": 65, "anchor": "center"},
                {"key": "detected_count", "label": "检出", "width": 50, "anchor": "center"},
                {"key": "detection_rate", "label": "检出率", "width": 65, "percent": True, "anchor": "e"},
                {"key": "mae_m", "label": "MAE m", "width": 70, "digits": 3, "anchor": "e"},
                {"key": "mean_error_m", "label": "平均误差 m", "width": 85, "digits": 3, "anchor": "e"},
                {"key": "within_tolerance_rate", "label": "定位合格率", "width": 85, "percent": True, "anchor": "e"},
            ],
            height=6,
        )
        table.pack(fill="both", expand=True, padx=4, pady=(2, 4))
        polarity_label = {"positive": "正", "negative": "负", "none": "无", "unknown": "不确定"}
        table.set_rows(
            [
                {**item, "expected_polarity_label": polarity_label.get(item.get("expected_polarity"), "—")}
                for item in summary
            ]
        )

    def _export_figure(self, fmt: str):
        fig = self._figures.get(self._current_tab)
        if fig is None:
            messagebox.showinfo("提示", "当前页没有可导出的图", parent=self)
            return
        path = filedialog.asksaveasfilename(
            parent=self, title=f"导出 {fmt.upper()} 图表",
            defaultextension=f".{fmt}",
            filetypes=[(f"{fmt.upper()} 图像", f"*.{fmt}")],
            initialfile=f"TDR_{self._current_tab}.{fmt}",
        )
        if not path:
            return
        try:
            fig.savefig(path, format=fmt, dpi=200, facecolor="#FFFFFF", bbox_inches="tight")
            self.app.notify(f"图表已导出：{Path(path).name}", "success")
        except Exception as exc:
            self.app.show_error("导出图表失败", exc)
