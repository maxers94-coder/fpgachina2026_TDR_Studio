"""测试板管理。"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from ... import config
from ...config import BOARD_STATUS_LABELS, BOARD_TYPE_LABELS, COLORS
from ...services.reflection import calculate_gamma, gamma_percent, reflection_strength
from ...utils import format_number, format_percent
from ..base import BasePage
from ..widgets import (
    DataTable,
    ModalDialog,
    page_header,
    section_card,
)
from ..theme import card


class BoardDialog(ModalDialog):
    def __init__(self, parent, repo, board: dict | None = None):
        self.repo = repo
        self.board = board
        self.photo_source: str | None = None
        super().__init__(parent, "编辑测试板" if board else "新增测试板", width=780, height=720)

    def build_body(self, parent):
        form = tk.Frame(parent, bg=COLORS["bg"])
        form.pack(fill="both", expand=True)
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        board = self.board or {}
        self.code_var = tk.StringVar(value=board.get("code", ""))
        self.name_var = tk.StringVar(value=board.get("name", ""))
        type_label = BOARD_TYPE_LABELS.get(board.get("board_type", "series"), "串联")
        self.type_var = tk.StringVar(value=type_label)
        self.nominal_var = tk.StringVar(
            value="" if board.get("nominal_ohm") is None else str(board.get("nominal_ohm"))
        )
        self.measured_var = tk.StringVar(
            value="" if board.get("measured_ohm") is None else str(board.get("measured_ohm"))
        )
        self.z0_var = tk.StringVar(value=str(board.get("z0") or 50))
        self.override_var = tk.StringVar(
            value="" if board.get("gamma_override") is None else str(board.get("gamma_override"))
        )
        self.pcb_var = tk.StringVar(value=board.get("pcb_no", ""))
        self.component_var = tk.StringVar(value=board.get("component_model", ""))
        self.date_var = tk.StringVar(value=board.get("manufacture_date", ""))
        status_label = BOARD_STATUS_LABELS.get(board.get("status", "available"), "可用")
        self.status_var = tk.StringVar(value=status_label)
        self.photo_var = tk.StringVar(value=board.get("photo_path", ""))
        self._make_field(form, "测试板代号 *", self.code_var, 0, 0, hint="物理板唯一代号，例如 A、B、N2")
        self._make_field(form, "测试板名称 *", self.name_var, 0, 1, hint="例如 2Ω 串联异常")
        self.type_combo = self._make_combo(
            form, "测试板类型 *", self.type_var, list(BOARD_TYPE_LABELS.values()), 1, 0
        )
        self._make_field(form, "标称阻值 (Ω)", self.nominal_var, 1, 1, hint="串联/并联必填")
        self._make_field(form, "实测阻值 (Ω)", self.measured_var, 2, 0, hint="可选；用于计算实测阻值对应的理论 Γ")
        self._make_field(form, "特性阻抗 Z0 (Ω)", self.z0_var, 2, 1, hint="默认 50 Ω")
        self._make_field(form, "自定义反射系数 (-1~+1)", self.override_var, 3, 0,
                         hint="仅“自定义”类型使用；不是仪器实测值")
        self._make_combo(form, "当前状态", self.status_var, list(BOARD_STATUS_LABELS.values()), 3, 1)
        self._make_field(form, "PCB 编号", self.pcb_var, 4, 0)
        self._make_field(form, "元件型号", self.component_var, 4, 1)
        self._make_field(form, "制作日期", self.date_var, 5, 0, hint="YYYY-MM-DD")
        photo_row = tk.Frame(form, bg=COLORS["bg"])
        photo_row.grid(row=5, column=1, sticky="ew", padx=(0, 0), pady=5)
        tk.Label(photo_row, text="测试板照片", bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
        row = tk.Frame(photo_row, bg=COLORS["bg"])
        row.pack(fill="x", pady=(2, 0))
        ttk.Entry(row, textvariable=self.photo_var, state="readonly").pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="选择…", command=self._choose_photo).pack(side="left", padx=(6, 0))
        tk.Label(form, text="备注", bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), anchor="w").grid(row=6, column=0, columnspan=2, sticky="w", pady=(8, 2))
        self.notes_text = tk.Text(form, height=4, wrap="word", bg="white", relief="solid", bd=1,
                                  font=("Microsoft YaHei UI", 9))
        self.notes_text.grid(row=7, column=0, columnspan=2, sticky="nsew")
        self.notes_text.insert("1.0", board.get("notes", ""))
        preview_frame = tk.Frame(form, bg="#EAF4F4", highlightbackground=COLORS["border"], highlightthickness=1)
        preview_frame.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        self.preview_label = tk.Label(
            preview_frame, text="", bg="#EAF4F4", fg=COLORS["primary"],
            font=("Microsoft YaHei UI", 10, "bold"), anchor="w", justify="left", padx=12, pady=10,
        )
        self.preview_label.pack(fill="x")
        for variable in (self.type_var, self.nominal_var, self.measured_var, self.z0_var, self.override_var):
            variable.trace_add("write", lambda *args: self._update_preview())
        self._update_preview()

    def _make_field(self, parent, label, variable, row, column, hint=""):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=column, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
        ttk.Entry(frame, textvariable=variable).pack(fill="x", pady=(2, 0))
        if hint:
            tk.Label(frame, text=hint, bg=COLORS["bg"], fg="#87969C",
                     font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")

    def _make_combo(self, parent, label, variable, values, row, column):
        frame = tk.Frame(parent, bg=COLORS["bg"])
        frame.grid(row=row, column=column, sticky="ew", padx=(0, 14), pady=5)
        tk.Label(frame, text=label, bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
        combo = ttk.Combobox(frame, textvariable=variable, values=values, state="readonly")
        combo.pack(fill="x", pady=(2, 0))
        return combo

    def _choose_photo(self):
        path = filedialog.askopenfilename(
            parent=self, title="选择测试板照片",
            filetypes=[("图片", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("所有文件", "*.*")],
        )
        if path:
            self.photo_source = path
            self.photo_var.set(path)

    def _type_code(self) -> str:
        label = self.type_var.get()
        for code, text in BOARD_TYPE_LABELS.items():
            if text == label:
                return code
        return "series"

    def _update_preview(self):
        try:
            from ...utils import safe_float

            gamma = calculate_gamma(
                self._type_code(),
                nominal_ohm=safe_float(self.nominal_var.get()),
                measured_ohm=safe_float(self.measured_var.get()),
                z0=safe_float(self.z0_var.get()) or 50.0,
                gamma_override=safe_float(self.override_var.get()),
            )
            strength_code, strength_text = reflection_strength(gamma["gamma_nominal"])
            text = (
                f"理论 Γ（标称电阻）= {gamma['gamma_nominal'] * 100:+.2f}%    "
                f"极性：{'正反射' if gamma['polarity'] == 'positive' else '负反射' if gamma['polarity'] == 'negative' else '无反射'}    "
                f"强度：{strength_text}\n{gamma['formula_note']}。该值不是仪器实测反射系数。"
            )
            self.preview_label.configure(text=text, fg=COLORS["primary"])
        except Exception as exc:
            self.preview_label.configure(text=f"参数不完整：{exc}", fg=COLORS["warning"])

    def on_save(self):
        photo_path = self.photo_var.get().strip()
        if self.photo_source:
            photo_path = self.repo.save_photo(self.code_var.get().strip() or "board", self.photo_source)
        data = {
            "code": self.code_var.get().strip(),
            "name": self.name_var.get().strip(),
            "board_type": self._type_code(),
            "nominal_ohm": self.nominal_var.get().strip(),
            "measured_ohm": self.measured_var.get().strip(),
            "z0": self.z0_var.get().strip(),
            "gamma_override": self.override_var.get().strip(),
            "pcb_no": self.pcb_var.get().strip(),
            "component_model": self.component_var.get().strip(),
            "manufacture_date": self.date_var.get().strip(),
            "photo_path": photo_path,
            "notes": self.notes_text.get("1.0", "end").strip(),
            "status": next((k for k, v in BOARD_STATUS_LABELS.items() if v == self.status_var.get()), "available"),
        }
        if self.board:
            self.result = self.repo.update(self.board["id"], data)
        else:
            self.result = self.repo.create(data)
        return True


class StatusDialog(ModalDialog):
    def __init__(self, parent, repo, board):
        self.repo = repo
        self.board = board
        super().__init__(parent, "修改测试板状态", width=440, height=240)

    def build_body(self, parent):
        tk.Label(parent, text=f"{self.board['code']}｜{self.board['name']}", bg=COLORS["bg"],
                 font=("Microsoft YaHei UI", 11, "bold"), anchor="w").pack(fill="x", pady=(4, 10))
        self.status_var = tk.StringVar(
            value=BOARD_STATUS_LABELS.get(self.board.get("status"), "可用")
        )
        combo = ttk.Combobox(parent, textvariable=self.status_var, values=list(BOARD_STATUS_LABELS.values()),
                             state="readonly")
        combo.pack(fill="x")
        tk.Label(parent, text="停用不会删除历史实验关联。", bg=COLORS["bg"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 8), anchor="w").pack(fill="x", pady=(8, 0))

    def on_save(self):
        status = next((k for k, v in BOARD_STATUS_LABELS.items() if v == self.status_var.get()), "available")
        self.repo.set_status(self.board["id"], status)
        self.result = True
        return True


class BoardsPage(BasePage):
    key = "boards"
    title = "测试板管理"
    subtitle = "维护全部物理阻抗测试板、理论反射系数与状态"

    def build(self):
        header = page_header(
            self, "测试板资产", "同一阻值允许多块独立物理板；代号唯一，理论 Γ 自动计算。",
            actions=[("新增测试板", self._new_board, "Primary.TButton")],
        )
        header.pack(fill="x", pady=(4, 14))

        toolbar = card(self)
        toolbar.pack(fill="x", pady=(0, 12))
        row = tk.Frame(toolbar, bg=COLORS["card"])
        row.pack(fill="x", padx=14, pady=10)
        tk.Label(row, text="搜索", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9)).pack(side="left")
        self.search_var = tk.StringVar()
        search = ttk.Entry(row, textvariable=self.search_var, width=28)
        search.pack(side="left", padx=(6, 14))
        search.bind("<Return>", lambda event: self.refresh())
        tk.Label(row, text="类型", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9)).pack(side="left")
        self.type_var = tk.StringVar(value="全部")
        ttk.Combobox(row, textvariable=self.type_var, values=["全部"] + list(BOARD_TYPE_LABELS.values()),
                     state="readonly", width=10).pack(side="left", padx=(6, 14))
        tk.Label(row, text="状态", bg=COLORS["card"], fg=COLORS["muted"],
                 font=("Microsoft YaHei UI", 9)).pack(side="left")
        self.status_var = tk.StringVar(value="全部")
        ttk.Combobox(row, textvariable=self.status_var, values=["全部"] + list(BOARD_STATUS_LABELS.values()),
                     state="readonly", width=10).pack(side="left", padx=(6, 14))
        ttk.Button(row, text="查询", command=self.refresh, style="Ghost.TButton").pack(side="left")
        ttk.Button(row, text="重置", command=self._reset, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.count_label = tk.Label(row, text="", bg=COLORS["card"], fg=COLORS["muted"],
                                    font=("Microsoft YaHei UI", 9))
        self.count_label.pack(side="right")

        body = tk.Frame(self, bg=COLORS["bg"])
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=COLORS["bg"])
        left.pack(side="left", fill="both", expand=True, padx=(0, 10))
        right = tk.Frame(body, bg=COLORS["bg"], width=330)
        right.pack(side="right", fill="y")
        right.pack_propagate(False)

        table_card, table_body = section_card(left, "测试板清单", "双击行编辑；Γ 为理想模型理论值")
        table_card.pack(fill="both", expand=True)
        self.table = DataTable(
            table_body,
            [
                {"key": "code", "label": "代号", "width": 62, "anchor": "center"},
                {"key": "name", "label": "名称", "width": 190},
                {"key": "type_label", "label": "类型", "width": 65},
                {"key": "nominal_ohm", "label": "标称 Ω", "width": 72, "digits": 2, "anchor": "e"},
                {"key": "gamma_nominal", "label": "理论 Γ", "width": 82, "percent": True, "anchor": "e"},
                {"key": "polarity_label", "label": "极性", "width": 50, "anchor": "center"},
                {"key": "status_label", "label": "状态", "width": 60},
                {"key": "config_count", "label": "引用", "width": 50, "anchor": "center"},
                {"key": "pcb_no", "label": "PCB 编号", "width": 100},
            ],
            height=15,
            selectmode="browse",
            on_double_click=lambda row: self._edit_board(row),
        )
        self.table.pack(fill="both", expand=True)
        self.table.tree.bind("<<TreeviewSelect>>", lambda event: self._update_detail())
        actions = tk.Frame(table_body, bg=COLORS["card"])
        actions.pack(fill="x", pady=(10, 0))
        for text, command in [
            ("编辑", self._edit_selected), ("复制", self._duplicate_selected),
            ("修改状态", self._status_selected), ("查看照片", self._view_photo),
        ]:
            ttk.Button(actions, text=text, command=command, style="Ghost.TButton").pack(side="left", padx=(0, 6))

        detail_card, self.detail_body = section_card(right, "测试板详情", "选择一行查看")
        detail_card.pack(fill="both", expand=True)
        self.detail_labels: dict[str, tk.Label] = {}
        for key, label in [
            ("code", "代号"), ("name", "名称"), ("type", "类型"), ("ohm", "标称 / 实测"),
            ("gamma", "理论反射系数"), ("polarity", "反射极性"), ("strength", "异常强度"),
            ("z0", "特性阻抗"), ("status", "状态"), ("pcb", "PCB 编号"),
            ("component", "元件型号"), ("date", "制作日期"), ("notes", "备注"),
        ]:
            row = tk.Frame(self.detail_body, bg=COLORS["card"])
            row.pack(fill="x", pady=3)
            tk.Label(row, text=label, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8), width=9, anchor="nw").pack(side="left", anchor="n")
            value = tk.Label(row, text="—", bg=COLORS["card"], fg=COLORS["text"],
                             font=("Microsoft YaHei UI", 9), anchor="w", justify="left",
                             wraplength=210)
            value.pack(side="left", fill="x", expand=True)
            self.detail_labels[key] = value
        self.photo_label = tk.Label(self.detail_body, bg=COLORS["card"], anchor="w")
        self.photo_label.pack(fill="x", pady=(8, 0))
        self.formula_label = tk.Label(
            self.detail_body, text="Γ 为按标称/实测电阻计算的理想集总模型理论值，不是仪器实测反射系数。",
            bg="#F4F8F9", fg=COLORS["muted"], font=("Microsoft YaHei UI", 8),
            justify="left", wraplength=280, padx=8, pady=7,
        )
        self.formula_label.pack(fill="x", pady=(8, 0))
        self._boards_cache: list[dict] = []

    def _reset(self):
        self.search_var.set("")
        self.type_var.set("全部")
        self.status_var.set("全部")
        self.refresh()

    def _filters(self):
        type_label = self.type_var.get()
        board_type = next((k for k, v in BOARD_TYPE_LABELS.items() if v == type_label), "")
        status_label = self.status_var.get()
        status = next((k for k, v in BOARD_STATUS_LABELS.items() if v == status_label), "")
        return self.search_var.get().strip(), status, board_type

    def refresh(self):
        search, status, board_type = self._filters()
        boards = self.app.repos.boards.list(search=search, status=status, board_type=board_type)
        self._boards_cache = boards
        rows = []
        for board in boards:
            strength_code, strength_text = reflection_strength(board.get("gamma_nominal"))
            rows.append(
                {
                    **board,
                    "type_label": BOARD_TYPE_LABELS.get(board["board_type"], board["board_type"]),
                    "status_label": BOARD_STATUS_LABELS.get(board["status"], board["status"]),
                    "polarity_label": {"positive": "正", "negative": "负", "none": "无"}.get(board.get("polarity"), "—"),
                    "gamma_nominal": board.get("gamma_nominal"),
                    "_status_tag": {"damaged": "bad", "retired": "muted", "pending": "warn"}.get(board["status"], ""),
                    "_strength": strength_text,
                }
            )
        self.table.set_rows(rows)
        self.count_label.configure(text=f"共 {len(rows)} 块测试板")
        selected = self.table.selected_id()
        if selected:
            self._update_detail()
        elif rows:
            first = self.table.tree.get_children()
            if first:
                self.table.tree.selection_set(first[0])
                self.table.tree.focus(first[0])
                self._update_detail()
        else:
            self._clear_detail()

    def _clear_detail(self):
        for label in self.detail_labels.values():
            label.configure(text="—")
        self.photo_label.configure(image="", text="")

    def _update_detail(self):
        board_id = self.table.selected_id()
        board = next((b for b in self._boards_cache if b["id"] == board_id), None)
        if not board:
            return
        gamma = board.get("gamma_nominal")
        strength = reflection_strength(gamma)[1]
        values = {
            "code": board["code"],
            "name": board["name"],
            "type": BOARD_TYPE_LABELS.get(board["board_type"], board["board_type"]),
            "ohm": f"{format_number(board.get('nominal_ohm'), 3)} / {format_number(board.get('measured_ohm'), 3)} Ω",
            "gamma": (
                f"标称：{gamma_percent(gamma, 3)}\n"
                f"实测阻值：{gamma_percent(board.get('gamma_measured'), 3)}"
                if board.get("gamma_measured") is not None
                else f"标称：{gamma_percent(gamma, 3)}\n实测阻值：未提供"
            ),
            "polarity": {"positive": "正反射", "negative": "负反射", "none": "无反射"}.get(board.get("polarity"), "—"),
            "strength": strength,
            "z0": f"{format_number(board.get('z0'), 1)} Ω",
            "status": BOARD_STATUS_LABELS.get(board["status"], board["status"]),
            "pcb": board.get("pcb_no") or "—",
            "component": board.get("component_model") or "—",
            "date": board.get("manufacture_date") or "—",
            "notes": board.get("notes") or "—",
        }
        for key, value in values.items():
            self.detail_labels[key].configure(text=str(value))
        photo = board.get("photo_path")
        if photo:
            path = config.DATA_DIR / photo
            if path.exists():
                try:
                    from PIL import Image, ImageTk

                    image = Image.open(path)
                    image.thumbnail((280, 150))
                    self._photo_image = ImageTk.PhotoImage(image)
                    self.photo_label.configure(image=self._photo_image, text="")
                except Exception:
                    self.photo_label.configure(image="", text=f"照片：{path.name}")
            else:
                self.photo_label.configure(image="", text="照片文件缺失")
        else:
            self.photo_label.configure(image="", text="未上传照片")

    def _selected_board(self):
        board_id = self.table.selected_id()
        if not board_id:
            messagebox.showinfo("提示", "请先选择一块测试板", parent=self)
            return None
        return next((b for b in self._boards_cache if b["id"] == board_id), None)

    def _new_board(self):
        dialog = BoardDialog(self, self.app.repos.boards)
        result = dialog.show()
        if result:
            self.app.notify(f"已新增测试板 {result['code']}", "success")
            self.refresh()

    def _edit_board(self, row):
        if not row:
            return
        board = self.app.repos.boards.get(row["id"])
        if not board:
            return
        dialog = BoardDialog(self, self.app.repos.boards, board)
        result = dialog.show()
        if result:
            self.app.notify(f"已保存测试板 {result['code']}", "success")
            self.refresh()

    def _edit_selected(self):
        board = self._selected_board()
        if board:
            self._edit_board(board)

    def _duplicate_selected(self):
        board = self._selected_board()
        if not board:
            return
        if messagebox.askyesno("复制测试板", f"将复制 {board['code']} 为新的物理板，是否继续？", parent=self):
            try:
                created = self.app.repos.boards.duplicate(board["id"])
                self.app.notify(f"已复制为 {created['code']}", "success")
                self.refresh()
            except Exception as exc:
                self.app.show_error("复制失败", exc)

    def _status_selected(self):
        board = self._selected_board()
        if not board:
            return
        dialog = StatusDialog(self, self.app.repos.boards, board)
        if dialog.show():
            self.app.notify("测试板状态已更新", "success")
            self.refresh()

    def _view_photo(self):
        board = self._selected_board()
        if not board or not board.get("photo_path"):
            messagebox.showinfo("提示", "该测试板没有照片", parent=self)
            return
        path = config.DATA_DIR / board["photo_path"]
        if not path.exists():
            messagebox.showwarning("提示", "照片文件不存在", parent=self)
            return
        try:
            from ..widgets import open_local_path

            open_local_path(path)
        except Exception as exc:
            self.app.show_error("无法打开照片", exc)
