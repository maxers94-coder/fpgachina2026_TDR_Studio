"""系统设置、备份恢复与审计。"""
from __future__ import annotations

import csv
import json
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from ... import config
from ...config import COLORS, FRONTEND_LABELS
from ...services.analytics import load_rules
from ...utils import format_percent, json_loads, now_iso, safe_float, safe_int
from ..base import BasePage
from ..theme import card
from ..widgets import DataTable, ModalDialog, page_header, section_card, open_local_path


class AuditDetailDialog(ModalDialog):
    def __init__(self, parent, row):
        self.row = row
        super().__init__(parent, "审计日志详情", width=760, height=560, resizable=True)

    def build_body(self, parent):
        self.save_button.configure(text="关闭", command=self.cancel)
        info = (
            f"时间：{self.row['timestamp']}\n操作：{self.row['action']}　对象：{self.row['entity_type']} / {self.row['entity_id']}\n"
            f"操作员：{self.row.get('actor') or '—'}　备注：{self.row.get('note') or '—'}"
        )
        tk.Label(parent, text=info, bg=COLORS["bg"], fg=COLORS["text"], justify="left",
                 anchor="w", font=("Microsoft YaHei UI", 9)).pack(fill="x", pady=(0, 8))
        text = tk.Text(parent, wrap="word", font=("Consolas", 9), relief="solid", bd=1)
        text.pack(fill="both", expand=True)
        before = self.row.get("before_json")
        after = self.row.get("after_json")
        lines = ["修改前："]
        if before:
            try:
                lines.append(json.dumps(json.loads(before), ensure_ascii=False, indent=2))
            except Exception:
                lines.append(str(before))
        else:
            lines.append("（无）")
        lines.append("\n修改后：")
        if after:
            try:
                lines.append(json.dumps(json.loads(after), ensure_ascii=False, indent=2))
            except Exception:
                lines.append(str(after))
        else:
            lines.append("（无）")
        text.insert("1.0", "\n".join(lines))
        text.configure(state="disabled")

    def on_save(self):
        return False


class SettingsPage(BasePage):
    key = "settings"
    title = "系统设置"
    subtitle = "项目参数、判定标准、备份恢复与审计追踪"

    def build(self):
        header = page_header(self, "系统设置", "判定标准影响所有统计视图；修改会被审计。")
        header.pack(fill="x", pady=(4, 10))
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)
        self.tab_general = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_rules = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_safety = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_audit = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.tab_about = tk.Frame(self.notebook, bg=COLORS["bg"])
        self.notebook.add(self.tab_general, text="  项目参数  ")
        self.notebook.add(self.tab_rules, text="  判定标准  ")
        self.notebook.add(self.tab_safety, text="  数据安全  ")
        self.notebook.add(self.tab_audit, text="  审计日志  ")
        self.notebook.add(self.tab_about, text="  关于  ")
        self._build_general()
        self._build_rules()
        self._build_safety()
        self._build_audit()
        self._build_about()
        self.notebook.bind("<<NotebookTabChanged>>", lambda event: self.refresh_current())

    def _build_general(self):
        outer, body = section_card(self.tab_general, "项目与默认实验参数", "修改后新实验/导出的默认值随之更新")
        outer.pack(fill="x", pady=(12, 0), padx=2)
        form = tk.Frame(body, bg=COLORS["card"])
        form.pack(fill="x")
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        self.project_var = tk.StringVar()
        self.operator_var = tk.StringVar()
        self.firmware_var = tk.StringVar()
        for index, (label, var, hint) in enumerate([
            ("项目名称", self.project_var, "用于导出与报告"),
            ("默认操作员", self.operator_var, "新实验运行自动带入，可修改"),
            ("默认固件版本", self.firmware_var, "例如 FW63 V1.0"),
        ]):
            frame = tk.Frame(form, bg=COLORS["card"])
            frame.grid(row=index // 2, column=index % 2, sticky="ew", padx=(0, 18), pady=6)
            tk.Label(frame, text=label, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
            ttk.Entry(frame, textvariable=var, width=44).pack(fill="x", pady=(2, 0))
            tk.Label(frame, text=hint, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
        ttk.Button(body, text="保存项目参数", command=self._save_general,
                   style="Primary.TButton").pack(anchor="w", pady=(12, 0))

        hw_outer, hw_body = section_card(self.tab_general, "硬件与系统信息", "以下为项目固定参数，不参与数据库修改")
        hw_outer.pack(fill="x", pady=(12, 0), padx=2)
        items = [
            ("FPGA", "XC7Z020CLG484-2"), ("开发板", "小梅哥 AC820"),
            ("ADC / DAC", "ADS5474 / AD9142A"), ("实际采样率", "200 MSPS"),
            ("PN 序列", "PN127"), ("码片速率", "50 Mchip/s"),
            ("相关数据", "256 点 Q16"), ("当前固件", "FW63 V1.0"),
            ("模拟前端", "电阻功分器"), ("实验对象", "50 Ω 同轴线缆"),
        ]
        for index, (key, value) in enumerate(items):
            frame = tk.Frame(hw_body, bg=COLORS["card"])
            frame.grid(row=index // 5, column=index % 5, sticky="nw", padx=(0, 20), pady=4)
            tk.Label(frame, text=key, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
            tk.Label(frame, text=value, bg=COLORS["card"], fg=COLORS["text"],
                     font=("Microsoft YaHei UI", 9, "bold"), anchor="w").pack(anchor="w")

    def _build_rules(self):
        outer, body = section_card(self.tab_rules, "自动判定与统计规则", "修改后所有统计页面与导出重新计算")
        outer.pack(fill="x", pady=(12, 0), padx=2)
        form = tk.Frame(body, bg=COLORS["card"])
        form.pack(fill="x")
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)
        form.grid_columnconfigure(2, weight=1)
        self.rule_vars: dict[str, tk.StringVar] = {}
        specs = [
            ("distance_tolerance_m", "距离容差 (m)", "定位误差绝对值上限，例如 0.60"),
            ("min_detection_rate", "最低检出率 (%)", "异常组检出率下限，例如 95"),
            ("max_false_alarm_rate", "正常误报率上限 (%)", "正常组误报率上限，例如 5"),
            ("min_location_rate", "最低定位合格率 (%)", "定位合格率/多异常完整识别率下限"),
            ("max_invalid_rate", "无效率/拒判率上限 (%)", "超过即判未通过"),
            ("min_trials_for_judgement", "自动判定最少试次数", "小于此值判“数据不足”"),
        ]
        for index, (key, label, hint) in enumerate(specs):
            frame = tk.Frame(form, bg=COLORS["card"])
            frame.grid(row=index // 3, column=index % 3, sticky="ew", padx=(0, 18), pady=6)
            tk.Label(frame, text=label, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 9), anchor="w").pack(anchor="w")
            var = tk.StringVar()
            self.rule_vars[key] = var
            ttk.Entry(frame, textvariable=var, width=20).pack(fill="x", pady=(2, 0))
            tk.Label(frame, text=hint, bg=COLORS["card"], fg=COLORS["muted"],
                     font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
        self.require_polarity = tk.BooleanVar()
        self.edge_valid = tk.BooleanVar()
        self.hardware_fail = tk.BooleanVar()
        checks = tk.Frame(body, bg=COLORS["card"])
        checks.pack(fill="x", pady=(10, 0))
        ttk.Checkbutton(checks, text="要求检出极性全部正确", variable=self.require_polarity).pack(anchor="w")
        ttk.Checkbutton(checks, text="EDGE* 数据视为有效（默认不视为有效）", variable=self.edge_valid).pack(anchor="w")
        ttk.Checkbutton(checks, text="出现 PN? / OVERFLOW 时判定失败", variable=self.hardware_fail).pack(anchor="w")
        ttk.Button(body, text="保存判定标准", command=self._save_rules, style="Primary.TButton").pack(anchor="w", pady=(12, 0))
        tk.Label(body, text="统计口径：检出率=检出/(检出+未检出)；定位合格率=容差内/有效定位；"
                            "综合成功率同时考虑检出、极性、定位和质量。未测试不会自动算通过。",
                 bg=COLORS["card"], fg=COLORS["muted"], font=("Microsoft YaHei UI", 8),
                 justify="left", wraplength=920).pack(anchor="w", pady=(10, 0))

    def _build_safety(self):
        outer, body = section_card(self.tab_safety, "数据库与备份", f"数据库：{self.db.path}")
        outer.pack(fill="x", pady=(12, 0), padx=2)
        self.db_count_label = tk.Label(body, text="", bg=COLORS["card"], fg=COLORS["text"],
                                       font=("Microsoft YaHei UI", 9), justify="left", anchor="w")
        self.db_count_label.pack(fill="x")
        actions = tk.Frame(body, bg=COLORS["card"])
        actions.pack(fill="x", pady=(10, 6))
        ttk.Button(actions, text="立即备份数据库", command=self._backup_now, style="Primary.TButton").pack(side="left")
        ttk.Button(actions, text="从备份恢复", command=self._restore_selected, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(actions, text="从文件恢复…", command=self._restore_file, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(actions, text="完整性检查", command=self._integrity, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(actions, text="打开备份目录", command=lambda: self._open(config.BACKUPS_DIR), style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.auto_backup_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(body, text="启动时每 24 小时自动备份数据库（有实测数据时）",
                        variable=self.auto_backup_var, command=self._toggle_auto_backup).pack(anchor="w", pady=(2, 4))
        self.integrity_label = tk.Label(body, text="", bg=COLORS["card"], fg=COLORS["muted"],
                                        font=("Microsoft YaHei UI", 8), anchor="w")
        self.integrity_label.pack(fill="x", pady=(2, 6))
        tk.Label(body, text="备份列表", bg=COLORS["card"], fg=COLORS["text"],
                 font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="w", pady=(4, 3))
        self.backup_table = DataTable(
            body,
            [
                {"key": "file", "label": "备份文件", "width": 360},
                {"key": "created", "label": "创建时间", "width": 160},
                {"key": "size", "label": "大小", "width": 100, "anchor": "e"},
            ],
            height=7,
        )
        self.backup_table.pack(fill="x")
        tk.Label(body, text="恢复会先自动创建安全备份，再替换当前数据库。附件文件不在数据库备份内，"
                            "已包含在 AI 数据包导出中。",
                 bg=COLORS["card"], fg=COLORS["warning"], font=("Microsoft YaHei UI", 8),
                 justify="left", wraplength=900).pack(anchor="w", pady=(8, 0))

    def _build_audit(self):
        bar = tk.Frame(self.tab_audit, bg=COLORS["bg"])
        bar.pack(fill="x", pady=(12, 8))
        ttk.Button(bar, text="刷新", command=self._refresh_audit, style="Ghost.TButton").pack(side="left")
        ttk.Button(bar, text="查看详情", command=self._audit_detail, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        ttk.Button(bar, text="导出审计 CSV", command=self._export_audit, style="Ghost.TButton").pack(side="left", padx=(6, 0))
        self.audit_count = tk.Label(bar, text="", bg=COLORS["bg"], fg=COLORS["muted"],
                                    font=("Microsoft YaHei UI", 8))
        self.audit_count.pack(side="right")
        self.audit_table = DataTable(
            self.tab_audit,
            [
                {"key": "timestamp", "label": "时间", "width": 155},
                {"key": "actor", "label": "操作员", "width": 100},
                {"key": "action", "label": "操作", "width": 105},
                {"key": "entity_type", "label": "对象类型", "width": 130},
                {"key": "entity_id", "label": "对象 ID", "width": 190},
                {"key": "note", "label": "说明", "width": 300},
            ],
            height=17, on_double_click=lambda row: self._audit_detail(row),
        )
        self.audit_table.pack(fill="both", expand=True)
        self._audit_rows: list[dict] = []

    def _build_about(self):
        outer, body = section_card(self.tab_about, "TDR Measurement Studio", config.APP_NAME_CN)
        outer.pack(fill="x", pady=(12, 0), padx=2)
        text = f"""版本：{config.APP_VERSION}
阶段：{config.SOFTWARE_STAGE}
数据结构版本：{config.DATA_SCHEMA_VERSION}
运行方式：Windows 本地原生桌面程序（Python + Tkinter），无需服务器、浏览器或网络。

设计说明
--------
本机处于完全离线环境，无法安装 Streamlit 及其依赖；因此采用 Python 标准库 Tkinter
实现桌面界面。这样可以直接复用本机 Python 3.12，界面响应快，适合实验室键盘连续录入，
且不依赖浏览器生命周期或网络端口。数据层、统计层、导入导出层、界面层完全分离。

关键保障
--------
• SQLite WAL + 事务；每次保存后立即持久化。
• 修改/删除写审计日志；删除前明确确认。
• 数据库备份与恢复；恢复前自动安全备份。
• 理论反射系数与仪器实测值严格区分。
• JSON 中无 NaN/Infinity，缺失值为 null。
• 统计结果可从原始记录重算。

数据目录：{config.DATA_DIR}
导出目录：{config.EXPORTS_DIR}
"""
        label = tk.Label(body, text=text, bg=COLORS["card"], fg=COLORS["text"], justify="left",
                         anchor="nw", font=("Microsoft YaHei UI", 9), wraplength=980)
        label.pack(fill="x")
        buttons = tk.Frame(body, bg=COLORS["card"])
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="打开文档目录", command=lambda: self._open(config.PROJECT_ROOT / "docs"),
                   style="Ghost.TButton").pack(side="left")
        ttk.Button(buttons, text="打开数据目录", command=lambda: self._open(config.DATA_DIR),
                   style="Ghost.TButton").pack(side="left", padx=(6, 0))

    def refresh(self):
        self.refresh_current()

    def refresh_current(self):
        try:
            index = self.notebook.index(self.notebook.select())
        except tk.TclError:
            index = 0
        if index == 0:
            self._load_general()
        elif index == 1:
            self._load_rules()
        elif index == 2:
            self._refresh_safety()
        elif index == 3:
            self._refresh_audit()

    def _load_general(self):
        settings = self.db.get_all_settings()
        self.project_var.set(settings.get("project_name", ""))
        self.operator_var.set(settings.get("operator", ""))
        self.firmware_var.set(settings.get("firmware_version", ""))

    def _save_general(self):
        values = {
            "project_name": self.project_var.get().strip(),
            "operator": self.operator_var.get().strip(),
            "firmware_version": self.firmware_var.get().strip(),
        }
        if not values["project_name"]:
            messagebox.showwarning("提示", "项目名称不能为空", parent=self)
            return
        try:
            self.db.set_settings(values)
            self.app.notify("项目参数已保存", "success")
        except Exception as exc:
            self.app.show_error("保存失败", exc)

    def _load_rules(self):
        rules = load_rules(self.db)
        self.rule_vars["distance_tolerance_m"].set(f"{rules['distance_tolerance_m']:.2f}")
        self.rule_vars["min_detection_rate"].set(f"{rules['min_detection_rate'] * 100:.1f}")
        self.rule_vars["max_false_alarm_rate"].set(f"{rules['max_false_alarm_rate'] * 100:.1f}")
        self.rule_vars["min_location_rate"].set(f"{rules['min_location_rate'] * 100:.1f}")
        self.rule_vars["max_invalid_rate"].set(f"{rules['max_invalid_rate'] * 100:.1f}")
        self.rule_vars["min_trials_for_judgement"].set(str(int(rules["min_trials_for_judgement"])))
        self.require_polarity.set(bool(rules["require_polarity"]))
        self.edge_valid.set(bool(rules["edge_as_valid"]))
        self.hardware_fail.set(bool(rules["hardware_error_fails"]))

    def _save_rules(self):
        try:
            tolerance = safe_float(self.rule_vars["distance_tolerance_m"].get())
            if tolerance is None or tolerance <= 0:
                raise ValueError("距离容差必须大于 0")
            percentages = {}
            for key, label in [
                ("min_detection_rate", "最低检出率"),
                ("max_false_alarm_rate", "正常误报率上限"),
                ("min_location_rate", "最低定位合格率"),
                ("max_invalid_rate", "无效率上限"),
            ]:
                value = safe_float(self.rule_vars[key].get())
                if value is None or not 0 <= value <= 100:
                    raise ValueError(f"{label}须在 0–100% 之间")
                percentages[key] = value / 100.0
            min_trials = safe_int(self.rule_vars["min_trials_for_judgement"].get(), 1) or 1
            if min_trials < 1:
                raise ValueError("最少试次数必须大于 0")
            values = {
                "distance_tolerance_m": tolerance,
                **percentages,
                "min_trials_for_judgement": min_trials,
                "require_polarity": self.require_polarity.get(),
                "edge_as_valid": self.edge_valid.get(),
                "hardware_error_fails": self.hardware_fail.get(),
            }
            self.db.set_settings(values)
            self.app.notify("判定标准已保存，统计将按新规则重新计算", "success")
        except Exception as exc:
            self.app.show_error("保存失败", exc)

    def _refresh_safety(self):
        counts = self.db.counts()
        self.db_count_label.configure(
            text=f"测试板 {counts['boards']} · 线缆 {counts['cables']} · 健康参考 {counts['health_references']}\n"
                 f"实验配置 {counts['experiment_configs']} · 实验运行 {counts['experiment_runs']} · 试次 {counts['trials']}\n"
                 f"候选 {counts['detected_candidates']} · 附件 {counts['attachments']} · 审计记录 {counts['audit_log']}"
        )
        self.auto_backup_var.set(bool(self.db.get_setting("auto_backup_daily", True)))
        backups = sorted(config.BACKUPS_DIR.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        rows = [
            {
                "_iid": path.name,
                "file": path.name,
                "created": datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                "size": _human_size(path.stat().st_size),
            }
            for path in backups
        ]
        self.backup_table.set_rows(rows)

    def _toggle_auto_backup(self):
        try:
            self.db.set_settings({"auto_backup_daily": bool(self.auto_backup_var.get())})
            self.app.notify("自动备份设置已保存", "success")
        except Exception as exc:
            self.app.show_error("保存失败", exc)

    def _backup_now(self):
        try:
            path = self.db.backup_default(note="设置页手动备份")
            self.app.notify(f"数据库备份完成：{path.name}", "success")
            self._refresh_safety()
        except Exception as exc:
            self.app.show_error("备份失败", exc)

    def _selected_backup(self):
        row = self.backup_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择一个备份文件", parent=self)
            return None
        path = config.BACKUPS_DIR / row["file"]
        return path if path.exists() else None

    def _restore_selected(self):
        path = self._selected_backup()
        if not path:
            return
        self._restore(path)

    def _restore_file(self):
        path = filedialog.askopenfilename(parent=self, title="选择数据库备份",
                                          filetypes=[("SQLite 备份", "*.db"), ("所有文件", "*.*")])
        if path:
            self._restore(Path(path))

    def _restore(self, path: Path):
        if not messagebox.askyesno(
            "恢复数据库",
            f"将用以下备份替换当前数据库：\n{path.name}\n\n"
            "替换前会自动创建当前数据库的安全备份。\n"
            "恢复后，当前数据库中的新增实验和审计记录将被备份内容覆盖。\n\n确定继续？",
            parent=self,
        ):
            return
        try:
            safety = self.db.replace_from(path)
            self.db.initialize()
            self.app.current_config_id = None
            self.app.current_run_id = None
            self.app.notify(f"恢复完成。恢复前安全备份：{safety.name}", "success")
            messagebox.showinfo("恢复完成", f"数据库已恢复。\n恢复前安全备份：\n{safety}", parent=self)
            self.refresh()
        except Exception as exc:
            self.app.show_error("恢复失败", exc)

    def _integrity(self):
        try:
            ok, message = self.db.integrity_check()
            fk = self.db.foreign_key_check()
            if ok and not fk:
                text = "完整性检查通过；外键检查通过。"
                color = COLORS["success"]
            elif ok:
                text = f"数据库主体检查通过，但存在 {len(fk)} 个外键异常。"
                color = COLORS["warning"]
            else:
                text = f"完整性检查失败：{message}"
                color = COLORS["danger"]
            self.integrity_label.configure(text=f"{now_iso()}  {text}", fg=color)
            self.app.notify(text, "success" if ok and not fk else "warning")
        except Exception as exc:
            self.app.show_error("检查失败", exc)

    def _refresh_audit(self):
        rows = self.db.audit_rows(limit=500)
        self._audit_rows = rows
        self.audit_table.set_rows(
            [{**row, "timestamp": str(row["timestamp"])[:19].replace("T", " ")} for row in rows]
        )
        self.audit_count.configure(text=f"最近 {len(rows)} 条（上限 500）")

    def _audit_detail(self, row=None):
        row = row or self.audit_table.selected_row()
        if not row:
            messagebox.showinfo("提示", "请选择审计记录", parent=self)
            return
        full = next((r for r in self._audit_rows if r["id"] == row["id"]), row)
        AuditDetailDialog(self, full).show()

    def _export_audit(self):
        rows = self.db.audit_rows(limit=100000)
        if not rows:
            messagebox.showinfo("提示", "没有审计记录", parent=self)
            return
        path = filedialog.asksaveasfilename(parent=self, title="导出审计日志",
                                            defaultextension=".csv",
                                            filetypes=[("CSV", "*.csv")],
                                            initialfile="TDR_audit_log.csv")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
                writer.writeheader()
                writer.writerows(rows)
            self.app.notify(f"审计日志已导出：{Path(path).name}", "success")
        except Exception as exc:
            self.app.show_error("导出失败", exc)

    def _open(self, path):
        try:
            open_local_path(path)
        except Exception as exc:
            self.app.show_error("无法打开目录", exc)


def _human_size(size: int) -> str:
    value = float(size or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"
