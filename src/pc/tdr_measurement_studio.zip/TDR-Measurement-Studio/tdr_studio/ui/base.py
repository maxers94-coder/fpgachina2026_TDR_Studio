"""页面基类。"""
from __future__ import annotations

import tkinter as tk

from ..config import COLORS


class BasePage(tk.Frame):
    key = ""
    title = ""
    subtitle = ""

    def __init__(self, app, parent):
        super().__init__(parent, bg=COLORS["bg"])
        self.app = app
        self.db = app.db
        self._built = False
        self.build()
        self._built = True

    def build(self):
        raise NotImplementedError

    def refresh(self):
        pass

    def on_show(self):
        self.refresh()

    def safe_refresh(self):
        try:
            self.refresh()
        except Exception as exc:
            self.app.notify(f"刷新失败：{exc}", "error")
            import traceback

            traceback.print_exc()
