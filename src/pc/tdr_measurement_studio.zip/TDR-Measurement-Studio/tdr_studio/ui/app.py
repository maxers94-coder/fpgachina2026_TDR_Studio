"""主窗口与应用状态。"""
from __future__ import annotations

import ctypes
import sys
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk
from types import SimpleNamespace

from .. import config
from ..database import Database
from ..repositories.boards import BoardRepository
from ..repositories.cables import CableRepository
from ..repositories.experiments import ExperimentRepository
from ..repositories.organization import BatchRepository, CategoryRepository
from ..repositories.references import ReferenceRepository
from ..repositories.runs import RunRepository
from ..repositories.trials import TrialRepository
from ..services.attachments import AttachmentService
from ..services.export_service import build_dataset
from .base import BasePage
from .theme import apply_theme
from .widgets import open_local_path
from .pages.analysis import AnalysisPage
from .pages.boards import BoardsPage
from .pages.cables_references import CablesReferencesPage
from .pages.dashboard import DashboardPage
from .pages.plan import PlanPage
from .pages.settings import SettingsPage
from .pages.transfer import TransferPage
from .pages.workbench import WorkbenchPage

NAV_ITEMS = [
    ("dashboard", "仪表盘"),
    ("boards", "测试板管理"),
    ("cables", "线缆与参考"),
    ("plan", "实验计划"),
    ("workbench", "实验工作台"),
    ("analysis", "数据分析"),
    ("transfer", "数据导入导出"),
    ("settings", "系统设置"),
]

PAGE_CLASSES = {
    "dashboard": DashboardPage,
    "boards": BoardsPage,
    "cables": CablesReferencesPage,
    "plan": PlanPage,
    "workbench": WorkbenchPage,
    "analysis": AnalysisPage,
    "transfer": TransferPage,
    "settings": SettingsPage,
}


def enable_high_dpi():
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


class TDRApp:
    def __init__(self, root: tk.Tk, db: Database | None = None):
        self.root = root
        self.db = db or Database()
        self.db.initialize()
        self.fonts = apply_theme(root)
        self.pages: dict[str, BasePage] = {}
        self.current_page: BasePage | None = None
        self.current_page_key = ""
        self.current_config_id: str | None = None
        self.current_run_id: str | None = None
        self._status_job = None
        self.repos = SimpleNamespace(
            boards=BoardRepository(self.db),
            cables=CableRepository(self.db),
            references=ReferenceRepository(self.db),
            categories=CategoryRepository(self.db),
            batches=BatchRepository(self.db),
            experiments=ExperimentRepository(self.db),
            runs=RunRepository(self.db),
            trials=TrialRepository(self.db),
            attachments=AttachmentService(self.db),
        )
        self._build_window()
        self._build_shell()
        try:
            self.db.maybe_auto_backup()
        except Exception:
            pass
        self.navigate("dashboard")

    # ------------------------------------------------------------------ 外壳
    def _build_window(self):
        self.root.title(f"{config.APP_NAME} — {config.APP_NAME_CN}")
        self.root.configure(bg=config.COLORS["bg"])
        try:
            screen_w = self.root.winfo_screenwidth()
            screen_h = self.root.winfo_screenheight()
            width = min(1780, max(1120, screen_w - 60))
            height = min(1010, max(700, screen_h - 70))
            x = max(0, (screen_w - width) // 2)
            y = max(0, (screen_h - height) // 2 - 10)
            self.root.geometry(f"{width}x{height}+{x}+{y}")
            self.root.minsize(1220, 700)
        except tk.TclError:
            self.root.geometry("1400x900")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        icon_path = config.PROJECT_ROOT / "assets" / "tdr_icon.png"
        if icon_path.exists():
            try:
                self._app_icon = tk.PhotoImage(file=str(icon_path))
                self.root.iconphoto(True, self._app_icon)
            except tk.TclError:
                pass
        self.root.bind("<Control-Key-1>", lambda event: self.navigate("dashboard"))
        self.root.bind("<Control-Key-2>", lambda event: self.navigate("boards"))
        self.root.bind("<Control-Key-3>", lambda event: self.navigate("cables"))
        self.root.bind("<Control-Key-4>", lambda event: self.navigate("plan"))
        self.root.bind("<Control-Key-5>", lambda event: self.navigate("workbench"))
        self.root.bind("<Control-Key-6>", lambda event: self.navigate("analysis"))
        self.root.bind("<Control-Key-7>", lambda event: self.navigate("transfer"))
        self.root.bind("<Control-Key-8>", lambda event: self.navigate("settings"))
        self.root.bind("<F5>", lambda event: self.refresh_current())

    def _build_shell(self):
        shell = tk.Frame(self.root, bg=config.COLORS["bg"])
        shell.pack(fill="both", expand=True)
        # Sidebar
        sidebar = tk.Frame(shell, bg=config.COLORS["sidebar"], width=268)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        brand = tk.Frame(sidebar, bg=config.COLORS["sidebar"])
        brand.pack(fill="x", padx=18, pady=(22, 16))
        logo = tk.Label(brand, text="TDR", bg=config.COLORS["primary"], fg="#FFFFFF",
                        font=("Consolas", 12, "bold"), width=4, height=2)
        logo.pack(side="left")
        brand_text = tk.Frame(brand, bg=config.COLORS["sidebar"])
        brand_text.pack(side="left", padx=(8, 0))
        tk.Label(brand_text, text="实验管理平台", bg=config.COLORS["sidebar"], fg="#FFFFFF",
                 font=("Microsoft YaHei UI", 10, "bold"), anchor="w").pack(anchor="w")
        tk.Label(brand_text, text="Measurement Studio", bg=config.COLORS["sidebar"], fg="#8FB7C2",
                 font=("Microsoft YaHei UI", 8), anchor="w").pack(anchor="w")
        tk.Frame(sidebar, bg="#174251", height=1).pack(fill="x", padx=16, pady=(0, 12))
        tk.Label(sidebar, text="实验管理导航", bg=config.COLORS["sidebar"], fg="#7496A3",
                 font=("Microsoft YaHei UI", 8), anchor="w").pack(fill="x", padx=22, pady=(0, 6))
        self.nav_buttons: dict[str, tk.Button] = {}
        for index, (key, label) in enumerate(NAV_ITEMS, start=1):
            button = tk.Button(
                sidebar, text=f"  {label}", bg=config.COLORS["sidebar"],
                fg=config.COLORS["sidebar_text"], activebackground=config.COLORS["sidebar_active"],
                activeforeground="#FFFFFF", relief="flat", bd=0, anchor="w",
                font=("Microsoft YaHei UI", 10, "bold"), padx=22, pady=11,
                cursor="hand2", command=lambda k=key: self.navigate(k),
            )
            button.pack(fill="x", pady=1)
            self.nav_buttons[key] = button
        # Sidebar footer
        footer = tk.Frame(sidebar, bg=config.COLORS["sidebar"])
        footer.pack(side="bottom", fill="x", padx=18, pady=(10, 18))
        tk.Frame(footer, bg="#174251", height=1).pack(fill="x", pady=(0, 12))
        tk.Label(footer, text="本地离线运行 · SQLite", bg=config.COLORS["sidebar"], fg="#84A6B1",
                 font=("Microsoft YaHei UI", 8), anchor="w").pack(fill="x")
        tk.Label(footer, text=f"v{config.APP_VERSION}  ·  离线 · 数据本地", bg=config.COLORS["sidebar"],
                 fg="#5F8491", font=("Microsoft YaHei UI", 8), anchor="w").pack(fill="x", pady=(3, 0))

        # Main
        main = tk.Frame(shell, bg=config.COLORS["bg"])
        main.pack(side="left", fill="both", expand=True)
        self.content = tk.Frame(main, bg=config.COLORS["bg"])
        self.content.pack(fill="both", expand=True, padx=24, pady=(20, 0))
        # Status bar
        status = tk.Frame(main, bg="#E9EFF1", height=28)
        status.pack(fill="x", side="bottom")
        status.pack_propagate(False)
        self.status_label = tk.Label(status, text="就绪", bg="#E9EFF1", fg=config.COLORS["muted"],
                                     font=("Microsoft YaHei UI", 8), anchor="w")
        self.status_label.pack(side="left", padx=14)
        self.db_label = tk.Label(status, text=f"SQLite：{self.db.path.name}", bg="#E9EFF1",
                                 fg=config.COLORS["muted"], font=("Microsoft YaHei UI", 8), anchor="e")
        self.db_label.pack(side="right", padx=14)
        self.clock_label = tk.Label(status, text="", bg="#E9EFF1", fg=config.COLORS["muted"],
                                    font=("Microsoft YaHei UI", 8))
        self.clock_label.pack(side="right", padx=14)
        self._update_clock()

    # ------------------------------------------------------------------ 导航
    def navigate(self, key: str, *, config_id: str | None = None):
        if key not in PAGE_CLASSES:
            return
        if config_id:
            self.current_config_id = config_id
        if self.current_page is not None:
            self.current_page.pack_forget()
        if key not in self.pages:
            try:
                page = PAGE_CLASSES[key](self, self.content)
            except Exception as exc:
                self.show_error("页面加载失败", exc)
                return
            self.pages[key] = page
        page = self.pages[key]
        page.pack(fill="both", expand=True)
        self.current_page = page
        self.current_page_key = key
        for nav_key, button in self.nav_buttons.items():
            if nav_key == key:
                button.configure(bg=config.COLORS["sidebar_active"], fg="#FFFFFF",
                                 bd=0, highlightthickness=0)
            else:
                button.configure(bg=config.COLORS["sidebar"], fg=config.COLORS["sidebar_text"])
        self.root.title(f"{page.title or key} — {config.APP_NAME_CN}")
        page.safe_refresh()
        self.notify(f"已进入：{page.title or key}")

    def open_workbench(self, config_id: str):
        self.current_config_id = config_id
        self.navigate("workbench")

    def refresh_current(self):
        if self.current_page:
            self.current_page.safe_refresh()
            self.notify("已刷新当前页面")

    def refresh_all(self):
        for page in self.pages.values():
            if page is self.current_page:
                page.safe_refresh()

    # ------------------------------------------------------------------ 状态
    def notify(self, message: str, level: str = "info"):
        color = {
            "info": config.COLORS["muted"],
            "success": config.COLORS["success"],
            "warning": config.COLORS["warning"],
            "error": config.COLORS["danger"],
        }.get(level, config.COLORS["muted"])
        self.status_label.configure(text=message, fg=color)
        if level in {"error", "warning", "success"}:
            self.root.after(10000, lambda: self.status_label.configure(text="就绪", fg=config.COLORS["muted"]))

    def _update_clock(self):
        self.clock_label.configure(text=datetime.now().strftime("%Y-%m-%d %H:%M"))
        self.root.after(30000, self._update_clock)

    def show_error(self, title: str, exc: Exception):
        self.notify(str(exc), "error")
        messagebox.showerror(title, str(exc), parent=self.root)

    def open_data_dir(self):
        try:
            open_local_path(config.DATA_DIR)
        except Exception as exc:
            self.show_error("无法打开目录", exc)

    def on_close(self):
        try:
            self.root.destroy()
        except tk.TclError:
            pass


def main():
    enable_high_dpi()
    root = tk.Tk()
    try:
        dpi = root.winfo_fpixels("1i")
        root.tk.call("tk", "scaling", max(1.0, dpi / 72.0))
    except tk.TclError:
        pass
    app = TDRApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
