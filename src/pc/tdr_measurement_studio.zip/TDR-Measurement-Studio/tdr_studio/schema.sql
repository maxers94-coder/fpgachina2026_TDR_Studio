-- TDR Measurement Studio SQLite schema v1.0
-- 设计原则：原始单次记录不可被统计结果覆盖；所有修改留审计；外键保护关联数据。
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS experiment_categories (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    is_builtin INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS batches (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    firmware_version TEXT DEFAULT '',
    frontend TEXT DEFAULT 'resistive_divider',
    description TEXT DEFAULT '',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS boards (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    board_type TEXT NOT NULL CHECK (board_type IN ('normal','series','shunt','open','short','custom')),
    nominal_ohm REAL,
    measured_ohm REAL,
    z0 REAL NOT NULL DEFAULT 50.0,
    gamma_override REAL,
    gamma_nominal REAL,
    gamma_measured REAL,
    polarity TEXT DEFAULT 'none',
    pcb_no TEXT DEFAULT '',
    component_model TEXT DEFAULT '',
    manufacture_date TEXT DEFAULT '',
    photo_path TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','pending','damaged','retired')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cables (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    physical_length_m REAL NOT NULL CHECK (physical_length_m > 0),
    model TEXT DEFAULT '',
    z0 REAL NOT NULL DEFAULT 50.0,
    velocity_factor REAL DEFAULT 0.66,
    notes TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','damaged','retired')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cable_configs (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    total_length_m REAL NOT NULL DEFAULT 0,
    connector_count INTEGER NOT NULL DEFAULT 0,
    correction_m REAL NOT NULL DEFAULT 0,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cable_config_items (
    id TEXT PRIMARY KEY,
    config_id TEXT NOT NULL REFERENCES cable_configs(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    item_type TEXT NOT NULL CHECK (item_type IN ('cable','board','connector','termination')),
    cable_id TEXT REFERENCES cables(id) ON DELETE SET NULL,
    board_id TEXT REFERENCES boards(id) ON DELETE SET NULL,
    label TEXT NOT NULL,
    length_m REAL NOT NULL DEFAULT 0,
    correction_m REAL NOT NULL DEFAULT 0,
    notes TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS health_references (
    id TEXT PRIMARY KEY,
    ref_no TEXT NOT NULL UNIQUE COLLATE NOCASE,
    created_at_ref TEXT NOT NULL,
    config_id TEXT REFERENCES cable_configs(id) ON DELETE SET NULL,
    frontend TEXT NOT NULL DEFAULT 'resistive_divider',
    firmware_version TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    file_path TEXT DEFAULT '',
    is_valid INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS experiment_configs (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    category_id TEXT NOT NULL REFERENCES experiment_categories(id),
    batch_id TEXT NOT NULL REFERENCES batches(id),
    priority TEXT NOT NULL DEFAULT 'P1' CHECK (priority IN ('P0','P1','P2')),
    mode TEXT NOT NULL DEFAULT 'single' CHECK (mode IN ('normal','single','multi')),
    distance_m REAL,
    distance_expr TEXT DEFAULT '',
    near_expr TEXT DEFAULT '',
    far_expr TEXT DEFAULT '',
    board_id TEXT REFERENCES boards(id) ON DELETE SET NULL,
    expected_polarity TEXT DEFAULT 'none',
    nominal_gamma REAL,
    planned_repeats INTEGER NOT NULL DEFAULT 5 CHECK (planned_repeats > 0),
    tolerance_m REAL,
    reference_id TEXT REFERENCES health_references(id) ON DELETE SET NULL,
    cable_config_id TEXT REFERENCES cable_configs(id) ON DELETE SET NULL,
    reference_label TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'not_started' CHECK (status IN ('not_started','in_progress','completed','skipped','failed')),
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_multi INTEGER NOT NULL DEFAULT 0,
    expected_anomalies_json TEXT DEFAULT '[]',
    notes TEXT DEFAULT '',
    source TEXT NOT NULL DEFAULT 'manual',
    source_row INTEGER,
    source_payload TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS experiment_runs (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE COLLATE NOCASE,
    config_id TEXT NOT NULL UNIQUE REFERENCES experiment_configs(id) ON DELETE RESTRICT,
    batch_id TEXT NOT NULL REFERENCES batches(id),
    session_id TEXT NOT NULL,
    firmware_version TEXT DEFAULT '',
    reference_id TEXT REFERENCES health_references(id) ON DELETE SET NULL,
    cable_config_id TEXT REFERENCES cable_configs(id) ON DELETE SET NULL,
    frontend TEXT DEFAULT 'resistive_divider',
    operator TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','completed','abandoned')),
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS expected_anomalies (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES experiment_runs(id) ON DELETE CASCADE,
    anomaly_index INTEGER NOT NULL,
    board_id TEXT REFERENCES boards(id) ON DELETE SET NULL,
    true_distance_m REAL NOT NULL,
    expected_polarity TEXT DEFAULT 'none',
    tolerance_m REAL,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE (run_id, anomaly_index)
);

CREATE TABLE IF NOT EXISTS trials (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES experiment_runs(id) ON DELETE CASCADE,
    config_id TEXT NOT NULL REFERENCES experiment_configs(id) ON DELETE RESTRICT,
    trial_index INTEGER NOT NULL,
    true_distance_m REAL,
    measured_distance_m REAL,
    polarity TEXT NOT NULL DEFAULT 'unknown' CHECK (polarity IN ('positive','negative','none','unknown')),
    detection_status TEXT NOT NULL CHECK (detection_status IN ('detected','not_detected','normal','false_alarm','invalid','rejected')),
    quality_flag TEXT NOT NULL DEFAULT '正常',
    extra_candidate_count INTEGER NOT NULL DEFAULT 0,
    is_manual INTEGER NOT NULL DEFAULT 1,
    notes TEXT DEFAULT '',
    measured_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE (run_id, trial_index)
);

CREATE TABLE IF NOT EXISTS detected_candidates (
    id TEXT PRIMARY KEY,
    trial_id TEXT NOT NULL REFERENCES trials(id) ON DELETE CASCADE,
    candidate_index INTEGER NOT NULL,
    measured_distance_m REAL,
    polarity TEXT NOT NULL DEFAULT 'unknown' CHECK (polarity IN ('positive','negative','none','unknown')),
    quality_flag TEXT NOT NULL DEFAULT '正常',
    matched_expected_id TEXT REFERENCES expected_anomalies(id) ON DELETE SET NULL,
    match_status TEXT NOT NULL DEFAULT 'unreviewed' CHECK (match_status IN ('matched','extra','ambiguous','unreviewed')),
    polarity_correct INTEGER,
    distance_error_m REAL,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE (trial_id, candidate_index)
);

CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES experiment_runs(id) ON DELETE CASCADE,
    trial_id TEXT REFERENCES trials(id) ON DELETE SET NULL,
    file_name TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    category TEXT DEFAULT '其他',
    notes TEXT DEFAULT '',
    uploaded_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS judgements (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES experiment_runs(id) ON DELETE CASCADE,
    decision TEXT NOT NULL CHECK (decision IN ('pass','fail','insufficient','not_tested','review')),
    rules_json TEXT NOT NULL,
    metrics_json TEXT NOT NULL,
    summary TEXT DEFAULT '',
    reviewer TEXT DEFAULT '',
    review_note TEXT DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS import_runs (
    id TEXT PRIMARY KEY,
    source_file TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    imported_at TEXT NOT NULL,
    imported_count INTEGER NOT NULL DEFAULT 0,
    warning_count INTEGER NOT NULL DEFAULT 0,
    error_count INTEGER NOT NULL DEFAULT 0,
    report_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    actor TEXT DEFAULT '',
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    before_json TEXT,
    after_json TEXT,
    note TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_boards_code ON boards(code);
CREATE INDEX IF NOT EXISTS idx_configs_batch ON experiment_configs(batch_id);
CREATE INDEX IF NOT EXISTS idx_configs_category ON experiment_configs(category_id);
CREATE INDEX IF NOT EXISTS idx_configs_status ON experiment_configs(status);
CREATE INDEX IF NOT EXISTS idx_trials_run ON trials(run_id);
CREATE INDEX IF NOT EXISTS idx_trials_config ON trials(config_id);
CREATE INDEX IF NOT EXISTS idx_candidates_trial ON detected_candidates(trial_id);
CREATE INDEX IF NOT EXISTS idx_expected_run ON expected_anomalies(run_id);
CREATE INDEX IF NOT EXISTS idx_attachments_run ON attachments(run_id);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(timestamp);
