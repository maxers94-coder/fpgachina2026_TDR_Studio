"""线缆资产与线缆组合。"""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from .. import config
from ..database import Database
from ..utils import clean_filename, new_id, now_iso, safe_float


class CableRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    # ------------------------------------------------------------- 线缆资产
    def list(self, search: str = "", status: str = "") -> list[dict[str, Any]]:
        sql = "SELECT * FROM cables WHERE 1=1"
        params: list[Any] = []
        if search:
            sql += " AND (code LIKE ? OR name LIKE ? OR model LIKE ?)"
            like = f"%{search}%"
            params.extend([like, like, like])
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY physical_length_m, code"
        return self.db.query(sql, tuple(params))

    def get(self, cable_id: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM cables WHERE id=?", (cable_id,))

    def get_by_code(self, code: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM cables WHERE code=? COLLATE NOCASE", (code.strip(),))

    def _prepare(self, data: dict[str, Any]) -> dict[str, Any]:
        code = str(data.get("code", "")).strip()
        name = str(data.get("name", "")).strip()
        length = safe_float(data.get("physical_length_m"))
        z0 = safe_float(data.get("z0"))
        velocity = safe_float(data.get("velocity_factor"))
        if not code:
            raise ValueError("线缆代号不能为空")
        if not name:
            raise ValueError("线缆名称不能为空")
        if length is None or length <= 0:
            raise ValueError("物理长度必须大于 0")
        if z0 is None or z0 <= 0:
            raise ValueError("特性阻抗必须大于 0")
        if velocity is None or not 0 < velocity <= 1:
            raise ValueError("传播速度系数须在 (0, 1] 之间")
        status = str(data.get("status", "available"))
        if status not in {"available", "damaged", "retired"}:
            status = "available"
        return {
            "code": code,
            "name": name,
            "physical_length_m": length,
            "model": str(data.get("model", "") or "").strip(),
            "z0": z0,
            "velocity_factor": velocity,
            "notes": str(data.get("notes", "") or "").strip(),
            "status": status,
        }

    def create(self, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        prepared = self._prepare(data)
        if self.get_by_code(prepared["code"]):
            raise ValueError("线缆代号已存在")
        cable_id = new_id("CBL")
        timestamp = now_iso()
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO cables
                (id,code,name,physical_length_m,model,z0,velocity_factor,notes,status,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    cable_id,
                    prepared["code"],
                    prepared["name"],
                    prepared["physical_length_m"],
                    prepared["model"],
                    prepared["z0"],
                    prepared["velocity_factor"],
                    prepared["notes"],
                    prepared["status"],
                    timestamp,
                    timestamp,
                ),
            )
            self.db.audit(
                conn, action="create", entity_type="cable", entity_id=cable_id,
                after=prepared, actor=actor, note="新增线缆",
            )
        return self.get(cable_id) or {}

    def update(self, cable_id: str, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        before = self.get(cable_id)
        if not before:
            raise ValueError("线缆不存在")
        prepared = self._prepare(data)
        duplicate = self.get_by_code(prepared["code"])
        if duplicate and duplicate["id"] != cable_id:
            raise ValueError("线缆代号已存在")
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE cables SET code=?,name=?,physical_length_m=?,model=?,z0=?,velocity_factor=?,
                notes=?,status=?,updated_at=? WHERE id=?""",
                (
                    prepared["code"], prepared["name"], prepared["physical_length_m"], prepared["model"],
                    prepared["z0"], prepared["velocity_factor"], prepared["notes"], prepared["status"],
                    now_iso(), cable_id,
                ),
            )
            self.db.audit(
                conn, action="update", entity_type="cable", entity_id=cable_id,
                before=before, after=prepared, actor=actor, note="编辑线缆",
            )
        return self.get(cable_id) or {}

    def delete(self, cable_id: str, actor: str = "") -> None:
        cable = self.get(cable_id)
        if not cable:
            return
        used = self.db.scalar("SELECT COUNT(*) FROM cable_config_items WHERE cable_id=?", (cable_id,), 0)
        if used:
            raise ValueError("该线缆已被线缆组合引用，请先调整组合或改为停用")
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM cables WHERE id=?", (cable_id,))
            self.db.audit(
                conn, action="delete", entity_type="cable", entity_id=cable_id,
                before=cable, actor=actor, note="删除线缆",
            )

    # ------------------------------------------------------------- 线缆组合
    def list_configs(self) -> list[dict[str, Any]]:
        return self.db.query(
            """SELECT cc.*,
              (SELECT COUNT(*) FROM cable_config_items i WHERE i.config_id=cc.id) AS item_count,
              (SELECT COUNT(*) FROM experiment_configs e WHERE e.cable_config_id=cc.id) AS config_count
            FROM cable_configs cc ORDER BY cc.code COLLATE NOCASE"""
        )

    def get_config(self, config_id: str) -> dict[str, Any] | None:
        cfg = self.db.query_one("SELECT * FROM cable_configs WHERE id=?", (config_id,))
        if cfg:
            cfg["items"] = self.db.query(
                """SELECT i.*, c.code AS cable_code, c.name AS cable_name,
                          b.code AS board_code, b.name AS board_name, b.board_type
                FROM cable_config_items i
                LEFT JOIN cables c ON c.id=i.cable_id
                LEFT JOIN boards b ON b.id=i.board_id
                WHERE i.config_id=? ORDER BY i.position""",
                (config_id,),
            )
        return cfg

    def calculate_layout(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        """按顺序累计电缆长度，给出测试板理论位置和间距。"""
        cumulative = 0.0
        boards: list[dict[str, Any]] = []
        connector_count = 0
        for index, item in enumerate(items, start=1):
            item_type = item.get("item_type", "cable")
            correction = float(item.get("correction_m") or 0.0)
            if item_type == "cable":
                length = float(item.get("length_m") or 0.0)
                cumulative += length + correction
            elif item_type == "connector":
                connector_count += 1
                cumulative += correction
            elif item_type == "board":
                cumulative += correction
                board_code = item.get("board_code") or item.get("board_id") or ""
                board_name = item.get("board_name") or ""
                board_type = item.get("board_type") or ""
                board_id = item.get("board_id")
                if board_type != "normal":
                    boards.append(
                        {
                            "position": index,
                            "board_id": board_id,
                            "board_code": board_code,
                            "board_name": board_name,
                            "board_type": board_type,
                            "theoretical_distance_m": cumulative,
                            "correction_m": correction,
                        }
                    )
            elif item_type == "termination":
                cumulative += correction
        intervals = []
        for previous, current in zip(boards, boards[1:]):
            intervals.append(
                {
                    "from": previous["board_code"],
                    "to": current["board_code"],
                    "interval_m": current["theoretical_distance_m"] - previous["theoretical_distance_m"],
                }
            )
        return {
            "total_length_m": cumulative,
            "connector_count": connector_count,
            "boards": boards,
            "intervals": intervals,
        }

    def save_config(
        self,
        data: dict[str, Any],
        items: list[dict[str, Any]],
        *,
        config_id: str | None = None,
        actor: str = "",
    ) -> dict[str, Any]:
        code = str(data.get("code", "")).strip()
        name = str(data.get("name", "")).strip()
        if not code or not name:
            raise ValueError("线缆组合代号和名称不能为空")
        if not items:
            raise ValueError("线缆组合至少需要一个线段或测试板")
        duplicate = self.db.query_one(
            "SELECT id FROM cable_configs WHERE code=? COLLATE NOCASE", (code,)
        )
        if duplicate and duplicate["id"] != config_id:
            raise ValueError("线缆组合代号已存在")
        layout = self.calculate_layout(items)
        timestamp = now_iso()
        new_config_id = config_id or new_id("CCFG")
        before = self.get_config(config_id) if config_id else None
        with self.db.transaction() as conn:
            if config_id:
                conn.execute(
                    """UPDATE cable_configs SET code=?,name=?,description=?,total_length_m=?,connector_count=?,
                    correction_m=?,notes=?,updated_at=? WHERE id=?""",
                    (
                        code, name, str(data.get("description", "") or ""), layout["total_length_m"],
                        layout["connector_count"], float(data.get("correction_m") or 0.0),
                        str(data.get("notes", "") or ""), timestamp, config_id,
                    ),
                )
                conn.execute("DELETE FROM cable_config_items WHERE config_id=?", (config_id,))
            else:
                conn.execute(
                    """INSERT INTO cable_configs
                    (id,code,name,description,total_length_m,connector_count,correction_m,notes,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (
                        new_config_id, code, name, str(data.get("description", "") or ""),
                        layout["total_length_m"], layout["connector_count"],
                        float(data.get("correction_m") or 0.0), str(data.get("notes", "") or ""),
                        timestamp, timestamp,
                    ),
                )
            for position, item in enumerate(items, start=1):
                conn.execute(
                    """INSERT INTO cable_config_items
                    (id,config_id,position,item_type,cable_id,board_id,label,length_m,correction_m,notes)
                    VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (
                        new_id("CCI"), new_config_id, position, item.get("item_type", "cable"),
                        item.get("cable_id"), item.get("board_id"),
                        str(item.get("label", "") or ""), float(item.get("length_m") or 0.0),
                        float(item.get("correction_m") or 0.0), str(item.get("notes", "") or ""),
                    ),
                )
            after = {"code": code, "name": name, "items": items, "layout": layout}
            self.db.audit(
                conn, action="update" if config_id else "create", entity_type="cable_config",
                entity_id=new_config_id, before=before, after=after, actor=actor, note="保存线缆组合",
            )
        return self.get_config(new_config_id) or {}

    def delete_config(self, config_id: str, actor: str = "") -> None:
        config_row = self.get_config(config_id)
        if not config_row:
            return
        used = self.db.scalar("SELECT COUNT(*) FROM experiment_configs WHERE cable_config_id=?", (config_id,), 0)
        refs = self.db.scalar("SELECT COUNT(*) FROM health_references WHERE config_id=?", (config_id,), 0)
        if used or refs:
            raise ValueError("线缆组合已被实验配置或健康参考引用，不能删除")
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM cable_configs WHERE id=?", (config_id,))
            self.db.audit(
                conn, action="delete", entity_type="cable_config", entity_id=config_id,
                before=config_row, actor=actor, note="删除线缆组合",
            )

    def item_choices(self) -> list[dict[str, Any]]:
        cables = self.db.query(
            "SELECT id,code,name,physical_length_m,z0 FROM cables WHERE status!='retired' ORDER BY physical_length_m,code"
        )
        for cable in cables:
            cable["item_type"] = "cable"
            cable["display"] = f"线缆 {cable['code']}｜{cable['name']}（{cable['physical_length_m']:g} m）"
        boards = self.db.query(
            "SELECT id,code,name,board_type FROM boards WHERE status!='retired' ORDER BY code COLLATE NOCASE"
        )
        for board in boards:
            board["item_type"] = "board"
            board["display"] = f"测试板 {board['code']}｜{board['name']}"
        return cables + boards
