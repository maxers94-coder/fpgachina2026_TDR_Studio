"""实验运行实例与真实异常定义。"""
from __future__ import annotations

from typing import Any

from ..database import Database
from ..utils import json_loads, new_id, now_iso


class RunRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def get(self, run_id: str) -> dict[str, Any] | None:
        row = self.db.query_one(
            """SELECT r.*, b.name AS batch_name, b.code AS batch_code,
               c.code AS config_code, c.name AS config_name, c.mode, c.priority,
               c.distance_m, c.distance_expr, c.planned_repeats, c.tolerance_m,
               c.expected_polarity, c.expected_anomalies_json,
               cat.code AS category_code, cat.name AS category_name,
               bd.id AS board_id, bd.code AS board_code, bd.name AS board_name, bd.board_type,
               bd.gamma_nominal, bd.nominal_ohm, bd.measured_ohm,
               cc.code AS cable_config_code, cc.name AS cable_config_name,
               hr.ref_no AS reference_no
               FROM experiment_runs r
               JOIN experiment_configs c ON c.id=r.config_id
               JOIN experiment_categories cat ON cat.id=c.category_id
               JOIN batches b ON b.id=r.batch_id
               LEFT JOIN boards bd ON bd.id=c.board_id
               LEFT JOIN cable_configs cc ON cc.id=r.cable_config_id
               LEFT JOIN health_references hr ON hr.id=r.reference_id
               WHERE r.id=?""",
            (run_id,),
        )
        return row

    def get_by_config(self, config_id: str) -> dict[str, Any] | None:
        row = self.db.query_one("SELECT id FROM experiment_runs WHERE config_id=?", (config_id,))
        return self.get(row["id"]) if row else None

    def ensure_for_config(self, config_id: str, actor: str = "") -> dict[str, Any]:
        existing = self.get_by_config(config_id)
        if existing:
            return existing
        config = self.db.query_one(
            """SELECT c.*, b.firmware_version AS batch_firmware, b.frontend AS batch_frontend
               FROM experiment_configs c JOIN batches b ON b.id=c.batch_id WHERE c.id=?""",
            (config_id,),
        )
        if not config:
            raise ValueError("实验配置不存在")
        run_id = new_id("RUN")
        timestamp = now_iso()
        code = f"RUN-{config['code']}"
        if self.db.query_one("SELECT id FROM experiment_runs WHERE code=? COLLATE NOCASE", (code,)):
            code = f"RUN-{config['code']}-{run_id[-6:]}"
        operator = str(self.db.get_setting("operator", "") or "")
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO experiment_runs
                (id,code,config_id,batch_id,session_id,firmware_version,reference_id,cable_config_id,
                 frontend,operator,status,notes,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    run_id, code, config_id, config["batch_id"], config["batch_id"],
                    config.get("batch_firmware") or self.db.get_setting("firmware_version", ""),
                    config.get("reference_id"), config.get("cable_config_id"),
                    config.get("batch_frontend") or "resistive_divider", operator,
                    "active", "", timestamp, timestamp,
                ),
            )
            expected = json_loads(config.get("expected_anomalies_json"), [])
            if config["mode"] == "multi":
                for index, anomaly in enumerate(expected, start=1):
                    self._insert_expected(conn, run_id, anomaly, index, config)
            elif config["mode"] == "single":
                distance = config.get("distance_m")
                if distance is not None:
                    board = (
                        self.db.query_one("SELECT * FROM boards WHERE id=?", (config.get("board_id"),))
                        if config.get("board_id")
                        else None
                    )
                    conn.execute(
                        """INSERT INTO expected_anomalies
                        (id,run_id,anomaly_index,board_id,true_distance_m,expected_polarity,tolerance_m,notes,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?)""",
                        (
                            new_id("EA"), run_id, 1, config.get("board_id"), float(distance),
                            config.get("expected_polarity") or "none", config.get("tolerance_m"),
                            "", timestamp,
                        ),
                    )
            self.db.audit(
                conn, action="create", entity_type="experiment_run", entity_id=run_id,
                after={"config_id": config_id, "code": code}, actor=actor, note="开始实验运行",
            )
        return self.get(run_id) or {}

    def _insert_expected(self, conn, run_id: str, anomaly: dict[str, Any], index: int, config: dict[str, Any]) -> None:
        board_id = anomaly.get("board_id")
        board = self.db.query_one("SELECT * FROM boards WHERE id=?", (board_id,)) if board_id else None
        conn.execute(
            """INSERT INTO expected_anomalies
            (id,run_id,anomaly_index,board_id,true_distance_m,expected_polarity,tolerance_m,notes,created_at)
            VALUES(?,?,?,?,?,?,?,?,?)""",
            (
                new_id("EA"), run_id, index, board_id, float(anomaly["true_distance_m"]),
                anomaly.get("expected_polarity") or (board["polarity"] if board else "none"),
                anomaly.get("tolerance_m") or config.get("tolerance_m"),
                str(anomaly.get("notes", "") or ""), now_iso(),
            ),
        )

    def expected_anomalies(self, run_id: str) -> list[dict[str, Any]]:
        return self.db.query(
            """SELECT e.*, b.code AS board_code, b.name AS board_name, b.board_type,
                      b.gamma_nominal, b.nominal_ohm
               FROM expected_anomalies e
               LEFT JOIN boards b ON b.id=e.board_id
               WHERE e.run_id=? ORDER BY e.anomaly_index""",
            (run_id,),
        )

    def update(self, run_id: str, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        before = self.get(run_id)
        if not before:
            raise ValueError("实验运行不存在")
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE experiment_runs SET firmware_version=?,reference_id=?,cable_config_id=?,
                frontend=?,operator=?,status=?,notes=?,updated_at=? WHERE id=?""",
                (
                    str(data.get("firmware_version", before["firmware_version"]) or ""),
                    data.get("reference_id") or None,
                    data.get("cable_config_id") or None,
                    str(data.get("frontend") or before["frontend"] or "resistive_divider"),
                    str(data.get("operator", before["operator"]) or ""),
                    str(data.get("status") or before["status"]),
                    str(data.get("notes", before["notes"]) or ""),
                    now_iso(), run_id,
                ),
            )
            self.db.audit(
                conn, action="update", entity_type="experiment_run", entity_id=run_id,
                before={"status": before["status"], "reference_id": before["reference_id"],
                        "firmware_version": before["firmware_version"], "notes": before["notes"]},
                after=data, actor=actor, note="更新实验运行条件",
            )
        return self.get(run_id) or {}

    def list_recent(self, limit: int = 20) -> list[dict[str, Any]]:
        return self.db.query(
            """SELECT r.*, c.code AS config_code, c.name AS config_name, c.mode,
                      cat.code AS category_code, cat.name AS category_name,
                      (SELECT COUNT(*) FROM trials t WHERE t.run_id=r.id) AS trial_count,
                      (SELECT MAX(t.updated_at) FROM trials t WHERE t.run_id=r.id) AS last_trial_at
               FROM experiment_runs r
               JOIN experiment_configs c ON c.id=r.config_id
               JOIN experiment_categories cat ON cat.id=c.category_id
               ORDER BY COALESCE(last_trial_at, r.updated_at) DESC LIMIT ?""",
            (limit,),
        )

    def reference_condition_issues(self, run: dict[str, Any]) -> list[str]:
        reference_id = run.get("reference_id")
        if not reference_id:
            return []
        ref = self.db.query_one("SELECT * FROM health_references WHERE id=?", (reference_id,))
        if not ref:
            return ["关联的健康参考已不存在"]
        issues = []
        if not ref["is_valid"]:
            issues.append("关联健康参考已标记为无效")
        if ref.get("config_id") and run.get("cable_config_id") != ref["config_id"]:
            issues.append("线缆组合与健康参考不一致")
        if ref.get("frontend") and run.get("frontend") != ref["frontend"]:
            issues.append("模拟前端与健康参考不一致")
        if (
            ref.get("firmware_version")
            and run.get("firmware_version")
            and ref["firmware_version"].strip() != run["firmware_version"].strip()
        ):
            issues.append("固件版本与健康参考不一致")
        return issues
