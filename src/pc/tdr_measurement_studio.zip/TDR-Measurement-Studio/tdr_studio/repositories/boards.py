"""阻抗测试板数据访问。"""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from .. import config
from ..database import Database
from ..services.reflection import calculate_gamma
from ..utils import clean_filename, new_id, now_iso, safe_float


class BoardRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def list(self, search: str = "", status: str = "", board_type: str = "") -> list[dict[str, Any]]:
        sql = """
            SELECT b.*,
              (SELECT COUNT(*) FROM experiment_configs c WHERE c.board_id=b.id) AS config_count,
              (SELECT COUNT(*) FROM expected_anomalies e WHERE e.board_id=b.id) AS anomaly_count
            FROM boards b WHERE 1=1
        """
        params: list[Any] = []
        if search:
            sql += " AND (b.code LIKE ? OR b.name LIKE ? OR b.notes LIKE ? OR b.pcb_no LIKE ?)"
            like = f"%{search}%"
            params.extend([like, like, like, like])
        if status:
            sql += " AND b.status=?"
            params.append(status)
        if board_type:
            sql += " AND b.board_type=?"
            params.append(board_type)
        sql += " ORDER BY b.code COLLATE NOCASE"
        return self.db.query(sql, tuple(params))

    def get(self, board_id: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM boards WHERE id=?", (board_id,))

    def get_by_code(self, code: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM boards WHERE code=? COLLATE NOCASE", (code.strip(),))

    def _prepare(self, data: dict[str, Any]) -> dict[str, Any]:
        code = str(data.get("code", "")).strip()
        name = str(data.get("name", "")).strip()
        board_type = str(data.get("board_type", "custom")).strip()
        if not code:
            raise ValueError("测试板代号不能为空")
        if not name:
            raise ValueError("测试板名称不能为空")
        if board_type not in config.BOARD_TYPE_LABELS:
            raise ValueError("测试板类型不合法")
        z0 = safe_float(data.get("z0"))
        z0 = 50.0 if z0 is None else z0
        if z0 <= 0:
            raise ValueError("特性阻抗 Z0 必须大于 0")
        nominal = safe_float(data.get("nominal_ohm"))
        measured = safe_float(data.get("measured_ohm"))
        override = safe_float(data.get("gamma_override"))
        if board_type not in {"series", "shunt"}:
            nominal = None
        if board_type != "custom":
            override = None
        if board_type in {"series", "shunt"} and nominal is None:
            raise ValueError("串联/并联测试板必须输入标称阻值")
        if board_type == "custom" and override is None:
            raise ValueError("自定义测试板必须输入反射系数")
        gamma = calculate_gamma(
            board_type,
            nominal_ohm=nominal,
            measured_ohm=measured,
            z0=z0,
            gamma_override=override,
        )
        status = str(data.get("status", "available"))
        if status not in config.BOARD_STATUS_LABELS:
            status = "available"
        return {
            "code": code,
            "name": name,
            "board_type": board_type,
            "nominal_ohm": nominal,
            "measured_ohm": measured,
            "z0": z0,
            "gamma_override": override,
            "gamma_nominal": gamma["gamma_nominal"],
            "gamma_measured": gamma["gamma_measured"],
            "polarity": gamma["polarity"],
            "pcb_no": str(data.get("pcb_no", "") or "").strip(),
            "component_model": str(data.get("component_model", "") or "").strip(),
            "manufacture_date": str(data.get("manufacture_date", "") or "").strip(),
            "photo_path": str(data.get("photo_path", "") or "").strip(),
            "notes": str(data.get("notes", "") or "").strip(),
            "status": status,
        }

    def create(self, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        prepared = self._prepare(data)
        if self.get_by_code(prepared["code"]):
            raise ValueError(f"测试板代号已存在：{prepared['code']}")
        board_id = new_id("BRD")
        timestamp = now_iso()
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO boards
                (id,code,name,board_type,nominal_ohm,measured_ohm,z0,gamma_override,gamma_nominal,gamma_measured,
                 polarity,pcb_no,component_model,manufacture_date,photo_path,notes,status,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    board_id,
                    prepared["code"],
                    prepared["name"],
                    prepared["board_type"],
                    prepared["nominal_ohm"],
                    prepared["measured_ohm"],
                    prepared["z0"],
                    prepared["gamma_override"],
                    prepared["gamma_nominal"],
                    prepared["gamma_measured"],
                    prepared["polarity"],
                    prepared["pcb_no"],
                    prepared["component_model"],
                    prepared["manufacture_date"],
                    prepared["photo_path"],
                    prepared["notes"],
                    prepared["status"],
                    timestamp,
                    timestamp,
                ),
            )
            self.db.audit(
                conn,
                action="create",
                entity_type="board",
                entity_id=board_id,
                after=prepared,
                actor=actor,
                note="新增测试板",
            )
        return self.get(board_id) or {}

    def update(self, board_id: str, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        before = self.get(board_id)
        if not before:
            raise ValueError("测试板不存在")
        prepared = self._prepare(data)
        duplicate = self.get_by_code(prepared["code"])
        if duplicate and duplicate["id"] != board_id:
            raise ValueError(f"测试板代号已存在：{prepared['code']}")
        prepared["updated_at"] = now_iso()
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE boards SET code=?,name=?,board_type=?,nominal_ohm=?,measured_ohm=?,z0=?,
                gamma_override=?,gamma_nominal=?,gamma_measured=?,polarity=?,pcb_no=?,component_model=?,
                manufacture_date=?,photo_path=?,notes=?,status=?,updated_at=? WHERE id=?""",
                (
                    prepared["code"],
                    prepared["name"],
                    prepared["board_type"],
                    prepared["nominal_ohm"],
                    prepared["measured_ohm"],
                    prepared["z0"],
                    prepared["gamma_override"],
                    prepared["gamma_nominal"],
                    prepared["gamma_measured"],
                    prepared["polarity"],
                    prepared["pcb_no"],
                    prepared["component_model"],
                    prepared["manufacture_date"],
                    prepared["photo_path"],
                    prepared["notes"],
                    prepared["status"],
                    prepared["updated_at"],
                    board_id,
                ),
            )
            self.db.audit(
                conn,
                action="update",
                entity_type="board",
                entity_id=board_id,
                before=before,
                after=prepared,
                actor=actor,
                note="编辑测试板",
            )
        return self.get(board_id) or {}

    def duplicate(self, board_id: str, new_code: str | None = None, actor: str = "") -> dict[str, Any]:
        source = self.get(board_id)
        if not source:
            raise ValueError("测试板不存在")
        if not new_code:
            base = source["code"] + "-副本"
            candidate = base
            index = 2
            while self.get_by_code(candidate):
                candidate = f"{base}{index}"
                index += 1
            new_code = candidate
        data = dict(source)
        data["code"] = new_code
        data["name"] = f"{source['name']}（副本）"
        data["status"] = "pending"
        data["pcb_no"] = ""
        return self.create(data, actor=actor)

    def set_status(self, board_id: str, status: str, actor: str = "") -> None:
        if status not in config.BOARD_STATUS_LABELS:
            raise ValueError("测试板状态不合法")
        before = self.get(board_id)
        if not before:
            raise ValueError("测试板不存在")
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE boards SET status=?,updated_at=? WHERE id=?",
                (status, now_iso(), board_id),
            )
            self.db.audit(
                conn,
                action="status",
                entity_type="board",
                entity_id=board_id,
                before={"status": before["status"]},
                after={"status": status},
                actor=actor,
                note="修改测试板状态",
            )

    def save_photo(self, board_code: str, source_path: str) -> str:
        source = Path(source_path)
        if not source.exists():
            raise ValueError("照片文件不存在")
        target_dir = config.ATTACHMENTS_DIR / "boards"
        target_dir.mkdir(parents=True, exist_ok=True)
        suffix = source.suffix.lower() or ".png"
        if suffix not in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}:
            raise ValueError("测试板照片仅支持 PNG/JPG/WEBP/GIF/BMP")
        target = target_dir / f"{clean_filename(board_code)}_{new_id()[:8]}{suffix}"
        shutil.copy2(source, target)
        return str(target.relative_to(config.DATA_DIR)).replace("\\", "/")
