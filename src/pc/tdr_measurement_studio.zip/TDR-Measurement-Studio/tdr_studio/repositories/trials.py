"""逐次测量记录与多异常候选。"""
from __future__ import annotations

from typing import Any

from .. import config
from ..database import Database
from ..services.matching import match_candidates
from ..utils import json_dumps, new_id, now_iso, safe_float, safe_int


class TrialRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    # ------------------------------------------------------------- 查询
    def list_for_run(self, run_id: str) -> list[dict[str, Any]]:
        return self.db.query(
            """SELECT t.*,
              (SELECT COUNT(*) FROM detected_candidates c WHERE c.trial_id=t.id) AS candidate_count,
              (SELECT COUNT(*) FROM detected_candidates c WHERE c.trial_id=t.id AND c.matched_expected_id IS NOT NULL) AS matched_count,
              (SELECT COUNT(*) FROM detected_candidates c WHERE c.trial_id=t.id AND c.match_status='ambiguous') AS ambiguous_count,
              (SELECT COUNT(*) FROM attachments a WHERE a.trial_id=t.id) AS attachment_count
            FROM trials t WHERE t.run_id=? ORDER BY t.trial_index""",
            (run_id,),
        )

    def get(self, trial_id: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM trials WHERE id=?", (trial_id,))

    def candidates(self, trial_id: str) -> list[dict[str, Any]]:
        return self.db.query(
            """SELECT c.*, e.anomaly_index AS matched_anomaly_index,
                      e.true_distance_m AS matched_true_distance_m
               FROM detected_candidates c
               LEFT JOIN expected_anomalies e ON e.id=c.matched_expected_id
               WHERE c.trial_id=? ORDER BY c.candidate_index""",
            (trial_id,),
        )

    def candidates_for_trials(self, trial_ids: list[str]) -> dict[str, list[dict[str, Any]]]:
        if not trial_ids:
            return {}
        placeholders = ",".join("?" for _ in trial_ids)
        rows = self.db.query(
            f"""SELECT c.*, e.anomaly_index AS matched_anomaly_index,
                       e.true_distance_m AS matched_true_distance_m
                FROM detected_candidates c
                LEFT JOIN expected_anomalies e ON e.id=c.matched_expected_id
                WHERE c.trial_id IN ({placeholders}) ORDER BY c.trial_id, c.candidate_index""",
            tuple(trial_ids),
        )
        result: dict[str, list[dict[str, Any]]] = {trial_id: [] for trial_id in trial_ids}
        for row in rows:
            result.setdefault(row["trial_id"], []).append(row)
        return result

    def next_index(self, run_id: str) -> int:
        value = self.db.scalar(
            "SELECT COALESCE(MAX(trial_index),0)+1 FROM trials WHERE run_id=?", (run_id,), 1
        )
        return int(value or 1)

    def count_for_run(self, run_id: str) -> int:
        return int(self.db.scalar("SELECT COUNT(*) FROM trials WHERE run_id=?", (run_id,), 0) or 0)

    def last_trial(self, run_id: str) -> dict[str, Any] | None:
        return self.db.query_one(
            "SELECT * FROM trials WHERE run_id=? ORDER BY trial_index DESC LIMIT 1", (run_id,)
        )

    # ------------------------------------------------------------- 单次创建/编辑
    def _validate_trial(
        self,
        *,
        mode: str,
        status: str,
        measured_distance_m: Any,
        polarity: str,
        quality_flag: str,
    ) -> tuple[str, float | None, str]:
        allowed = {
            "normal": {"normal", "false_alarm", "invalid", "rejected"},
            "single": {"detected", "not_detected", "invalid", "rejected"},
            "multi": {"detected", "not_detected", "invalid", "rejected"},
        }.get(mode, {"detected", "not_detected", "invalid", "rejected"})
        if status not in allowed:
            raise ValueError(f"当前实验模式下不允许状态：{status}")
        if polarity not in {"positive", "negative", "none", "unknown"}:
            raise ValueError("极性不合法")
        measured = safe_float(measured_distance_m)
        if measured is not None and measured < 0:
            raise ValueError("测量距离不能为负数")
        if status == "detected" and measured is None:
            raise ValueError("检出状态必须填写系统测量距离；否则请标记未检出或无效")
        if status == "not_detected":
            measured = None
            polarity = "unknown"
        if status == "normal":
            measured = None
            polarity = "none"
        quality = (quality_flag or "正常").strip() or "正常"
        return status, measured, quality

    def create(
        self,
        run_id: str,
        *,
        measured_distance_m: Any = None,
        polarity: str = "unknown",
        detection_status: str = "not_detected",
        quality_flag: str = "正常",
        notes: str = "",
        trial_index: int | None = None,
        actor: str = "",
    ) -> dict[str, Any]:
        run = self.db.query_one(
            """SELECT r.*, c.mode, c.distance_m, c.id AS config_id
               FROM experiment_runs r JOIN experiment_configs c ON c.id=r.config_id WHERE r.id=?""",
            (run_id,),
        )
        if not run:
            raise ValueError("实验运行不存在")
        status, measured, quality = self._validate_trial(
            mode=run["mode"], status=detection_status,
            measured_distance_m=measured_distance_m, polarity=polarity, quality_flag=quality_flag,
        )
        index = safe_int(trial_index) or self.next_index(run_id)
        if index <= 0:
            raise ValueError("试次号必须大于 0")
        if self.db.query_one(
            "SELECT id FROM trials WHERE run_id=? AND trial_index=?", (run_id, index)
        ):
            raise ValueError(f"试次号 {index} 已存在")
        true_distance = run["distance_m"] if run["mode"] == "single" else None
        trial_id = new_id("TRL")
        timestamp = now_iso()
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO trials
                (id,run_id,config_id,trial_index,true_distance_m,measured_distance_m,polarity,
                 detection_status,quality_flag,extra_candidate_count,is_manual,notes,measured_at,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    trial_id, run_id, run["config_id"], index, true_distance, measured, polarity,
                    status, quality, 0, 1, str(notes or ""), timestamp, timestamp, timestamp,
                ),
            )
            self.db.audit(
                conn, action="create", entity_type="trial", entity_id=trial_id,
                after={"run_id": run_id, "trial_index": index, "status": status,
                       "measured_distance_m": measured, "polarity": polarity,
                       "quality_flag": quality, "notes": notes},
                actor=actor, note="保存单次测量",
            )
            conn.execute("UPDATE experiment_runs SET updated_at=? WHERE id=?", (timestamp, run_id))
        self.db.query("SELECT 1")
        from .experiments import ExperimentRepository

        ExperimentRepository(self.db).refresh_status(run["config_id"])
        return self.get(trial_id) or {}

    def update(self, trial_id: str, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        before = self.get(trial_id)
        if not before:
            raise ValueError("测量记录不存在")
        run = self.db.query_one(
            """SELECT r.*, c.mode, c.id AS config_id FROM experiment_runs r
               JOIN experiment_configs c ON c.id=r.config_id WHERE r.id=?""",
            (before["run_id"],),
        )
        if not run:
            raise ValueError("实验运行不存在")
        status, measured, quality = self._validate_trial(
            mode=run["mode"],
            status=str(data.get("detection_status", before["detection_status"])),
            measured_distance_m=data.get("measured_distance_m", before["measured_distance_m"]),
            polarity=str(data.get("polarity", before["polarity"])),
            quality_flag=str(data.get("quality_flag", before["quality_flag"])),
        )
        new_index = safe_int(data.get("trial_index"), before["trial_index"])
        if new_index is None or new_index <= 0:
            raise ValueError("试次号必须大于 0")
        duplicate = self.db.query_one(
            "SELECT id FROM trials WHERE run_id=? AND trial_index=? AND id!=?",
            (before["run_id"], new_index, trial_id),
        )
        if duplicate:
            raise ValueError("该试次号已存在")
        timestamp = now_iso()
        after = {
            "trial_index": new_index,
            "detection_status": status,
            "measured_distance_m": measured,
            "polarity": data.get("polarity", before["polarity"]) if status not in {"not_detected", "normal"} else ("unknown" if status == "not_detected" else "none"),
            "quality_flag": quality,
            "notes": str(data.get("notes", before["notes"]) or ""),
        }
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE trials SET trial_index=?,measured_distance_m=?,polarity=?,detection_status=?,
                quality_flag=?,notes=?,updated_at=? WHERE id=?""",
                (
                    new_index, measured, after["polarity"], status, quality,
                    after["notes"], timestamp, trial_id,
                ),
            )
            self.db.audit(
                conn, action="update", entity_type="trial", entity_id=trial_id,
                before=before, after=after, actor=actor, note="修改测量记录",
            )
            conn.execute("UPDATE experiment_runs SET updated_at=? WHERE id=?", (timestamp, before["run_id"]))
        return self.get(trial_id) or {}

    def delete(self, trial_id: str, actor: str = "") -> None:
        before = self.get(trial_id)
        if not before:
            return
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM trials WHERE id=?", (trial_id,))
            self.db.audit(
                conn, action="delete", entity_type="trial", entity_id=trial_id,
                before=before, actor=actor, note="删除测量记录（含原始字段快照）",
            )
        from .experiments import ExperimentRepository

        ExperimentRepository(self.db).refresh_status(before["config_id"])

    # ------------------------------------------------------------- 多异常保存
    def _run_context(self, run_id: str) -> dict[str, Any]:
        run = self.db.query_one(
            """SELECT r.*, c.mode, c.distance_m, c.id AS config_id, c.tolerance_m
               FROM experiment_runs r JOIN experiment_configs c ON c.id=r.config_id WHERE r.id=?""",
            (run_id,),
        )
        if not run:
            raise ValueError("实验运行不存在")
        return run

    def _prepare_candidates(self, raw_candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
        prepared = []
        for index, raw in enumerate(raw_candidates, start=1):
            distance = safe_float(raw.get("measured_distance_m"))
            if distance is None:
                continue
            if distance < 0:
                raise ValueError("候选距离不能为负数")
            polarity = str(raw.get("polarity") or "unknown")
            if polarity not in {"positive", "negative", "none", "unknown"}:
                polarity = "unknown"
            prepared.append(
                {
                    "id": new_id("CAND"),
                    "candidate_index": index,
                    "measured_distance_m": distance,
                    "polarity": polarity,
                    "quality_flag": (str(raw.get("quality_flag") or "正常").strip() or "正常"),
                    "notes": str(raw.get("notes", "") or ""),
                }
            )
        return prepared

    def _match_for_run(
        self, run_id: str, candidates: list[dict[str, Any]], default_tolerance: float
    ) -> dict[str, Any]:
        expected = self.db.query(
            "SELECT * FROM expected_anomalies WHERE run_id=? ORDER BY anomaly_index", (run_id,)
        )
        return match_candidates(expected, candidates, default_tolerance_m=default_tolerance)

    def _save_multi(
        self,
        *,
        run_id: str,
        trial_index: int,
        candidates_raw: list[dict[str, Any]],
        quality_flag: str,
        notes: str,
        status_override: str | None = None,
        actor: str = "",
        existing_trial_id: str | None = None,
    ) -> dict[str, Any]:
        run = self._run_context(run_id)
        if run["mode"] != "multi":
            raise ValueError("该实验不是多异常模式")
        candidates = self._prepare_candidates(candidates_raw)
        default_tolerance = float(
            run.get("tolerance_m") or self.db.get_setting("distance_tolerance_m", 0.60)
        )
        match = self._match_for_run(run_id, candidates, default_tolerance)
        matched_by_candidate = {a["candidate_id"]: a for a in match["assignments"]}
        if status_override in {"invalid", "rejected"}:
            status = status_override
        elif status_override == "not_detected":
            status = "not_detected"
        else:
            status = "detected" if match["assignments"] else "not_detected"
        quality = (quality_flag or "正常").strip() or "正常"
        timestamp = now_iso()
        trial_id = existing_trial_id or new_id("TRL")
        before = self.get(existing_trial_id) if existing_trial_id else None
        before_candidates = self.candidates(existing_trial_id) if existing_trial_id else []
        extra_count = len(candidates) - len(match["matched_candidate_ids"])
        with self.db.transaction() as conn:
            if existing_trial_id:
                conn.execute(
                    """UPDATE trials SET trial_index=?,measured_distance_m=NULL,polarity='unknown',
                    detection_status=?,quality_flag=?,extra_candidate_count=?,notes=?,updated_at=?
                    WHERE id=?""",
                    (trial_index, status, quality, extra_count, str(notes or ""), timestamp, trial_id),
                )
                conn.execute("DELETE FROM detected_candidates WHERE trial_id=?", (trial_id,))
            else:
                conn.execute(
                    """INSERT INTO trials
                    (id,run_id,config_id,trial_index,true_distance_m,measured_distance_m,polarity,
                     detection_status,quality_flag,extra_candidate_count,is_manual,notes,measured_at,created_at,updated_at)
                    VALUES(?,?,?,?,NULL,NULL,'unknown',?,?,?,?,?,?,?,?)""",
                    (
                        trial_id, run_id, run["config_id"], trial_index, status, quality,
                        extra_count, 1, str(notes or ""), timestamp, timestamp, timestamp,
                    ),
                )
            for candidate in candidates:
                assignment = matched_by_candidate.get(candidate["id"])
                match_status = "extra"
                matched_expected_id = None
                polarity_ok = None
                distance_error = None
                if assignment:
                    match_status = "ambiguous" if match.get("ambiguous") else "matched"
                    matched_expected_id = assignment["expected_id"]
                    polarity_ok = 1 if assignment["polarity_correct"] else 0
                    distance_error = assignment["distance_error_m"]
                conn.execute(
                    """INSERT INTO detected_candidates
                    (id,trial_id,candidate_index,measured_distance_m,polarity,quality_flag,
                     matched_expected_id,match_status,polarity_correct,distance_error_m,notes,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        candidate["id"], trial_id, candidate["candidate_index"],
                        candidate["measured_distance_m"], candidate["polarity"],
                        candidate["quality_flag"], matched_expected_id, match_status,
                        polarity_ok, distance_error, candidate["notes"], timestamp, timestamp,
                    ),
                )
            after = {
                "run_id": run_id, "trial_index": trial_index, "status": status,
                "candidates": candidates, "match": {
                    "assignments": len(match["assignments"]),
                    "missed": len(match["missed_expected_ids"]),
                    "extra": extra_count,
                    "ambiguous": match.get("ambiguous", False),
                },
                "quality_flag": quality, "notes": notes,
            }
            self.db.audit(
                conn,
                action="update" if existing_trial_id else "create",
                entity_type="trial", entity_id=trial_id,
                before={"trial": before, "candidates": before_candidates} if existing_trial_id else None,
                after=after, actor=actor,
                note="保存多异常测量与候选匹配",
            )
            conn.execute("UPDATE experiment_runs SET updated_at=? WHERE id=?", (timestamp, run_id))
        from .experiments import ExperimentRepository

        ExperimentRepository(self.db).refresh_status(run["config_id"])
        return self.get(trial_id) or {}

    def save_multi_trial(
        self,
        run_id: str,
        *,
        trial_index: int | None,
        candidates: list[dict[str, Any]],
        quality_flag: str = "正常",
        notes: str = "",
        status_override: str | None = None,
        actor: str = "",
    ) -> dict[str, Any]:
        index = safe_int(trial_index) or self.next_index(run_id)
        if index <= 0:
            raise ValueError("试次号必须大于 0")
        if self.db.query_one("SELECT id FROM trials WHERE run_id=? AND trial_index=?", (run_id, index)):
            raise ValueError(f"试次号 {index} 已存在")
        return self._save_multi(
            run_id=run_id, trial_index=index, candidates_raw=candidates,
            quality_flag=quality_flag, notes=notes, status_override=status_override, actor=actor,
        )

    def update_multi_trial(
        self,
        trial_id: str,
        *,
        trial_index: int,
        candidates: list[dict[str, Any]],
        quality_flag: str = "正常",
        notes: str = "",
        status_override: str | None = None,
        actor: str = "",
    ) -> dict[str, Any]:
        before = self.get(trial_id)
        if not before:
            raise ValueError("测量记录不存在")
        duplicate = self.db.query_one(
            "SELECT id FROM trials WHERE run_id=? AND trial_index=? AND id!=?",
            (before["run_id"], trial_index, trial_id),
        )
        if duplicate:
            raise ValueError("该试次号已存在")
        return self._save_multi(
            run_id=before["run_id"], trial_index=trial_index, candidates_raw=candidates,
            quality_flag=quality_flag, notes=notes, status_override=status_override,
            actor=actor, existing_trial_id=trial_id,
        )

    def update_extra_candidate_count(self, run_id: str) -> None:
        for trial in self.list_for_run(run_id):
            count = max(0, int(trial["candidate_count"] or 0) - int(trial["matched_count"] or 0))
            if count != int(trial["extra_candidate_count"] or 0):
                self.db.execute(
                    "UPDATE trials SET extra_candidate_count=? WHERE id=?",
                    (count, trial["id"]),
                )
