"""实验配置（测试矩阵）与实验运行实例。"""
from __future__ import annotations

import re
from typing import Any, Iterable

from ..database import Database
from ..services.reflection import calculate_gamma
from ..utils import json_dumps, json_loads, new_id, now_iso, safe_float, safe_int


class ExperimentRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    # ------------------------------------------------------------- 查询
    def list(
        self,
        *,
        batch_id: str | None = None,
        category_id: str | None = None,
        status: str | None = None,
        priority: str | None = None,
        board_id: str | None = None,
        mode: str | None = None,
        search: str = "",
    ) -> list[dict[str, Any]]:
        sql = """
            SELECT ec.*,
              cat.code AS category_code, cat.name AS category_name,
              b.code AS batch_code, b.name AS batch_name, b.firmware_version AS batch_firmware,
              b.frontend AS batch_frontend,
              bd.code AS board_code, bd.name AS board_name, bd.board_type, bd.gamma_nominal,
              bd.nominal_ohm, bd.measured_ohm, bd.z0 AS board_z0,
              cc.code AS cable_config_code, cc.name AS cable_config_name,
              hr.ref_no AS reference_no,
              r.id AS run_id,
              (SELECT COUNT(*) FROM trials t WHERE t.config_id=ec.id) AS trial_count,
              (SELECT COUNT(*) FROM trials t WHERE t.config_id=ec.id AND t.detection_status IN ('detected','not_detected')) AS resolved_count,
              (SELECT COUNT(*) FROM trials t WHERE t.config_id=ec.id AND t.detection_status='detected') AS detected_count,
              (SELECT COUNT(*) FROM trials t WHERE t.config_id=ec.id AND t.detection_status IN ('invalid','rejected')) AS invalid_count
            FROM experiment_configs ec
            JOIN experiment_categories cat ON cat.id=ec.category_id
            JOIN batches b ON b.id=ec.batch_id
            LEFT JOIN boards bd ON bd.id=ec.board_id
            LEFT JOIN cable_configs cc ON cc.id=ec.cable_config_id
            LEFT JOIN health_references hr ON hr.id=ec.reference_id
            LEFT JOIN experiment_runs r ON r.config_id=ec.id
            WHERE 1=1
        """
        params: list[Any] = []
        if batch_id:
            sql += " AND ec.batch_id=?"
            params.append(batch_id)
        if category_id:
            sql += " AND ec.category_id=?"
            params.append(category_id)
        if status:
            sql += " AND ec.status=?"
            params.append(status)
        if priority:
            sql += " AND ec.priority=?"
            params.append(priority)
        if board_id:
            sql += " AND ec.board_id=?"
            params.append(board_id)
        if mode:
            sql += " AND ec.mode=?"
            params.append(mode)
        if search:
            sql += " AND (ec.code LIKE ? OR ec.name LIKE ? OR ec.notes LIKE ? OR bd.code LIKE ?)"
            like = f"%{search}%"
            params.extend([like, like, like, like])
        sql += " ORDER BY ec.sort_order, ec.code COLLATE NOCASE"
        return self.db.query(sql, tuple(params))

    def get(self, config_id: str) -> dict[str, Any] | None:
        row = self.db.query_one(
            """SELECT ec.*, cat.code AS category_code, cat.name AS category_name,
               b.code AS batch_code, b.name AS batch_name, b.firmware_version AS batch_firmware,
               b.frontend AS batch_frontend,
               bd.code AS board_code, bd.name AS board_name, bd.board_type, bd.gamma_nominal,
               bd.nominal_ohm, bd.measured_ohm, bd.z0 AS board_z0
               FROM experiment_configs ec
               JOIN experiment_categories cat ON cat.id=ec.category_id
               JOIN batches b ON b.id=ec.batch_id
               LEFT JOIN boards bd ON bd.id=ec.board_id
               WHERE ec.id=?""",
            (config_id,),
        )
        if row:
            row["expected_anomalies"] = json_loads(row.get("expected_anomalies_json"), [])
        return row

    def get_by_code(self, code: str) -> dict[str, Any] | None:
        return self.db.query_one(
            "SELECT * FROM experiment_configs WHERE code=? COLLATE NOCASE", (code.strip(),)
        )

    def next_code(self, category_code: str) -> str:
        prefix = re.sub(r"[^A-Za-z0-9_-]", "", category_code).upper() or "EXP"
        rows = self.db.query(
            "SELECT code FROM experiment_configs WHERE code LIKE ?", (f"{prefix}%",)
        )
        maximum = 0
        for row in rows:
            match = re.fullmatch(re.escape(prefix) + r"(\d+)", str(row["code"]))
            if match:
                maximum = max(maximum, int(match.group(1)))
        candidate = f"{prefix}{maximum + 1:02d}"
        while self.get_by_code(candidate):
            maximum += 1
            candidate = f"{prefix}{maximum + 1:02d}"
        return candidate

    def counts(self, batch_id: str | None = None) -> dict[str, int]:
        sql = "SELECT status, COUNT(*) AS n FROM experiment_configs"
        params: tuple = ()
        if batch_id:
            sql += " WHERE batch_id=?"
            params = (batch_id,)
        sql += " GROUP BY status"
        result = {"not_started": 0, "in_progress": 0, "completed": 0, "skipped": 0, "failed": 0}
        for row in self.db.query(sql, params):
            result[row["status"]] = int(row["n"])
        result["total"] = sum(result.values())
        return result

    # ------------------------------------------------------------- 创建/编辑
    def _default_name(self, data: dict[str, Any], board: dict[str, Any] | None) -> str:
        mode = data.get("mode", "single")
        distance = data.get("distance_m")
        if mode == "multi":
            expr = data.get("distance_expr") or data.get("distance_m") or "见备注"
            return f"多异常定位｜{expr} m"
        if mode == "normal":
            return f"正常参考｜{distance:g} m" if isinstance(distance, (int, float)) else "正常参考"
        board_label = f"{board['code']} {board['name']}" if board else "未指定测试板"
        return f"{distance:g} m｜{board_label}｜单异常" if isinstance(distance, (int, float)) else f"{board_label}｜单异常"

    def _validate_common(self, data: dict[str, Any]) -> dict[str, Any]:
        category_id = data.get("category_id")
        batch_id = data.get("batch_id")
        if not category_id or not self.db.query_one("SELECT id FROM experiment_categories WHERE id=?", (category_id,)):
            raise ValueError("请选择有效的实验类别")
        if not batch_id or not self.db.query_one("SELECT id FROM batches WHERE id=?", (batch_id,)):
            raise ValueError("请选择有效的实验批次")
        mode = str(data.get("mode", "single"))
        if mode not in {"normal", "single", "multi"}:
            raise ValueError("实验模式不合法")
        planned = safe_int(data.get("planned_repeats"), 5)
        if planned is None or planned <= 0:
            raise ValueError("计划重复次数必须大于 0")
        priority = str(data.get("priority", "P1"))
        if priority not in {"P0", "P1", "P2"}:
            priority = "P1"
        board_id = data.get("board_id") or None
        board = None
        if board_id:
            board = self.db.query_one("SELECT * FROM boards WHERE id=?", (board_id,))
            if not board:
                raise ValueError("所选测试板不存在")
        distance = safe_float(data.get("distance_m"))
        if mode == "single":
            if distance is None or distance <= 0:
                raise ValueError("单异常实验必须输入大于 0 的真实距离")
            if not board:
                raise ValueError("单异常实验必须选择测试板")
            if board["board_type"] == "normal":
                mode = "normal"
        elif mode == "normal":
            if board and board["board_type"] != "normal":
                raise ValueError("正常参考模式只能选择 Normal 类型测试板，或留空")
            if distance is not None and distance <= 0:
                raise ValueError("距离必须大于 0 或留空")
        elif mode == "multi":
            expected = data.get("expected_anomalies") or []
            if len(expected) < 1:
                raise ValueError("多异常实验至少需要一个真实异常")
            for anomaly in expected:
                if safe_float(anomaly.get("true_distance_m")) is None:
                    raise ValueError("每个真实异常都必须有有效距离")
        status = str(data.get("status", "not_started"))
        if status not in {"not_started", "in_progress", "completed", "skipped", "failed"}:
            status = "not_started"
        expected_polarity = str(data.get("expected_polarity") or "none")
        nominal_gamma = safe_float(data.get("nominal_gamma"))
        if mode == "normal":
            expected_polarity = "none"
            nominal_gamma = 0.0
            distance = distance
        elif board:
            gamma = calculate_gamma(
                board["board_type"],
                nominal_ohm=board.get("nominal_ohm"),
                measured_ohm=None,
                z0=board.get("z0") or 50.0,
                gamma_override=board.get("gamma_override"),
            )
            expected_polarity = gamma["polarity"]
            nominal_gamma = gamma["gamma_nominal"]
        return {
            "category_id": category_id,
            "batch_id": batch_id,
            "mode": mode,
            "planned_repeats": planned,
            "priority": priority,
            "board_id": board_id,
            "board": board,
            "distance_m": distance,
            "expected_polarity": expected_polarity,
            "nominal_gamma": nominal_gamma,
            "status": status,
            "tolerance_m": safe_float(data.get("tolerance_m")),
        }

    def create(self, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        validated = self._validate_common(data)
        category = self.db.query_one(
            "SELECT * FROM experiment_categories WHERE id=?", (validated["category_id"],)
        )
        code = str(data.get("code", "")).strip() or self.next_code(category["code"])
        if self.get_by_code(code):
            raise ValueError(f"实验编号已存在：{code}")
        board = validated["board"]
        name = str(data.get("name", "")).strip() or self._default_name(
            {**data, "mode": validated["mode"], "distance_m": validated["distance_m"]}, board
        )
        expected = data.get("expected_anomalies") or []
        if validated["mode"] == "multi":
            normalized_expected = []
            for index, anomaly in enumerate(expected, start=1):
                normalized_expected.append(self._normalize_expected(anomaly, index))
        elif validated["mode"] == "single":
            normalized_expected = [
                {
                    "anomaly_index": 1,
                    "true_distance_m": validated["distance_m"],
                    "board_id": validated["board_id"],
                    "board_code": board["code"] if board else "",
                    "board_name": board["name"] if board else "",
                    "expected_polarity": validated["expected_polarity"],
                    "tolerance_m": validated["tolerance_m"],
                    "notes": "",
                }
            ]
        else:
            normalized_expected = []
        sort_order = safe_int(data.get("sort_order"))
        if sort_order is None:
            sort_order = int(self.db.scalar("SELECT COALESCE(MAX(sort_order),0)+1 FROM experiment_configs", default=1))
        config_id = new_id("EXP")
        timestamp = now_iso()
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO experiment_configs
                (id,code,name,category_id,batch_id,priority,mode,distance_m,distance_expr,near_expr,far_expr,
                 board_id,expected_polarity,nominal_gamma,planned_repeats,tolerance_m,reference_id,cable_config_id,
                 reference_label,status,sort_order,is_multi,expected_anomalies_json,notes,source,source_row,
                 source_payload,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    config_id, code, name, validated["category_id"], validated["batch_id"],
                    validated["priority"], validated["mode"], validated["distance_m"],
                    str(data.get("distance_expr", "") or ""), str(data.get("near_expr", "") or ""),
                    str(data.get("far_expr", "") or ""), validated["board_id"],
                    validated["expected_polarity"], validated["nominal_gamma"], validated["planned_repeats"],
                    validated["tolerance_m"], data.get("reference_id") or None,
                    data.get("cable_config_id") or None, str(data.get("reference_label", "") or ""),
                    validated["status"], sort_order, 1 if validated["mode"] == "multi" else 0,
                    json_dumps(normalized_expected), str(data.get("notes", "") or ""),
                    str(data.get("source", "manual") or "manual"), data.get("source_row"),
                    str(data.get("source_payload", "") or ""), timestamp, timestamp,
                ),
            )
            self.db.audit(
                conn, action="create", entity_type="experiment_config", entity_id=config_id,
                after={"code": code, "name": name, "mode": validated["mode"],
                       "distance_m": validated["distance_m"], "planned_repeats": validated["planned_repeats"]},
                actor=actor, note="新增实验配置",
            )
        return self.get(config_id) or {}

    def _normalize_expected(self, anomaly: dict[str, Any], index: int) -> dict[str, Any]:
        distance = safe_float(anomaly.get("true_distance_m"))
        if distance is None:
            raise ValueError("真实异常距离无效")
        board_id = anomaly.get("board_id") or None
        board = self.db.query_one("SELECT * FROM boards WHERE id=?", (board_id,)) if board_id else None
        polarity = str(anomaly.get("expected_polarity") or (board["polarity"] if board else "none"))
        if polarity not in {"positive", "negative", "none", "unknown"}:
            polarity = "none"
        return {
            "anomaly_index": index,
            "true_distance_m": distance,
            "board_id": board_id,
            "board_code": board["code"] if board else str(anomaly.get("board_code", "") or ""),
            "board_name": board["name"] if board else str(anomaly.get("board_name", "") or ""),
            "expected_polarity": polarity,
            "tolerance_m": safe_float(anomaly.get("tolerance_m")),
            "notes": str(anomaly.get("notes", "") or ""),
        }

    def update(self, config_id: str, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        before = self.get(config_id)
        if not before:
            raise ValueError("实验配置不存在")
        validated = self._validate_common(data)
        has_trials = self.db.scalar(
            "SELECT COUNT(*) FROM trials WHERE config_id=?", (config_id,), 0
        )
        if has_trials:
            locked_changes = []
            if validated["mode"] != before["mode"]:
                locked_changes.append("模式")
            if (validated["distance_m"] or 0) != (before["distance_m"] or 0):
                locked_changes.append("真实距离")
            if validated["board_id"] != before["board_id"]:
                locked_changes.append("测试板")
            if locked_changes:
                raise ValueError(
                    "已有测量记录，不能修改" + "、".join(locked_changes) +
                    "。请复制配置创建新的实验，或先归档原数据。"
                )
        code = str(data.get("code", "")).strip() or before["code"]
        duplicate = self.get_by_code(code)
        if duplicate and duplicate["id"] != config_id:
            raise ValueError("实验编号已存在")
        board = validated["board"]
        name = str(data.get("name", "")).strip() or before["name"]
        if validated["mode"] == "multi":
            expected = data.get("expected_anomalies", json_loads(before.get("expected_anomalies_json"), []))
            normalized_expected = [
                self._normalize_expected(anomaly, index)
                for index, anomaly in enumerate(expected, start=1)
            ]
        elif validated["mode"] == "single":
            normalized_expected = [
                {
                    "anomaly_index": 1,
                    "true_distance_m": validated["distance_m"],
                    "board_id": validated["board_id"],
                    "board_code": board["code"] if board else "",
                    "board_name": board["name"] if board else "",
                    "expected_polarity": validated["expected_polarity"],
                    "tolerance_m": validated["tolerance_m"],
                    "notes": "",
                }
            ]
        else:
            normalized_expected = []
        if has_trials and validated["mode"] == "multi":
            old_expected = json_loads(before.get("expected_anomalies_json"), [])
            old_projection = sorted(
                (
                    round(float(item.get("true_distance_m") or 0), 6),
                    item.get("board_id"),
                    item.get("expected_polarity"),
                )
                for item in old_expected
            )
            new_projection = sorted(
                (
                    round(float(item.get("true_distance_m") or 0), 6),
                    item.get("board_id"),
                    item.get("expected_polarity"),
                )
                for item in normalized_expected
            )
            if old_projection != new_projection:
                raise ValueError("该多异常实验已有测量记录，不能修改真实异常定义")
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE experiment_configs SET code=?,name=?,category_id=?,batch_id=?,priority=?,mode=?,
                distance_m=?,distance_expr=?,near_expr=?,far_expr=?,board_id=?,expected_polarity=?,
                nominal_gamma=?,planned_repeats=?,tolerance_m=?,reference_id=?,cable_config_id=?,
                reference_label=?,status=?,sort_order=?,is_multi=?,expected_anomalies_json=?,notes=?,
                updated_at=? WHERE id=?""",
                (
                    code, name, validated["category_id"], validated["batch_id"], validated["priority"],
                    validated["mode"], validated["distance_m"], str(data.get("distance_expr", "") or ""),
                    str(data.get("near_expr", "") or ""), str(data.get("far_expr", "") or ""),
                    validated["board_id"], validated["expected_polarity"], validated["nominal_gamma"],
                    validated["planned_repeats"], validated["tolerance_m"], data.get("reference_id") or None,
                    data.get("cable_config_id") or None, str(data.get("reference_label", "") or ""),
                    validated["status"], int(data.get("sort_order") or before["sort_order"]),
                    1 if validated["mode"] == "multi" else 0, json_dumps(normalized_expected),
                    str(data.get("notes", "") or ""), now_iso(), config_id,
                ),
            )
            self.db.audit(
                conn, action="update", entity_type="experiment_config", entity_id=config_id,
                before=before, after={"code": code, "name": name, "priority": validated["priority"],
                                     "planned_repeats": validated["planned_repeats"],
                                     "status": validated["status"], "expected_anomalies": normalized_expected},
                actor=actor, note="编辑实验配置",
            )
        # 若运行已建立但尚无试次，同步运行快照中的真实异常定义。
        run = self.db.query_one("SELECT id FROM experiment_runs WHERE config_id=?", (config_id,))
        if run:
            count = self.db.scalar("SELECT COUNT(*) FROM trials WHERE run_id=?", (run["id"],), 0)
            if not count:
                self._replace_run_expected(run["id"], validated, normalized_expected)
        return self.get(config_id) or {}

    def _replace_run_expected(self, run_id: str, validated: dict[str, Any], expected: list[dict[str, Any]]) -> None:
        from ..utils import new_id

        timestamp = now_iso()
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM expected_anomalies WHERE run_id=?", (run_id,))
            if validated["mode"] == "multi":
                for index, anomaly in enumerate(expected, start=1):
                    conn.execute(
                        """INSERT INTO expected_anomalies
                        (id,run_id,anomaly_index,board_id,true_distance_m,expected_polarity,tolerance_m,notes,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?)""",
                        (
                            new_id("EA"), run_id, index, anomaly.get("board_id"),
                            float(anomaly["true_distance_m"]), anomaly.get("expected_polarity") or "none",
                            anomaly.get("tolerance_m"), str(anomaly.get("notes", "") or ""), timestamp,
                        ),
                    )
            elif validated["mode"] == "single" and validated["distance_m"] is not None:
                conn.execute(
                    """INSERT INTO expected_anomalies
                    (id,run_id,anomaly_index,board_id,true_distance_m,expected_polarity,tolerance_m,notes,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?)""",
                    (
                        new_id("EA"), run_id, 1, validated.get("board_id"),
                        float(validated["distance_m"]), validated.get("expected_polarity") or "none",
                        validated.get("tolerance_m"), "", timestamp,
                    ),
                )
            self.db.audit(
                conn, action="sync_expected", entity_type="experiment_run", entity_id=run_id,
                after={"expected_count": len(expected) if validated["mode"] == "multi" else (1 if validated["mode"] == "single" else 0)},
                note="配置变更后同步未测试运行的异常定义",
            )

    def duplicate(self, config_id: str, actor: str = "") -> dict[str, Any]:
        source = self.get(config_id)
        if not source:
            raise ValueError("实验配置不存在")
        data = dict(source)
        data["code"] = self.next_code(source["category_code"])
        data["name"] = source["name"] + "（副本）"
        data["status"] = "not_started"
        data["expected_anomalies"] = json_loads(source.get("expected_anomalies_json"), [])
        data["source"] = "manual"
        data["source_row"] = None
        data["source_payload"] = ""
        return self.create(data, actor=actor)

    def delete(self, config_id: str, actor: str = "") -> None:
        config_row = self.get(config_id)
        if not config_row:
            return
        trial_count = self.db.scalar("SELECT COUNT(*) FROM trials WHERE config_id=?", (config_id,), 0)
        if trial_count:
            raise ValueError("该实验已有测量记录，不能删除。为保护原始数据，请保留记录。")
        run = self.db.query_one("SELECT * FROM experiment_runs WHERE config_id=?", (config_id,))
        with self.db.transaction() as conn:
            if run:
                conn.execute("DELETE FROM experiment_runs WHERE id=?", (run["id"],))
            conn.execute("DELETE FROM experiment_configs WHERE id=?", (config_id,))
            self.db.audit(
                conn, action="delete", entity_type="experiment_config", entity_id=config_id,
                before=config_row, actor=actor, note="删除未测试实验配置",
            )

    def move(self, config_id: str, delta: int, actor: str = "") -> None:
        target = self.get(config_id)
        if not target:
            raise ValueError("实验配置不存在")
        ordered = self.list(batch_id=target["batch_id"])
        try:
            index = next(i for i, item in enumerate(ordered) if item["id"] == config_id)
        except StopIteration:
            return
        new_index = index + (1 if delta > 0 else -1)
        if new_index < 0 or new_index >= len(ordered):
            return
        other = ordered[new_index]
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE experiment_configs SET sort_order=?,updated_at=? WHERE id=?",
                (other["sort_order"], now_iso(), target["id"]),
            )
            conn.execute(
                "UPDATE experiment_configs SET sort_order=?,updated_at=? WHERE id=?",
                (target["sort_order"], now_iso(), other["id"]),
            )
            self.db.audit(
                conn, action="reorder", entity_type="experiment_config", entity_id=config_id,
                before={"sort_order": target["sort_order"]}, after={"sort_order": other["sort_order"]},
                actor=actor, note="调整实验执行顺序",
            )

    def set_planned_repeats(self, config_id: str, repeats: int, actor: str = "") -> None:
        if repeats <= 0:
            raise ValueError("计划重复次数必须大于 0")
        before = self.get(config_id)
        if not before:
            raise ValueError("实验配置不存在")
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE experiment_configs SET planned_repeats=?,updated_at=? WHERE id=?",
                (int(repeats), now_iso(), config_id),
            )
            self.db.audit(
                conn, action="update", entity_type="experiment_config", entity_id=config_id,
                before={"planned_repeats": before["planned_repeats"]},
                after={"planned_repeats": int(repeats)}, actor=actor,
                note="调整计划重复次数（保留已录入数据）",
            )
        self.refresh_status(config_id)

    def set_status(self, config_id: str, status: str, actor: str = "") -> None:
        if status not in {"not_started", "in_progress", "completed", "skipped", "failed"}:
            raise ValueError("实验状态不合法")
        before = self.get(config_id)
        if not before:
            raise ValueError("实验配置不存在")
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE experiment_configs SET status=?,updated_at=? WHERE id=?",
                (status, now_iso(), config_id),
            )
            self.db.audit(
                conn, action="status", entity_type="experiment_config", entity_id=config_id,
                before={"status": before["status"]}, after={"status": status},
                actor=actor, note="修改实验状态",
            )
        if status == "completed":
            run = self.db.query_one("SELECT id FROM experiment_runs WHERE config_id=?", (config_id,))
            if run:
                with self.db.transaction() as conn:
                    conn.execute(
                        "UPDATE experiment_runs SET status='completed',updated_at=? WHERE id=?",
                        (now_iso(), run["id"]),
                    )

    def bulk_set(self, ids: Iterable[str], field: str, value: str, actor: str = "") -> int:
        ids = list(ids)
        if not ids:
            return 0
        if field == "priority":
            if value not in {"P0", "P1", "P2"}:
                raise ValueError("优先级不合法")
        elif field == "status":
            if value not in {"not_started", "in_progress", "completed", "skipped", "failed"}:
                raise ValueError("状态不合法")
        else:
            raise ValueError("不支持的批量字段")
        count = 0
        with self.db.transaction() as conn:
            for config_id in ids:
                before = conn.execute(
                    "SELECT status,priority FROM experiment_configs WHERE id=?", (config_id,)
                ).fetchone()
                if not before:
                    continue
                conn.execute(
                    f"UPDATE experiment_configs SET {field}=?,updated_at=? WHERE id=?",
                    (value, now_iso(), config_id),
                )
                self.db.audit(
                    conn, action="bulk_update", entity_type="experiment_config", entity_id=config_id,
                    before={"status": before["status"], "priority": before["priority"]},
                    after={field: value}, actor=actor, note="批量修改实验配置",
                )
                count += 1
        return count

    def refresh_status(self, config_id: str) -> None:
        row = self.db.query_one("SELECT status,planned_repeats FROM experiment_configs WHERE id=?", (config_id,))
        if not row or row["status"] in {"completed", "skipped", "failed"}:
            return
        count = int(
            self.db.scalar("SELECT COUNT(*) FROM trials WHERE config_id=?", (config_id,), 0) or 0
        )
        status = "not_started" if count == 0 else "in_progress"
        if count >= int(row["planned_repeats"] or 0):
            status = "completed"
        if status != row["status"]:
            self.db.execute(
                "UPDATE experiment_configs SET status=?,updated_at=? WHERE id=?",
                (status, now_iso(), config_id),
            )

    # ------------------------------------------------------------- 批量生成
    def generate_matrix(
        self,
        *,
        category_id: str,
        batch_id: str,
        board_ids: list[str],
        distances: list[float],
        planned_repeats: int,
        priority: str = "P1",
        tolerance_m: float | None = None,
        reference_id: str | None = None,
        cable_config_id: str | None = None,
        notes: str = "",
        actor: str = "",
    ) -> list[dict[str, Any]]:
        if not board_ids:
            raise ValueError("请至少选择一块测试板")
        if not distances:
            raise ValueError("请至少输入一个测试距离")
        if planned_repeats <= 0:
            raise ValueError("重复次数必须大于 0")
        created = []
        for board_id in board_ids:
            board = self.db.query_one("SELECT * FROM boards WHERE id=?", (board_id,))
            if not board:
                continue
            mode = "normal" if board["board_type"] == "normal" else "single"
            for distance in distances:
                config = self.create(
                    {
                        "category_id": category_id,
                        "batch_id": batch_id,
                        "board_id": board_id,
                        "distance_m": float(distance),
                        "planned_repeats": int(planned_repeats),
                        "priority": priority,
                        "mode": mode,
                        "tolerance_m": tolerance_m,
                        "reference_id": reference_id,
                        "cable_config_id": cable_config_id,
                        "notes": notes,
                    },
                    actor=actor,
                )
                created.append(config)
        return created

    def planned_trials(self, batch_id: str | None = None) -> int:
        sql = "SELECT COALESCE(SUM(planned_repeats),0) FROM experiment_configs"
        params: tuple = ()
        if batch_id:
            sql += " WHERE batch_id=?"
            params = (batch_id,)
        return int(self.db.scalar(sql, params, 0) or 0)

    def actual_trials(self, batch_id: str | None = None) -> int:
        sql = "SELECT COUNT(*) FROM trials t JOIN experiment_configs ec ON ec.id=t.config_id"
        params: tuple = ()
        if batch_id:
            sql += " WHERE ec.batch_id=?"
            params = (batch_id,)
        return int(self.db.scalar(sql, params, 0) or 0)
