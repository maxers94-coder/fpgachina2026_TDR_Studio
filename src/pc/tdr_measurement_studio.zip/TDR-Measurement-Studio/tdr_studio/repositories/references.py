"""健康参考管理。"""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from .. import config
from ..database import Database
from ..utils import clean_filename, new_id, now_iso


class ReferenceRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def list(self, search: str = "", valid_only: bool = False) -> list[dict[str, Any]]:
        sql = """SELECT r.*, cc.code AS cable_config_code, cc.name AS cable_config_name,
                 (SELECT COUNT(*) FROM experiment_configs e WHERE e.reference_id=r.id) AS config_count
                 FROM health_references r
                 LEFT JOIN cable_configs cc ON cc.id=r.config_id WHERE 1=1"""
        params: list[Any] = []
        if search:
            sql += " AND (r.ref_no LIKE ? OR r.notes LIKE ? OR r.firmware_version LIKE ?)"
            like = f"%{search}%"
            params.extend([like, like, like])
        if valid_only:
            sql += " AND r.is_valid=1"
        sql += " ORDER BY r.created_at_ref DESC, r.ref_no COLLATE NOCASE"
        return self.db.query(sql, tuple(params))

    def get(self, ref_id: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM health_references WHERE id=?", (ref_id,))

    def get_by_no(self, ref_no: str) -> dict[str, Any] | None:
        return self.db.query_one(
            "SELECT * FROM health_references WHERE ref_no=? COLLATE NOCASE", (ref_no.strip(),)
        )

    def create(self, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        ref_no = str(data.get("ref_no", "")).strip()
        if not ref_no:
            raise ValueError("参考编号不能为空")
        if self.get_by_no(ref_no):
            raise ValueError("参考编号已存在")
        ref_id = new_id("REF")
        timestamp = now_iso()
        created_at_ref = str(data.get("created_at_ref") or timestamp)
        frontend = str(data.get("frontend") or "resistive_divider")
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO health_references
                (id,ref_no,created_at_ref,config_id,frontend,firmware_version,notes,file_path,is_valid,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    ref_id, ref_no, created_at_ref, data.get("config_id"), frontend,
                    str(data.get("firmware_version", "") or ""), str(data.get("notes", "") or ""),
                    str(data.get("file_path", "") or ""), 1 if data.get("is_valid", True) else 0,
                    timestamp, timestamp,
                ),
            )
            self.db.audit(
                conn, action="create", entity_type="reference", entity_id=ref_id,
                after={"ref_no": ref_no, **data}, actor=actor, note="新建健康参考",
            )
        return self.get(ref_id) or {}

    def update(self, ref_id: str, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        before = self.get(ref_id)
        if not before:
            raise ValueError("健康参考不存在")
        ref_no = str(data.get("ref_no", "")).strip()
        if not ref_no:
            raise ValueError("参考编号不能为空")
        duplicate = self.get_by_no(ref_no)
        if duplicate and duplicate["id"] != ref_id:
            raise ValueError("参考编号已存在")
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE health_references SET ref_no=?,created_at_ref=?,config_id=?,frontend=?,
                firmware_version=?,notes=?,file_path=?,is_valid=?,updated_at=? WHERE id=?""",
                (
                    ref_no, str(data.get("created_at_ref") or before["created_at_ref"]),
                    data.get("config_id"), str(data.get("frontend") or "resistive_divider"),
                    str(data.get("firmware_version", "") or ""), str(data.get("notes", "") or ""),
                    str(data.get("file_path", "") or ""), 1 if data.get("is_valid", True) else 0,
                    now_iso(), ref_id,
                ),
            )
            self.db.audit(
                conn, action="update", entity_type="reference", entity_id=ref_id,
                before=before, after=data, actor=actor, note="编辑健康参考",
            )
        return self.get(ref_id) or {}

    def set_valid(self, ref_id: str, valid: bool, actor: str = "") -> None:
        before = self.get(ref_id)
        if not before:
            raise ValueError("健康参考不存在")
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE health_references SET is_valid=?,updated_at=? WHERE id=?",
                (1 if valid else 0, now_iso(), ref_id),
            )
            self.db.audit(
                conn, action="validity", entity_type="reference", entity_id=ref_id,
                before={"is_valid": before["is_valid"]}, after={"is_valid": valid},
                actor=actor, note="修改健康参考有效性",
            )

    def delete(self, ref_id: str, actor: str = "") -> None:
        before = self.get(ref_id)
        if not before:
            return
        used = self.db.scalar("SELECT COUNT(*) FROM experiment_configs WHERE reference_id=?", (ref_id,), 0)
        used_runs = self.db.scalar("SELECT COUNT(*) FROM experiment_runs WHERE reference_id=?", (ref_id,), 0)
        if used or used_runs:
            raise ValueError("参考已被实验引用，请改为“无效”，不能删除")
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM health_references WHERE id=?", (ref_id,))
            self.db.audit(
                conn, action="delete", entity_type="reference", entity_id=ref_id,
                before=before, actor=actor, note="删除健康参考",
            )

    def save_file(self, ref_no: str, source_path: str) -> str:
        source = Path(source_path)
        if not source.exists():
            raise ValueError("参考数据文件不存在")
        target_dir = config.ATTACHMENTS_DIR / "references"
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / f"{clean_filename(ref_no)}_{new_id()[:8]}{source.suffix.lower()}"
        shutil.copy2(source, target)
        return str(target.relative_to(config.DATA_DIR)).replace("\\", "/")

    def condition_issues(
        self,
        reference: dict[str, Any] | None,
        *,
        cable_config_id: str | None,
        frontend: str | None,
        firmware_version: str | None,
    ) -> list[str]:
        if not reference:
            return []
        issues: list[str] = []
        if reference.get("is_valid") == 0:
            issues.append("所选健康参考已标记为无效")
        if reference.get("config_id") and cable_config_id and reference["config_id"] != cable_config_id:
            issues.append("线缆组合与健康参考不一致")
        if reference.get("frontend") and frontend and reference["frontend"] != frontend:
            issues.append("模拟前端与健康参考不一致")
        if (
            reference.get("firmware_version")
            and firmware_version
            and reference["firmware_version"].strip() != str(firmware_version).strip()
        ):
            issues.append("固件版本与健康参考不一致")
        return issues
