"""实验类别与实验批次。"""
from __future__ import annotations

from typing import Any

from ..database import Database
from ..utils import new_id, now_iso


class CategoryRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def list(self) -> list[dict[str, Any]]:
        return self.db.query(
            """SELECT c.*,
              (SELECT COUNT(*) FROM experiment_configs e WHERE e.category_id=c.id) AS config_count,
              (SELECT COALESCE(SUM(e.planned_repeats),0) FROM experiment_configs e WHERE e.category_id=c.id) AS planned_trials,
              (SELECT COUNT(*) FROM trials t JOIN experiment_configs e ON e.id=t.config_id WHERE e.category_id=c.id) AS trial_count
            FROM experiment_categories c ORDER BY c.sort_order, c.code"""
        )

    def get(self, category_id: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM experiment_categories WHERE id=?", (category_id,))

    def get_by_code(self, code: str) -> dict[str, Any] | None:
        return self.db.query_one(
            "SELECT * FROM experiment_categories WHERE code=? COLLATE NOCASE", (code.strip(),)
        )

    def create(self, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        code = str(data.get("code", "")).strip()
        name = str(data.get("name", "")).strip()
        if not code or not name:
            raise ValueError("类别编号和名称不能为空")
        if self.get_by_code(code):
            raise ValueError("类别编号已存在")
        category_id = new_id("CAT")
        timestamp = now_iso()
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO experiment_categories
                (id,code,name,description,is_builtin,sort_order,created_at,updated_at)
                VALUES(?,?,?,?,0,?,?,?)""",
                (
                    category_id, code, name, str(data.get("description", "") or ""),
                    int(data.get("sort_order") or 99), timestamp, timestamp,
                ),
            )
            self.db.audit(
                conn, action="create", entity_type="category", entity_id=category_id,
                after={"code": code, "name": name}, actor=actor, note="新增实验类别",
            )
        return self.get(category_id) or {}

    def update(self, category_id: str, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        before = self.get(category_id)
        if not before:
            raise ValueError("实验类别不存在")
        code = str(data.get("code", "")).strip()
        name = str(data.get("name", "")).strip()
        if not code or not name:
            raise ValueError("类别编号和名称不能为空")
        duplicate = self.get_by_code(code)
        if duplicate and duplicate["id"] != category_id:
            raise ValueError("类别编号已存在")
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE experiment_categories SET code=?,name=?,description=?,sort_order=?,updated_at=?
                WHERE id=?""",
                (
                    code, name, str(data.get("description", "") or ""),
                    int(data.get("sort_order") or before["sort_order"]), now_iso(), category_id,
                ),
            )
            self.db.audit(
                conn, action="update", entity_type="category", entity_id=category_id,
                before=before, after=data, actor=actor, note="编辑实验类别",
            )
        return self.get(category_id) or {}

    def duplicate(self, category_id: str, actor: str = "") -> dict[str, Any]:
        source = self.get(category_id)
        if not source:
            raise ValueError("实验类别不存在")
        base = source["code"] + "-COPY"
        code = base
        index = 2
        while self.get_by_code(code):
            code = f"{base}{index}"
            index += 1
        return self.create(
            {
                "code": code,
                "name": source["name"] + "（副本）",
                "description": source.get("description", ""),
                "sort_order": int(source.get("sort_order") or 99) + 1,
            },
            actor=actor,
        )

    def delete(self, category_id: str, actor: str = "") -> None:
        before = self.get(category_id)
        if not before:
            return
        used = self.db.scalar(
            "SELECT COUNT(*) FROM experiment_configs WHERE category_id=?", (category_id,), 0
        )
        if used:
            raise ValueError("该类别下仍有实验配置，不能删除；可先移动或删除配置")
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM experiment_categories WHERE id=?", (category_id,))
            self.db.audit(
                conn, action="delete", entity_type="category", entity_id=category_id,
                before=before, actor=actor, note="删除实验类别",
            )


class BatchRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def list(self, include_inactive: bool = True) -> list[dict[str, Any]]:
        sql = """SELECT b.*,
              (SELECT COUNT(*) FROM experiment_configs e WHERE e.batch_id=b.id) AS config_count,
              (SELECT COUNT(*) FROM trials t JOIN experiment_configs e ON e.id=t.config_id WHERE e.batch_id=b.id) AS trial_count
            FROM batches b"""
        if not include_inactive:
            sql += " WHERE b.is_active=1"
        sql += " ORDER BY b.is_active DESC, b.created_at"
        return self.db.query(sql)

    def get(self, batch_id: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM batches WHERE id=?", (batch_id,))

    def get_active(self) -> dict[str, Any] | None:
        row = self.db.query_one("SELECT * FROM batches WHERE is_active=1 ORDER BY created_at LIMIT 1")
        if row:
            return row
        return self.db.query_one("SELECT * FROM batches ORDER BY created_at LIMIT 1")

    def create(self, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        code = str(data.get("code", "")).strip()
        name = str(data.get("name", "")).strip()
        if not code or not name:
            raise ValueError("批次代号和名称不能为空")
        if self.db.query_one("SELECT id FROM batches WHERE code=? COLLATE NOCASE", (code,)):
            raise ValueError("批次代号已存在")
        batch_id = new_id("BATCH")
        timestamp = now_iso()
        active = 1 if data.get("is_active") else 0
        with self.db.transaction() as conn:
            if active:
                conn.execute("UPDATE batches SET is_active=0")
            conn.execute(
                """INSERT INTO batches
                (id,code,name,firmware_version,frontend,description,is_active,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    batch_id, code, name, str(data.get("firmware_version", "") or ""),
                    str(data.get("frontend") or "resistive_divider"),
                    str(data.get("description", "") or ""), active, timestamp, timestamp,
                ),
            )
            self.db.audit(
                conn, action="create", entity_type="batch", entity_id=batch_id,
                after={"code": code, "name": name}, actor=actor, note="新增实验批次",
            )
        return self.get(batch_id) or {}

    def update(self, batch_id: str, data: dict[str, Any], actor: str = "") -> dict[str, Any]:
        before = self.get(batch_id)
        if not before:
            raise ValueError("实验批次不存在")
        code = str(data.get("code", "")).strip()
        name = str(data.get("name", "")).strip()
        if not code or not name:
            raise ValueError("批次代号和名称不能为空")
        duplicate = self.db.query_one(
            "SELECT id FROM batches WHERE code=? COLLATE NOCASE", (code,)
        )
        if duplicate and duplicate["id"] != batch_id:
            raise ValueError("批次代号已存在")
        with self.db.transaction() as conn:
            conn.execute(
                """UPDATE batches SET code=?,name=?,firmware_version=?,frontend=?,description=?,
                is_active=?,updated_at=? WHERE id=?""",
                (
                    code, name, str(data.get("firmware_version", "") or ""),
                    str(data.get("frontend") or "resistive_divider"),
                    str(data.get("description", "") or ""), 1 if data.get("is_active") else 0,
                    now_iso(), batch_id,
                ),
            )
            self.db.audit(
                conn, action="update", entity_type="batch", entity_id=batch_id,
                before=before, after=data, actor=actor, note="编辑实验批次",
            )
        return self.get(batch_id) or {}

    def set_active(self, batch_id: str, actor: str = "") -> None:
        before = self.get(batch_id)
        if not before:
            raise ValueError("实验批次不存在")
        with self.db.transaction() as conn:
            conn.execute("UPDATE batches SET is_active=0")
            conn.execute("UPDATE batches SET is_active=1 WHERE id=?", (batch_id,))
            self.db.audit(
                conn, action="activate", entity_type="batch", entity_id=batch_id,
                before=before, after={"is_active": 1}, actor=actor, note="设为当前批次",
            )

    def delete(self, batch_id: str, actor: str = "") -> None:
        before = self.get(batch_id)
        if not before:
            return
        used = self.db.scalar("SELECT COUNT(*) FROM experiment_configs WHERE batch_id=?", (batch_id,), 0)
        if used:
            raise ValueError("批次下仍有实验配置，不能删除")
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM batches WHERE id=?", (batch_id,))
            self.db.audit(
                conn, action="delete", entity_type="batch", entity_id=batch_id,
                before=before, actor=actor, note="删除实验批次",
            )
