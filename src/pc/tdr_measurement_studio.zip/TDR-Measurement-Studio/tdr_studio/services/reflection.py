"""测试板理论反射系数计算。

公式基于理想集总电阻模型，结果只能标记为“理论值”，不得表述为仪器实测值。
串联：Γ = Rs / (2*Z0 + Rs)
并联：Γ = -Z0 / (2*Rp + Z0)
正常：0；理想开路：+1；理想短路：-1。
"""
from __future__ import annotations

import math
from typing import Any

from ..config import BOARD_TYPE_LABELS


class ReflectionError(ValueError):
    pass


def polarity_from_gamma(gamma: float | None) -> str:
    if gamma is None:
        return "none"
    if gamma > 1e-9:
        return "positive"
    if gamma < -1e-9:
        return "negative"
    return "none"


def reflection_strength(gamma: float | None) -> tuple[str, str]:
    """返回 (等级, 显示文本)。等级用于统计分组。"""
    if gamma is None:
        return ("none", "未计算")
    value = abs(gamma)
    if value <= 1e-9:
        return ("none", "无反射")
    if value < 0.03:
        return ("weak", "弱反射")
    if value < 0.10:
        return ("medium", "中等反射")
    return ("strong", "强反射")


def calculate_gamma(
    board_type: str,
    *,
    nominal_ohm: float | None = None,
    measured_ohm: float | None = None,
    z0: float = 50.0,
    gamma_override: float | None = None,
) -> dict[str, Any]:
    """计算并返回标称/实测电阻对应的理论反射系数。"""
    if board_type not in BOARD_TYPE_LABELS:
        raise ReflectionError(f"未知测试板类型：{board_type}")
    if z0 is None or z0 <= 0:
        raise ReflectionError("特性阻抗 Z0 必须大于 0")
    if board_type == "custom":
        if gamma_override is None:
            raise ReflectionError("自定义测试板必须提供反射系数")
        if not -1.0 <= gamma_override <= 1.0:
            raise ReflectionError("自定义反射系数必须在 -1 到 +1 之间")
        nominal = float(gamma_override)
        measured = float(gamma_override)
    elif board_type == "normal":
        nominal = 0.0
        measured = 0.0
    elif board_type == "open":
        nominal = 1.0
        measured = 1.0
    elif board_type == "short":
        nominal = -1.0
        measured = -1.0
    elif board_type == "series":
        if not nominal_ohm or nominal_ohm <= 0:
            raise ReflectionError("串联测试板必须输入大于 0 的标称阻值")
        nominal = nominal_ohm / (2.0 * z0 + nominal_ohm)
        if measured_ohm is not None:
            if measured_ohm <= 0:
                raise ReflectionError("实测阻值必须大于 0")
            measured = measured_ohm / (2.0 * z0 + measured_ohm)
        else:
            measured = None
    elif board_type == "shunt":
        if not nominal_ohm or nominal_ohm <= 0:
            raise ReflectionError("并联测试板必须输入大于 0 的标称阻值")
        nominal = -z0 / (2.0 * nominal_ohm + z0)
        if measured_ohm is not None:
            if measured_ohm <= 0:
                raise ReflectionError("实测阻值必须大于 0")
            measured = -z0 / (2.0 * measured_ohm + z0)
        else:
            measured = None
    else:  # pragma: no cover - 类型约束由 UI 与数据库双重检查
        raise ReflectionError(f"不支持的类型：{board_type}")

    if nominal is not None and (math.isnan(nominal) or math.isinf(nominal)):
        raise ReflectionError("反射系数计算结果无效")
    if measured is not None and (math.isnan(measured) or math.isinf(measured)):
        raise ReflectionError("实测反射系数计算结果无效")
    strength_code, strength_text = reflection_strength(nominal)
    return {
        "gamma_nominal": float(nominal),
        "gamma_measured": float(measured) if measured is not None else None,
        "polarity": polarity_from_gamma(nominal),
        "strength": strength_code,
        "strength_text": strength_text,
        "formula_note": _formula_note(board_type),
        "is_theoretical": True,
    }


def _formula_note(board_type: str) -> str:
    return {
        "series": "Γ = Rs / (2Z0 + Rs)，理想集总串联电阻模型",
        "shunt": "Γ = -Z0 / (2Rp + Z0)，理想集总并联电阻模型",
        "normal": "理想 50Ω 匹配，Γ = 0",
        "open": "理想开路，Γ = +1",
        "short": "理想短路，Γ = -1",
        "custom": "用户输入的自定义反射系数",
    }[board_type]


def gamma_percent(gamma: float | None, digits: int = 2) -> str:
    if gamma is None:
        return "—"
    return f"{gamma * 100:+.{digits}f}%"


def describe_board(board: dict[str, Any]) -> str:
    """生成测试板一行摘要，供界面和导出复用。"""
    type_label = BOARD_TYPE_LABELS.get(board.get("board_type", ""), board.get("board_type", ""))
    if board.get("board_type") in {"series", "shunt"}:
        ohm = board.get("nominal_ohm")
        ohm_text = f"{ohm:g}Ω" if isinstance(ohm, (int, float)) else "阻值缺失"
    elif board.get("board_type") == "custom":
        ohm_text = f"Γ={gamma_percent(board.get('gamma_nominal'))}"
    else:
        ohm_text = type_label
    return f"{board.get('code', '')}｜{board.get('name', '')}（{ohm_text}）"
