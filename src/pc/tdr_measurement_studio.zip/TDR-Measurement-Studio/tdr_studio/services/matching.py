"""多异常候选与真实异常的一对一匹配。

规则：
1. 只有距离差在容差内才允许匹配（极性不阻止匹配，但会单独记错）。
2. 每个候选最多匹配一个真实异常，每个真实异常最多匹配一个候选。
3. 优先最大化匹配数量；数量相同则优先极性正确数；再优先总距离误差最小。
4. 无法匹配的真实异常 = 漏检；无法匹配的候选 = 额外候选。
5. 若存在多个同分最优方案，标记 ambiguous 供人工复核。
"""
from __future__ import annotations

import math
from functools import lru_cache
from typing import Any

INVALID_QUALITY = {"PN?", "OVERFLOW", "拒判"}


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not math.isnan(value) and not math.isinf(value)


def match_candidates(
    expected: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
    *,
    default_tolerance_m: float = 0.6,
) -> dict[str, Any]:
    """返回匹配结果；不修改输入对象。"""
    expected = [e for e in expected if _is_number(e.get("true_distance_m"))]
    # 严重质量异常的候选不参与自动匹配，但保留为额外候选。
    usable: list[dict[str, Any]] = []
    severe: list[dict[str, Any]] = []
    for cand in candidates:
        if not _is_number(cand.get("measured_distance_m")) or cand.get("quality_flag") in INVALID_QUALITY:
            severe.append(cand)
        else:
            usable.append(cand)
    if not expected or not usable:
        return {
            "assignments": [],
            "matched_candidate_ids": set(),
            "missed_expected_ids": {e.get("id") for e in expected},
            "extra_candidate_ids": {c.get("id") for c in candidates},
            "ambiguous": False,
            "total_error": None,
            "polarity_correct": 0,
        }

    # 按真实异常编号排序，保证结果稳定。
    expected_sorted = sorted(
        expected,
        key=lambda e: (e.get("anomaly_index", 0), str(e.get("id", ""))),
    )
    n_exp = len(expected_sorted)
    n_cand = len(usable)
    if n_cand > 15:
        return _greedy_match(expected_sorted, usable, candidates, default_tolerance_m)

    edges: list[list[tuple[int, int, float]]] = []
    for exp in expected_sorted:
        tol = exp.get("tolerance_m")
        if not _is_number(tol) or tol <= 0:
            tol = default_tolerance_m
        row = []
        for idx, cand in enumerate(usable):
            error = float(cand["measured_distance_m"]) - float(exp["true_distance_m"])
            if abs(error) <= float(tol) + 1e-12:
                pol_ok = int(
                    exp.get("expected_polarity") in {"positive", "negative"}
                    and cand.get("polarity") == exp.get("expected_polarity")
                )
                row.append((idx, pol_ok, abs(error), error))
        edges.append(row)

    @lru_cache(maxsize=None)
    def dp(i: int, mask: int) -> tuple[int, int, float]:
        if i >= n_exp:
            return (0, 0, 0.0)
        best = dp(i + 1, mask)
        for idx, pol_ok, abs_err, _signed in edges[i]:
            if mask & (1 << idx):
                continue
            child = dp(i + 1, mask | (1 << idx))
            score = (child[0] + 1, child[1] + pol_ok, child[2] + abs_err)
            if _better(score, best):
                best = score
        return best

    @lru_cache(maxsize=None)
    def ways(i: int, mask: int) -> int:
        """最优方案数量（上限 2），用于歧义提示。"""
        if i >= n_exp:
            return 1
        target = dp(i, mask)
        total = 0
        if dp(i + 1, mask) == target:
            total += ways(i + 1, mask)
        for idx, pol_ok, abs_err, _signed in edges[i]:
            if mask & (1 << idx):
                continue
            child = dp(i + 1, mask | (1 << idx))
            score = (child[0] + 1, child[1] + pol_ok, child[2] + abs_err)
            if score == target:
                total += ways(i + 1, mask | (1 << idx))
            if total >= 2:
                return 2
        return total

    # 重建一个最优方案
    assignments: list[dict[str, Any]] = []
    mask = 0
    for i, exp in enumerate(expected_sorted):
        target = dp(i, mask)
        chosen = None
        # 先看不匹配是否能达到最优
        if dp(i + 1, mask) == target:
            chosen = None
        else:
            for idx, pol_ok, abs_err, signed in edges[i]:
                if mask & (1 << idx):
                    continue
                child = dp(i + 1, mask | (1 << idx))
                score = (child[0] + 1, child[1] + pol_ok, child[2] + abs_err)
                if score == target:
                    chosen = (idx, pol_ok, signed)
                    break
        if chosen is not None:
            idx, pol_ok, signed = chosen
            cand = usable[idx]
            mask |= 1 << idx
            assignments.append(
                {
                    "expected_id": exp.get("id"),
                    "candidate_id": cand.get("id"),
                    "expected_index": exp.get("anomaly_index"),
                    "candidate_index": cand.get("candidate_index"),
                    "distance_error_m": signed,
                    "abs_error_m": abs(signed),
                    "polarity_correct": bool(pol_ok),
                    "candidate": cand,
                    "expected": exp,
                }
            )
    ambiguous = ways(0, 0) > 1
    matched_candidates = {a["candidate_id"] for a in assignments}
    matched_expected = {a["expected_id"] for a in assignments}
    extra_ids = {c.get("id") for c in candidates if c.get("id") not in matched_candidates}
    missed_ids = {e.get("id") for e in expected if e.get("id") not in matched_expected}
    total_error = sum(a["abs_error_m"] for a in assignments)
    return {
        "assignments": assignments,
        "matched_candidate_ids": matched_candidates,
        "missed_expected_ids": missed_ids,
        "extra_candidate_ids": extra_ids,
        "ambiguous": ambiguous,
        "total_error": total_error,
        "polarity_correct": sum(1 for a in assignments if a["polarity_correct"]),
        "expected_count": len(expected),
        "candidate_count": len(usable),
        "severe_candidate_count": len(severe),
    }


def _better(a: tuple[int, int, float], b: tuple[int, int, float]) -> bool:
    if a[0] != b[0]:
        return a[0] > b[0]
    if a[1] != b[1]:
        return a[1] > b[1]
    return a[2] < b[2] - 1e-12


def _greedy_match(
    expected: list[dict[str, Any]],
    usable: list[dict[str, Any]],
    all_candidates: list[dict[str, Any]],
    default_tolerance_m: float,
) -> dict[str, Any]:
    """候选极多时使用确定性贪心，避免指数爆炸；UI 会提示复核。"""
    pairs = []
    for exp in expected:
        tol = exp.get("tolerance_m") or default_tolerance_m
        for cand in usable:
            error = float(cand["measured_distance_m"]) - float(exp["true_distance_m"])
            if abs(error) <= float(tol) + 1e-12:
                pol_ok = int(cand.get("polarity") == exp.get("expected_polarity"))
                pairs.append((abs(error), -pol_ok, str(exp.get("id")), str(cand.get("id")), exp, cand, error))
    pairs.sort(key=lambda x: x[:4])
    used_exp: set[str] = set()
    used_cand: set[str] = set()
    assignments = []
    for _, _, _, _, exp, cand, error in pairs:
        if exp.get("id") in used_exp or cand.get("id") in used_cand:
            continue
        used_exp.add(exp.get("id"))
        used_cand.add(cand.get("id"))
        assignments.append(
            {
                "expected_id": exp.get("id"),
                "candidate_id": cand.get("id"),
                "expected_index": exp.get("anomaly_index"),
                "candidate_index": cand.get("candidate_index"),
                "distance_error_m": error,
                "abs_error_m": abs(error),
                "polarity_correct": cand.get("polarity") == exp.get("expected_polarity"),
                "candidate": cand,
                "expected": exp,
            }
        )
    return {
        "assignments": assignments,
        "matched_candidate_ids": used_cand,
        "missed_expected_ids": {e.get("id") for e in expected if e.get("id") not in used_exp},
        "extra_candidate_ids": {c.get("id") for c in all_candidates if c.get("id") not in used_cand},
        "ambiguous": True,
        "total_error": sum(a["abs_error_m"] for a in assignments),
        "polarity_correct": sum(1 for a in assignments if a["polarity_correct"]),
        "expected_count": len(expected),
        "candidate_count": len(usable),
        "severe_candidate_count": len(all_candidates) - len(usable),
    }
