"""从导出数据生成 PNG 图表（仅使用真实记录）。"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..utils import json_dumps


def _setup_matplotlib():
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei UI", "Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "DejaVu Sans",
        ]
        plt.rcParams["axes.unicode_minus"] = False
        return plt
    except Exception:
        return None


def generate_figures(dataset: dict[str, Any], target: Path) -> list[Path]:
    target.mkdir(parents=True, exist_ok=True)
    plt = _setup_matplotlib()
    if plt is None:
        (target / "README.txt").write_text(
            "当前环境缺少 matplotlib，未生成图表。原始数据与统计 CSV/Excel 不受影响。",
            encoding="utf-8",
        )
        return []
    trials = dataset.get("trials", [])
    if not trials:
        (target / "README.txt").write_text(
            "数据集没有实测试次，因此未生成图表。未测试配置不会被绘制为实验结果。",
            encoding="utf-8",
        )
        return []
    generated: list[Path] = []
    style = {
        "axes.grid": True,
        "grid.alpha": 0.25,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.dpi": 120,
        "savefig.dpi": 180,
        "font.size": 9,
    }
    plt.rcParams.update(style)

    stats = dataset.get("statistics", {})
    board_perf = stats.get("board_performance", [])
    if board_perf:
        fig, ax = plt.subplots(figsize=(7.2, 3.8))
        labels = [b["board_code"] or "多异常" for b in board_perf]
        values = [b.get("detection_rate") for b in board_perf]
        colors = ["#0F6E6E" if v is None or v >= 0.95 else "#B42318" for v in values]
        bars = ax.bar(labels, [0 if v is None else v for v in values], color=colors, width=0.55)
        ax.set_ylim(0, 1.05)
        ax.set_ylabel("检出率")
        ax.set_title("各测试板检出率")
        for bar, value in zip(bars, values):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.02,
                    "—" if value is None else f"{value * 100:.1f}%", ha="center", fontsize=8)
        fig.tight_layout()
        path = target / "01_detection_rate_by_board.png"
        fig.savefig(path)
        plt.close(fig)
        generated.append(path)

    errors = [
        float(t["distance_error_m"])
        for t in trials
        if t.get("distance_error_m") is not None and t.get("quality_usable")
    ]
    if errors:
        fig, ax = plt.subplots(figsize=(7.2, 3.8))
        ax.hist(errors, bins=min(20, max(5, len(errors) // 3)), color="#0F6E6E", alpha=0.8, edgecolor="white")
        mean = sum(errors) / len(errors)
        ax.axvline(mean, color="#D97706", linestyle="--", label=f"平均有符号误差 {mean:+.3f} m")
        ax.axvline(0, color="#63747D", linewidth=1)
        ax.set_xlabel("定位误差 (m)")
        ax.set_ylabel("次数")
        ax.set_title("定位误差分布（仅有效定位）")
        ax.legend()
        fig.tight_layout()
        path = target / "02_error_distribution.png"
        fig.savefig(path)
        plt.close(fig)
        generated.append(path)

    error_rows = stats.get("error_by_distance", [])
    if error_rows:
        fig, ax = plt.subplots(figsize=(7.2, 3.8))
        distances = [r["distance_m"] for r in error_rows]
        ax.plot(distances, [r["mae_m"] for r in error_rows], "o-", color="#0F6E6E", label="MAE")
        ax.plot(distances, [r["rmse_m"] for r in error_rows], "s--", color="#D97706", label="RMSE")
        ax.set_xlabel("真实距离 (m)")
        ax.set_ylabel("误差 (m)")
        ax.set_title("定位误差随距离变化")
        ax.legend()
        fig.tight_layout()
        path = target / "03_error_by_distance.png"
        fig.savefig(path)
        plt.close(fig)
        generated.append(path)

    gamma_rows = [
        r for r in stats.get("detection_vs_gamma", [])
        if r.get("abs_gamma") is not None and r.get("detection_rate") is not None
    ]
    if gamma_rows:
        fig, ax = plt.subplots(figsize=(7.2, 3.8))
        for polarity, color, marker in (("positive", "#B42318", "o"), ("negative", "#175CD3", "s")):
            rows = [r for r in gamma_rows if r.get("polarity") == polarity]
            if rows:
                ax.scatter(
                    [r["abs_gamma"] for r in rows],
                    [r["detection_rate"] for r in rows],
                    color=color, marker=marker, s=55, label="正反射" if polarity == "positive" else "负反射",
                )
                for r in rows:
                    ax.annotate(r.get("board_code") or "", (r["abs_gamma"], r["detection_rate"]),
                                textcoords="offset points", xytext=(5, 5), fontsize=7)
        ax.set_xlabel("|理论反射系数|")
        ax.set_ylabel("检出率")
        ax.set_ylim(-0.02, 1.05)
        ax.set_title("检出率与理论反射系数（按极性区分）")
        ax.legend()
        fig.tight_layout()
        path = target / "04_detection_vs_gamma.png"
        fig.savefig(path)
        plt.close(fig)
        generated.append(path)

    multi_rows = stats.get("multi_mapping", [])
    if multi_rows:
        fig, ax = plt.subplots(figsize=(6.5, 5))
        xs = [r["true_distance_m"] for r in multi_rows]
        ys = [r["measured_distance_m"] for r in multi_rows]
        ax.scatter(xs, ys, color="#0F6E6E", s=35, alpha=0.8)
        low = min(xs + ys) - 1
        high = max(xs + ys) + 1
        ax.plot([low, high], [low, high], color="#B42318", linestyle="--", linewidth=1, label="理想 y=x")
        ax.set_xlabel("真实异常距离 (m)")
        ax.set_ylabel("系统候选距离 (m)")
        ax.set_title("多异常真实位置与识别位置")
        ax.legend()
        fig.tight_layout()
        path = target / "05_multi_anomaly_mapping.png"
        fig.savefig(path)
        plt.close(fig)
        generated.append(path)

    # 选第一组有数据的单异常配置绘制重复测量序列
    series = [
        s for s in stats.get("per_configuration", [])
        if s.get("mode") == "single" and s.get("total_trials", 0) > 0
    ]
    if series:
        chosen = series[0]
        rows = [
            t for t in trials
            if t.get("config_code") == chosen.get("config_code")
            and t.get("measured_distance_m") is not None
        ]
        if rows:
            fig, ax = plt.subplots(figsize=(7.2, 3.8))
            ax.plot([r["trial_index"] for r in rows], [r["measured_distance_m"] for r in rows],
                    "o-", color="#0F6E6E", label="系统测量距离")
            truth = chosen.get("distance_m")
            if truth is not None:
                ax.axhline(truth, color="#B42318", linestyle="--", label=f"真实距离 {truth:.3f} m")
            ax.set_xlabel("重复测量次数")
            ax.set_ylabel("距离 (m)")
            ax.set_title(f"重复定位结果分布 — {chosen.get('config_code')}")
            ax.legend()
            fig.tight_layout()
            path = target / "06_repeat_distribution.png"
            fig.savefig(path)
            plt.close(fig)
            generated.append(path)
    return generated
