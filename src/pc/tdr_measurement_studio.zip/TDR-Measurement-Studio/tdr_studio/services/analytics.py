"""从数据库原始记录构建实验统计视图。"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from ..database import Database
from ..utils import safe_float
from .statistics import aggregate_stats, normalize_rules, summarize_trials


def load_rules(db: Database) -> dict[str, Any]:
    settings = db.get_all_settings()
    return normalize_rules(settings)


def run_stats(db: Database, run_id: str, rules: dict[str, Any] | None = None) -> dict[str, Any]:
    from ..repositories.runs import RunRepository
    from ..repositories.trials import TrialRepository

    rules = normalize_rules(rules or load_rules(db))
    run = RunRepository(db).get(run_id)
    if not run:
        raise ValueError("实验运行不存在")
    if run.get("tolerance_m") is not None:
        rules = dict(rules)
        rules["distance_tolerance_m"] = float(run["tolerance_m"])
    trial_repo = TrialRepository(db)
    trials = trial_repo.list_for_run(run_id)
    candidates = trial_repo.candidates_for_trials([t["id"] for t in trials])
    expected = RunRepository(db).expected_anomalies(run_id)
    stats = summarize_trials(
        mode=run["mode"],
        trials=trials,
        planned_trials=run.get("planned_repeats") or 0,
        expected_polarity=run.get("expected_polarity") or "none",
        true_distance_m=run.get("distance_m"),
        expected_anomalies=expected,
        candidates_by_trial=candidates,
        rules=rules,
    )
    stats["run_id"] = run_id
    stats["config_id"] = run["config_id"]
    stats["config_code"] = run.get("config_code")
    stats["config_name"] = run.get("config_name")
    stats["category_code"] = run.get("category_code")
    stats["category_name"] = run.get("category_name")
    stats["batch_id"] = run.get("batch_id")
    stats["batch_name"] = run.get("batch_name")
    stats["board_id"] = run.get("board_id")
    stats["board_code"] = run.get("board_code") or ""
    stats["board_name"] = run.get("board_name") or ""
    stats["gamma_nominal"] = run.get("gamma_nominal")
    stats["distance_m"] = run.get("distance_m")
    stats["rules"] = rules
    stats["reference_issues"] = RunRepository(db).reference_condition_issues(run)
    stats["_trials"] = trials
    stats["_candidates"] = candidates
    stats["_expected"] = expected
    return stats


def config_stats(db: Database, config_id: str, rules: dict[str, Any] | None = None) -> dict[str, Any]:
    from ..repositories.runs import RunRepository

    run = RunRepository(db).get_by_config(config_id)
    if run:
        return run_stats(db, run["id"], rules)
    # 无运行记录时返回可判定的空统计
    from ..repositories.experiments import ExperimentRepository

    config = ExperimentRepository(db).get(config_id)
    if not config:
        raise ValueError("实验配置不存在")
    rules = normalize_rules(rules or load_rules(db))
    if config.get("tolerance_m") is not None:
        rules = dict(rules)
        rules["distance_tolerance_m"] = float(config["tolerance_m"])
    stats = summarize_trials(
        mode=config["mode"],
        trials=[],
        planned_trials=config.get("planned_repeats") or 0,
        expected_polarity=config.get("expected_polarity") or "none",
        true_distance_m=config.get("distance_m"),
        expected_anomalies=[],
        rules=rules,
    )
    stats.update(
        {
            "run_id": None,
            "config_id": config_id,
            "config_code": config.get("code"),
            "config_name": config.get("name"),
            "category_code": config.get("category_code"),
            "category_name": config.get("category_name"),
            "batch_id": config.get("batch_id"),
            "batch_name": config.get("batch_name"),
            "board_id": config.get("board_id"),
            "board_code": config.get("board_code") or "",
            "board_name": config.get("board_name") or "",
            "gamma_nominal": config.get("gamma_nominal"),
            "distance_m": config.get("distance_m"),
            "rules": rules,
            "reference_issues": [],
            "_trials": [],
            "_candidates": {},
            "_expected": [],
        }
    )
    return stats


def scope_runs(
    db: Database,
    *,
    batch_id: str | None = None,
    category_id: str | None = None,
    board_id: str | None = None,
    mode: str | None = None,
    only_with_trials: bool = True,
) -> list[dict[str, Any]]:
    sql = """SELECT r.id AS run_id, r.config_id
             FROM experiment_runs r JOIN experiment_configs c ON c.id=r.config_id
             WHERE 1=1"""
    params: list[Any] = []
    if batch_id:
        sql += " AND c.batch_id=?"
        params.append(batch_id)
    if category_id:
        sql += " AND c.category_id=?"
        params.append(category_id)
    if board_id:
        sql += " AND c.board_id=?"
        params.append(board_id)
    if mode:
        sql += " AND c.mode=?"
        params.append(mode)
    if only_with_trials:
        sql += " AND EXISTS(SELECT 1 FROM trials t WHERE t.run_id=r.id)"
    sql += " ORDER BY c.sort_order, c.code"
    return db.query(sql, tuple(params))


def scope_stats(
    db: Database,
    *,
    batch_id: str | None = None,
    category_id: str | None = None,
    board_id: str | None = None,
    mode: str | None = None,
    rules: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rules = normalize_rules(rules or load_rules(db))
    runs = scope_runs(db, batch_id=batch_id, category_id=category_id, board_id=board_id, mode=mode)
    stats_list = [run_stats(db, row["run_id"], rules) for row in runs]
    return aggregate_stats(stats_list), stats_list


def board_performance(
    db: Database,
    *,
    batch_id: str | None = None,
    category_id: str | None = None,
    anomaly_only: bool = True,
) -> list[dict[str, Any]]:
    runs = scope_runs(db, batch_id=batch_id, category_id=category_id)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in runs:
        stats = run_stats(db, row["run_id"])
        if anomaly_only and stats["mode"] == "normal":
            continue
        key = stats.get("board_id") or "MULTI"
        grouped[key].append(stats)
    result = []
    for key, group in grouped.items():
        total = aggregate_stats(group)
        result.append(
            {
                "board_id": None if key == "MULTI" else key,
                "board_code": group[0].get("board_code") or "多异常",
                "board_name": group[0].get("board_name") or "多异常组合",
                "gamma_nominal": group[0].get("gamma_nominal"),
                "runs": len(group),
                "total_trials": total["total_trials"],
                "detection_rate": total.get("anomaly_detection_rate"),
                "polarity_accuracy": total.get("polarity_accuracy"),
                "mae_m": total["distance"].get("mae_m"),
                "p95_abs_error_m": total["distance"].get("p95_abs_error_m"),
                "location_pass_rate": total.get("location_pass_rate"),
                "comprehensive_success_rate": total.get("comprehensive_success_rate"),
            }
        )
    result.sort(key=lambda x: str(x.get("board_code") or ""))
    return result


def detection_vs_gamma(
    db: Database,
    *,
    batch_id: str | None = None,
    category_id: str | None = None,
) -> list[dict[str, Any]]:
    runs = scope_runs(db, batch_id=batch_id, category_id=category_id)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in runs:
        stats = run_stats(db, row["run_id"])
        if stats["mode"] == "normal" or stats.get("gamma_nominal") is None:
            continue
        key = stats.get("board_id") or "MULTI"
        grouped[key].append(stats)
    rows = []
    for key, group in grouped.items():
        total = aggregate_stats(group)
        gamma = group[0].get("gamma_nominal")
        rows.append(
            {
                "board_id": key,
                "board_code": group[0].get("board_code"),
                "board_name": group[0].get("board_name"),
                "gamma_nominal": gamma,
                "abs_gamma": abs(gamma) if gamma is not None else None,
                "polarity": "positive" if (gamma or 0) > 0 else ("negative" if (gamma or 0) < 0 else "none"),
                "total_trials": total["total_trials"],
                "detection_rate": total.get("anomaly_detection_rate"),
                "location_pass_rate": total.get("location_pass_rate"),
            }
        )
    rows.sort(key=lambda r: (r["abs_gamma"] is None, r["abs_gamma"] or 0))
    return rows


def error_by_distance(
    db: Database,
    *,
    batch_id: str | None = None,
    board_id: str | None = None,
    category_id: str | None = None,
) -> list[dict[str, Any]]:
    runs = scope_runs(db, batch_id=batch_id, category_id=category_id, board_id=board_id)
    buckets: dict[tuple[float, str], list[float]] = defaultdict(list)
    for row in runs:
        stats = run_stats(db, row["run_id"])
        if stats["mode"] != "single":
            continue
        distance = safe_float(stats.get("distance_m"))
        if distance is None:
            continue
        for trial in stats.get("_trials", []):
            if trial.get("detection_status") != "detected":
                continue
            measured = safe_float(trial.get("measured_distance_m"))
            if measured is None:
                continue
            quality = trial.get("quality_flag") or "正常"
            if quality in {"PN?", "OVERFLOW", "拒判"}:
                continue
            if quality == "EDGE*" and not stats["rules"].get("edge_as_valid"):
                continue
            buckets[(distance, stats.get("board_code") or "")].append(measured - distance)
    rows = []
    for (distance, board), errors in sorted(buckets.items()):
        n = len(errors)
        mae = sum(abs(e) for e in errors) / n
        rmse = (sum(e * e for e in errors) / n) ** 0.5
        rows.append(
            {
                "distance_m": distance,
                "board_code": board,
                "n": n,
                "mae_m": mae,
                "rmse_m": rmse,
                "mean_error_m": sum(errors) / n,
            }
        )
    return rows


def multi_anomaly_summary(
    db: Database,
    *,
    batch_id: str | None = None,
    category_id: str | None = None,
) -> list[dict[str, Any]]:
    """逐真实异常统计检出率与定位误差（按实验配置区分）。"""
    runs = scope_runs(db, batch_id=batch_id, category_id=category_id, mode="multi")
    rows = []
    for run_row in runs:
        stats = run_stats(db, run_row["run_id"])
        for anomaly in stats.get("per_anomaly", []):
            rows.append(
                {
                    "config_code": stats.get("config_code"),
                    "config_name": stats.get("config_name"),
                    "batch_name": stats.get("batch_name"),
                    "anomaly_index": anomaly.get("anomaly_index"),
                    "board_code": anomaly.get("board_code"),
                    "true_distance_m": anomaly.get("true_distance_m"),
                    "expected_polarity": anomaly.get("expected_polarity"),
                    "resolved_trials": anomaly.get("resolved_trials"),
                    "detected_count": anomaly.get("detected_count"),
                    "detection_rate": anomaly.get("detection_rate"),
                    "mae_m": anomaly.get("mae_m"),
                    "mean_error_m": anomaly.get("mean_error_m"),
                    "within_tolerance_rate": anomaly.get("within_tolerance_rate"),
                }
            )
    return rows


def multi_mapping(db: Database, *, batch_id: str | None = None) -> list[dict[str, Any]]:
    from .matching import match_candidates

    runs = scope_runs(db, batch_id=batch_id, mode="multi")
    rows = []
    for row in runs:
        stats = run_stats(db, row["run_id"])
        for trial in stats.get("_trials", []):
            expected_list = stats.get("_expected", [])
            candidates = stats.get("_candidates", {}).get(trial["id"], [])
            match = match_candidates(
                expected_list, candidates,
                default_tolerance_m=float(stats["rules"]["distance_tolerance_m"]),
            )
            for assignment in match["assignments"]:
                expected = assignment["expected"]
                cand = assignment["candidate"]
                rows.append(
                    {
                        "run_id": row["run_id"],
                        "config_code": stats.get("config_code"),
                        "trial_id": trial["id"],
                        "trial_index": trial["trial_index"],
                        "anomaly_index": expected.get("anomaly_index"),
                        "true_distance_m": expected.get("true_distance_m"),
                        "measured_distance_m": cand.get("measured_distance_m"),
                        "expected_polarity": expected.get("expected_polarity"),
                        "actual_polarity": cand.get("polarity"),
                        "distance_error_m": assignment.get("distance_error_m"),
                        "quality_flag": cand.get("quality_flag"),
                    }
                )
    return rows


def batch_comparison(db: Database, batch_ids: list[str] | None = None) -> list[dict[str, Any]]:
    from ..repositories.organization import BatchRepository

    batches = BatchRepository(db).list()
    rows = []
    for batch in batches:
        if batch_ids and batch["id"] not in batch_ids:
            continue
        stats, per_config = scope_stats(db, batch_id=batch["id"])
        rows.append(
            {
                "batch_id": batch["id"],
                "batch_name": batch["name"],
                "firmware_version": batch["firmware_version"],
                "frontend": batch["frontend"],
                "config_count": batch["config_count"],
                "total_trials": stats["total_trials"],
                "detection_rate": stats.get("anomaly_detection_rate"),
                "mae_m": stats["distance"].get("mae_m"),
                "p95_abs_error_m": stats["distance"].get("p95_abs_error_m"),
                "false_alarm_rate": stats.get("false_alarm_rate"),
                "polarity_accuracy": stats.get("polarity_accuracy"),
                "comprehensive_success_rate": stats.get("comprehensive_success_rate"),
            }
        )
    return rows


def dashboard_data(db: Database) -> dict[str, Any]:
    from ..repositories.experiments import ExperimentRepository

    exp_repo = ExperimentRepository(db)
    counts = exp_repo.counts()
    all_stats, stats_list = scope_stats(db)
    total_trials = int(db.scalar("SELECT COUNT(*) FROM trials", default=0) or 0)
    total_planned = int(db.scalar("SELECT COALESCE(SUM(planned_repeats),0) FROM experiment_configs", default=0) or 0)
    boards = int(db.scalar("SELECT COUNT(*) FROM boards WHERE status='available'", default=0) or 0)
    refs = int(db.scalar("SELECT COUNT(*) FROM health_references WHERE is_valid=1", default=0) or 0)
    categories = db.query(
        """SELECT cat.id, cat.code, cat.name,
             COUNT(ec.id) AS config_count,
             COALESCE(SUM(ec.planned_repeats),0) AS planned,
             (SELECT COUNT(*) FROM trials t JOIN experiment_configs e2 ON e2.id=t.config_id WHERE e2.category_id=cat.id) AS actual,
             SUM(CASE WHEN ec.status='completed' THEN 1 ELSE 0 END) AS completed,
             SUM(CASE WHEN ec.status='in_progress' THEN 1 ELSE 0 END) AS in_progress,
             SUM(CASE WHEN ec.status='not_started' THEN 1 ELSE 0 END) AS not_started,
             SUM(CASE WHEN ec.status='skipped' THEN 1 ELSE 0 END) AS skipped,
             SUM(CASE WHEN ec.status='failed' THEN 1 ELSE 0 END) AS failed
           FROM experiment_categories cat
           LEFT JOIN experiment_configs ec ON ec.category_id=cat.id
           GROUP BY cat.id ORDER BY cat.sort_order, cat.code"""
    )
    recent = db.query(
        """SELECT t.*, ec.code AS config_code, ec.name AS config_name
           FROM trials t JOIN experiment_configs ec ON ec.id=t.config_id
           ORDER BY t.updated_at DESC LIMIT 12"""
    )
    return {
        "config_counts": counts,
        "total_trials": total_trials,
        "total_planned": total_planned,
        "boards": boards,
        "references": refs,
        "stats": all_stats,
        "stats_list": stats_list,
        "categories": categories,
        "recent_trials": recent,
    }
