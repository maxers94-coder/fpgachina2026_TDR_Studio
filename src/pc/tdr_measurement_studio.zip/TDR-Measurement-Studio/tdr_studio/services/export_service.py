"""Excel / CSV / JSON / AI ZIP 数据导出。

导出原则：
* 所有统计均从原始 trial / candidate 重建，不导出缓存的“好看数字”。
* 保留全部单次记录，包括未检出、无效、拒判和额外候选。
* 未测试配置可出现在配置清单中，但必须带 data_status，不能混入实测统计。
* JSON 中无 NaN/Infinity；缺失值为 null。
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Iterable

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .. import config
from ..database import Database
from ..config import (
    BOARD_TYPE_LABELS,
    CONFIG_STATUS_LABELS,
    JUDGEMENT_LABELS,
    MODE_LABELS,
    POLARITY_LABELS,
)
from ..utils import (
    format_percent,
    json_dumps,
    new_id,
    now_iso,
    sanitize_json,
)
from .analytics import (
    batch_comparison,
    board_performance,
    config_stats,
    detection_vs_gamma,
    error_by_distance,
    load_rules,
    multi_mapping,
    scope_stats,
)
from .judgement import evaluate_judgement
from .statistics import aggregate_stats, quality_usable, strip_internal

UNITS = {
    "distance": "m（米；系统报告距离与真值均为物理长度，不是往返时延）",
    "resistance": "Ω（欧姆）",
    "reflection_coefficient": "无量纲，范围 -1..+1；百分比=数值×100%",
    "time": "ISO-8601 本地时区字符串",
    "rate": "比例 0..1；界面和 Excel 中同时以百分比显示",
    "sample_rate": "MSPS（百万采样点/秒）",
    "chip_rate": "Mchip/s",
}

DATA_STATUS_LABELS = {
    "not_tested": "未测试",
    "has_data": "有实测数据",
    "skipped": "已跳过",
    "failed": "标记失败",
}


def _json_safe_copy(value: Any) -> Any:
    return sanitize_json(value)


def _trial_flat(
    trial: dict[str, Any],
    *,
    run: dict[str, Any],
    config: dict[str, Any],
    expected: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
    rules: dict[str, Any],
) -> dict[str, Any]:
    measured = trial.get("measured_distance_m")
    truth = trial.get("true_distance_m")
    error = None
    if measured is not None and truth is not None:
        error = float(measured) - float(truth)
    tolerance = config.get("tolerance_m") or rules["distance_tolerance_m"]
    within = abs(error) <= float(tolerance) + 1e-12 if error is not None else None
    usable = quality_usable(trial.get("quality_flag"), rules["edge_as_valid"])
    expected_pol = config.get("expected_polarity")
    pol_correct = None
    if trial.get("polarity") in {"positive", "negative"} and expected_pol in {"positive", "negative"}:
        pol_correct = trial["polarity"] == expected_pol
    return {
        "trial_id": trial["id"],
        "run_id": trial["run_id"],
        "experiment_id": trial["run_id"],
        "configuration_id": trial["config_id"],
        "config_code": config.get("code"),
        "config_name": config.get("name"),
        "batch_id": config.get("batch_id"),
        "batch_name": config.get("batch_name"),
        "category_code": config.get("category_code"),
        "category_name": config.get("category_name"),
        "mode": config.get("mode"),
        "board_id": config.get("board_id"),
        "board_code": config.get("board_code"),
        "board_name": config.get("board_name"),
        "trial_index": trial["trial_index"],
        "true_distance_m": truth,
        "measured_distance_m": measured,
        "distance_error_m": error,
        "within_tolerance": within,
        "tolerance_m": tolerance,
        "polarity": trial.get("polarity"),
        "expected_polarity": expected_pol,
        "polarity_correct": pol_correct,
        "detection_status": trial.get("detection_status"),
        "quality_flag": trial.get("quality_flag"),
        "quality_usable": usable,
        "extra_candidate_count": int(trial.get("extra_candidate_count") or 0),
        "candidate_count": len(candidates),
        "expected_anomaly_count": len(expected),
        "notes": trial.get("notes", ""),
        "measured_at": trial.get("measured_at"),
        "created_at": trial.get("created_at"),
        "updated_at": trial.get("updated_at"),
    }


def _candidate_flat(
    candidate: dict[str, Any],
    trial: dict[str, Any],
    config: dict[str, Any],
    expected_map: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    expected = expected_map.get(candidate.get("matched_expected_id"))
    return {
        "candidate_id": candidate["id"],
        "trial_id": candidate["trial_id"],
        "run_id": trial["run_id"],
        "configuration_id": config["id"],
        "config_code": config.get("code"),
        "trial_index": trial.get("trial_index"),
        "candidate_index": candidate.get("candidate_index"),
        "measured_distance_m": candidate.get("measured_distance_m"),
        "polarity": candidate.get("polarity"),
        "quality_flag": candidate.get("quality_flag"),
        "matched_expected_anomaly_id": candidate.get("matched_expected_id"),
        "matched_anomaly_index": expected.get("anomaly_index") if expected else None,
        "true_distance_m": expected.get("true_distance_m") if expected else None,
        "distance_error_m": candidate.get("distance_error_m"),
        "match_status": candidate.get("match_status"),
        "polarity_correct": (
            bool(candidate.get("polarity_correct")) if candidate.get("polarity_correct") is not None else None
        ),
        "notes": candidate.get("notes", ""),
    }


def build_dataset(db: Database, *, include_settings: bool = True) -> dict[str, Any]:
    from ..repositories.boards import BoardRepository
    from ..repositories.cables import CableRepository
    from ..repositories.experiments import ExperimentRepository
    from ..repositories.organization import BatchRepository, CategoryRepository
    from ..repositories.references import ReferenceRepository
    from ..repositories.runs import RunRepository
    from ..repositories.trials import TrialRepository

    rules = load_rules(db)
    settings = db.get_all_settings() if include_settings else {}
    boards = BoardRepository(db).list()
    cables = CableRepository(db).list()
    cable_repo = CableRepository(db)
    cable_configs = []
    for cfg in cable_repo.list_configs():
        full = cable_repo.get_config(cfg["id"])
        cable_configs.append(full or cfg)
    references = ReferenceRepository(db).list()
    categories = CategoryRepository(db).list()
    batches = BatchRepository(db).list()
    configs = ExperimentRepository(db).list()
    run_repo = RunRepository(db)
    trial_repo = TrialRepository(db)
    all_runs = db.query(
        """SELECT r.*, c.code AS config_code, c.name AS config_name, c.mode,
                  cat.code AS category_code, cat.name AS category_name,
                  b.code AS batch_code, b.name AS batch_name
           FROM experiment_runs r
           JOIN experiment_configs c ON c.id=r.config_id
           JOIN experiment_categories cat ON cat.id=c.category_id
           JOIN batches b ON b.id=r.batch_id
           ORDER BY c.sort_order, c.code"""
    )
    configs_by_id = {c["id"]: c for c in configs}
    runs_by_config = {r["config_id"]: r for r in all_runs}
    expected_all = db.query(
        """SELECT e.*, b.code AS board_code, b.name AS board_name, b.board_type
           FROM expected_anomalies e LEFT JOIN boards b ON b.id=e.board_id
           ORDER BY e.run_id, e.anomaly_index"""
    )
    expected_by_run: dict[str, list[dict[str, Any]]] = {}
    expected_map = {e["id"]: e for e in expected_all}
    for expected in expected_all:
        expected_by_run.setdefault(expected["run_id"], []).append(expected)

    per_config_stats: list[dict[str, Any]] = []
    tested_stats: list[dict[str, Any]] = []
    judgements: list[dict[str, Any]] = []
    statistics_by_config: list[dict[str, Any]] = []
    trial_rows: list[dict[str, Any]] = []
    candidate_rows: list[dict[str, Any]] = []

    for cfg in configs:
        stats = config_stats(db, cfg["id"], rules)
        data_status = "has_data" if stats["total_trials"] > 0 else (
            "skipped" if cfg["status"] == "skipped" else (
                "failed" if cfg["status"] == "failed" else "not_tested"
            )
        )
        judgement = evaluate_judgement(
            stats, stats.get("rules") or rules, planned_trials=cfg.get("planned_repeats") or 0
        ) if stats["total_trials"] > 0 else {
            "decision": "not_tested", "label": "未测试",
            "summary": "尚未录入试次。未测试不等于未通过。",
            "rules": [], "reasons": ["没有测量记录"], "rules_used": rules,
        }
        clean_stats = strip_internal(stats)
        clean_stats["data_status"] = data_status
        clean_stats["data_status_label"] = DATA_STATUS_LABELS[data_status]
        clean_stats["planned_repeats"] = cfg.get("planned_repeats")
        clean_stats["config_code"] = cfg.get("code")
        clean_stats["config_name"] = cfg.get("name")
        clean_stats["board_code"] = cfg.get("board_code")
        clean_stats["board_name"] = cfg.get("board_name")
        clean_stats["category_code"] = cfg.get("category_code")
        clean_stats["category_name"] = cfg.get("category_name")
        clean_stats["batch_id"] = cfg.get("batch_id")
        clean_stats["batch_name"] = cfg.get("batch_name")
        per_config_stats.append(clean_stats)
        if stats["total_trials"] > 0:
            tested_stats.append(stats)
        judgements.append(
            {
                "config_id": cfg["id"],
                "config_code": cfg.get("code"),
                "config_name": cfg.get("name"),
                "batch_id": cfg.get("batch_id"),
                "batch_name": cfg.get("batch_name"),
                "decision": judgement["decision"],
                "decision_label": judgment_label(judgement["decision"]),
                "summary": judgement["summary"],
                "rules_used": judgement.get("rules_used", rules),
                "rule_rows": judgement.get("rules", []),
                "has_data": stats["total_trials"] > 0,
                "total_trials": stats["total_trials"],
            }
        )
        statistics_by_config.append(
            {
                "config_id": cfg["id"],
                **clean_stats,
            }
        )
        run = runs_by_config.get(cfg["id"])
        if not run:
            continue
        expected = expected_by_run.get(run["id"], [])
        trials = trial_repo.list_for_run(run["id"])
        candidates_map = trial_repo.candidates_for_trials([t["id"] for t in trials])
        for trial in trials:
            candidates = candidates_map.get(trial["id"], [])
            trial_rows.append(
                _trial_flat(
                    trial, run=run, config=cfg, expected=expected,
                    candidates=candidates, rules=rules,
                )
            )
            for candidate in candidates:
                candidate_rows.append(_candidate_flat(candidate, trial, cfg, expected_map))

    overall = aggregate_stats(tested_stats)
    by_batch = batch_comparison(db)
    board_perf = board_performance(db)
    gamma_rows = detection_vs_gamma(db)
    error_rows = error_by_distance(db)
    multi_rows = multi_mapping(db)

    tested_config_ids = {s["config_id"] for s in tested_stats}
    manifest_counts = {
        "configuration_count": len(configs),
        "tested_configuration_count": len(tested_config_ids),
        "experiment_run_count": len(all_runs),
        "tested_experiment_run_count": sum(1 for r in all_runs if r["config_id"] in tested_config_ids),
        "trial_count": len(trial_rows),
        "candidate_count": len(candidate_rows),
        "expected_anomaly_definition_count": len(expected_all),
        "board_count": len(boards),
        "attachment_count": int(db.scalar("SELECT COUNT(*) FROM attachments", default=0) or 0),
    }
    metadata = {
        "project_name": settings.get("project_name", config.APP_NAME_CN),
        "software": config.APP_NAME,
        "software_version": config.APP_VERSION,
        "data_schema_version": config.DATA_SCHEMA_VERSION,
        "exported_at": now_iso(),
        "export_id": new_id("EXPORT"),
        "firmware_version_default": settings.get("firmware_version", ""),
        "operator_default": settings.get("operator", ""),
        **manifest_counts,
        "statistics_rules": rules,
        "units": UNITS,
        "data_policy": [
            "理论反射系数由理想集总电阻公式计算，不是仪器实测反射系数。",
            "所有统计均来自 trials/detected_candidates 原始记录，可独立重算。",
            "未检出试次保留在检出率分母，但不参与距离均值。",
            "无效、拒判保留在总试次与无效率中，不进入检出率分母。",
            "未测试配置只出现在配置与统计清单中，data_status=not_tested，不进入总体实测统计。",
            "不同批次、固件、模拟前端、健康参考的数据未自动混合为单一结论。",
        ],
    }
    dataset = {
        "metadata": metadata,
        "boards": _boards_export(boards),
        "cables": _cables_export(cables),
        "cable_configurations": _cable_configs_export(cable_configs),
        "references": _references_export(references),
        "categories": categories,
        "batches": batches,
        "configurations": _configs_export(configs),
        "experiment_runs": _runs_export(all_runs),
        "expected_anomalies": _expected_export(expected_all),
        "trials": trial_rows,
        "detected_candidates": candidate_rows,
        "statistics": {
            "per_configuration": statistics_by_config,
            "overall": strip_internal(overall),
            "by_batch": by_batch,
            "board_performance": board_perf,
            "detection_vs_gamma": gamma_rows,
            "error_by_distance": error_rows,
            "multi_mapping": multi_rows,
            "rules": rules,
            "definitions": overall.get("definitions", {}),
        },
        "judgements": judgements,
        "settings": settings if include_settings else {},
    }
    return _json_safe_copy(dataset)


def judgment_label(decision: str) -> str:
    return {
        "pass": "通过", "fail": "未通过", "insufficient": "数据不足",
        "not_tested": "未测试", "review": "需要人工复核",
    }.get(decision, decision)


def _boards_export(boards: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for board in boards:
        item = dict(board)
        item["board_type_label"] = BOARD_TYPE_LABELS.get(board["board_type"], board["board_type"])
        item["gamma_nominal_percent"] = (
            board["gamma_nominal"] * 100 if board.get("gamma_nominal") is not None else None
        )
        item["gamma_measured_percent"] = (
            board["gamma_measured"] * 100 if board.get("gamma_measured") is not None else None
        )
        item["gamma_note"] = "理论值（理想集总模型），不是仪器实测反射系数"
        rows.append(item)
    return rows


def _cables_export(cables: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [dict(cable) for cable in cables]


def _cable_configs_export(configs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for cfg in configs:
        items = cfg.get("items", [])
        rows.append(
            {
                **{k: v for k, v in cfg.items() if k != "items"},
                "items": [
                    {
                        "position": item.get("position"),
                        "item_type": item.get("item_type"),
                        "cable_id": item.get("cable_id"),
                        "board_id": item.get("board_id"),
                        "label": item.get("label"),
                        "length_m": item.get("length_m"),
                        "correction_m": item.get("correction_m"),
                        "notes": item.get("notes"),
                    }
                    for item in items
                ],
            }
        )
    return rows


def _references_export(references: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for ref in references:
        item = dict(ref)
        item["is_valid_bool"] = bool(ref.get("is_valid"))
        rows.append(item)
    return rows


def _configs_export(configs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for cfg in configs:
        item = {k: v for k, v in cfg.items() if k not in {"source_payload", "expected_anomalies"}}
        item["mode_label"] = MODE_LABELS.get(cfg.get("mode"), cfg.get("mode"))
        item["status_label"] = CONFIG_STATUS_LABELS.get(cfg.get("status"), cfg.get("status"))
        item["expected_polarity_label"] = POLARITY_LABELS.get(cfg.get("expected_polarity"), "")
        item["planned_trials"] = cfg.get("planned_repeats")
        item["expected_anomalies"] = json.loads(cfg.get("expected_anomalies_json") or "[]")
        rows.append(item)
    return rows


def _runs_export(runs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [dict(run) for run in runs]


def _expected_export(expected: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for exp in expected:
        rows.append(
            {
                **exp,
                "expected_polarity_label": POLARITY_LABELS.get(exp.get("expected_polarity"), ""),
            }
        )
    return rows


# ------------------------------------------------------------------ CSV
CSV_TABLES: dict[str, tuple[list[str], str]] = {
    "boards.csv": (
        ["id", "code", "name", "board_type", "nominal_ohm", "measured_ohm", "z0",
         "gamma_nominal", "gamma_measured", "gamma_nominal_percent", "gamma_measured_percent",
         "polarity", "pcb_no", "component_model", "manufacture_date", "photo_path", "notes",
         "status", "created_at", "updated_at", "gamma_note"],
        "boards",
    ),
    "cables.csv": (
        ["id", "code", "name", "physical_length_m", "model", "z0", "velocity_factor",
         "notes", "status", "created_at", "updated_at"],
        "cables",
    ),
    "cable_configurations.csv": (
        ["id", "code", "name", "description", "total_length_m", "connector_count", "correction_m", "notes"],
        "cable_configurations",
    ),
    "references.csv": (
        ["id", "ref_no", "created_at_ref", "config_id", "frontend", "firmware_version",
         "notes", "file_path", "is_valid", "is_valid_bool", "created_at", "updated_at"],
        "references",
    ),
    "categories.csv": (
        ["id", "code", "name", "description", "is_builtin", "sort_order"],
        "categories",
    ),
    "batches.csv": (
        ["id", "code", "name", "firmware_version", "frontend", "description", "is_active"],
        "batches",
    ),
    "configurations.csv": (
        ["id", "code", "name", "category_id", "batch_id", "priority", "mode", "distance_m",
         "distance_expr", "near_expr", "far_expr", "board_id", "expected_polarity",
         "nominal_gamma", "planned_trials", "tolerance_m", "reference_id", "cable_config_id",
         "reference_label", "status", "sort_order", "is_multi", "notes", "source", "source_row",
         "created_at", "updated_at", "expected_polarity_label", "mode_label", "status_label"],
        "configurations",
    ),
    "experiment_runs.csv": (
        ["id", "code", "config_id", "batch_id", "session_id", "firmware_version", "reference_id",
         "cable_config_id", "frontend", "operator", "status", "notes", "created_at", "updated_at"],
        "experiment_runs",
    ),
    "experiments.csv": (
        ["experiment_id", "configuration_id", "session_id", "firmware_version", "reference_id",
         "created_at", "updated_at", "operator", "notes", "config_code", "config_name",
         "category_code", "batch_code", "mode"],
        "experiment_runs",
    ),
    "expected_anomalies.csv": (
        ["id", "run_id", "anomaly_index", "board_id", "true_distance_m", "expected_polarity",
         "tolerance_m", "notes", "board_code", "board_name", "board_type", "expected_polarity_label"],
        "expected_anomalies",
    ),
    "trials.csv": (
        ["trial_id", "run_id", "experiment_id", "configuration_id", "config_code", "config_name",
         "batch_id", "batch_name", "category_code", "category_name", "mode", "board_id",
         "board_code", "board_name", "trial_index", "true_distance_m", "measured_distance_m",
         "distance_error_m", "within_tolerance", "tolerance_m", "polarity", "expected_polarity",
         "polarity_correct", "detection_status", "quality_flag", "quality_usable",
         "extra_candidate_count", "candidate_count", "expected_anomaly_count", "notes",
         "measured_at", "created_at", "updated_at"],
        "trials",
    ),
    "detected_candidates.csv": (
        ["candidate_id", "trial_id", "run_id", "configuration_id", "config_code", "trial_index",
         "candidate_index", "measured_distance_m", "polarity", "quality_flag",
         "matched_expected_anomaly_id", "matched_anomaly_index", "true_distance_m",
         "distance_error_m", "match_status", "polarity_correct", "notes"],
        "detected_candidates",
    ),
    "judgements.csv": (
        ["config_id", "config_code", "config_name", "batch_id", "batch_name", "decision",
         "decision_label", "summary", "has_data", "total_trials"],
        "judgements",
    ),
}

STATS_COLUMNS = [
    "config_id", "config_code", "config_name", "batch_id", "batch_name", "category_code",
    "category_name", "board_code", "board_name", "mode", "data_status", "data_status_label",
    "total_trials", "planned_trials", "resolved_trials", "detected_count", "not_detected_count",
    "detection_rate", "normal_count", "false_alarm_count", "normal_judgement_rate",
    "false_alarm_rate", "polarity_correct_count", "polarity_wrong_count",
    "polarity_unknown_count", "polarity_accuracy", "located_count", "within_tolerance_count",
    "location_pass_rate", "comprehensive_success_count", "comprehensive_success_rate",
    "invalid_count", "rejected_count", "invalid_rate", "extra_candidate_count",
    "mean_distance_m", "mean_signed_error_m", "mae_m", "max_abs_error_m", "min_abs_error_m",
    "std_error_m", "rmse_m", "median_abs_error_m", "median_signed_error_m", "p95_abs_error_m",
    "expected_anomaly_count", "matched_anomaly_count", "average_missed_anomalies",
    "average_extra_candidates", "any_detection_rate", "all_detected_rate", "strict_complete_rate",
    "ambiguous_trials",
]


def multi_anomaly_rows(dataset: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for stats in dataset.get("statistics", {}).get("per_configuration", []):
        if stats.get("mode") != "multi":
            continue
        for anomaly in stats.get("per_anomaly", []) or []:
            rows.append(
                {
                    "config_id": stats.get("config_id"),
                    "config_code": stats.get("config_code"),
                    "config_name": stats.get("config_name"),
                    "batch_id": stats.get("batch_id"),
                    "batch_name": stats.get("batch_name"),
                    "anomaly_index": anomaly.get("anomaly_index"),
                    "board_id": anomaly.get("board_id"),
                    "board_code": anomaly.get("board_code"),
                    "board_name": anomaly.get("board_name"),
                    "true_distance_m": anomaly.get("true_distance_m"),
                    "expected_polarity": anomaly.get("expected_polarity"),
                    "resolved_trials": anomaly.get("resolved_trials"),
                    "detected_count": anomaly.get("detected_count"),
                    "detection_rate": anomaly.get("detection_rate"),
                    "mae_m": anomaly.get("mae_m"),
                    "mean_error_m": anomaly.get("mean_error_m"),
                    "within_tolerance_rate": anomaly.get("within_tolerance_rate"),
                }
            )
    return rows


def _stats_row(stats: dict[str, Any]) -> dict[str, Any]:
    distance = stats.get("distance") or {}
    row = {key: stats.get(key) for key in STATS_COLUMNS}
    row.update(
        {
            "mean_distance_m": distance.get("mean_distance_m"),
            "mean_signed_error_m": distance.get("mean_signed_error_m"),
            "mae_m": distance.get("mae_m"),
            "max_abs_error_m": distance.get("max_abs_error_m"),
            "min_abs_error_m": distance.get("min_abs_error_m"),
            "std_error_m": distance.get("std_error_m"),
            "rmse_m": distance.get("rmse_m"),
            "median_abs_error_m": distance.get("median_abs_error_m"),
            "median_signed_error_m": distance.get("median_signed_error_m"),
            "p95_abs_error_m": distance.get("p95_abs_error_m"),
        }
    )
    return row


def _csv_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (dict, list)):
        return json_dumps(value)
    return value


def write_csv(path: Path, fieldnames: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _csv_value(row.get(key)) for key in fieldnames})


def write_csv_bundle(db: Database, target_dir: Path, dataset: dict[str, Any] | None = None) -> list[Path]:
    dataset = dataset or build_dataset(db)
    target_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for filename, (columns, key) in CSV_TABLES.items():
        rows = dataset.get(key, [])
        write_csv(target_dir / filename, columns, rows)
        written.append(target_dir / filename)
    stats_rows = [_stats_row(s) for s in dataset["statistics"]["per_configuration"]]
    write_csv(target_dir / "statistics.csv", STATS_COLUMNS, stats_rows)
    written.append(target_dir / "statistics.csv")
    multi_columns = [
        "config_id", "config_code", "config_name", "batch_id", "batch_name",
        "anomaly_index", "board_id", "board_code", "board_name", "true_distance_m",
        "expected_polarity", "resolved_trials", "detected_count", "detection_rate",
        "mae_m", "mean_error_m", "within_tolerance_rate",
    ]
    write_csv(target_dir / "multi_anomaly.csv", multi_columns, multi_anomaly_rows(dataset))
    written.append(target_dir / "multi_anomaly.csv")
    # 总体与分批次汇总
    per_config = dataset["statistics"]["per_configuration"]
    tested_by_batch: dict[str, int] = {}
    for stats in per_config:
        if stats.get("data_status") == "has_data":
            tested_by_batch[stats.get("batch_id")] = tested_by_batch.get(stats.get("batch_id"), 0) + 1
    overall_summary = _summary_flat(dataset["statistics"]["overall"])
    overall_summary["tested_configuration_count"] = sum(tested_by_batch.values())
    summary_rows = [{"summary_scope": "overall", "scope_id": "ALL", "scope_name": "全部实测数据",
                     **overall_summary}]
    for batch in dataset["statistics"].get("by_batch", []):
        batch_summary = _summary_flat(batch)
        batch_summary["tested_configuration_count"] = tested_by_batch.get(batch["batch_id"], 0)
        summary_rows.append(
            {"summary_scope": "batch", "scope_id": batch["batch_id"], "scope_name": batch["batch_name"],
             **batch_summary}
        )
    summary_columns = ["summary_scope", "scope_id", "scope_name", "tested_configuration_count",
                       "total_trials", "resolved_trials", "detection_rate", "normal_judgement_rate",
                       "false_alarm_rate", "polarity_accuracy", "location_pass_rate",
                       "comprehensive_success_rate", "mae_m", "p95_abs_error_m", "rmse_m",
                       "invalid_rate", "average_missed_anomalies", "average_extra_candidates"]
    write_csv(target_dir / "summary.csv", summary_columns, summary_rows)
    written.append(target_dir / "summary.csv")
    return written


def _summary_flat(stats: dict[str, Any]) -> dict[str, Any]:
    distance = stats.get("distance") or {}
    return {
        "tested_configuration_count": stats.get("tested_configuration_count", stats.get("config_count")),
        "total_trials": stats.get("total_trials"),
        "resolved_trials": stats.get("resolved_trials"),
        "detection_rate": stats.get("anomaly_detection_rate") or stats.get("detection_rate"),
        "normal_judgement_rate": stats.get("normal_judgement_rate"),
        "false_alarm_rate": stats.get("false_alarm_rate"),
        "polarity_accuracy": stats.get("polarity_accuracy"),
        "location_pass_rate": stats.get("location_pass_rate"),
        "comprehensive_success_rate": stats.get("comprehensive_success_rate"),
        "mae_m": distance.get("mae_m"),
        "p95_abs_error_m": distance.get("p95_abs_error_m"),
        "rmse_m": distance.get("rmse_m"),
        "invalid_rate": stats.get("invalid_rate"),
        "average_missed_anomalies": stats.get("average_missed_anomalies"),
        "average_extra_candidates": stats.get("average_extra_candidates"),
    }


# ------------------------------------------------------------------ Excel
HEADER_FILL = PatternFill("solid", fgColor="0F6E6E")
HEADER_FONT = Font(color="FFFFFF", bold=True, name="Microsoft YaHei UI", size=10)
BODY_FONT = Font(name="Microsoft YaHei UI", size=10)
THIN = Side(style="thin", color="D9E1E5")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WARNING_FILL = PatternFill("solid", fgColor="FFF4E5")
TITLE_FILL = PatternFill("solid", fgColor="E6F2F2")


def _excel_safe(value: Any) -> Any:
    if isinstance(value, str) and value[:1] in {"=", "+", "-", "@"}:
        return "'" + value
    if isinstance(value, (dict, list)):
        return json_dumps(value)
    return value


def _write_table(ws, headers: list[str], rows: Iterable[dict[str, Any]], widths: dict[str, int] | None = None) -> None:
    ws.append(headers)
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    for row in rows:
        ws.append([_excel_safe(row.get(header)) for header in headers])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=False)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    ws.row_dimensions[1].height = 30
    for index, header in enumerate(headers, start=1):
        width = (widths or {}).get(header)
        if width is None:
            max_len = len(str(header)) * 2
            for row in ws.iter_rows(min_row=2, min_col=index, max_col=index, max_row=min(ws.max_row, 200)):
                for cell in row:
                    max_len = max(max_len, min(len(str(cell.value or "")), 48))
            width = max(10, min(max_len + 2, 42))
        ws.column_dimensions[get_column_letter(index)].width = width


def write_excel(db: Database, target: Path, dataset: dict[str, Any] | None = None) -> Path:
    dataset = dataset or build_dataset(db)
    wb = Workbook()
    wb.remove(wb.active)

    # 项目信息
    ws = wb.create_sheet("项目信息")
    ws["A1"] = "TDR Measurement Studio 数据导出"
    ws["A1"].font = Font(name="Microsoft YaHei UI", size=15, bold=True, color="0B2B36")
    ws.merge_cells("A1:D1")
    ws["A2"] = "本工作簿包含全部单次原始测量记录、配置、资产与统计结果。理论反射系数不等同于仪器实测反射系数。"
    ws["A2"].font = BODY_FONT
    ws.merge_cells("A2:D2")
    metadata = dataset["metadata"]
    info_rows = [
        ("项目名称", metadata["project_name"]),
        ("软件版本", f"{metadata['software']} {metadata['software_version']}"),
        ("数据结构版本", metadata["data_schema_version"]),
        ("导出时间", metadata["exported_at"]),
        ("导出 ID", metadata["export_id"]),
        ("默认固件版本", metadata["firmware_version_default"]),
        ("实验配置数", metadata["configuration_count"]),
        ("有实测数据的配置数", metadata["tested_configuration_count"]),
        ("实验运行数", metadata["experiment_run_count"]),
        ("总试次数", metadata["trial_count"]),
        ("候选总数", metadata["candidate_count"]),
        ("测试板数", metadata["board_count"]),
        ("附件数", metadata["attachment_count"]),
        ("距离容差 (m)", metadata["statistics_rules"].get("distance_tolerance_m")),
        ("最低检出率", format_percent(metadata["statistics_rules"].get("min_detection_rate"))),
        ("正常误报率上限", format_percent(metadata["statistics_rules"].get("max_false_alarm_rate"))),
        ("EDGE* 视为有效", "是" if metadata["statistics_rules"].get("edge_as_valid") else "否"),
    ]
    for index, (key, value) in enumerate(info_rows, start=4):
        ws.cell(row=index, column=1, value=key).font = Font(name="Microsoft YaHei UI", bold=True)
        ws.cell(row=index, column=2, value=_excel_safe(value)).font = BODY_FONT
        ws.cell(row=index, column=1).fill = TITLE_FILL
        ws.cell(row=index, column=1).border = BORDER
        ws.cell(row=index, column=2).border = BORDER
    note_row = 4 + len(info_rows) + 1
    ws.cell(row=note_row, column=1, value="数据口径与注意事项").font = Font(
        name="Microsoft YaHei UI", bold=True, color="B42318"
    )
    for offset, note in enumerate(metadata.get("data_policy", []) + [
        "未测试配置的 data_status=not_tested，不计入总体实测统计。",
        "单次记录位于“全部逐次记录”，未检出记录仍保留。",
        "统计可由 trials.csv + detected_candidates.csv + expected_anomalies.csv 独立重算。",
    ], start=1):
        cell = ws.cell(row=note_row + offset, column=1, value="• " + note)
        cell.font = BODY_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=note_row + offset, start_column=1, end_row=note_row + offset, end_column=4)
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 55
    ws.column_dimensions["C"].width = 30
    ws.column_dimensions["D"].width = 30

    # 资产表
    board_fields = ["id", "code", "name", "board_type_label", "nominal_ohm", "measured_ohm", "z0",
                    "gamma_nominal", "gamma_nominal_percent", "gamma_measured", "gamma_measured_percent",
                    "polarity", "pcb_no", "component_model", "manufacture_date", "status", "notes", "gamma_note"]
    board_labels = ["测试板ID", "代号", "名称", "类型", "标称阻值 Ω", "实测阻值 Ω", "Z0 Ω",
                    "理论Γ(标称)", "理论Γ %(标称)", "理论Γ(实测阻值)", "理论Γ %(实测阻值)",
                    "极性", "PCB编号", "元件型号", "制作日期", "状态", "备注", "理论值说明"]
    _write_table(wb.create_sheet("测试板"), [f"{label}" for label in board_labels],
                 [_rename(row, board_fields, board_labels) for row in dataset["boards"]])
    cable_fields = ["id", "code", "name", "physical_length_m", "model", "z0", "velocity_factor", "status", "notes"]
    cable_labels = ["线缆ID", "代号", "名称", "物理长度 m", "型号", "Z0 Ω", "速度系数", "状态", "备注"]
    _write_table(wb.create_sheet("线缆"), cable_labels,
                 [_rename(row, cable_fields, cable_labels) for row in dataset["cables"]])

    # 线缆组合
    ws = wb.create_sheet("线缆组合")
    combo_rows = []
    for combo in dataset["cable_configurations"]:
        for item in combo.get("items", []) or [{}]:
            combo_rows.append(
                {
                    "组合代号": combo.get("code"), "组合名称": combo.get("name"),
                    "总长度 m": combo.get("total_length_m"), "连接器数": combo.get("connector_count"),
                    "顺序": item.get("position"), "类型": item.get("item_type"),
                    "标签": item.get("label"), "长度 m": item.get("length_m"),
                    "修正 m": item.get("correction_m"), "备注": item.get("notes"),
                }
            )
    _write_table(ws, ["组合代号", "组合名称", "总长度 m", "连接器数", "顺序", "类型", "标签", "长度 m", "修正 m", "备注"], combo_rows)

    ref_fields = ["id", "ref_no", "created_at_ref", "config_id", "frontend", "firmware_version",
                  "is_valid", "file_path", "notes"]
    ref_labels = ["参考ID", "参考编号", "建立时间", "线缆组合ID", "模拟前端", "固件版本", "有效", "数据文件", "备注"]
    _write_table(wb.create_sheet("健康参考"), ref_labels,
                 [_rename(row, ref_fields, ref_labels) for row in dataset["references"]])

    # 实验配置
    config_headers = ["实验编号", "实验名称", "类别", "批次", "优先级", "模式", "真值距离 m",
                      "真值表达式", "测试板", "理论Γ", "理论极性", "计划次数", "实际试次",
                      "状态", "参考标识", "线缆组合ID", "容差 m", "来源行", "数据状态", "备注"]
    config_rows = []
    status_by_config = {s["config_id"]: s for s in dataset["statistics"]["per_configuration"]}
    for cfg in dataset["configurations"]:
        stat = status_by_config.get(cfg["id"], {})
        config_rows.append(
            {
                "实验编号": cfg["code"], "实验名称": cfg["name"],
                "类别": cfg.get("category_id"), "批次": cfg.get("batch_id"),
                "优先级": cfg.get("priority"), "模式": cfg.get("mode_label"),
                "真值距离 m": cfg.get("distance_m"), "真值表达式": cfg.get("distance_expr"),
                "测试板": cfg.get("board_id"), "理论Γ": cfg.get("nominal_gamma"),
                "理论极性": cfg.get("expected_polarity_label"), "计划次数": cfg.get("planned_repeats"),
                "实际试次": stat.get("total_trials", 0), "状态": cfg.get("status_label"),
                "参考标识": cfg.get("reference_label"), "线缆组合ID": cfg.get("cable_config_id"),
                "容差 m": cfg.get("tolerance_m"), "来源行": cfg.get("source_row"),
                "数据状态": stat.get("data_status_label", "未测试"), "备注": cfg.get("notes"),
            }
        )
    _write_table(wb.create_sheet("实验配置"), config_headers, config_rows)

    # 实验运行
    run_headers = ["运行ID", "运行编号", "配置ID", "批次ID", "会话ID", "固件版本", "参考ID",
                   "线缆组合ID", "模拟前端", "操作员", "状态", "创建时间", "更新时间", "备注"]
    run_rows = [
        {
            "运行ID": r["id"], "运行编号": r["code"], "配置ID": r["config_id"], "批次ID": r["batch_id"],
            "会话ID": r.get("session_id"), "固件版本": r.get("firmware_version"),
            "参考ID": r.get("reference_id"), "线缆组合ID": r.get("cable_config_id"),
            "模拟前端": r.get("frontend"), "操作员": r.get("operator"), "状态": r.get("status"),
            "创建时间": r.get("created_at"), "更新时间": r.get("updated_at"), "备注": r.get("notes"),
        }
        for r in dataset["experiment_runs"]
    ]
    _write_table(wb.create_sheet("实验运行"), run_headers, run_rows)

    # 全部试次
    trial_headers = ["试次ID", "实验运行ID", "实验编号", "试次号", "真实距离 m", "系统测量距离 m",
                     "定位误差 m", "容差内", "检测极性", "预期极性", "极性正确", "检测状态",
                     "质量标记", "质量可用", "额外候选数", "候选数", "备注", "测量时间"]
    trial_rows = []
    for t in dataset["trials"]:
        trial_rows.append(
            {
                "试次ID": t["trial_id"], "实验运行ID": t["run_id"], "实验编号": t["config_code"],
                "试次号": t["trial_index"], "真实距离 m": t["true_distance_m"],
                "系统测量距离 m": t["measured_distance_m"], "定位误差 m": t["distance_error_m"],
                "容差内": t["within_tolerance"], "检测极性": t["polarity"],
                "预期极性": t["expected_polarity"], "极性正确": t["polarity_correct"],
                "检测状态": t["detection_status"], "质量标记": t["quality_flag"],
                "质量可用": t["quality_usable"], "额外候选数": t["extra_candidate_count"],
                "候选数": t["candidate_count"], "备注": t["notes"], "测量时间": t["measured_at"],
            }
        )
    _write_table(wb.create_sheet("全部逐次记录"), trial_headers, trial_rows)

    # 多异常候选
    candidate_rows = [
        {
            "候选ID": c["candidate_id"], "试次ID": c["trial_id"], "实验编号": c["config_code"],
            "试次号": c["trial_index"], "候选号": c["candidate_index"],
            "候选距离 m": c["measured_distance_m"], "候选极性": c["polarity"],
            "质量标记": c["quality_flag"], "匹配异常号": c["matched_anomaly_index"],
            "真实距离 m": c["true_distance_m"], "误差 m": c["distance_error_m"],
            "匹配状态": c["match_status"], "极性正确": c["polarity_correct"], "备注": c["notes"],
        }
        for c in dataset["detected_candidates"]
    ]
    _write_table(wb.create_sheet("多异常候选"), list(candidate_rows[0].keys()) if candidate_rows else
                 ["候选ID", "试次ID", "实验编号", "试次号", "候选号", "候选距离 m", "候选极性",
                  "质量标记", "匹配异常号", "真实距离 m", "误差 m", "匹配状态", "极性正确", "备注"],
                 candidate_rows)

    # 真实异常
    expected_rows = [
        {
            "异常ID": e["id"], "实验运行ID": e["run_id"], "异常号": e["anomaly_index"],
            "测试板": e.get("board_code"), "真实距离 m": e["true_distance_m"],
            "预期极性": e.get("expected_polarity"), "容差 m": e.get("tolerance_m"), "备注": e.get("notes"),
        }
        for e in dataset["expected_anomalies"]
    ]
    _write_table(wb.create_sheet("真实异常"), ["异常ID", "实验运行ID", "异常号", "测试板", "真实距离 m", "预期极性", "容差 m", "备注"], expected_rows)

    # 各组统计
    stat_rows = []
    for s in dataset["statistics"]["per_configuration"]:
        row = _stats_row(s)
        distance = s.get("distance") or {}
        row["mean_distance_m"] = distance.get("mean_distance_m")
        row["mean_signed_error_m"] = distance.get("mean_signed_error_m")
        row["mae_m"] = distance.get("mae_m")
        row["max_abs_error_m"] = distance.get("max_abs_error_m")
        row["min_abs_error_m"] = distance.get("min_abs_error_m")
        row["std_error_m"] = distance.get("std_error_m")
        row["rmse_m"] = distance.get("rmse_m")
        row["median_abs_error_m"] = distance.get("median_abs_error_m")
        row["median_signed_error_m"] = distance.get("median_signed_error_m")
        row["p95_abs_error_m"] = distance.get("p95_abs_error_m")
        stat_rows.append(
            {
                "实验编号": s.get("config_code"), "实验名称": s.get("config_name"),
                "类别": s.get("category_name"), "批次": s.get("batch_name"), "测试板": s.get("board_code"),
                "模式": s.get("mode"), "数据状态": s.get("data_status_label"),
                "计划试次": s.get("planned_trials"), "总试次": s.get("total_trials"),
                "有效分母": s.get("resolved_trials"), "检出": s.get("detected_count"),
                "未检出": s.get("not_detected_count"), "检出率": s.get("detection_rate"),
                "正常判定": s.get("normal_count"), "误报": s.get("false_alarm_count"),
                "正常判定率": s.get("normal_judgement_rate"), "误报率": s.get("false_alarm_rate"),
                "极性正确": s.get("polarity_correct_count"), "极性错误": s.get("polarity_wrong_count"),
                "极性正确率": s.get("polarity_accuracy"), "有效定位数": s.get("located_count"),
                "定位合格数": s.get("within_tolerance_count"), "定位合格率": s.get("location_pass_rate"),
                "综合成功数": s.get("comprehensive_success_count"),
                "综合成功率": s.get("comprehensive_success_rate"),
                "无效": s.get("invalid_count"), "拒判": s.get("rejected_count"),
                "无效率": s.get("invalid_rate"), "额外候选": s.get("extra_candidate_count"),
                "平均测量距离 m": row.get("mean_distance_m"),
                "平均有符号误差 m": row.get("mean_signed_error_m"),
                "MAE m": row.get("mae_m"), "最大绝对误差 m": row.get("max_abs_error_m"),
                "最小绝对误差 m": row.get("min_abs_error_m"), "标准差 m": row.get("std_error_m"),
                "RMSE m": row.get("rmse_m"), "中位绝对误差 m": row.get("median_abs_error_m"),
                "P95 绝对误差 m": row.get("p95_abs_error_m"),
                "平均漏检异常数": s.get("average_missed_anomalies"),
                "平均额外候选数": s.get("average_extra_candidates"),
                "严格完整识别率": s.get("strict_complete_rate"),
            }
        )
    _write_table(wb.create_sheet("各组统计"), list(stat_rows[0].keys()) if stat_rows else
                 ["实验编号", "实验名称", "总试次", "检出率", "MAE m"], stat_rows)

    # 总体汇总
    overall = dataset["statistics"]["overall"]
    overall_rows = [
        ("统计口径", "ver 1.0；仅实测记录"),
        ("有实测数据的配置数", dataset["metadata"]["tested_configuration_count"]),
        ("总试次", overall.get("total_trials")),
        ("有效检测分母", overall.get("resolved_trials")),
        ("检出数", overall.get("detected_count")),
        ("未检出数", overall.get("not_detected_count")),
        ("异常检出率", overall.get("anomaly_detection_rate")),
        ("正常判定率", overall.get("normal_judgement_rate")),
        ("正常误报率", overall.get("false_alarm_rate")),
        ("极性正确率", overall.get("polarity_accuracy")),
        ("定位合格率", overall.get("location_pass_rate")),
        ("综合成功率", overall.get("comprehensive_success_rate")),
        ("无效率", overall.get("invalid_rate")),
        ("有效定位数", overall.get("located_count")),
        ("MAE (m)", (overall.get("distance") or {}).get("mae_m")),
        ("RMSE (m)", (overall.get("distance") or {}).get("rmse_m")),
        ("P95 绝对误差 (m)", (overall.get("distance") or {}).get("p95_abs_error_m")),
        ("平均有符号误差 (m)", (overall.get("distance") or {}).get("mean_signed_error_m")),
        ("平均漏检异常数", overall.get("average_missed_anomalies")),
        ("平均额外候选数", overall.get("average_extra_candidates")),
        ("批次", "见“批次汇总”"),
    ]
    ws = wb.create_sheet("总体汇总")
    ws.append(["指标", "数值", "说明"])
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
    explanations = {
        "异常检出率": "检出/(检出+未检出)，未检出在分母中",
        "正常误报率": "误报/(正常判定+误报)",
        "极性正确率": "极性正确的检出/已记录极性的检出",
        "定位合格率": "|误差|≤容差的有效定位/有效定位",
        "综合成功率": "检出+极性+定位+质量全部满足/(检出+未检出)",
        
    }
    for key, value in overall_rows:
        if key in {"异常检出率", "正常判定率", "正常误报率", "极性正确率", "定位合格率", "综合成功率", "无效率"}:
            value = format_percent(value)
        elif isinstance(value, float):
            value = round(value, 6)
        ws.append([key, _excel_safe(value), explanations.get(key, "")])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 24
    ws.column_dimensions["C"].width = 65

    # 批次汇总
    batch_rows = []
    for row in dataset["statistics"].get("by_batch", []):
        batch_rows.append(
            {
                "批次": row.get("batch_name"), "固件": row.get("firmware_version"),
                "模拟前端": row.get("frontend"), "配置数": row.get("config_count"),
                "总试次": row.get("total_trials"), "检出率": row.get("detection_rate"),
                "MAE m": row.get("mae_m"), "P95 m": row.get("p95_abs_error_m"),
                "正常误报率": row.get("false_alarm_rate"), "极性正确率": row.get("polarity_accuracy"),
                "综合成功率": row.get("comprehensive_success_rate"),
            }
        )
    _write_table(wb.create_sheet("批次汇总"), ["批次", "固件", "模拟前端", "配置数", "总试次", "检出率", "MAE m", "P95 m", "正常误报率", "极性正确率", "综合成功率"], batch_rows)

    # 多异常逐异常统计
    multi_rows = []
    for row in multi_anomaly_rows(dataset):
        multi_rows.append(
            {
                "实验编号": row["config_code"], "实验名称": row["config_name"],
                "批次": row["batch_name"], "异常号": row["anomaly_index"],
                "测试板": row["board_code"], "真实距离 m": row["true_distance_m"],
                "预期极性": row["expected_polarity"], "有效次数": row["resolved_trials"],
                "检出次数": row["detected_count"], "检出率": row["detection_rate"],
                "MAE m": row["mae_m"], "平均误差 m": row["mean_error_m"],
                "定位合格率": row["within_tolerance_rate"],
            }
        )
    _write_table(
        wb.create_sheet("多异常逐异常统计"),
        ["实验编号", "实验名称", "批次", "异常号", "测试板", "真实距离 m", "预期极性",
         "有效次数", "检出次数", "检出率", "MAE m", "平均误差 m", "定位合格率"],
        multi_rows,
    )

    # 自动判定
    judgment_rows = [
        {
            "实验编号": j["config_code"], "实验名称": j["config_name"], "批次": j["batch_name"],
            "判定": j["decision_label"], "总试次": j["total_trials"], "依据": j["summary"],
        }
        for j in dataset["judgements"]
    ]
    _write_table(wb.create_sheet("自动判定"), ["实验编号", "实验名称", "批次", "判定", "总试次", "依据"], judgment_rows)

    # 统计规则
    ws = wb.create_sheet("统计规则")
    ws.append(["规则键", "取值", "说明"])
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
    rule_notes = {
        "distance_tolerance_m": "定位合格的距离绝对误差上限",
        "min_detection_rate": "异常组检出率下限",
        "max_false_alarm_rate": "正常组误报率上限",
        "require_polarity": "是否要求检出极性全部正确",
        "edge_as_valid": "EDGE* 是否计入有效数据",
        "min_trials_for_judgement": "自动判定最小试次数",
        "max_invalid_rate": "无效率/拒判率上限",
        "hardware_error_fails": "PN?/OVERFLOW 是否直接判失败",
        "min_location_rate": "定位合格率/多异常完整识别率下限",
    }
    for key, value in dataset["statistics"]["rules"].items():
        ws.append([key, _excel_safe(value), rule_notes.get(key, "")])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 55

    # 数据字典
    ws = wb.create_sheet("数据字典")
    ws.append(["字段/概念", "说明"])
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
    dictionary = [
        ("trial_id", "单次测量唯一 ID；与 configuration_id、run_id 关联。"),
        ("configuration_id", "计划实验配置 ID（79 组矩阵中的一组）。"),
        ("experiment_id", "实验运行 ID（实际执行实例）；同一配置对应一次运行。"),
        ("true_distance_m", "从 DUT 近端参考面到异常作用面的真值距离，不是根据测量反推。"),
        ("measured_distance_m", "系统显示/人工录入的测量距离；未检出为 null。"),
        ("distance_error_m", "measured_distance_m - true_distance_m，仅有效定位有值。"),
        ("detection_status", "detected/not_detected/normal/false_alarm/invalid/rejected。"),
        ("quality_flag", "正常/EDGE*/PN?/OVERFLOW/LOW/OPEN-LIKE/SHORT-LIKE 等原始质量标记。"),
        ("gamma_nominal", "按标称电阻计算的理想理论反射系数，不是实测值。"),
        ("gamma_measured", "按实测电阻计算的理想理论反射系数；没有实测电阻时为 null。"),
        ("mae_m", "有效定位绝对误差的平均值。"),
        ("p95_abs_error_m", "有效定位绝对误差的 95% 分位数（线性插值）。"),
        ("detection_rate", "检出 /（检出 + 未检出）。"),
        ("false_alarm_rate", "误报 /（正常判定 + 误报）。"),
        ("comprehensive_success_rate", "同时满足检出、极性、定位和质量要求的试次比例。"),
    ]
    for key, value in dictionary:
        ws.append([key, value])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 95

    target.parent.mkdir(parents=True, exist_ok=True)
    wb.save(target)
    return target


def _rename(row: dict[str, Any], fields: list[str], labels: list[str]) -> dict[str, Any]:
    return {label: row.get(field) for field, label in zip(fields, labels)}


# ------------------------------------------------------------------ JSON / ZIP
def write_json(path: Path, data: Any) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(_json_safe_copy(data), handle, ensure_ascii=False, indent=2, allow_nan=False)
    return path


def export_excel(db: Database, target: Path | None = None) -> Path:
    stamp = now_iso().replace("-", "").replace(":", "").replace("+", "_")[:15]
    target = Path(target or (config.EXPORTS_DIR / f"TDR_导出_{stamp}.xlsx"))
    return write_excel(db, target)


def export_csv_zip(db: Database, target: Path | None = None) -> Path:
    stamp = now_iso().replace("-", "").replace(":", "").replace("+", "_")[:15]
    target = Path(target or (config.EXPORTS_DIR / f"TDR_CSV_{stamp}.zip"))
    target.parent.mkdir(parents=True, exist_ok=True)
    dataset = build_dataset(db)
    with tempfile.TemporaryDirectory(prefix="tdr_csv_") as tmp:
        csv_dir = Path(tmp) / "TDR_Experiment_Export"
        write_csv_bundle(db, csv_dir, dataset)
        write_json(csv_dir / "metadata" / "full_dataset.json", dataset)
        _write_readme(csv_dir / "README.txt", dataset, attachments_included=False)
        _write_manifest(csv_dir, dataset, csv_dir / "manifest.json", attachments_included=False)
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(csv_dir.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(Path(tmp)).as_posix())
    return target


def export_json(db: Database, target: Path | None = None) -> Path:
    stamp = now_iso().replace("-", "").replace(":", "").replace("+", "_")[:15]
    target = Path(target or (config.EXPORTS_DIR / f"TDR_数据_{stamp}.json"))
    return write_json(target, build_dataset(db))


def export_ai_package(
    db: Database,
    target: Path | None = None,
    *,
    include_attachments: bool = True,
    include_figures: bool = True,
) -> Path:
    stamp = now_iso().replace("-", "").replace(":", "").replace("+", "_")[:15]
    target = Path(target or (config.EXPORTS_DIR / f"TDR_AI_数据包_{stamp}.zip"))
    target.parent.mkdir(parents=True, exist_ok=True)
    dataset = build_dataset(db)
    with tempfile.TemporaryDirectory(prefix="tdr_export_") as tmp:
        root = Path(tmp) / "TDR_Experiment_Export"
        root.mkdir(parents=True)
        # metadata
        metadata_dir = root / "metadata"
        metadata_dir.mkdir()
        write_json(metadata_dir / "boards.json", dataset["boards"])
        write_json(metadata_dir / "cables.json", dataset["cables"])
        write_json(metadata_dir / "cable_configurations.json", dataset["cable_configurations"])
        write_json(metadata_dir / "references.json", dataset["references"])
        write_json(metadata_dir / "configurations.json", dataset["configurations"])
        write_json(metadata_dir / "categories.json", dataset["categories"])
        write_json(metadata_dir / "batches.json", dataset["batches"])
        write_json(metadata_dir / "experiment_runs.json", dataset["experiment_runs"])
        # measurements
        measurements = root / "measurements"
        measurements.mkdir()
        write_csv(measurements / "trials.csv", CSV_TABLES["trials.csv"][0], dataset["trials"])
        write_csv(measurements / "candidates.csv", CSV_TABLES["detected_candidates.csv"][0], dataset["detected_candidates"])
        write_csv(measurements / "expected_anomalies.csv", CSV_TABLES["expected_anomalies.csv"][0], dataset["expected_anomalies"])
        write_csv(
            measurements / "multi_anomaly.csv",
            ["config_id", "config_code", "config_name", "batch_id", "batch_name", "anomaly_index",
             "board_id", "board_code", "board_name", "true_distance_m", "expected_polarity",
             "resolved_trials", "detected_count", "detection_rate", "mae_m", "mean_error_m",
             "within_tolerance_rate"],
            multi_anomaly_rows(dataset),
        )
        write_json(measurements / "full_dataset.json", dataset)
        # statistics
        stats_dir = root / "statistics"
        stats_dir.mkdir()
        write_csv_bundle(db, stats_dir, dataset)
        write_excel(db, stats_dir / "results.xlsx", dataset)
        # figures
        if include_figures:
            from .figures import generate_figures

            generate_figures(dataset, root / "figures")
        # attachments
        if include_attachments:
            _copy_attachments(db, root / "attachments")
        _write_readme(root / "README.txt", dataset, attachments_included=include_attachments)
        _write_manifest(root, dataset, root / "manifest.json", attachments_included=include_attachments)
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(root.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(Path(tmp)).as_posix())
    return target


def _copy_attachments(db: Database, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for attachment in db.query("SELECT * FROM attachments ORDER BY uploaded_at"):
        source = config.DATA_DIR / attachment["relative_path"]
        if not source.exists():
            continue
        dest = target / attachment["run_id"] / attachment["file_name"]
        if dest.exists():
            dest = target / attachment["run_id"] / f"{attachment['id'][:8]}_{attachment['file_name']}"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_manifest(root: Path, dataset: dict[str, Any], target: Path, *, attachments_included: bool) -> None:
    files = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path == target:
            continue
        files.append(
            {
                "path": path.relative_to(root).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": _sha256(path),
            }
        )
    metadata = dataset["metadata"]
    manifest = {
        "package_type": "TDR_Experiment_Export",
        "package_version": "1.0",
        "exported_at": now_iso(),
        "project_name": metadata["project_name"],
        "software": metadata["software"],
        "software_version": metadata["software_version"],
        "data_schema_version": metadata["data_schema_version"],
        "default_firmware_version": metadata["firmware_version_default"],
        "experiment_count": metadata["tested_experiment_run_count"],
        "configuration_count": metadata["configuration_count"],
        "tested_configuration_count": metadata["tested_configuration_count"],
        "experiment_run_count": metadata["experiment_run_count"],
        "trial_count": metadata["trial_count"],
        "candidate_count": metadata["candidate_count"],
        "board_count": metadata["board_count"],
        "attachment_count": metadata["attachment_count"],
        "attachments_included": attachments_included,
        "statistics_rules": metadata["statistics_rules"],
        "units": metadata["units"],
        "files": files,
        "notes": [
            "SHA-256 列表不包含 manifest.json 自身。",
            "未测试配置在 configurations 与 statistics 中带 data_status=not_tested。",
            "统计结果可由 measurements/full_dataset.json 重新计算。",
        ],
    }
    write_json(target, manifest)


def _write_readme(path: Path, dataset: dict[str, Any], *, attachments_included: bool) -> None:
    meta = dataset["metadata"]
    text = f"""TDR Measurement Studio — AI 分析数据包
========================================

项目名称：{meta['project_name']}
导出时间：{now_iso()}
软件版本：{meta['software']} {meta['software_version']}
数据结构版本：{meta['data_schema_version']}
默认固件版本：{meta['firmware_version_default']}

数据范围
--------
实验配置：{meta['configuration_count']} 组（其中已测试 {meta['tested_configuration_count']} 组）
实验运行：{meta['experiment_run_count']} 次
逐次测量：{meta['trial_count']} 条
检测候选：{meta['candidate_count']} 条
附件：{'已包含' if attachments_included else '未包含'}

目录说明
--------
manifest.json                       文件清单、SHA-256、数据结构版本
README.txt                          本文件
metadata/boards.json                测试板与理论反射系数
metadata/cables.json               线缆资产
metadata/cable_configurations.json  线缆组合及顺序
metadata/references.json            健康参考
metadata/configurations.json        实验配置（含未测试配置）
metadata/categories.json            实验类别
metadata/batches.json               实验批次
metadata/experiment_runs.json       实验运行条件（固件/参考/前端）
measurements/trials.csv             全部单次测量（含未检出）
measurements/candidates.csv         多异常候选与匹配
measurements/expected_anomalies.csv 多异常真实异常定义
measurements/full_dataset.json      完整结构化数据，供 AI 读取
statistics/summary.csv              总体/批次统计
statistics/statistics.csv           每组配置统计
statistics/results.xlsx             完整 Excel（含全部工作表）
figures/                            基于真实数据生成的 PNG 图表
attachments/                        原始 UART/RAW/CORR/截图等附件

重要口径
--------
1. 理论反射系数由理想集总电阻公式计算，不是仪器实测反射系数。
2. 未检出试次保留在总试次与检出率分母，但不参与距离均值；缺失值为 null。
3. 无效/拒判保留在总试次与无效率中，不进入检出率分母。
4. “未测试”/“数据不足”不等于“通过”。
5. 不同批次、固件、前端和健康参考条件默认分别统计，不静默混合。
6. 统计规则见 manifest.json 的 statistics_rules 与 full_dataset.json 的
   statistics.rules；原始记录足以独立重算。

建议的 AI 分析入口
------------------
优先读取 measurements/full_dataset.json；如只需表格，读取
measurements/trials.csv、candidates.csv、expected_anomalies.csv 及
statistics/statistics.csv。所有 ID 字段可用于关联。
"""
    path.write_text(text, encoding="utf-8")
