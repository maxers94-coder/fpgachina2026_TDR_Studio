"""实验统计核心。

关键约定（同时写入界面与导出说明）：
* 总试次 = 已保存的全部试次，包括未检出、无效和拒判。
* 检出率 = 检出 / (检出 + 未检出)。无效/拒判不进入该分母，但保留在总试次与无效率中。
* 极性正确率 = 检出且已记录极性中，极性正确所占比例。
* 定位合格率 = 有效定位结果中，|误差| ≤ 容差所占比例。
* 综合成功率 = 满足检出 + 极性规则 + 定位容差 + 质量可用 的试次 / (检出 + 未检出)。
* 未检出不得当作 0 m；没有有效数据时统计值为 None，界面显示“不适用”。
* 正常板单独统计正常判定率与误报率，不使用异常检出率。
"""
from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Any, Iterable

from .matching import INVALID_QUALITY

DEFAULT_RULES: dict[str, Any] = {
    "distance_tolerance_m": 0.60,
    "min_detection_rate": 0.95,
    "max_false_alarm_rate": 0.05,
    "require_polarity": True,
    "edge_as_valid": False,
    "min_trials_for_judgement": 1,
    "max_invalid_rate": 0.20,
    "hardware_error_fails": True,
    "min_location_rate": 0.90,
}

RESOLVED_ANOMALY_STATUSES = {"detected", "not_detected"}
RESOLVED_NORMAL_STATUSES = {"normal", "false_alarm"}


def normalize_rules(rules: dict[str, Any] | None = None) -> dict[str, Any]:
    result = dict(DEFAULT_RULES)
    if rules:
        for key in DEFAULT_RULES:
            if key in rules and rules[key] is not None:
                result[key] = rules[key]
    for key in (
        "distance_tolerance_m",
        "min_detection_rate",
        "max_false_alarm_rate",
        "min_trials_for_judgement",
        "max_invalid_rate",
        "min_location_rate",
    ):
        try:
            result[key] = float(result[key])
        except (TypeError, ValueError):
            result[key] = DEFAULT_RULES[key]
    for key in ("require_polarity", "edge_as_valid", "hardware_error_fails"):
        result[key] = bool(result[key])
    return result


def quality_usable(quality_flag: str | None, edge_as_valid: bool = False) -> bool:
    flag = (quality_flag or "正常").strip()
    if flag in INVALID_QUALITY:
        return False
    if flag == "EDGE*" and not edge_as_valid:
        return False
    return True


def polarity_correct(expected: str | None, actual: str | None) -> bool | None:
    if expected not in {"positive", "negative"}:
        return None
    if actual not in {"positive", "negative"}:
        return None
    return expected == actual


def _finite_number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(number) or math.isinf(number):
        return None
    return number


def percentile_linear(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    pos = (len(ordered) - 1) * q
    low = int(math.floor(pos))
    high = int(math.ceil(pos))
    if low == high:
        return ordered[low]
    return ordered[low] + (ordered[high] - ordered[low]) * (pos - low)


def distance_metrics(errors: list[float], distances: list[float] | None = None) -> dict[str, Any]:
    clean_errors = [float(e) for e in errors if _finite_number(e) is not None]
    clean_distances = [float(d) for d in (distances or []) if _finite_number(d) is not None]
    n = len(clean_errors)
    if n == 0:
        return {
            "n": 0,
            "mean_distance_m": None,
            "mean_signed_error_m": None,
            "mae_m": None,
            "max_abs_error_m": None,
            "min_abs_error_m": None,
            "std_error_m": None,
            "rmse_m": None,
            "median_abs_error_m": None,
            "median_signed_error_m": None,
            "p95_abs_error_m": None,
        }
    abs_errors = [abs(e) for e in clean_errors]
    mean_error = sum(clean_errors) / n
    variance = (
        sum((e - mean_error) ** 2 for e in clean_errors) / (n - 1) if n >= 2 else None
    )
    return {
        "n": n,
        "mean_distance_m": (sum(clean_distances) / len(clean_distances)) if clean_distances else None,
        "mean_signed_error_m": mean_error,
        "mae_m": sum(abs_errors) / n,
        "max_abs_error_m": max(abs_errors),
        "min_abs_error_m": min(abs_errors),
        "std_error_m": math.sqrt(variance) if variance is not None else None,
        "rmse_m": math.sqrt(sum(e * e for e in clean_errors) / n),
        "median_abs_error_m": percentile_linear(abs_errors, 0.5),
        "median_signed_error_m": percentile_linear(clean_errors, 0.5),
        "p95_abs_error_m": percentile_linear(abs_errors, 0.95),
    }


def _base_result(mode: str) -> dict[str, Any]:
    return {
        "mode": mode,
        "has_data": False,
        "total_trials": 0,
        "planned_trials": 0,
        "status_counts": {
            "detected": 0,
            "not_detected": 0,
            "normal": 0,
            "false_alarm": 0,
            "invalid": 0,
            "rejected": 0,
        },
        "resolved_trials": 0,
        "invalid_count": 0,
        "rejected_count": 0,
        "invalid_rate": None,
        "detected_count": 0,
        "not_detected_count": 0,
        "detection_rate": None,
        "miss_rate": None,
        "polarity_correct_count": 0,
        "polarity_wrong_count": 0,
        "polarity_unknown_count": 0,
        "polarity_accuracy": None,
        "located_count": 0,
        "within_tolerance_count": 0,
        "location_pass_rate": None,
        "comprehensive_success_count": 0,
        "comprehensive_success_rate": None,
        "extra_candidate_count": 0,
        "quality_issue_counts": {},
        "distance": distance_metrics([]),
        "normal_count": 0,
        "false_alarm_count": 0,
        "normal_judgement_rate": None,
        "false_alarm_rate": None,
        "expected_anomaly_count": 0,
        "matched_anomaly_count": 0,
        "all_detected_count": 0,
        "strict_complete_count": 0,
        "average_missed_anomalies": None,
        "average_extra_candidates": None,
        "any_detection_rate": None,
        "all_detected_rate": None,
        "strict_complete_rate": None,
        "per_anomaly": [],
        "by_anomaly_count": [],
        "ambiguous_trials": 0,
        "multi_resolved_trials": 0,
        "multi_detected_count": 0,
        "_errors": [],
        "_distances": [],
        "_success_count_anomaly": 0,
        "definitions": {
            "detection_rate": "检出试次 / (检出 + 未检出)",
            "polarity_accuracy": "极性正确的检出试次 / 已记录极性的检出试次",
            "location_pass_rate": "|测量距离-真值|≤容差的有效定位试次 / 有效定位试次",
            "comprehensive_success_rate": "检出且极性、定位、质量均满足规则的试次 / (检出 + 未检出)",
            "invalid_rate": "(无效 + 拒判) / 总试次",
            "distance": "仅基于有效定位结果；未检出、无效、拒判不参与距离统计",
        },
    }


def summarize_trials(
    *,
    mode: str,
    trials: Iterable[dict[str, Any]],
    planned_trials: int = 0,
    expected_polarity: str = "none",
    true_distance_m: float | None = None,
    expected_anomalies: list[dict[str, Any]] | None = None,
    candidates_by_trial: dict[str, list[dict[str, Any]]] | None = None,
    rules: dict[str, Any] | None = None,
) -> dict[str, Any]:
    rules = normalize_rules(rules)
    trial_list = list(trials)
    if mode == "normal":
        return _summarize_normal(trial_list, planned_trials, rules)
    if mode == "multi":
        return _summarize_multi(
            trial_list,
            planned_trials,
            expected_anomalies or [],
            candidates_by_trial or {},
            rules,
        )
    return _summarize_single(
        trial_list,
        planned_trials,
        expected_polarity,
        true_distance_m,
        rules,
    )


def _count_common(result: dict[str, Any], trials: list[dict[str, Any]], rules: dict[str, Any]) -> None:
    result["total_trials"] = len(trials)
    counts = Counter(str(t.get("detection_status", "")) for t in trials)
    for key in result["status_counts"]:
        result["status_counts"][key] = int(counts.get(key, 0))
    result["invalid_count"] = result["status_counts"]["invalid"]
    result["rejected_count"] = result["status_counts"]["rejected"]
    result["invalid_rate"] = (
        (result["invalid_count"] + result["rejected_count"]) / len(trials) if trials else None
    )
    quality_counter = Counter(
        (t.get("quality_flag") or "正常").strip()
        for t in trials
        if (t.get("quality_flag") or "正常").strip() != "正常"
    )
    result["quality_issue_counts"] = dict(quality_counter)
    result["extra_candidate_count"] = sum(int(t.get("extra_candidate_count") or 0) for t in trials)
    result["has_data"] = bool(trials)
    if trials:
        result["max_quality_invalid"] = any(
            not quality_usable(t.get("quality_flag"), rules["edge_as_valid"]) for t in trials
        )


def _summarize_single(
    trials: list[dict[str, Any]],
    planned_trials: int,
    expected_polarity: str,
    true_distance_m: float | None,
    rules: dict[str, Any],
) -> dict[str, Any]:
    result = _base_result("single")
    result["planned_trials"] = int(planned_trials or 0)
    _count_common(result, trials, rules)
    errors: list[float] = []
    distances: list[float] = []
    success = 0

    for trial in trials:
        status = trial.get("detection_status")
        if status not in RESOLVED_ANOMALY_STATUSES:
            continue
        result["resolved_trials"] += 1
        if status == "not_detected":
            result["not_detected_count"] += 1
            continue
        result["detected_count"] += 1
        measured = _finite_number(trial.get("measured_distance_m"))
        truth = _finite_number(trial.get("true_distance_m"))
        if truth is None:
            truth = _finite_number(true_distance_m)
        actual_pol = trial.get("polarity")
        expected_pol = expected_polarity or "none"
        pol_ok = polarity_correct(expected_pol, actual_pol)
        if pol_ok is None:
            result["polarity_unknown_count"] += 1
        elif pol_ok:
            result["polarity_correct_count"] += 1
        else:
            result["polarity_wrong_count"] += 1

        usable = quality_usable(trial.get("quality_flag"), rules["edge_as_valid"])
        located = measured is not None and truth is not None and usable
        within = False
        if located:
            error = measured - truth
            errors.append(error)
            distances.append(measured)
            result["located_count"] += 1
            result["_errors"].append(error)
            result["_distances"].append(measured)
            within = abs(error) <= float(rules["distance_tolerance_m"]) + 1e-12
            if within:
                result["within_tolerance_count"] += 1
        polarity_requirement = pol_ok is True if rules["require_polarity"] else True
        if located and within and polarity_requirement and usable:
            success += 1
    result["comprehensive_success_count"] = success
    if result["resolved_trials"]:
        result["detection_rate"] = result["detected_count"] / result["resolved_trials"]
        result["miss_rate"] = result["not_detected_count"] / result["resolved_trials"]
        result["comprehensive_success_rate"] = success / result["resolved_trials"]
    polarity_denominator = result["polarity_correct_count"] + result["polarity_wrong_count"]
    if polarity_denominator:
        result["polarity_accuracy"] = result["polarity_correct_count"] / polarity_denominator
    if result["located_count"]:
        result["location_pass_rate"] = result["within_tolerance_count"] / result["located_count"]
    result["distance"] = distance_metrics(errors, distances)
    result["_success_count_anomaly"] = success
    result["expected_anomaly_count"] = 1 if true_distance_m is not None else 0
    result["matched_anomaly_count"] = result["located_count"]
    return result


def _summarize_normal(
    trials: list[dict[str, Any]], planned_trials: int, rules: dict[str, Any]
) -> dict[str, Any]:
    result = _base_result("normal")
    result["planned_trials"] = int(planned_trials or 0)
    _count_common(result, trials, rules)
    normal_count = 0
    false_alarm_count = 0
    for trial in trials:
        status = trial.get("detection_status")
        if status not in RESOLVED_NORMAL_STATUSES:
            continue
        result["resolved_trials"] += 1
        if status == "normal":
            normal_count += 1
        else:
            false_alarm_count += 1
    result["normal_count"] = normal_count
    result["false_alarm_count"] = false_alarm_count
    result["comprehensive_success_count"] = normal_count
    if result["resolved_trials"]:
        result["normal_judgement_rate"] = normal_count / result["resolved_trials"]
        result["false_alarm_rate"] = false_alarm_count / result["resolved_trials"]
        result["comprehensive_success_rate"] = normal_count / result["resolved_trials"]
        result["detection_rate"] = None
    else:
        result["normal_judgement_rate"] = None
        result["false_alarm_rate"] = None
    result["detection_rate"] = None
    result["definitions"]["normal_judgement_rate"] = "正常判定试次 / (正常判定 + 误报)"
    result["definitions"]["false_alarm_rate"] = "误报试次 / (正常判定 + 误报)"
    return result


def _summarize_multi(
    trials: list[dict[str, Any]],
    planned_trials: int,
    expected_anomalies: list[dict[str, Any]],
    candidates_by_trial: dict[str, list[dict[str, Any]]],
    rules: dict[str, Any],
) -> dict[str, Any]:
    result = _base_result("multi")
    result["planned_trials"] = int(planned_trials or 0)
    _count_common(result, trials, rules)
    expected_by_id = {e.get("id"): e for e in expected_anomalies}
    expected_count = len(expected_anomalies)
    result["expected_anomaly_count"] = expected_count
    per_anomaly: dict[str, dict[str, Any]] = {}
    for exp in expected_anomalies:
        eid = exp.get("id")
        per_anomaly[eid] = {
            "expected_id": eid,
            "anomaly_index": exp.get("anomaly_index"),
            "board_id": exp.get("board_id"),
            "board_code": exp.get("board_code", ""),
            "board_name": exp.get("board_name", ""),
            "true_distance_m": exp.get("true_distance_m"),
            "expected_polarity": exp.get("expected_polarity"),
            "resolved_trials": 0,
            "detected_count": 0,
            "polarity_correct_count": 0,
            "located_count": 0,
            "within_tolerance_count": 0,
            "detection_rate": None,
            "mae_m": None,
            "mean_error_m": None,
            "_errors": [],
        }

    all_errors: list[float] = []
    all_distances: list[float] = []
    total_missed = 0
    total_extra = 0
    strict_complete = 0
    all_detected_count = 0
    any_detected_count = 0
    by_count: dict[int, dict[str, Any]] = defaultdict(
        lambda: {"resolved_trials": 0, "strict_complete": 0, "any_detected": 0, "missed": 0, "extra": 0}
    )

    for trial in trials:
        if trial.get("detection_status") not in RESOLVED_ANOMALY_STATUSES:
            continue
        result["resolved_trials"] += 1
        status = trial.get("detection_status")
        trial_id = trial.get("id")
        candidates = candidates_by_trial.get(trial_id, [])
        # 统计始终使用当前容差重新执行匹配，确保规则变更后统计可复算；
        # 数据库中的 matched_expected_id 保留为保存时的历史快照。
        from .matching import match_candidates

        match_result = match_candidates(
            expected_anomalies,
            candidates,
            default_tolerance_m=float(rules["distance_tolerance_m"]),
        )
        matched_by_expected: dict[str, dict[str, Any]] = {
            assignment["expected_id"]: assignment["candidate"]
            for assignment in match_result["assignments"]
        }
        matched_candidate_ids: set[str] = set(match_result["matched_candidate_ids"])
        matched_count = len(matched_by_expected)
        missed = max(0, expected_count - matched_count)
        extra = max(0, len(candidates) - len(matched_candidate_ids))
        if match_result.get("ambiguous"):
            result["ambiguous_trials"] += 1
        total_missed += missed
        total_extra += extra
        group = by_count[expected_count]
        group["resolved_trials"] += 1
        group["missed"] += missed
        group["extra"] += extra
        if status == "detected" or matched_count > 0:
            result["detected_count"] += 1
            any_detected_count += 1
            group["any_detected"] += 1
        else:
            result["not_detected_count"] += 1
        if expected_count == 0:
            all_detected = len(candidates) == 0
        else:
            all_detected = matched_count == expected_count and missed == 0
        if all_detected:
            all_detected_count += 1

        trial_pol_ok = True
        trial_locations_ok = True
        trial_quality_ok = True
        for exp in expected_anomalies:
            eid = exp.get("id")
            pa = per_anomaly[eid]
            pa["resolved_trials"] += 1
            cand = matched_by_expected.get(eid)
            if not cand:
                trial_pol_ok = False
                trial_locations_ok = False
                continue
            pa["detected_count"] += 1
            actual_pol = cand.get("polarity")
            expected_pol = exp.get("expected_polarity")
            correct = polarity_correct(expected_pol, actual_pol)
            if correct:
                pa["polarity_correct_count"] += 1
                result["polarity_correct_count"] += 1
            elif correct is False:
                result["polarity_wrong_count"] += 1
                trial_pol_ok = False
            else:
                result["polarity_unknown_count"] += 1
                trial_pol_ok = False
            measured = _finite_number(cand.get("measured_distance_m"))
            truth = _finite_number(exp.get("true_distance_m"))
            usable = quality_usable(cand.get("quality_flag"), rules["edge_as_valid"])
            if not usable:
                trial_quality_ok = False
            if measured is not None and truth is not None and usable:
                error = measured - truth
                pa["located_count"] += 1
                pa["_errors"].append(error)
                all_errors.append(error)
                all_distances.append(measured)
                result["located_count"] += 1
                within = abs(error) <= float(rules["distance_tolerance_m"]) + 1e-12
                if within:
                    pa["within_tolerance_count"] += 1
                    result["within_tolerance_count"] += 1
                else:
                    trial_locations_ok = False
            else:
                trial_locations_ok = False
        result["matched_anomaly_count"] += matched_count
        if (
            all_detected
            and extra == 0
            and trial_pol_ok
            and trial_locations_ok
            and trial_quality_ok
            and (not rules["require_polarity"] or trial_pol_ok)
        ):
            strict_complete += 1
            group["strict_complete"] += 1
        if len(candidates) == 0 and status == "detected":
            # 数据异常：状态为检出但无候选，计为需复核
            result["ambiguous_trials"] += 1

    result["comprehensive_success_count"] = strict_complete
    result["all_detected_count"] = all_detected_count
    result["strict_complete_count"] = strict_complete
    if result["resolved_trials"]:
        result["detection_rate"] = result["detected_count"] / result["resolved_trials"]
        result["any_detection_rate"] = result["detection_rate"]
        result["all_detected_rate"] = all_detected_count / result["resolved_trials"]
        result["strict_complete_rate"] = strict_complete / result["resolved_trials"]
        result["comprehensive_success_rate"] = strict_complete / result["resolved_trials"]
        result["average_missed_anomalies"] = total_missed / result["resolved_trials"]
        result["average_extra_candidates"] = total_extra / result["resolved_trials"]
        result["miss_rate"] = total_missed / (
            result["resolved_trials"] * expected_count
        ) if expected_count else None
    result["extra_candidate_count"] = total_extra
    policy_denominator = result["polarity_correct_count"] + result["polarity_wrong_count"]
    if policy_denominator:
        result["polarity_accuracy"] = result["polarity_correct_count"] / policy_denominator
    if result["located_count"]:
        result["location_pass_rate"] = result["within_tolerance_count"] / result["located_count"]
    result["multi_resolved_trials"] = result["resolved_trials"]
    result["multi_detected_count"] = result["detected_count"]
    result["distance"] = distance_metrics(all_errors, all_distances)
    result["_errors"] = all_errors
    result["_distances"] = all_distances
    result["_success_count_anomaly"] = strict_complete

    for pa in per_anomaly.values():
        if pa["resolved_trials"]:
            pa["detection_rate"] = pa["detected_count"] / pa["resolved_trials"]
            if pa["located_count"]:
                pa["within_tolerance_rate"] = pa["within_tolerance_count"] / pa["located_count"]
                pa["mae_m"] = sum(abs(e) for e in pa["_errors"]) / len(pa["_errors"])
                pa["mean_error_m"] = sum(pa["_errors"]) / len(pa["_errors"])
        pa.pop("_errors", None)
    result["per_anomaly"] = list(per_anomaly.values())
    result["by_anomaly_count"] = [
        {
            "expected_count": key,
            "resolved_trials": value["resolved_trials"],
            "strict_complete_rate": (
                value["strict_complete"] / value["resolved_trials"] if value["resolved_trials"] else None
            ),
            "any_detection_rate": (
                value["any_detected"] / value["resolved_trials"] if value["resolved_trials"] else None
            ),
            "average_missed": (
                value["missed"] / value["resolved_trials"] if value["resolved_trials"] else None
            ),
            "average_extra": (
                value["extra"] / value["resolved_trials"] if value["resolved_trials"] else None
            ),
        }
        for key, value in sorted(by_count.items())
    ]
    return result


def aggregate_stats(stats_list: list[dict[str, Any]]) -> dict[str, Any]:
    """将多个配置的统计合并为总体统计。保留 normal/anomaly 两套口径。"""
    if not stats_list:
        return _base_result("aggregate")
    modes = {s.get("mode") for s in stats_list if s.get("total_trials", 0) > 0}
    mode = "mixed" if len(modes) > 1 else (next(iter(modes)) if modes else "aggregate")
    result = _base_result(mode)
    result["has_data"] = any(s.get("total_trials", 0) > 0 for s in stats_list)
    result["config_count"] = len(stats_list)
    all_errors: list[float] = []
    all_distances: list[float] = []
    for stats in stats_list:
        result["total_trials"] += stats.get("total_trials", 0)
        result["resolved_trials"] += stats.get("resolved_trials", 0)
        result["detected_count"] += stats.get("detected_count", 0)
        result["not_detected_count"] += stats.get("not_detected_count", 0)
        result["polarity_correct_count"] += stats.get("polarity_correct_count", 0)
        result["polarity_wrong_count"] += stats.get("polarity_wrong_count", 0)
        result["polarity_unknown_count"] += stats.get("polarity_unknown_count", 0)
        result["located_count"] += stats.get("located_count", 0)
        result["within_tolerance_count"] += stats.get("within_tolerance_count", 0)
        result["comprehensive_success_count"] += stats.get("comprehensive_success_count", 0)
        result["_success_count_anomaly"] += stats.get("_success_count_anomaly", 0)
        result["invalid_count"] += stats.get("invalid_count", 0)
        result["rejected_count"] += stats.get("rejected_count", 0)
        result["extra_candidate_count"] += stats.get("extra_candidate_count", 0)
        result["normal_count"] = result.get("normal_count", 0) + stats.get("normal_count", 0)
        result["false_alarm_count"] = result.get("false_alarm_count", 0) + stats.get(
            "false_alarm_count", 0
        )
        for key, count in stats.get("status_counts", {}).items():
            result["status_counts"][key] = result["status_counts"].get(key, 0) + count
        for key, count in stats.get("quality_issue_counts", {}).items():
            result["quality_issue_counts"][key] = result["quality_issue_counts"].get(key, 0) + count
        all_errors.extend(stats.get("_errors", []))
        all_distances.extend(stats.get("_distances", []))
        result["planned_trials"] += stats.get("planned_trials", 0)
        result["ambiguous_trials"] += stats.get("ambiguous_trials", 0)
        result["expected_anomaly_count"] += stats.get("expected_anomaly_count", 0)
        result["matched_anomaly_count"] += stats.get("matched_anomaly_count", 0)
        result["all_detected_count"] += stats.get("all_detected_count", 0)
        result["strict_complete_count"] = result.get("strict_complete_count", 0) + stats.get(
            "strict_complete_count", 0
        )
        if stats.get("mode") == "multi":
            result["multi_resolved_trials"] += stats.get("resolved_trials", 0)
            result["multi_detected_count"] += stats.get("detected_count", 0)
        if stats.get("average_missed_anomalies") is not None:
            result["_missed_sum"] = result.get("_missed_sum", 0.0) + (
                stats["average_missed_anomalies"] * stats.get("resolved_trials", 0)
            )
        if stats.get("average_extra_candidates") is not None:
            result["_extra_sum"] = result.get("_extra_sum", 0.0) + (
                stats["average_extra_candidates"] * stats.get("resolved_trials", 0)
            )
    anomaly_resolved = sum(
        s.get("resolved_trials", 0)
        for s in stats_list
        if s.get("mode") in {"single", "multi"}
    )
    normal_resolved = sum(
        s.get("resolved_trials", 0) for s in stats_list if s.get("mode") == "normal"
    )
    if result["total_trials"]:
        result["invalid_rate"] = (result["invalid_count"] + result["rejected_count"]) / result[
            "total_trials"
        ]
    if anomaly_resolved:
        result["anomaly_detection_rate"] = result["detected_count"] / anomaly_resolved
        result["detection_rate"] = result["anomaly_detection_rate"]
        result["miss_rate"] = result["not_detected_count"] / anomaly_resolved
        result["location_pass_rate"] = (
            result["within_tolerance_count"] / result["located_count"]
            if result["located_count"]
            else None
        )
        pol_denom = result["polarity_correct_count"] + result["polarity_wrong_count"]
        result["polarity_accuracy"] = (
            result["polarity_correct_count"] / pol_denom if pol_denom else None
        )
    if normal_resolved:
        result["normal_judgement_rate"] = result.get("normal_count", 0) / normal_resolved
        result["false_alarm_rate"] = result.get("false_alarm_count", 0) / normal_resolved
    if result["resolved_trials"]:
        result["comprehensive_success_rate"] = result[
            "comprehensive_success_count"
        ] / result["resolved_trials"]
    multi_resolved = sum(s.get("resolved_trials", 0) for s in stats_list if s.get("mode") == "multi")
    if multi_resolved:
        result["average_missed_anomalies"] = result.get("_missed_sum", 0.0) / multi_resolved
        result["average_extra_candidates"] = result.get("_extra_sum", 0.0) / multi_resolved
        result["any_detection_rate"] = result["multi_detected_count"] / multi_resolved
        result["all_detected_rate"] = result["all_detected_count"] / multi_resolved
        result["strict_complete_rate"] = result.get("strict_complete_count", 0) / multi_resolved
    result["distance"] = distance_metrics(all_errors, all_distances)
    result["_errors"] = all_errors
    result["_distances"] = all_distances
    for key in ("_missed_sum", "_extra_sum"):
        result.pop(key, None)
    return result


def strip_internal(stats: dict[str, Any]) -> dict[str, Any]:
    """导出前移除内部中间数组。"""
    return {k: v for k, v in stats.items() if not str(k).startswith("_")}
