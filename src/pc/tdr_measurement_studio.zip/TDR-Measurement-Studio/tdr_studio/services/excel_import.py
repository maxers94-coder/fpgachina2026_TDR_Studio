"""FW63 初验 Excel 测量矩阵导入。

导入策略：
* 先定位表头并按同义字段映射，不依赖固定列号。
* 不会丢弃任何有编号的行；重复编号自动生成唯一后缀并写入报告。
* 仅导入“计划矩阵”和测试板资产；不把模板中的实测列当作正式测量结果。
* 每一行原始字段保存在 experiment_configs.source_payload，导入报告另存 JSON。
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from .. import config
from ..database import Database
from ..repositories.boards import BoardRepository
from ..repositories.cables import CableRepository
from ..repositories.experiments import ExperimentRepository
from ..repositories.organization import BatchRepository, CategoryRepository
from ..repositories.references import ReferenceRepository
from ..utils import json_dumps, new_id, now_iso, safe_float, safe_int

try:  # 通过 config 注入 vendor 路径后导入
    import openpyxl
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("缺少 openpyxl，无法导入 Excel") from exc


HEADER_ALIASES = {
    "code": ["编号", "实验编号", "配置编号", "id"],
    "priority": ["优先", "优先级", "prio"],
    "category": ["组", "组别", "类别"],
    "distance": ["真值点位", "真值位置", "目标距离", "标称距离", "定位距离", "常值定位"],
    "near": ["板前线段", "板前"],
    "far": ["板后线段", "板后"],
    "board_text": ["试件", "测试板", "端点", "异常类型"],
    "gamma": ["γ理论", "gamma", "反射率", "反射系数"],
    "expected_response": ["预期响应", "预期结果"],
    "repeats": ["计划测量次数", "计划次数", "重复次数", "测量次数"],
    "reference": ["参考/基线", "参考", "基线"],
    "notes": ["操作说明", "备注", "特别注意", "说明"],
    "source_status": ["实测状态", "实验状态"],
    "source_measured": ["实测距离", "测量距离"],
    "end_load": ["末端负载"],
}

BOARD_DEFINITIONS: dict[str, dict[str, Any]] = {
    "A": {
        "code": "A", "name": "27Ω 串联异常", "board_type": "series",
        "nominal_ohm": 27.0, "notes": "Excel 矩阵 A=27Ω 串联；理论 Γ 由公式自动计算。",
    },
    "B": {
        "code": "B", "name": "4.7Ω 串联异常", "board_type": "series",
        "nominal_ohm": 4.7, "notes": "Excel 矩阵 B=4.7Ω 串联。",
    },
    "C": {
        "code": "C", "name": "470Ω 并联异常", "board_type": "shunt",
        "nominal_ohm": 470.0, "notes": "Excel 矩阵 C=470Ω 并联。",
    },
    "D": {
        "code": "D", "name": "1kΩ 并联异常", "board_type": "shunt",
        "nominal_ohm": 1000.0, "notes": "Excel 矩阵 D=1kΩ 并联。",
    },
    "E": {
        "code": "E", "name": "Normal 正常参考板", "board_type": "normal",
        "nominal_ohm": None, "notes": "Excel 矩阵 Normal / N。",
    },
    "F": {
        "code": "F", "name": "2Ω 串联异常", "board_type": "series",
        "nominal_ohm": 2.0, "notes": "Excel 矩阵 F=2Ω 串联。",
    },
    "G": {
        "code": "G", "name": "1Ω 串联异常", "board_type": "series",
        "nominal_ohm": 1.0, "notes": "Excel 矩阵 S1=1Ω 串联（挑战项）。",
    },
    "H": {
        "code": "H", "name": "2kΩ 并联异常", "board_type": "shunt",
        "nominal_ohm": 2000.0, "notes": "Excel 矩阵 P2000=2kΩ 并联（挑战项）。",
    },
    "N2": {
        "code": "N2", "name": "Normal N2 第二块正常参考板", "board_type": "normal",
        "nominal_ohm": None, "notes": "独立物理板，不与 Normal N 混为同一块。",
    },
    "OPEN": {
        "code": "OPEN", "name": "末端开路夹具", "board_type": "open",
        "nominal_ohm": None, "notes": "理想开路，理论 Γ=+1。",
    },
    "SHORT": {
        "code": "SHORT", "name": "末端短路夹具", "board_type": "short",
        "nominal_ohm": None, "notes": "理想短路，理论 Γ=-1。",
    },
}


def _norm_header(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip().lower()
    text = text.replace("（", "(").replace("）", ")").replace("：", ":")
    text = re.sub(r"\s+", "", text)
    return text


def _find_header(headers: list[Any]) -> dict[str, int]:
    normalized = [_norm_header(h) for h in headers]
    mapping: dict[str, int] = {}
    for field, aliases in HEADER_ALIASES.items():
        for index, header in enumerate(normalized):
            if any(_norm_header(alias) in header for alias in aliases):
                mapping[field] = index
                break
    return mapping


def _locate_sheet(wb) -> tuple[Any, int, dict[str, int]]:
    candidates = []
    for ws in wb.worksheets:
        for row_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=min(ws.max_row, 20), values_only=True), 1):
            headers = list(row)
            mapping = _find_header(headers)
            score = 0
            if "code" in mapping:
                score += 3
            if "repeats" in mapping:
                score += 2
            if "board_text" in mapping:
                score += 2
            if "category" in mapping:
                score += 2
            if score >= 7:
                candidates.append((score, ws, row_idx, mapping))
    if not candidates:
        raise ValueError("未找到测量矩阵表头（至少需要编号、组、试件、计划测量次数列）")
    candidates.sort(key=lambda item: item[0], reverse=True)
    _, ws, header_row, mapping = candidates[0]
    required = {"code", "category", "board_text", "repeats"}
    missing = required - set(mapping)
    if missing:
        raise ValueError(f"测量矩阵缺少必要列：{sorted(missing)}")
    return ws, header_row, mapping


def _cell(row: tuple, mapping: dict[str, int], field: str) -> Any:
    index = mapping.get(field)
    if index is None or index >= len(row):
        return None
    return row[index]


def _parse_board_text(text: str) -> list[dict[str, Any]]:
    """解析试件/端点描述，返回命中的板定义列表。"""
    raw = str(text or "").strip()
    upper = raw.upper().replace(" ", "")
    matches: list[dict[str, Any]] = []
    # 多异常表达式：D15 + A25 + C30 + B33
    multi = re.findall(r"([A-H])\s*(\d+(?:\.\d+)?)", raw, flags=re.IGNORECASE)
    if len(multi) >= 2:
        for code, distance in multi:
            definition = BOARD_DEFINITIONS.get(code.upper())
            if definition:
                matches.append({**definition, "distance_m": float(distance)})
        if matches:
            return matches
    if "N2" in upper:
        return [{**BOARD_DEFINITIONS["N2"], "distance_m": None}]
    if "NORMAL" in upper or upper in {"N", "正常", "正常前后对照"} or "正常" in raw:
        return [{**BOARD_DEFINITIONS["E"], "distance_m": None}]
    if "开路" in raw or "OPEN" in upper:
        return [{**BOARD_DEFINITIONS["OPEN"], "distance_m": None}]
    if "短路" in raw or "SHORT" in upper:
        return [{**BOARD_DEFINITIONS["SHORT"], "distance_m": None}]
    patterns = [
        (r"S\s*27", "A"),
        (r"S\s*4\.7", "B"),
        (r"S\s*2(?!\d)", "F"),
        (r"S\s*1(?!\d)", "G"),
        (r"P\s*470", "C"),
        (r"P\s*1000|1K", "D"),
        (r"P\s*2000|2K", "H"),
    ]
    for pattern, code in patterns:
        if re.search(pattern, raw, flags=re.IGNORECASE):
            return [{**BOARD_DEFINITIONS[code], "distance_m": None}]
    return []


def _parse_multi_distances(text: str) -> list[dict[str, Any]]:
    return _parse_board_text(text) if "+" in str(text) else []


def _ensure_board(
    db: Database,
    board_repo: BoardRepository,
    definition: dict[str, Any],
    warnings: list[str],
) -> dict[str, Any] | None:
    existing = board_repo.get_by_code(definition["code"])
    if existing:
        if existing["board_type"] != definition["board_type"]:
            warnings.append(
                f"测试板 {definition['code']} 已存在但类型为 {existing['board_type']}，"
                f"Excel 期望 {definition['board_type']}；保留现有资产，请人工核对。"
            )
        if existing["status"] != "available":
            warnings.append(f"测试板 {definition['code']} 当前状态为 {existing['status']}，仍按历史资产关联。")
        return existing
    try:
        board = board_repo.create(
            {
                "code": definition["code"],
                "name": definition["name"],
                "board_type": definition["board_type"],
                "nominal_ohm": definition.get("nominal_ohm"),
                "z0": 50.0,
                "notes": definition.get("notes", "由 Excel 矩阵自动建立"),
                "status": "available",
            },
            actor="Excel 导入",
        )
        return board
    except Exception as exc:
        warnings.append(f"无法自动建立测试板 {definition['code']}：{exc}")
        return None


def _unique_code(repo: ExperimentRepository, desired: str, used: set[str], warnings: list[str]) -> str:
    candidate = desired
    if candidate.upper() not in used and not repo.get_by_code(candidate):
        used.add(candidate.upper())
        return candidate
    index = 2
    while True:
        candidate = f"{desired}-I{index}"
        if candidate.upper() not in used and not repo.get_by_code(candidate):
            used.add(candidate.upper())
            warnings.append(f"编号 {desired} 重复，已保留为 {candidate}")
            return candidate
        index += 1


def _make_name(mode: str, distance_text: str, board_text: str, board: dict[str, Any] | None) -> str:
    if mode == "normal":
        return f"正常参考 | {distance_text or '见备注'} | {board_text}"
    if mode == "multi":
        return f"多异常定位 | {distance_text} | {board_text}"
    return f"{distance_text} m | {board_text}"


def import_workbook(
    db: Database,
    source_path: str | Path,
    *,
    actor: str = "Excel 导入",
    allow_repeat: bool = False,
) -> dict[str, Any]:
    source = Path(source_path).resolve()
    if not source.exists():
        raise ValueError("Excel 文件不存在")
    sha = hashlib.sha256(source.read_bytes()).hexdigest()
    existing_import = db.query_one("SELECT * FROM import_runs WHERE sha256=? ORDER BY imported_at DESC", (sha,))
    if existing_import and not allow_repeat:
        return {
            "already_imported": True,
            "source_file": str(source),
            "sha256": sha,
            "imported_count": 0,
            "skipped_count": int(existing_import["imported_count"]),
            "warnings": ["该文件 SHA-256 与既有导入记录相同；为避免重复建组，本次未写入。若确需再导入，请勾选允许重复。"],
            "errors": [],
            "row_reports": [],
            "existing_import_id": existing_import["id"],
        }

    wb = openpyxl.load_workbook(source, data_only=True, read_only=False)
    ws, header_row, mapping = _locate_sheet(wb)
    headers = [cell.value for cell in ws[header_row]]
    warnings: list[str] = []
    errors: list[str] = []
    row_reports: list[dict[str, Any]] = []
    used_codes: set[str] = set()
    imported: list[dict[str, Any]] = []
    board_created: list[str] = []
    skipped = 0

    # 批次与类别
    batch_repo = BatchRepository(db)
    batch = db.query_one("SELECT * FROM batches WHERE code='FW63-V1.0-XLSX' COLLATE NOCASE")
    if not batch:
        batch = batch_repo.create(
            {
                "code": "FW63-V1.0-XLSX",
                "name": "FW63 V1.0 初验（Excel 导入）",
                "firmware_version": str(db.get_setting("firmware_version", "FW63 V1.0")),
                "frontend": "resistive_divider",
                "description": f"由 {source.name} 导入；原始编号保留在 source_row。",
                "is_active": True,
            },
            actor=actor,
        )
    category_repo = CategoryRepository(db)
    exp_repo = ExperimentRepository(db)
    board_repo = BoardRepository(db)

    board_cache: dict[str, dict[str, Any]] = {}
    rows = list(ws.iter_rows(min_row=header_row + 1, values_only=True))
    for offset, row in enumerate(rows, start=header_row + 1):
        if not row or all(cell is None or str(cell).strip() == "" for cell in row):
            continue
        raw_code = _cell(row, mapping, "code")
        if raw_code is None or str(raw_code).strip() == "":
            # 无编号但有数据：不丢弃，生成临时编号并记录。
            raw_code = f"IMP-{offset:03d}"
            warnings.append(f"第 {offset} 行缺少编号，已生成临时编号 {raw_code}")
        desired_code = str(raw_code).strip()
        category_code = str(_cell(row, mapping, "category") or "").strip().upper()
        if not category_code:
            category_code = "Z"
            warnings.append(f"{desired_code} 缺少组别，归入类别 Z")
        category = category_repo.get_by_code(category_code)
        if not category:
            builtin_name = next(
                (name for code, name, _, _ in config.BUILTIN_CATEGORIES if code == category_code),
                f"自定义类别 {category_code}",
            )
            category = category_repo.create(
                {"code": category_code, "name": builtin_name, "description": "由 Excel 导入建立", "sort_order": 90},
                actor=actor,
            )
            warnings.append(f"类别 {category_code} 不存在，已按导入内容创建")
        board_text = str(_cell(row, mapping, "board_text") or "").strip()
        board_matches = _parse_board_text(board_text)
        distance_text = str(_cell(row, mapping, "distance") or "").strip()
        distance = safe_float(distance_text)
        repeats = safe_int(_cell(row, mapping, "repeats"), 1)
        if repeats is None or repeats <= 0:
            repeats = 1
            warnings.append(f"{desired_code} 计划次数无效，按 1 次保留")
        priority = str(_cell(row, mapping, "priority") or "P1").strip().upper()
        if priority not in {"P0", "P1", "P2"}:
            warnings.append(f"{desired_code} 优先级“{priority}”无法识别，规范为 P1")
            priority = "P1"
        gamma_text = _cell(row, mapping, "gamma")
        reference_label = str(_cell(row, mapping, "reference") or "").strip()
        notes = str(_cell(row, mapping, "notes") or "").strip()
        expected_response = str(_cell(row, mapping, "expected_response") or "").strip()
        end_load = str(_cell(row, mapping, "end_load") or "").strip()
        source_status = _cell(row, mapping, "source_status")
        source_measured = _cell(row, mapping, "source_measured")
        if source_status not in (None, "") or source_measured not in (None, ""):
            warnings.append(f"{desired_code} 模板中存在实测字段；本次只导入计划，不将其作为正式结果。")

        # 判定模式与测试板
        is_recovery = "恢复" in board_text or "全部" in board_text
        is_multi_expr = len(board_matches) >= 2 and "+" in board_text
        board_for_config = None
        expected_anomalies: list[dict[str, Any]] = []
        if is_multi_expr:
            mode = "multi"
            for anomaly in board_matches:
                board_key = anomaly["code"]
                if board_key not in board_cache:
                    board_cache[board_key] = _ensure_board(db, board_repo, anomaly, warnings) or {}
                board = board_cache[board_key]
                if not board:
                    continue
                anomaly_distance = anomaly.get("distance_m") or safe_float(distance_text)
                if anomaly_distance is None:
                    warnings.append(f"{desired_code} 多异常缺少距离，已跳过该异常定义")
                    continue
                expected_anomalies.append(
                    {
                        "true_distance_m": anomaly_distance,
                        "board_id": board["id"],
                        "board_code": board["code"],
                        "board_name": board["name"],
                        "expected_polarity": board["polarity"],
                    }
                )
            if len(expected_anomalies) < 2:
                warnings.append(f"{desired_code} 多异常表达式解析不足 2 个，请人工复核")
        elif board_matches:
            first = board_matches[0]
            if first["code"] not in board_cache:
                board_cache[first["code"]] = _ensure_board(db, board_repo, first, warnings) or {}
            board_for_config = board_cache[first["code"]]
            mode = "normal" if (board_for_config and board_for_config["board_type"] == "normal") else "single"
        else:
            mode = "normal" if ("正常" in board_text or "NORMAL" in board_text.upper()) else "single"
            if not board_matches:
                warnings.append(f"{desired_code} 无法识别试件“{board_text}”，未关联测试板，请人工编辑")
            board_for_config = None
        if is_recovery:
            mode = "normal"
            if not board_for_config:
                board_for_config = _ensure_board(db, board_repo, BOARD_DEFINITIONS["E"], warnings)
        if mode == "single" and distance is None:
            warnings.append(f"{desired_code} 单异常缺少有效真值距离，已保留为未完成配置")
        if mode == "multi":
            board_for_config = None
        unique_code = _unique_code(exp_repo, desired_code, used_codes, warnings)
        payload = {
            str(headers[i]) if i < len(headers) else f"col{i+1}": (row[i] if i < len(row) else None)
            for i in range(len(headers))
        }
        try:
            created = exp_repo.create(
                {
                    "code": unique_code,
                    "name": _make_name(mode, distance_text, board_text, board_for_config),
                    "category_id": category["id"],
                    "batch_id": batch["id"],
                    "priority": priority,
                    "mode": mode,
                    "distance_m": distance,
                    "distance_expr": distance_text,
                    "near_expr": str(_cell(row, mapping, "near") or ""),
                    "far_expr": str(_cell(row, mapping, "far") or ""),
                    "board_id": board_for_config["id"] if board_for_config else None,
                    "planned_repeats": repeats,
                    "expected_anomalies": expected_anomalies,
                    "reference_label": reference_label,
                    "notes": "\n".join(part for part in [
                        notes,
                        f"预期响应：{expected_response}" if expected_response else "",
                        f"末端负载：{end_load}" if end_load else "",
                        f"原始组别：{category_code}",
                    ] if part),
                    "source": "excel",
                    "source_row": offset,
                    "source_payload": json_dumps(payload),
                    "status": "not_started",
                },
                actor=actor,
            )
            imported.append(created)
            row_reports.append(
                {
                    "row": offset,
                    "source_code": desired_code,
                    "imported_code": created["code"],
                    "status": "imported",
                    "mode": mode,
                    "warnings": [],
                }
            )
        except Exception as exc:
            skipped += 1
            message = f"{desired_code}（第 {offset} 行）导入失败：{exc}"
            errors.append(message)
            row_reports.append(
                {
                    "row": offset,
                    "source_code": desired_code,
                    "imported_code": None,
                    "status": "error",
                    "mode": mode,
                    "warnings": [str(exc)],
                }
            )

    imported_count = len(imported)
    report = {
        "already_imported": False,
        "source_file": str(source),
        "source_name": source.name,
        "sha256": sha,
        "imported_at": now_iso(),
        "sheet": ws.title,
        "header_row": header_row,
        "field_map": {key: headers[index] if index < len(headers) else "" for key, index in mapping.items()},
        "rows_scanned": len([r for r in rows if r and any(c is not None and str(c).strip() != "" for c in r)]),
        "imported_count": imported_count,
        "skipped_count": skipped,
        "warning_count": len(warnings),
        "error_count": len(errors),
        "warnings": warnings,
        "errors": errors,
        "row_reports": row_reports,
        "batch_id": batch["id"],
        "batch_name": batch["name"],
        "planned_trials": sum(int(item.get("planned_repeats") or 0) for item in imported),
        "import_run_id": new_id("IMPORT"),
    }
    # 持久化报告
    config.IMPORT_REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = now_iso().replace(":", "").replace("+", "_")[:19]
    report_path = config.IMPORT_REPORTS_DIR / f"excel_import_{stamp}.json"
    with report_path.open("w", encoding="utf-8") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)
    report["report_path"] = str(report_path)
    with db.transaction() as conn:
        conn.execute(
            """INSERT INTO import_runs
            (id,source_file,sha256,imported_at,imported_count,warning_count,error_count,report_json,created_at)
            VALUES(?,?,?,?,?,?,?,?,?)""",
            (
                report["import_run_id"], str(source), sha, report["imported_at"],
                imported_count, len(warnings), len(errors), json_dumps(report), now_iso(),
            ),
        )
        db.audit(
            conn, action="import_excel", entity_type="import_run", entity_id=report["import_run_id"],
            after={"source": source.name, "imported": imported_count, "warnings": len(warnings),
                   "errors": len(errors), "batch_id": batch["id"]},
            actor=actor, note="导入 FW63 初验测量矩阵",
        )
    return report


def list_import_reports(db: Database, limit: int = 20) -> list[dict[str, Any]]:
    rows = db.query("SELECT * FROM import_runs ORDER BY imported_at DESC LIMIT ?", (limit,))
    for row in rows:
        try:
            row["report"] = json.loads(row.pop("report_json"))
        except (TypeError, ValueError):
            row["report"] = {}
    return rows
