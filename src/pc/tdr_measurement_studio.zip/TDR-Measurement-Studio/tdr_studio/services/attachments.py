"""实验附件：复制入本地数据目录、登记 SHA-256 与相对路径。"""
from __future__ import annotations

import hashlib
import shutil
from pathlib import Path
from typing import Any

from .. import config
from ..database import Database
from ..utils import clean_filename, new_id, now_iso

ATTACHMENT_CATEGORIES = [
    "UART 日志",
    "RAW 数据",
    "CORR 数据",
    "差分相关数据",
    "串口屏截图",
    "实验接线照片",
    "其他",
]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class AttachmentService:
    def __init__(self, db: Database) -> None:
        self.db = db

    def list(self, run_id: str, trial_id: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM attachments WHERE run_id=?"
        params: list[Any] = [run_id]
        if trial_id:
            sql += " AND trial_id=?"
            params.append(trial_id)
        sql += " ORDER BY uploaded_at DESC"
        return self.db.query(sql, tuple(params))

    def add(
        self,
        run_id: str,
        source_path: str,
        *,
        category: str = "其他",
        notes: str = "",
        trial_id: str | None = None,
        actor: str = "",
    ) -> dict[str, Any]:
        source = Path(source_path)
        if not source.exists() or not source.is_file():
            raise ValueError("附件文件不存在")
        run = self.db.query_one("SELECT id FROM experiment_runs WHERE id=?", (run_id,))
        if not run:
            raise ValueError("实验运行不存在")
        if trial_id:
            trial = self.db.query_one("SELECT id FROM trials WHERE id=? AND run_id=?", (trial_id, run_id))
            if not trial:
                raise ValueError("试次与实验不匹配")
        if source.stat().st_size > 200 * 1024 * 1024:
            raise ValueError("单个附件不得超过 200 MB")
        target_dir = config.ATTACHMENTS_DIR / "runs" / run_id
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / f"{new_id()[:12]}_{clean_filename(source.name)}"
        shutil.copy2(source, target)
        attachment_id = new_id("ATT")
        timestamp = now_iso()
        relative = str(target.relative_to(config.DATA_DIR)).replace("\\", "/")
        digest = sha256_file(target)
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO attachments
                (id,run_id,trial_id,file_name,relative_path,sha256,size_bytes,category,notes,uploaded_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (
                    attachment_id, run_id, trial_id, source.name, relative, digest,
                    target.stat().st_size, category or "其他", str(notes or ""), timestamp,
                ),
            )
            self.db.audit(
                conn, action="attach", entity_type="attachment", entity_id=attachment_id,
                after={"run_id": run_id, "file_name": source.name, "sha256": digest,
                       "relative_path": relative, "category": category},
                actor=actor, note="上传实验附件",
            )
        return self.get(attachment_id) or {}

    def get(self, attachment_id: str) -> dict[str, Any] | None:
        return self.db.query_one("SELECT * FROM attachments WHERE id=?", (attachment_id,))

    def path(self, attachment: dict[str, Any]) -> Path:
        path = (config.DATA_DIR / attachment["relative_path"]).resolve()
        base = config.ATTACHMENTS_DIR.resolve()
        if base not in path.parents and path != base:
            raise ValueError("附件路径越界，拒绝访问")
        return path

    def verify(self, attachment: dict[str, Any]) -> tuple[bool, str]:
        path = self.path(attachment)
        if not path.exists():
            return False, "文件缺失"
        digest = sha256_file(path)
        if digest != attachment["sha256"]:
            return False, "SHA-256 不匹配"
        return True, "校验通过"

    def delete(self, attachment_id: str, actor: str = "") -> None:
        attachment = self.get(attachment_id)
        if not attachment:
            return
        path = self.path(attachment)
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM attachments WHERE id=?", (attachment_id,))
            self.db.audit(
                conn, action="delete", entity_type="attachment", entity_id=attachment_id,
                before=attachment, actor=actor, note="删除实验附件记录",
            )
        try:
            if path.exists():
                path.unlink()
        except OSError:
            # 文件删除失败不回滚已记录操作，用户可从审计与备份恢复；界面显示文件残留。
            pass
