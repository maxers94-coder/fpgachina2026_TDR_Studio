"""基于统计证据的自动判定。

判定顺序：未测试 → 数据不足 → 硬性失败 → 需复核 → 通过。
所有结论都返回逐条规则依据，界面与导出必须同时展示判定规则与统计口径。
"""
from __future__ import annotations

from typing import Any

from .statistics import normalize_rules


def _pct(value: Any) -> str:
    if value is None:
        return "不适用"
    return f"{float(value) * 100:.2f}%"


def _rule(
    code: str,
    label: str,
    actual: Any,
    threshold: Any,
    passed: bool | None,
    detail: str = "",
    fmt: str = "percent",
) -> dict[str, Any]:
    if fmt == "percent":
        actual_text = _pct(actual)
        threshold_text = _pct(threshold)
    elif fmt == "number":
        actual_text = "不适用" if actual is None else f"{float(actual):.3f}"
        threshold_text = "不适用" if threshold is None else f"{float(threshold):.3f}"
    else:
        actual_text = str(actual)
        threshold_text = str(threshold)
    return {
        "code": code,
        "label": label,
        "actual": actual,
        "actual_text": actual_text,
        "threshold": threshold,
        "threshold_text": threshold_text,
        "passed": passed,
        "detail": detail,
    }


def evaluate_judgement(
    stats: dict[str, Any],
    rules: dict[str, Any] | None = None,
    *,
    planned_trials: int | None = None,
    manual_review: bool = False,
) -> dict[str, Any]:
    rules = normalize_rules(rules)
    mode = stats.get("mode", "single")
    total = int(stats.get("total_trials", 0) or 0)
    resolved = int(stats.get("resolved_trials", 0) or 0)
    planned = int(planned_trials if planned_trials is not None else stats.get("planned_trials", 0) or 0)
    rule_rows: list[dict[str, Any]] = []
    reasons: list[str] = []

    if total == 0:
        return {
            "decision": "not_tested",
            "label": "未测试",
            "summary": "尚未录入任何试次。未测试不等于未通过。",
            "rules": [],
            "reasons": ["没有测量记录"],
            "stats": stats,
            "rules_used": rules,
        }

    minimum = max(1, int(rules["min_trials_for_judgement"]))
    required = max(minimum, planned if planned > 0 else minimum)
    enough = total >= required
    rule_rows.append(
        _rule(
            "data_quantity",
            "试次数量",
            total,
            required,
            enough,
            "未达到最小判定样本量" if not enough else "样本量满足",
            fmt="number",
        )
    )
    if not enough:
        return {
            "decision": "insufficient",
            "label": "数据不足",
            "summary": f"已录入 {total} 次，至少需要 {required} 次才能判定。数据不足不等于通过。",
            "rules": rule_rows,
            "reasons": ["样本量不足"],
            "stats": stats,
            "rules_used": rules,
        }

    if resolved == 0:
        return {
            "decision": "insufficient",
            "label": "数据不足",
            "summary": "全部试次均为无效或拒判，没有可用于判定的有效检测分母。",
            "rules": rule_rows,
            "reasons": ["没有有效检测结果"],
            "stats": stats,
            "rules_used": rules,
        }

    failed = False
    review = manual_review or bool(stats.get("ambiguous_trials"))
    invalid_rate = stats.get("invalid_rate")
    invalid_ok = invalid_rate is not None and invalid_rate <= rules["max_invalid_rate"] + 1e-12
    rule_rows.append(
        _rule(
            "invalid_rate",
            "无效率/拒判率",
            invalid_rate,
            rules["max_invalid_rate"],
            invalid_ok if invalid_rate is not None else None,
            "无效或拒判比例不得超过上限",
        )
    )
    if invalid_rate is not None and not invalid_ok:
        failed = True
        reasons.append("无效率/拒判率超过上限")

    quality = stats.get("quality_issue_counts", {})
    hardware_count = int(quality.get("PN?", 0)) + int(quality.get("OVERFLOW", 0))
    if rules["hardware_error_fails"]:
        hardware_ok = hardware_count == 0
        rule_rows.append(
            _rule(
                "hardware_errors",
                "严重硬件/解析错误（PN? / OVERFLOW）",
                hardware_count,
                0,
                hardware_ok,
                "出现严重错误即不通过" if not hardware_ok else "未发现严重错误",
                fmt="number",
            )
        )
        if not hardware_ok:
            failed = True
            reasons.append(f"出现 {hardware_count} 次 PN?/OVERFLOW")
    edge_count = int(quality.get("EDGE*", 0))
    if edge_count and not rules["edge_as_valid"]:
        rule_rows.append(
            _rule(
                "edge_policy",
                "EDGE* 数据有效性",
                "不合格",
                "不合格",
                False,
                f"存在 {edge_count} 次 EDGE*，当前设定为不计入有效定位",
                fmt="text",
            )
        )
        # 已经反映到定位/综合指标；这里标记需复核，避免静默当作正常。
        review = True

    if mode in {"single", "multi"}:
        detection_rate = stats.get("anomaly_detection_rate") or stats.get("detection_rate")
        if detection_rate is None:
            detection_ok = None
        else:
            detection_ok = detection_rate + 1e-12 >= rules["min_detection_rate"]
        rule_rows.append(
            _rule(
                "detection_rate",
                "检出率",
                detection_rate,
                rules["min_detection_rate"],
                detection_ok,
                "未检出保留在检出率分母",
            )
        )
        if detection_ok is False:
            failed = True
            reasons.append("检出率低于阈值")

        location_rate = stats.get("location_pass_rate")
        if mode == "multi":
            strict = stats.get("strict_complete_rate")
            complete_ok = strict is not None and strict + 1e-12 >= rules["min_location_rate"]
            rule_rows.append(
                _rule(
                    "multi_complete",
                    "多异常完整识别率",
                    strict,
                    rules["min_location_rate"],
                    complete_ok,
                    "要求全部真实异常匹配、无额外候选且定位/极性合格",
                )
            )
            if not complete_ok:
                failed = True
                reasons.append("多异常完整识别率低于阈值")
        if location_rate is None:
            location_ok = False
            reasons.append("没有可用的定位数据")
        else:
            location_ok = location_rate + 1e-12 >= rules["min_location_rate"]
        rule_rows.append(
            _rule(
                "location_rate",
                "定位合格率",
                location_rate,
                rules["min_location_rate"],
                location_ok,
                f"容差 ±{rules['distance_tolerance_m']:.3f} m",
            )
        )
        if not location_ok:
            failed = True
            reasons.append("定位合格率不足")

        if rules["require_polarity"]:
            polarity_rate = stats.get("polarity_accuracy")
            polarity_ok = polarity_rate is not None and polarity_rate >= 1.0 - 1e-12
            rule_rows.append(
                _rule(
                    "polarity",
                    "极性正确率（要求全部正确）",
                    polarity_rate,
                    1.0,
                    polarity_ok,
                    "有极性未知的检出同样视为不满足",
                )
            )
            if not polarity_ok:
                failed = True
                reasons.append("极性未全部正确")
    elif mode == "normal":
        false_alarm_rate = stats.get("false_alarm_rate")
        false_ok = false_alarm_rate is not None and false_alarm_rate <= rules[
            "max_false_alarm_rate"
        ] + 1e-12
        rule_rows.append(
            _rule(
                "false_alarm_rate",
                "正常误报率",
                false_alarm_rate,
                rules["max_false_alarm_rate"],
                false_ok,
                "正常参考组不使用异常检出率评价",
            )
        )
        if not false_ok:
            failed = True
            reasons.append("正常误报率超过阈值")
        normal_rate = stats.get("normal_judgement_rate")
        normal_ok = normal_rate is not None and normal_rate >= 1.0 - rules["max_false_alarm_rate"]
        rule_rows.append(
            _rule(
                "normal_rate",
                "正常判定率",
                normal_rate,
                1.0 - rules["max_false_alarm_rate"],
                normal_ok,
                "正常判定率与误报率互为补充",
            )
        )
        if not normal_ok:
            failed = True
            reasons.append("正常判定率不足")

    success_rate = stats.get("comprehensive_success_rate")
    rule_rows.append(
        _rule(
            "comprehensive",
            "综合成功率",
            success_rate,
            None,
            None,
            "展示用，不单独决定判定",
        )
    )

    if failed:
        decision, label = "fail", "未通过"
        summary = "；".join(reasons) if reasons else "存在不满足的验收规则。"
    elif review:
        decision, label = "review", "需要人工复核"
        summary = "统计规则已满足，但存在歧义或 EDGE* 质量事项，需要人工复核后归档。"
    else:
        decision, label = "pass", "通过"
        summary = "全部自动验收规则通过。结论基于当前统计口径与原始记录。"
    return {
        "decision": decision,
        "label": label,
        "summary": summary,
        "rules": rule_rows,
        "reasons": reasons,
        "stats": stats,
        "rules_used": rules,
    }
