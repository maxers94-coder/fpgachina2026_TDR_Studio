@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   TDR Measurement Studio
echo   线缆弱阻抗异常检测与定位系统实验管理平台
echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 goto try_python
py -3.12 -c "import tkinter" >nul 2>nul
if errorlevel 1 goto try_python
py -3.12 app.py
goto finished

:try_python
where python >nul 2>nul
if errorlevel 1 goto no_python
python -c "import tkinter" >nul 2>nul
if errorlevel 1 goto no_python
python app.py
goto finished

:no_python
echo [错误] 未找到带 Tkinter 的 Python 3.11/3.12。
echo 请安装 Python 3.11 或更新版本，并勾选 Tcl/Tk 组件。
echo.
pause
exit /b 1

:finished
if errorlevel 1 (
    echo.
    echo 程序异常退出，请保留上面的错误信息以便排查。
    pause
)
endlocal
