TDR Measurement Studio — AI 分析数据包
========================================

项目名称：线缆弱阻抗异常检测与定位系统实验管理平台
导出时间：2026-11-02T23:19:00+08:00
软件版本：TDR Measurement Studio 1.0.0
数据结构版本：1.0
默认固件版本：FW63 V1.0

数据范围
--------
实验配置：161 组（其中已测试 82 组）
实验运行：90 次
逐次测量：230 条
检测候选：49 条
附件：已包含

目录说明
--------
manifest.json                       文件清单、SHA-256、数据结构版本
README.txt                          本文件
metadata/boards.json                测试板与理论反射系数
metadata/cables.json               线缆资产
metadata/cable_configurations.json  线缆组合及顺序
metadata/references.json            健康参考
metadata/configurations.json        实验配置（含未测试配置）
metadata/categories.json            实验类别
metadata/batches.json               实验批次
metadata/experiment_runs.json       实验运行条件（固件/参考/前端）
measurements/trials.csv             全部单次测量（含未检出）
measurements/candidates.csv         多异常候选与匹配
measurements/expected_anomalies.csv 多异常真实异常定义
measurements/full_dataset.json      完整结构化数据，供 AI 读取
statistics/summary.csv              总体/批次统计
statistics/statistics.csv           每组配置统计
statistics/results.xlsx             完整 Excel（含全部工作表）
figures/                            基于真实数据生成的 PNG 图表
attachments/                        原始 UART/RAW/CORR/截图等附件

重要口径
--------
1. 理论反射系数由理想集总电阻公式计算，不是仪器实测反射系数。
2. 未检出试次保留在总试次与检出率分母，但不参与距离均值；缺失值为 null。
3. 无效/拒判保留在总试次与无效率中，不进入检出率分母。
4. “未测试”/“数据不足”不等于“通过”。
5. 不同批次、固件、前端和健康参考条件默认分别统计，不静默混合。
6. 统计规则见 manifest.json 的 statistics_rules 与 full_dataset.json 的
   statistics.rules；原始记录足以独立重算。

建议的 AI 分析入口
------------------
优先读取 measurements/full_dataset.json；如只需表格，读取
measurements/trials.csv、candidates.csv、expected_anomalies.csv 及
statistics/statistics.csv。所有 ID 字段可用于关联。
