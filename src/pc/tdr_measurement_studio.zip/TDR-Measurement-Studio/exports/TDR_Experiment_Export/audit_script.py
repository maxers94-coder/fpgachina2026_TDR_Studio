"""
TDR系统性能测试报告数据审计脚本 (纯标准库版本)
=========================================

目标：独立验证报告中所有统计数据的准确性
方法：从原始CSV文件重新计算所有指标
输出：审计结果、差异分析

不依赖第三方库，仅使用Python标准库
"""

import json
import csv
from pathlib import Path
from collections import defaultdict
from typing import Dict, List
import math

# ============================================================================
# 第一部分：数据加载
# ============================================================================

def load_csv(file_path: str) -> List[Dict]:
    """加载CSV文件为字典列表"""
    data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data

def safe_float(value) -> float:
    """安全转换为浮点数"""
    if value is None or value == '' or value == 'null':
        return 0.0
    try:
        return float(value)
    except:
        return 0.0

def safe_int(value) -> int:
    """安全转换为整数"""
    if value is None or value == '' or value == 'null':
        return 0
    try:
        return int(float(value))
    except:
        return 0

# ============================================================================
# 第二部分：基础统计计算
# ============================================================================

def calculate_overall_stats(stats_data: List[Dict]) -> Dict:
    """计算总体统计"""

    # 筛选有实测数据的配置
    tested_configs = [row for row in stats_data if row['data_status'] == 'has_data']

    # 累加统计
    total_trials = sum(safe_int(row['total_trials']) for row in tested_configs)
    resolved_trials = sum(safe_int(row['resolved_trials']) for row in tested_configs)
    detected_count = sum(safe_int(row['detected_count']) for row in tested_configs)
    not_detected_count = sum(safe_int(row['not_detected_count']) for row in tested_configs)

    # 正常参考统计
    normal_configs = [row for row in tested_configs if row['mode'] == 'normal']
    normal_count = sum(safe_int(row['normal_count']) for row in normal_configs)
    false_alarm_count = sum(safe_int(row['false_alarm_count']) for row in normal_configs)

    # 极性统计
    polarity_correct = sum(safe_int(row['polarity_correct_count']) for row in tested_configs)
    polarity_wrong = sum(safe_int(row['polarity_wrong_count']) for row in tested_configs)

    # 定位统计 (加权平均)
    total_mae_weighted = 0.0
    total_rmse_weighted = 0.0
    total_located = 0

    for row in tested_configs:
        if row['mean_distance_m'] and row['mean_distance_m'] != '':
            mae = safe_float(row['mae_m'])
            rmse = safe_float(row['rmse_m'])
            located = safe_int(row['located_count'])

            total_mae_weighted += mae * located
            total_rmse_weighted += rmse * located
            total_located += located

    # 计算比率
    detection_rate = detected_count / resolved_trials if resolved_trials > 0 else 0.0
    false_alarm_rate = false_alarm_count / normal_count if normal_count > 0 else 0.0
    polarity_accuracy = polarity_correct / (polarity_correct + polarity_wrong) if (polarity_correct + polarity_wrong) > 0 else 0.0
    mae_overall = total_mae_weighted / total_located if total_located > 0 else 0.0
    rmse_overall = total_rmse_weighted / total_located if total_located > 0 else 0.0

    return {
        'tested_configs': len(tested_configs),
        'total_trials': total_trials,
        'resolved_trials': resolved_trials,
        'detected_count': detected_count,
        'not_detected_count': not_detected_count,
        'detection_rate': detection_rate,
        'detection_rate_percent': detection_rate * 100,
        'normal_configs': len(normal_configs),
        'normal_count': normal_count,
        'false_alarm_count': false_alarm_count,
        'false_alarm_rate': false_alarm_rate,
        'false_alarm_rate_percent': false_alarm_rate * 100,
        'polarity_correct': polarity_correct,
        'polarity_wrong': polarity_wrong,
        'polarity_accuracy': polarity_accuracy,
        'polarity_accuracy_percent': polarity_accuracy * 100,
        'total_located': total_located,
        'mae_m': mae_overall,
        'rmse_m': rmse_overall
    }

def calculate_category_stats(stats_data: List[Dict], category_code: str) -> Dict:
    """计算某一类别的统计"""

    cat_configs = [row for row in stats_data
                   if row['category_code'] == category_code and row['data_status'] == 'has_data']

    total_trials = sum(safe_int(row['total_trials']) for row in cat_configs)
    resolved_trials = sum(safe_int(row['resolved_trials']) for row in cat_configs)
    detected_count = sum(safe_int(row['detected_count']) for row in cat_configs)
    not_detected_count = sum(safe_int(row['not_detected_count']) for row in cat_configs)
    normal_count = sum(safe_int(row['normal_count']) for row in cat_configs)
    false_alarm_count = sum(safe_int(row['false_alarm_count']) for row in cat_configs)

    # 定位统计
    total_mae_weighted = 0.0
    total_located = 0

    for row in cat_configs:
        if row['mean_distance_m'] and row['mean_distance_m'] != '':
            mae = safe_float(row['mae_m'])
            located = safe_int(row['located_count'])
            total_mae_weighted += mae * located
            total_located += located

    detection_rate = detected_count / resolved_trials if resolved_trials > 0 else 0.0
    mae = total_mae_weighted / total_located if total_located > 0 else 0.0

    return {
        'category_code': category_code,
        'configs': len(cat_configs),
        'total_trials': total_trials,
        'resolved_trials': resolved_trials,
        'detected_count': detected_count,
        'not_detected_count': not_detected_count,
        'detection_rate': detection_rate,
        'detection_rate_percent': detection_rate * 100,
        'normal_count': normal_count,
        'false_alarm_count': false_alarm_count,
        'total_located': total_located,
        'mae_m': mae
    }

# ============================================================================
# 第三部分：差异检查
# ============================================================================

def check_discrepancies(overall: Dict, categories: Dict) -> List[Dict]:
    """检查报告与实际数据的差异"""

    discrepancies = []

    # 1. 检查 229/230 = 99.46%
    actual_229_230 = (229 / 230) * 100
    if abs(actual_229_230 - 99.46) > 0.01:
        discrepancies.append({
            'item': '检出率公式',
            'reported': '229/230 = 99.46%',
            'calculated': f'229/230 = {actual_229_230:.4f}%',
            'issue': f'数学计算错误: 99.46% != {actual_229_230:.2f}%'
        })

    # 2. 检查总测量次数
    if overall['total_trials'] != 230:
        discrepancies.append({
            'item': '总测量次数',
            'reported': '230',
            'calculated': str(overall['total_trials']),
            'issue': f'报告声称230次，实际为{overall["total_trials"]}次'
        })

    # 3. 检查检出率
    if abs(overall['detection_rate_percent'] - 99.46) > 0.1:
        discrepancies.append({
            'item': '实际检出率',
            'reported': '99.46%',
            'calculated': f'{overall["detection_rate_percent"]:.2f}%',
            'formula': f'{overall["detected_count"]}/{overall["resolved_trials"]}',
            'issue': '基于数据计算的检出率与报告不符'
        })

    # 4. 检查配置数合计
    total_configs_by_cat = sum(cat['configs'] for cat in categories.values())
    if total_configs_by_cat != 82:
        discrepancies.append({
            'item': '配置数合计',
            'reported': '82组',
            'calculated': f'{total_configs_by_cat}组',
            'breakdown': {cat_code: cat['configs'] for cat_code, cat in categories.items()},
            'issue': f'各类别配置数合计为{total_configs_by_cat}，而非82'
        })

    # 5. 检查测量次数合计
    total_trials_by_cat = sum(cat['total_trials'] for cat in categories.values())
    if total_trials_by_cat != overall['total_trials']:
        discrepancies.append({
            'item': '测量次数合计',
            'reported': '230次(报告总体)',
            'calculated': f'{total_trials_by_cat}次(各类别合计)',
            'overall_trials': overall['total_trials'],
            'breakdown': {cat_code: cat['total_trials'] for cat_code, cat in categories.items()},
            'issue': f'各类别测量次数合计({total_trials_by_cat}) ≠ 总体测量次数({overall["total_trials"]})'
        })

    return discrepancies

# ============================================================================
# 第四部分：生成审计报告
# ============================================================================

def generate_report(overall: Dict, categories: Dict, discrepancies: List[Dict]) -> str:
    """生成文本格式的审计报告"""

    report = []
    report.append("="*80)
    report.append("TDR系统性能测试报告 - 数据审计结果")
    report.append("="*80)
    report.append("")

    # 总体统计
    report.append("【一】总体统计 (独立计算结果)")
    report.append("-" * 80)
    report.append(f"测试配置数:     {overall['tested_configs']} 组")
    report.append(f"总测量次数:     {overall['total_trials']} 次")
    report.append(f"有效判决次数:   {overall['resolved_trials']} 次")
    report.append(f"检出次数:       {overall['detected_count']} 次")
    report.append(f"未检出次数:     {overall['not_detected_count']} 次")
    report.append(f"检出率:         {overall['detection_rate_percent']:.2f}% ({overall['detected_count']}/{overall['resolved_trials']})")
    report.append("")
    report.append(f"正常配置数:     {overall['normal_configs']} 组")
    report.append(f"正常判断数:     {overall['normal_count']} 次")
    report.append(f"误报次数:       {overall['false_alarm_count']} 次")
    report.append(f"误报率:         {overall['false_alarm_rate_percent']:.2f}%")
    report.append("")
    report.append(f"极性判断总数:   {overall['polarity_correct'] + overall['polarity_wrong']} 次")
    report.append(f"极性正确:       {overall['polarity_correct']} 次")
    report.append(f"极性错误:       {overall['polarity_wrong']} 次")
    report.append(f"极性准确率:     {overall['polarity_accuracy_percent']:.2f}%")
    report.append("")
    report.append(f"定位总次数:     {overall['total_located']} 次")
    report.append(f"平均绝对误差:   {overall['mae_m']:.4f} m ({overall['mae_m']*100:.2f} cm)")
    report.append(f"均方根误差:     {overall['rmse_m']:.4f} m")
    report.append("")

    # 分类统计
    report.append("【二】分类统计 (独立计算结果)")
    report.append("-" * 80)

    for cat_code in ['A', 'B', 'C', 'D', 'E', 'F']:
        cat = categories.get(cat_code, {})
        if cat:
            report.append(f"\n类别{cat_code}:")
            report.append(f"  配置数:       {cat['configs']} 组")
            report.append(f"  测量次数:     {cat['total_trials']} 次")
            report.append(f"  检出率:       {cat['detection_rate_percent']:.2f}%")
            if cat['mae_m'] > 0:
                report.append(f"  定位MAE:      {cat['mae_m']:.4f} m ({cat['mae_m']*100:.2f} cm)")

    # 合计
    total_configs = sum(cat['configs'] for cat in categories.values())
    total_trials = sum(cat['total_trials'] for cat in categories.values())
    report.append("")
    report.append(f"各类别配置数合计:     {total_configs} 组")
    report.append(f"各类别测量次数合计:   {total_trials} 次")
    report.append("")

    # 差异分析
    report.append("【三】差异检查")
    report.append("-" * 80)

    if discrepancies:
        for i, disc in enumerate(discrepancies, 1):
            report.append(f"\n差异 #{i}: {disc['item']}")
            report.append(f"  报告数值:  {disc['reported']}")
            report.append(f"  计算数值:  {disc['calculated']}")
            if 'formula' in disc:
                report.append(f"  计算公式:  {disc['formula']}")
            if 'breakdown' in disc:
                report.append(f"  详细分解:  {disc['breakdown']}")
            report.append(f"  问题描述:  {disc['issue']}")
    else:
        report.append("\n✓ 未发现显著差异")

    report.append("")
    report.append("="*80)
    report.append("审计完成")
    report.append("="*80)

    return "\n".join(report)

# ============================================================================
# 第五部分：主执行函数
# ============================================================================

def main():
    """主执行函数"""

    # 设置文件路径
    base_path = Path(r"C:\Users\maxer\Documents\deepseek-harness\default-workspace\TDR-Measurement-Studio\exports\TDR_Experiment_Export")

    stats_path = base_path / "statistics" / "statistics.csv"
    manifest_path = base_path / "manifest.json"

    # 加载数据
    print("正在加载数据文件...")
    stats_data = load_csv(str(stats_path))
    print(f"✓ 加载 statistics.csv: {len(stats_data)} 条配置记录")

    with open(manifest_path, 'r', encoding='utf-8') as f:
        manifest = json.load(f)
    print(f"✓ 加载 manifest.json")
    print("")

    # 计算总体统计
    print("正在计算总体统计...")
    overall = calculate_overall_stats(stats_data)

    # 计算分类统计
    print("正在计算分类统计...")
    categories = {}
    for cat_code in ['A', 'B', 'C', 'D', 'E', 'F']:
        categories[cat_code] = calculate_category_stats(stats_data, cat_code)

    # 检查差异
    print("正在检查差异...")
    discrepancies = check_discrepancies(overall, categories)

    # 生成报告
    report_text = generate_report(overall, categories, discrepancies)
    print(report_text)

    # 保存审计结果
    output_json = base_path / "数据审计结果.json"
    output_txt = base_path / "数据审计报告.txt"

    audit_results = {
        'overall': overall,
        'categories': categories,
        'discrepancies': discrepancies,
        'summary': {
            'total_configs_tested': overall['tested_configs'],
            'total_trials': overall['total_trials'],
            'detection_rate_percent': overall['detection_rate_percent'],
            'false_alarm_rate_percent': overall['false_alarm_rate_percent'],
            'mae_m': overall['mae_m'],
            'discrepancy_count': len(discrepancies)
        }
    }

    with open(output_json, 'w', encoding='utf-8') as f:
        json.dump(audit_results, f, ensure_ascii=False, indent=2)

    with open(output_txt, 'w', encoding='utf-8') as f:
        f.write(report_text)

    print(f"\n✓ 审计结果已保存:")
    print(f"  JSON格式: {output_json}")
    print(f"  文本格式: {output_txt}")

    return audit_results

if __name__ == "__main__":
    results = main()
