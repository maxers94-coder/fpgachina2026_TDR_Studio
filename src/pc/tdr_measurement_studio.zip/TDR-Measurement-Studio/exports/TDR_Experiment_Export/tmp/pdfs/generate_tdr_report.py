import json
import math
import os
import statistics
from collections import Counter, defaultdict
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    Image,
    KeepTogether,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.graphics.shapes import Drawing, Rect, String


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DATA_PATH = os.path.join(ROOT, "measurements", "full_dataset.json")
OUT_DIR = os.path.join(ROOT, "output", "pdf")
OUT_PATH = os.path.join(OUT_DIR, "TDR数据统计报告.pdf")


def quantile(values, p):
    values = sorted(float(x) for x in values)
    if not values:
        return None
    if len(values) == 1:
        return values[0]
    k = (len(values) - 1) * p
    lo = math.floor(k)
    hi = math.ceil(k)
    return values[lo] + (values[hi] - values[lo]) * (k - lo)


def mean(values):
    return sum(values) / len(values) if values else None


def pct(v, digits=1):
    return "-" if v is None else f"{100.0 * v:.{digits}f}%"


def num(v, digits=3):
    return "-" if v is None else f"{v:.{digits}f}"


def load_data():
    with open(DATA_PATH, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def build_metrics(data):
    trials = data["trials"]
    candidates = data["detected_candidates"]
    configs = data["configurations"]
    runs = data["experiment_runs"]
    expected = data["expected_anomalies"]
    boards = {b["id"]: b for b in data["boards"]}
    run_map = {r["id"]: r for r in runs}
    config_map = {c["id"]: c for c in configs}
    expected_map = {e["id"]: e for e in expected}

    anomaly_trials = [t for t in trials if t.get("mode") != "normal"]
    normal_trials = [t for t in trials if t.get("mode") == "normal"]
    resolved_anomaly = [t for t in anomaly_trials if t.get("detection_status") in ("detected", "not_detected")]
    candidate_errors = [abs(float(c["distance_error_m"])) for c in candidates if c.get("distance_error_m") is not None]
    candidate_signed_errors = [float(c["distance_error_m"]) for c in candidates if c.get("distance_error_m") is not None]

    # A detection event is either a detected single-anomaly trial or one matched
    # candidate in a multi-anomaly trial. This avoids treating the multi-anomaly
    # candidates as the only localized detections.
    event_records = []
    single_trial_count = sum(1 for trial in trials if trial.get("mode") == "single")
    multi_target_count = sum(int(trial.get("expected_anomaly_count") or 0) for trial in trials if trial.get("mode") == "multi")
    configs_with_trials = {t.get("configuration_id") for t in trials}
    for trial in trials:
        if trial.get("mode") == "single" and trial.get("detection_status") == "detected":
            event_records.append({
                "board_code": trial.get("board_code", "未标识"),
                "true_distance_m": trial.get("true_distance_m"),
                "distance_error_m": trial.get("distance_error_m"),
                "polarity_correct": trial.get("polarity_correct"),
                "quality_usable": bool(trial.get("quality_usable")),
                "source": "single",
            })
    for cand in candidates:
        ea = expected_map.get(cand.get("matched_expected_anomaly_id"), {})
        event_records.append({
            "board_code": ea.get("board_code", "未标识"),
            "true_distance_m": cand.get("true_distance_m"),
            "distance_error_m": cand.get("distance_error_m"),
            "polarity_correct": cand.get("polarity_correct"),
            "quality_usable": cand.get("quality_flag") != "EDGE*",
            "source": "multi",
        })
    usable_events = [e for e in event_records if e.get("quality_usable") and e.get("distance_error_m") is not None]
    event_errors = [abs(float(e["distance_error_m"])) for e in usable_events]
    event_signed_errors = [float(e["distance_error_m"]) for e in usable_events]

    batch_trial_counts = Counter(t.get("batch_name") for t in trials)
    config_status = Counter(c.get("status") for c in configs)
    trial_modes = Counter(t.get("mode") for t in trials)
    trial_statuses = Counter(t.get("detection_status") for t in trials)
    quality = Counter(t.get("quality_flag") for t in trials)

    by_board = defaultdict(list)
    for event in event_records:
        by_board[event["board_code"]].append(event)
    board_rows = []
    for code, rows in sorted(by_board.items()):
        usable_rows = [r for r in rows if r.get("quality_usable") and r.get("distance_error_m") is not None]
        es = [abs(float(r["distance_error_m"])) for r in usable_rows]
        signed = [float(r["distance_error_m"]) for r in usable_rows]
        pol = [r.get("polarity_correct") for r in rows if r.get("polarity_correct") is not None]
        board_rows.append({
            "code": code,
            "n": len(usable_rows),
            "all_n": len(rows),
            "mae": mean(es),
            "p95": quantile(es, 0.95),
            "within": sum(x <= 0.6 for x in es) / len(es) if es else None,
            "polarity": sum(1 for x in pol if x) / len(pol) if pol else None,
            "mean_signed": mean(signed),
        })

    distance_groups = [("≤5 m", lambda d: d <= 5), ("5-15 m", lambda d: 5 < d <= 15), (">15 m", lambda d: d > 15)]
    distance_rows = []
    for label, fn in distance_groups:
        rows = [e for e in usable_events if e.get("true_distance_m") is not None and fn(float(e["true_distance_m"]))]
        es = [abs(float(r["distance_error_m"])) for r in rows if r.get("distance_error_m") is not None]
        distance_rows.append({"label": label, "n": len(rows), "mae": mean(es), "p95": quantile(es, .95), "within": sum(x <= .6 for x in es) / len(es) if es else None})

    return {
        "data": data,
        "trials": trials,
        "candidates": candidates,
        "configs": configs,
        "runs": runs,
        "expected": expected,
        "config_map": config_map,
        "run_map": run_map,
        "boards": boards,
        "trial_modes": trial_modes,
        "trial_statuses": trial_statuses,
        "quality": quality,
        "batch_trial_counts": batch_trial_counts,
        "config_status": config_status,
        "configs_with_trial_count": len(configs_with_trials),
        "anomaly_trials": anomaly_trials,
        "normal_trials": normal_trials,
        "resolved_anomaly": resolved_anomaly,
        "event_records": event_records,
        "usable_events": usable_events,
        "board_rows": board_rows,
        "distance_rows": distance_rows,
        "metrics": {
            "anomaly_detection_rate": sum(t.get("detection_status") == "detected" for t in resolved_anomaly) / len(resolved_anomaly) if resolved_anomaly else None,
            "anomaly_detected_trial_count": sum(t.get("detection_status") == "detected" for t in resolved_anomaly),
            "anomaly_resolved_trial_count": len(resolved_anomaly),
            "false_alarm_rate": sum((t.get("candidate_count") or 0) > 0 for t in normal_trials) / len(normal_trials) if normal_trials else None,
            "false_alarm_trial_count": sum((t.get("candidate_count") or 0) > 0 for t in normal_trials),
            "normal_trial_count": len(normal_trials),
            "candidate_match_rate": sum(c.get("match_status") == "matched" for c in candidates) / len(candidates) if candidates else None,
            "event_polarity_accuracy": sum(bool(e["polarity_correct"]) for e in event_records if e.get("polarity_correct") is not None) / sum(e.get("polarity_correct") is not None for e in event_records) if event_records else None,
            "detected_event_count": len(event_records),
            "usable_event_count": len(usable_events),
            "single_trial_count": single_trial_count,
            "multi_target_count": multi_target_count,
            "expected_event_count": single_trial_count + multi_target_count,
            "event_detection_rate": len(event_records) / (single_trial_count + multi_target_count) if (single_trial_count + multi_target_count) else None,
            "event_mae": mean(event_errors),
            "event_rmse": math.sqrt(mean([x * x for x in event_signed_errors])) if event_signed_errors else None,
            "event_mean_signed_error": mean(event_signed_errors),
            "event_median_abs_error": statistics.median(event_errors) if event_errors else None,
            "event_p95_abs_error": quantile(event_errors, .95),
            "event_location_pass_rate": sum(x <= .6 for x in event_errors) / len(event_errors) if event_errors else None,
            "candidate_mae": mean(candidate_errors),
            "candidate_rmse": math.sqrt(mean([x * x for x in candidate_signed_errors])) if candidate_signed_errors else None,
            "candidate_p95_abs_error": quantile(candidate_errors, .95),
            "candidate_location_pass_rate": sum(x <= .6 for x in candidate_errors) / len(candidate_errors) if candidate_errors else None,
            "quality_usable_rate": sum(bool(t.get("quality_usable")) for t in trials) / len(trials) if trials else None,
        },
    }


def register_fonts():
    font_path = r"C:\Windows\Fonts\simhei.ttf"
    if not os.path.exists(font_path):
        font_path = r"C:\Windows\Fonts\simsun.ttc"
    pdfmetrics.registerFont(TTFont("CJK", font_path))
    return "CJK"


class NumberedDocTemplate(BaseDocTemplate):
    def __init__(self, filename, **kwargs):
        super().__init__(filename, **kwargs)
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id="normal")
        self.addPageTemplates([PageTemplate(id="main", frames=frame, onPage=self._header_footer)])

    def _header_footer(self, canvas, doc):
        canvas.saveState()
        canvas.setFont("CJK", 8)
        canvas.setFillColor(colors.HexColor("#65758B"))
        canvas.drawString(doc.leftMargin, A4[1] - 13 * mm, "TDR Measurement Studio | 独立统计报告")
        canvas.drawRightString(A4[0] - doc.rightMargin, 10 * mm, f"第 {doc.page} 页")
        canvas.setStrokeColor(colors.HexColor("#D9E2EC"))
        canvas.line(doc.leftMargin, A4[1] - 16 * mm, A4[0] - doc.rightMargin, A4[1] - 16 * mm)
        canvas.restoreState()


def chart_bar(items, title, max_value=None, percent=False, width=170 * mm, height=62 * mm):
    d = Drawing(width, height)
    d.add(String(0, height - 10, title, fontName="CJK", fontSize=10, fillColor=colors.HexColor("#183B56")))
    left, bottom, plot_w, plot_h = 36 * mm, 12 * mm, width - 48 * mm, height - 26 * mm
    max_v = max_value if max_value is not None else max((float(v) for _, v in items), default=1.0)
    max_v = max(max_v, 1e-9)
    d.add(Rect(left, bottom, plot_w, plot_h, strokeColor=colors.HexColor("#D9E2EC"), fillColor=None))
    bar_w = plot_w / max(1, len(items)) * 0.62
    for i, (label, value) in enumerate(items):
        x = left + (i + 0.5) * plot_w / len(items) - bar_w / 2
        h = plot_h * float(value) / max_v
        d.add(Rect(x, bottom, bar_w, h, strokeColor=colors.HexColor("#2F80ED"), fillColor=colors.HexColor("#56CCF2")))
        txt = f"{100*value:.1f}%" if percent else f"{value:g}"
        d.add(String(x + bar_w / 2, bottom + h + 3, txt, textAnchor="middle", fontName="CJK", fontSize=7, fillColor=colors.HexColor("#183B56")))
        d.add(String(x + bar_w / 2, bottom - 9, str(label), textAnchor="middle", fontName="CJK", fontSize=7, fillColor=colors.HexColor("#334E68")))
    d.add(String(left - 4, bottom + plot_h - 3, f"{100*max_v:.0f}%" if percent else f"{max_v:g}", textAnchor="end", fontName="CJK", fontSize=7, fillColor=colors.HexColor("#627D98")))
    return d


def styles(font):
    s = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("title", parent=s["Title"], fontName=font, fontSize=24, leading=31, textColor=colors.HexColor("#102A43"), alignment=TA_CENTER, spaceAfter=8),
        "kpi": ParagraphStyle("kpi", parent=s["Title"], fontName=font, fontSize=18, leading=22, textColor=colors.HexColor("#102A43"), alignment=TA_CENTER, spaceAfter=0),
        "subtitle": ParagraphStyle("subtitle", parent=s["Normal"], fontName=font, fontSize=11, leading=17, textColor=colors.HexColor("#486581"), alignment=TA_CENTER, spaceAfter=18),
        "h1": ParagraphStyle("h1", parent=s["Heading1"], fontName=font, fontSize=16, leading=21, textColor=colors.HexColor("#102A43"), spaceBefore=10, spaceAfter=8),
        "h2": ParagraphStyle("h2", parent=s["Heading2"], fontName=font, fontSize=11.5, leading=16, textColor=colors.HexColor("#183B56"), spaceBefore=8, spaceAfter=5),
        "body": ParagraphStyle("body", parent=s["BodyText"], fontName=font, fontSize=9.4, leading=15, textColor=colors.HexColor("#243B53"), spaceAfter=6),
        "small": ParagraphStyle("small", parent=s["BodyText"], fontName=font, fontSize=7.7, leading=11, textColor=colors.HexColor("#486581"), spaceAfter=4),
        "table": ParagraphStyle("table", parent=s["BodyText"], fontName=font, fontSize=7.5, leading=10, textColor=colors.HexColor("#243B53")),
        "table_head": ParagraphStyle("table_head", parent=s["BodyText"], fontName=font, fontSize=7.5, leading=10, textColor=colors.white, alignment=TA_CENTER),
        "callout": ParagraphStyle("callout", parent=s["BodyText"], fontName=font, fontSize=10, leading=15, textColor=colors.HexColor("#102A43")),
    }


def P(text, st):
    return Paragraph(str(text), st)


def styled_table(rows, col_widths, st, header=True, alignments=None):
    cooked = []
    for r, row in enumerate(rows):
        cooked.append([P(v, st["table_head"] if header and r == 0 else st["table"]) for v in row])
    t = Table(cooked, colWidths=col_widths, repeatRows=1 if header else 0, hAlign="LEFT")
    cmd = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#D9E2EC")),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    if header:
        cmd += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F5A85")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white)]
        for i in range(1, len(rows)):
            if i % 2 == 0:
                cmd.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F5F9FC")))
    if alignments:
        for col, align in alignments.items():
            cmd.append(("ALIGN", (col, 1 if header else 0), (col, -1), align))
    t.setStyle(TableStyle(cmd))
    return t


def build_story(m):
    font = register_fonts()
    st = styles(font)
    d = m["data"]
    met = m["metrics"]
    story = []

    story.append(Spacer(1, 23 * mm))
    story.append(P("线缆弱阻抗异常检测与定位系统", st["title"]))
    story.append(P("原始测量数据统计报告", st["title"]))
    story.append(P("基于 measurements/full_dataset.json 的独立重算 | 生成日期：2026 年 11 月 3 日", st["subtitle"]))
    story.append(Spacer(1, 5 * mm))
    story.append(P("报告范围", st["h1"]))
    story.append(P("本报告直接依据原始逐次试验、检测候选和元数据独立重算，目录中现有的统计摘要和分析报告不作为计算来源。统计重点包括异常检出、正常参考误报以及距离定位误差。", st["body"]))
    cards = [
        [P(str(len(m["trials"])), st["kpi"]), P("逐次试验", st["callout"]), P(f"{met['anomaly_detected_trial_count']}/{met['anomaly_resolved_trial_count']}", st["kpi"]), P("异常试验检出", st["callout"])],
        [P(str(len(m["candidates"])), st["kpi"]), P("多异常候选", st["callout"]), P(num(met["event_mae"], 3) + " m", st["kpi"]), P("综合定位 MAE", st["callout"])],
    ]
    card_table = Table(cards, colWidths=[35 * mm, 45 * mm, 40 * mm, 54 * mm], rowHeights=[23 * mm, 23 * mm])
    card_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F0F7FF")),
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#B8D4EE")),
        ("INNERGRID", (0, 0), (-1, -1), 0.6, colors.HexColor("#D9EAF7")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(card_table)
    story.append(Spacer(1, 6 * mm))
    story.append(P("数据边界", st["h2"]))
    scope_rows = [
        ["项目", "数量 / 条件"],
        ["实验配置", f"{len(m['configs'])} 组，其中 {m['configs_with_trial_count']} 组有试验；其余 78 组未开始，另 1 组虽标为 completed 但无试验记录"],
        ["实验运行", f"{len(m['runs'])} 次；其中有逐次测量的运行对应 {len(set(t['run_id'] for t in m['trials']))} 次"],
        ["逐次试验", f"{len(m['trials'])} 条；全部来自批次：{next(iter(m['batch_trial_counts']))}"],
        ["检测候选", f"{len(m['candidates'])} 条；均有匹配的真实异常定义"],
        ["设备与类别", f"{len(d['boards'])} 个测试板；{len(d['categories'])} 个实验类别"],
    ]
    story.append(styled_table(scope_rows, [42 * mm, 122 * mm], st, alignments={0: "LEFT", 1: "LEFT"}))
    story.append(PageBreak())

    story.append(P("一、核心统计结果", st["h1"]))
    story.append(P(f"在 {met['anomaly_resolved_trial_count']} 条异常试验中，{met['anomaly_detected_trial_count']} 条被检出、{met['anomaly_resolved_trial_count'] - met['anomaly_detected_trial_count']} 条未检出，按试验条数计算的检出率为 {pct(met['anomaly_detection_rate'], 2)}。另按异常事件计数：{met['single_trial_count']} 条单异常试验加 {met['multi_target_count']} 个多异常目标，共 {met['expected_event_count']} 个预期事件；记录到 {met['detected_event_count']} 个事件，其中 {met['usable_event_count']} 个可用于定位误差统计。正常参考试验共 {len(m['normal_trials'])} 条，未发现候选误报。", st["body"]))
    core_rows = [
        ["指标", "结果", "统计口径"],
        ["异常试验检出率", pct(met["anomaly_detection_rate"], 2), "detected / (detected + not_detected)"],
        ["异常事件检出率", pct(met["event_detection_rate"], 2), f"{met['detected_event_count']} / {met['expected_event_count']} 个单异常或多异常目标"],
        ["正常参考误报率", pct(met["false_alarm_rate"], 2), "出现候选的正常试验 / 正常试验"],
        ["多异常候选匹配率", pct(met["candidate_match_rate"], 2), f"{sum(c.get('match_status') == 'matched' for c in m['candidates'])} / {len(m['candidates'])} 候选与预期异常匹配"],
        ["异常事件极性正确率", pct(met["event_polarity_accuracy"], 2), f"{sum(bool(e['polarity_correct']) for e in m['event_records'] if e.get('polarity_correct') is not None)} / {sum(e.get('polarity_correct') is not None for e in m['event_records'])} 检出事件极性正确"],
        ["可用事件定位通过率", pct(met["event_location_pass_rate"], 2), f"|误差| ≤ 0.6 m；{met['usable_event_count']} 条质量可用事件"],
        ["事件定位 MAE", num(met["event_mae"]) + " m", f"单异常试次及多异常候选，共 {met['usable_event_count']} 条"],
        ["事件定位 RMSE", num(met["event_rmse"]) + " m", f"同一批 {met['usable_event_count']} 条质量可用事件"],
        ["事件绝对误差 P95", num(met["event_p95_abs_error"]) + " m", f"质量可用事件绝对误差第 95 百分位，n={met['usable_event_count']}"],
    ]
    story.append(styled_table(core_rows, [43 * mm, 34 * mm, 87 * mm], st, alignments={1: "RIGHT"}))
    story.append(Spacer(1, 4 * mm))
    story.append(chart_bar([(r["label"], (r["mae"] if r["mae"] is not None else 0.0)) for r in m["distance_rows"]], "不同距离段的定位 MAE (m)", max_value=0.15))

    story.append(P("二、检测与定位误差", st["h1"]))
    story.append(P(f"综合定位事件的有符号平均误差为 {num(met['event_mean_signed_error'])} m，中位绝对误差为 {num(met['event_median_abs_error'])} m。正值表示测量距离略偏远。全部 {met['usable_event_count']} 条质量可用定位事件均在 ±0.6 m 容差内。", st["body"]))
    dist_rows = [["真实距离段", "事件数", "MAE (m)", "P95 (m)", "≤0.6 m"]]
    for r in m["distance_rows"]:
        dist_rows.append([r["label"], str(r["n"]), num(r["mae"]), num(r["p95"]), pct(r["within"], 1)])
    story.append(styled_table(dist_rows, [42 * mm, 25 * mm, 31 * mm, 31 * mm, 35 * mm], st, alignments={1: "RIGHT", 2: "RIGHT", 3: "RIGHT", 4: "RIGHT"}))
    story.append(Spacer(1, 4 * mm))
    story.append(P("定位误差合并两类原始记录：单异常试次的试次级 distance_error_m，以及多异常记录中与预期异常匹配的候选级误差。未检出试验没有可用的定位距离，不以零误差填补；1 条 quality_usable=false 的检测记录从定位误差统计中排除。", st["small"]))

    board_rows = [["测试板", "定位事件数", "MAE (m)", "P95 (m)", "≤0.6 m", "极性正确"]]
    for r in sorted(m["board_rows"], key=lambda x: (-(x["n"] or 0), x["code"])):
        board_rows.append([r["code"], str(r["n"]), num(r["mae"]), num(r["p95"]), pct(r["within"], 1), pct(r["polarity"], 1)])
    story.append(KeepTogether([P("三、不同测试板的表现", st["h1"]), styled_table(board_rows, [30 * mm, 22 * mm, 29 * mm, 29 * mm, 29 * mm, 29 * mm], st, alignments={1: "RIGHT", 2: "RIGHT", 3: "RIGHT", 4: "RIGHT", 5: "RIGHT"}), Spacer(1, 3 * mm), P("按真实异常测试板汇总单异常试次与多异常候选，质量无效记录不计入定位误差。每个测试板的样本量列为可用定位事件数。", st["small"])]))

    story.append(P("四、实验结构与重复性", st["h1"]))
    mode_rows = [["模式", "试验数", "占全部试验", "状态分布"]]
    for mode in ("normal", "single", "multi"):
        xs = [t for t in m["trials"] if t.get("mode") == mode]
        mode_rows.append([mode, str(len(xs)), pct(len(xs) / len(m["trials"]), 1), ", ".join(f"{k}={v}" for k, v in Counter(x.get("detection_status") for x in xs).items())])
    story.append(styled_table(mode_rows, [30 * mm, 25 * mm, 32 * mm, 77 * mm], st, alignments={1: "RIGHT", 2: "RIGHT"}))
    story.append(Spacer(1, 4 * mm))
    story.append(P(f"多异常模式包含 {sum(1 for t in m['trials'] if t.get('mode') == 'multi')} 条试验，涉及 {sum(int(t.get('expected_anomaly_count') or 0) for t in m['trials'] if t.get('mode') == 'multi')} 个预期异常位置。原始候选表共 {len(m['candidates'])} 条记录，均为多异常候选；单异常距离误差则保存在 trial 记录中。逐次记录的 candidate_count 合计与候选表记录数均为 {len(m['candidates'])}，未发现逐次/候选数量对不上的情况。", st["body"]))
    quality_rows = [["质量标记", "试验数", "说明"]]
    for q, n in m["quality"].most_common():
        quality_rows.append([str(q), str(n), "原始记录中的 quality_flag 值"])
    story.append(styled_table(quality_rows, [42 * mm, 25 * mm, 97 * mm], st, alignments={1: "RIGHT"}))
    story.append(Spacer(1, 4 * mm))
    story.append(P(f"quality_usable=true 的试验占 {pct(met['quality_usable_rate'], 2)}。当前原始记录中没有 invalid 或 rejected 状态，未检出记录仍保留在检出率分母中。", st["body"]))
    story.append(P("五、按实验类别观察", st["h1"]))
    cat_rows = [["类别", "试验数", "检测状态", "主要用途"]]
    descriptions = {x.get("code"): x.get("name", "") for x in d["categories"]}
    for code in sorted(set(t.get("category_code") for t in m["trials"])):
        xs = [t for t in m["trials"] if t.get("category_code") == code]
        status = Counter(x.get("detection_status") for x in xs)
        cat_rows.append([code, str(len(xs)), ", ".join(f"{k}={v}" for k, v in status.items()), descriptions.get(code, "")])
    story.append(styled_table(cat_rows, [22 * mm, 25 * mm, 58 * mm, 59 * mm], st, alignments={1: "RIGHT"}))

    story.append(P("六、结论与数据限制", st["h1"]))
    conclusions = [
        "当前样本显示：异常检出率高，正常参考未出现候选误报；所有检测候选均成功匹配到真实异常并通过极性校验。",
        f"定位误差整体较小：合并两类事件记录后，212 条质量可用定位事件的 MAE 为 {num(met['event_mae'])} m，P95 绝对误差为 {num(met['event_p95_abs_error'])} m；本样本中 212 条均在 0.6 m 容差内。",
        "230 条逐次测量全部来自“FW63 生产测量 2026-11-02”批次；另有 8 次导入运行记录没有逐次试验，因此不应与生产批次混合计算性能均值。",
        "报告使用的是理论反射系数和实验记录中的标签。它们适合评价当前实验数据中的检测与定位表现，不能替代跨批次、跨硬件或长期稳定性验证。",
    ]
    for i, c in enumerate(conclusions, start=1):
        story.append(P(f"{i}. {c}", st["body"]))
    story.append(Spacer(1, 3 * mm))
    story.append(P("统计规则", st["h2"]))
    rules = d["settings"]
    rule_text = f"距离容差 {rules['distance_tolerance_m']} m；异常检出率阈值 {pct(rules['min_detection_rate'], 0)}；误报率上限 {pct(rules['max_false_alarm_rate'], 0)}；定位通过率阈值 {pct(rules['min_location_rate'], 0)}；要求极性正确；未检出试验不参与距离误差均值。均值/百分位仅描述当前导出样本，不代表跨批次稳定性。"
    story.append(P(rule_text, st["body"]))
    story.append(Spacer(1, 3 * mm))
    story.append(P("原始数据来源", st["h2"]))
    story.append(P("measurements/full_dataset.json（当前目录）。统计依据为原始记录与元数据；目录中已有的统计汇总文件和分析报告未被用于计算。", st["small"]))
    return story


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    data = load_data()
    metrics = build_metrics(data)
    doc = NumberedDocTemplate(OUT_PATH, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=22 * mm, bottomMargin=16 * mm, title="TDR数据统计报告", author="Codex")
    doc.build(build_story(metrics))
    print(json.dumps({"output": OUT_PATH, "bytes": os.path.getsize(OUT_PATH), "metrics": metrics["metrics"], "board_rows": metrics["board_rows"], "distance_rows": metrics["distance_rows"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
