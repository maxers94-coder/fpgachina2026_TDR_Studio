#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TDR系统性能测试报告 —— 独立数据审计脚本 (权威版)
==================================================

审计原则:
  1. 以 measurements/trials.csv (逐次测量原始记录) 为唯一权威数据源
  2. statistics.csv / summary.csv 仅用于交叉比对, 不作为计算依据
  3. 不修改任何原始数据
  4. 不填补缺失记录
  5. 所有指标均标注样本筛选规则
  6. 仅使用 Python 标准库

用法:
    python audit_v2.py
输出:
    审计结果_权威.json   (机器可读)
    审计结果_权威.txt     (人可读日志)
"""

import csv
import json
import math
import os
from collections import defaultdict, Counter
from pathlib import Path

BASE = Path(__file__).resolve().parent
TRIALS = BASE / "measurements" / "trials.csv"
STATS = BASE / "statistics" / "statistics.csv"
SUMMARY = BASE / "statistics" / "summary.csv"
MANIFEST = BASE / "manifest.json"
BOARDS = BASE / "metadata" / "boards.json"

LOG = []


def log(msg=""):
    print(msg)
    LOG.append(str(msg))


def rule(title):
    log()
    log("=" * 78)
    log(title)
    log("=" * 78)


def sub(title):
    log()
    log("-- " + title + " " + "-" * max(0, 74 - len(title)))


def fnum(v, default=None):
    if v is None:
        return default
    v = str(v).strip()
    if v == "" or v.lower() in ("none", "null", "nan"):
        return default
    try:
        return float(v)
    except ValueError:
        return default


def load_csv(path):
    with open(path, "r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def percentile(sorted_vals, p):
    """线性插值百分位 (与 numpy.percentile 默认一致)"""
    if not sorted_vals:
        return None
    n = len(sorted_vals)
    if n == 1:
        return sorted_vals[0]
    idx = (n - 1) * p
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return sorted_vals[lo]
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (idx - lo)


def mean(vals):
    return sum(vals) / len(vals) if vals else None


def stdev(vals):
    if len(vals) < 2:
        return None
    m = mean(vals)
    return math.sqrt(sum((v - m) ** 2 for v in vals) / (len(vals) - 1))


# ============================================================================
# 载入
# ============================================================================

rule("TDR 性能测试报告 —— 独立数据审计 (权威版)")
log(f"执行时间基准 : 脚本运行时")
log(f"数据目录     : {BASE}")
log(f"权威数据源   : measurements/trials.csv")

trials = load_csv(TRIALS)
stats = load_csv(STATS)
summary = load_csv(SUMMARY)
manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
boards_meta = json.loads(BOARDS.read_text(encoding="utf-8"))

if isinstance(boards_meta, list):
    boards = boards_meta
elif isinstance(boards_meta, dict):
    boards = boards_meta.get("boards", list(boards_meta.values()))
else:
    boards = []

RULES = manifest["statistics_rules"]
TOL = float(RULES["distance_tolerance_m"])

log(f"trials.csv 记录数        : {len(trials)}")
log(f"statistics.csv 配置记录数: {len(stats)}")
log(f"manifest 声明 trial_count: {manifest['trial_count']}")
log(f"manifest 声明 tolerance  : {TOL} m")
log(f"manifest 声明 rules      : {json.dumps(RULES, ensure_ascii=False)}")

# 校验 trials.csv 行数与 manifest 声明是否一致
assert len(trials) == manifest["trial_count"], "trials.csv 行数与 manifest 不符"

# ============================================================================
# 1. 基础分布 —— 确认原始记录完整性
# ============================================================================

rule("1. 原始记录完整性核查")

status_ct = Counter(t["detection_status"] for t in trials)
mode_ct = Counter(t["mode"] for t in trials)
cat_ct = Counter(t["category_code"] for t in trials)
usable_ct = Counter(t["quality_usable"] for t in trials)
batch_ct = Counter(t["batch_name"] for t in trials)

log(f"detection_status 分布 : {dict(status_ct)}")
log(f"mode 分布             : {dict(mode_ct)}")
log(f"category_code 分布    : {dict(cat_ct)}")
log(f"quality_usable 分布   : {dict(usable_ct)}")
log(f"batch_name 分布       : {dict(batch_ct)}")

# 唯一性校验
trial_ids = [t["trial_id"] for t in trials]
log(f"trial_id 唯一          : {len(set(trial_ids)) == len(trial_ids)} ({len(set(trial_ids))}/{len(trial_ids)})")

cfg_ids = set(t["configuration_id"] for t in trials)
log(f"trials 涉及配置数     : {len(cfg_ids)}")

# 有 anomaly 期望的试验 (mode != normal)
anomaly_trials = [t for t in trials if t["mode"] != "normal"]
normal_trials = [t for t in trials if t["mode"] == "normal"]
log(f"期望含异常的试验数     : {len(anomaly_trials)}")
log(f"正常线缆试验数         : {len(normal_trials)}")

# ============================================================================
# 2. 检出率 —— 多种口径并列
# ============================================================================

rule("2. 检出率：多口径并列计算")

detected = [t for t in anomaly_trials if t["detection_status"] == "detected"]
not_detected = [t for t in anomaly_trials if t["detection_status"] == "not_detected"]
other_status = [t for t in anomaly_trials if t["detection_status"] not in ("detected", "not_detected")]

n_det = len(detected)
n_nd = len(not_detected)
n_anom = len(anomaly_trials)

log("筛选规则: mode != 'normal' (即期望检出异常的试验)")
log(f"  分子 detected    : {n_det}")
log(f"  分母 anomaly 总数: {n_anom}")
log(f"  检出率           : {n_det}/{n_anom} = {n_det/n_anom*100:.4f}%")
log()

# 口径 B: 排除 quality_usable == false
anom_usable = [t for t in anomaly_trials if t["quality_usable"] == "true"]
det_usable = [t for t in anom_usable if t["detection_status"] == "detected"]
log("口径 B (排除 quality_usable=false 的边界记录):")
log(f"  检出率 = {len(det_usable)}/{len(anom_usable)} = {len(det_usable)/len(anom_usable)*100:.4f}%")
edge = [t for t in anomaly_trials if t["quality_usable"] != "true"]
for t in edge:
    log(f"  被排除: {t['config_code']} {t['config_name']} status={t['detection_status']} flag={t['quality_flag']}")
log()

# 口径 C: 全量 230 (含正常试验作分母) —— 报告中"229/230"式的错误口径
log("口径 C (全量 230 作分母, 正常试验计入分母 —— 错误口径, 仅用于对照):")
log(f"  {n_det}/{len(trials)} = {n_det/len(trials)*100:.4f}%")
log()

# 口径 D: edge_as_valid 规则 —— edge 记录既不算成功也不算失败
edge_as_invalid = len([t for t in edge if t["detection_status"] == "detected"])
log(f"口径 D (manifest rules: edge_as_valid={RULES['edge_as_valid']}, "
    f"hardware_error_fails={RULES['hardware_error_fails']}):")
log(f"  若 edge 视为无效 -> 有效异常试验 = {len(anom_usable)}, 检出 = {len(det_usable)}")
log(f"  -> 检出率 = {len(det_usable)/len(anom_usable)*100:.4f}%")

# 找一找 99.46% 的来源
target = 99.46
log()
log(f"反查报告声称的 {target}% 对应的分母组合:")
for num in range(150, 235):
    rate = num / n_anom * 100
    if abs(rate - target) < 0.02:
        log(f"  命中: {num}/{n_anom} = {rate:.4f}%")
for den in range(150, 235):
    rate = n_det / den * 100
    if abs(rate - target) < 0.02:
        log(f"  命中: {n_det}/{den} = {rate:.4f}%")

log()
log(f"直接验算 229/230 = {229/230*100:.4f}%   (报告写 99.46%, 正确值应为 {229/230*100:.2f}%)")

# ============================================================================
# 3. 误报率
# ============================================================================

rule("3. 误报率")

# 正常试验中产生候选的即为误报
false_alarm_trials = [t for t in normal_trials
                       if t["detection_status"] == "detected" or int(fnum(t["candidate_count"], 0) or 0) > 0]
n_fa = len(false_alarm_trials)
log("筛选规则: mode == 'normal' 且 detection_status == 'detected' 或 candidate_count > 0")
log(f"  正常试验总数   : {len(normal_trials)}")
log(f"  误报数         : {n_fa}")
log(f"  误报率         : {n_fa}/{len(normal_trials)} = {n_fa/len(normal_trials)*100:.4f}%")
log(f"  正常判断率     : {(len(normal_trials)-n_fa)}/{len(normal_trials)} = "
    f"{(len(normal_trials)-n_fa)/len(normal_trials)*100:.4f}%")

# 按类别A
catA_normal = [t for t in trials if t["category_code"] == "A"]
catA_fa = [t for t in catA_normal if t["detection_status"] == "detected"]
log(f"  类别A 子集     : {len(catA_normal)} 次正常试验, 误报 {len(catA_fa)} 次")

# ============================================================================
# 4. 极性准确率
# ============================================================================

rule("4. 极性判断准确率")

pol_checked = [t for t in trials if t["polarity_correct"] not in ("", None)]
pol_true = [t for t in pol_checked if t["polarity_correct"] == "true"]
pol_false = [t for t in pol_checked if t["polarity_correct"] == "false"]
pol_empty = [t for t in trials if t["polarity_correct"] in ("", None)]

log("筛选规则: polarity_correct 字段非空")
log(f"  有极性判定的试验数 : {len(pol_checked)}")
log(f"  正确               : {len(pol_true)}")
log(f"  错误               : {len(pol_false)}")
log(f"  准确率             : {len(pol_true)}/{len(pol_checked)} = "
    f"{len(pol_true)/len(pol_checked)*100:.4f}%")
log(f"  无极性判定的试验数 : {len(pol_empty)} (正常线缆, 无异常故无极性)")

# 交叉验证: detected 但极性判错的
log()
bad = [t for t in detected if t["polarity_correct"] == "false"]
log(f"  已检出但极性错误   : {len(bad)}")

# 极性与期望值一致性 (不依赖 polarity_correct 字段, 独立重算)
log()
log("独立重算: 比对 polarity 与 expected_polarity")
mismatch = []
for t in anomaly_trials:
    p, ep = t["polarity"].strip(), t["expected_polarity"].strip()
    if p and ep and p != ep:
        mismatch.append(t)
log(f"  polarity != expected_polarity 的试验数 : {len(mismatch)}")

# ============================================================================
# 5. 定位误差 —— 从 trials.csv 逐条重算
# ============================================================================

rule("5. 定位误差：从 trials.csv 逐条重算")

# 定位样本 = 异常试验 且 有 measured_distance_m
loc_trials = [t for t in anomaly_trials if fnum(t["measured_distance_m"]) is not None]
errors = []
for t in loc_trials:
    e = fnum(t["distance_error_m"])
    if e is None:
        e = fnum(t["measured_distance_m"]) - fnum(t["true_distance_m"])
    errors.append(e)

abs_err = [abs(e) for e in errors]
sq_err = [e * e for e in errors]
mae = mean(abs_err)
rmse = math.sqrt(mean(sq_err))
med = percentile(sorted(abs_err), 0.50)
p95 = percentile(sorted(abs_err), 0.95)
mx = max(abs_err)
mn = min(abs_err)
bias = mean(errors)
sd = stdev(errors)

log("筛选规则: mode != 'normal' 且 measured_distance_m 非空")
log(f"  定位样本数 n        : {len(loc_trials)}")
log(f"  MAE                 : {mae:.4f} m ({mae*100:.2f} cm)")
log(f"  RMSE                : {rmse:.4f} m")
log(f"  中位绝对误差        : {med:.4f} m")
log(f"  P95 绝对误差        : {p95:.4f} m")
log(f"  最大绝对误差        : {mx:.4f} m")
log(f"  最小绝对误差        : {mn:.4f} m")
log(f"  平均有符号误差(偏差): {bias:+.4f} m")
log(f"  误差标准差          : {sd:.4f} m")

# 容差内统计
within = [t for t in loc_trials
          if (fnum(t["distance_error_m"]) is not None
              and abs(fnum(t["distance_error_m"])) <= TOL)]
log(f"  容差(±{TOL}m)内      : {len(within)}/{len(loc_trials)} = "
    f"{len(within)/len(loc_trials)*100:.2f}%")

# 有距离但超出容差
outside = [t for t in loc_trials
           if fnum(t["distance_error_m"]) is not None
           and abs(fnum(t["distance_error_m"])) > TOL]
log(f"  超出容差            : {len(outside)}")
for t in outside:
    log(f"    {t['config_code']} {t['config_name']} err={fnum(t['distance_error_m']):.4f}")

# 归一化误差 (误差/线长)
rel = []
for t in loc_trials:
    td = fnum(t["true_distance_m"])
    e = fnum(t["distance_error_m"])
    if td and e is not None and td > 0:
        rel.append(abs(e) / td)
log(f"  平均相对误差        : {mean(rel)*100:.4f}%  (n={len(rel)})")

# ============================================================================
# 6. 分类统计 —— 从 trials.csv 重算
# ============================================================================

rule("6. 分类统计 (逐条重算, 与 statistics.csv 交叉比对)")

CATS = {
    "A": "正常参考与误报测试",
    "B": "开路与短路检测",
    "C": "单个阻抗异常检测",
    "D": "最小与最大检测距离",
    "E": "多异常同时定位",
    "F": "重复性、漂移和连续测量",
}

cat_results = {}
for code, name in CATS.items():
    ct = [t for t in trials if t["category_code"] == code]
    cfgs = sorted(set(t["configuration_id"] for t in ct))
    anom = [t for t in ct if t["mode"] != "normal"]
    det = [t for t in anom if t["detection_status"] == "detected"]
    nd = [t for t in anom if t["detection_status"] == "not_detected"]
    loc = [t for t in anom if fnum(t["measured_distance_m"]) is not None]
    e_list = [abs(fnum(t["distance_error_m"])) for t in loc]
    nor = [t for t in ct if t["mode"] == "normal"]
    fa = [t for t in nor if t["detection_status"] == "detected"]

    # 与 statistics.csv 交叉比对
    sc = [s for s in stats if s["category_code"] == code and s["data_status"] == "has_data"]
    sc_trials = sum(int(fnum(s["total_trials"], 0) or 0) for s in sc)
    sc_det = sum(int(fnum(s["detected_count"], 0) or 0) for s in sc)
    sc_mae = None
    tw = sum(int(fnum(s["located_count"], 0) or 0) for s in sc)
    if tw:
        sc_mae = sum(fnum(s["mae_m"], 0) * int(fnum(s["located_count"], 0) or 0) for s in sc) / tw

    cat_results[code] = {
        "name": name,
        "trials_from_trials_csv": len(ct),
        "configs_from_trials_csv": len(cfgs),
        "trials_from_statistics_csv": sc_trials,
        "configs_from_statistics_csv": len(sc),
        "anomaly_trials": len(anom),
        "normal_trials": len(nor),
        "detected": len(det),
        "not_detected": len(nd),
        "detection_rate_pct": (len(det) / len(anom) * 100) if anom else None,
        "false_alarms": len(fa),
        "false_alarm_rate_pct": (len(fa) / len(nor) * 100) if nor else None,
        "located_trials": len(loc),
        "mae_m_from_trials": mean(e_list),
        "mae_m_from_statistics": sc_mae,
        "max_abs_error_m": max(e_list) if e_list else None,
    }

    r = cat_results[code]
    log()
    log(f"类别 {code} — {name}")
    log(f"  配置数   trials.csv={r['configs_from_trials_csv']}  statistics.csv={r['configs_from_statistics_csv']}")
    log(f"  测量次数 trials.csv={r['trials_from_trials_csv']}  statistics.csv={r['trials_from_statistics_csv']}")
    log(f"  异常试验 {r['anomaly_trials']}  正常试验 {r['normal_trials']}")
    log(f"  检出 {r['detected']}  未检出 {r['not_detected']}  检出率 {r['detection_rate_pct']:.2f}%" if r["anomaly_trials"] else "  n/a")
    log(f"  误报 {r['false_alarms']}  误报率 {r['false_alarm_rate_pct']:.2f}%" if r["normal_trials"] else "  n/a")
    if r["located_trials"]:
        log(f"  定位样本 {r['located_trials']}  MAE(trials)={r['mae_m_from_trials']:.4f} m  "
            f"MAE(statistics)={r['mae_m_from_statistics']:.4f} m")
    else:
        log("  定位样本 0  (多异常场景距离由 candidates 表提供)")

# 合计
tot_cfg = sum(c["configs_from_trials_csv"] for c in cat_results.values())
tot_tri = sum(c["trials_from_trials_csv"] for c in cat_results.values())
log()
log(f"合计: 配置 {tot_cfg} 组, 测量 {tot_tri} 次")

# ============================================================================
# 7. 类别C 细分：按异常类型 / 按距离
# ============================================================================

rule("7. 类别C 细分（单异常检测）")

catC = [t for t in trials if t["category_code"] == "C"]
log(f"类别C 试验总数: {len(catC)}")
log()
log("7.1 按异常板类型 (board_code) 统计")
by_board = defaultdict(list)
for t in catC:
    by_board[t["board_code"]].append(t)
log(f"  {'板号':<6} {'板名':<22} {'n':>4} {'MAE(m)':>10} {'最大误差':>10}")
for bc in sorted(by_board):
    grp = by_board[bc]
    e = [abs(fnum(t["distance_error_m"])) for t in grp if fnum(t["distance_error_m"]) is not None]
    log(f"  {bc:<6} {grp[0]['board_name'][:20]:<22} {len(grp):>4} "
        f"{mean(e):>10.4f} {max(e):>10.4f}" if e else
        f"  {bc:<6} {grp[0]['board_name'][:20]:<22} {len(grp):>4} {'n/a':>10} {'n/a':>10}")

log()
log("7.2 按线缆长度统计")
by_dist = defaultdict(list)
for t in catC:
    by_dist[fnum(t["true_distance_m"])].append(t)
log(f"  {'距离(m)':>9} {'n':>4} {'MAE(m)':>10} {'RMSE(m)':>10} {'最大误差':>10}")
for d in sorted(by_dist):
    grp = by_dist[d]
    ee = [fnum(t["distance_error_m"]) for t in grp if fnum(t["distance_error_m"]) is not None]
    ae = [abs(x) for x in ee]
    rm = math.sqrt(mean([x * x for x in ee])) if ee else None
    log(f"  {d:>9.0f} {len(grp):>4} {mean(ae):>10.4f} {rm:>10.4f} {max(ae):>10.4f}")

log()
log("7.3 按 config_name 中声明的异常类型 (Sxx / Pxxxx) 统计")
by_type = defaultdict(list)
for t in catC:
    cn = t["config_name"]
    if "|" in cn:
        parts = [p.strip() for p in cn.split("|")]
        key = parts[1] if len(parts) > 1 else cn
    else:
        key = cn
    by_type[key].append(t)
log(f"  {'声明异常类型':<18} {'n':>4} {'MAE(m)':>10} {'最大误差':>10}")
type_maes = []
for k in sorted(by_type):
    grp = by_type[k]
    e = [abs(fnum(t["distance_error_m"])) for t in grp if fnum(t["distance_error_m"]) is not None]
    type_maes.extend(e)
    log(f"  {k:<18} {len(grp):>4} {mean(e):>10.4f} {max(e):>10.4f}" if e
        else f"  {k:<18} {len(grp):>4} {'n/a':>10} {'n/a':>10}")
log(f"  {'-> 合并MAE':<18} {len(type_maes):>4} {mean(type_maes):>10.4f} {max(type_maes):>10.4f}")

log()
log("7.4 三种口径的类别C MAE 对比")
all_c = [abs(fnum(t["distance_error_m"])) for t in catC if fnum(t["distance_error_m"]) is not None]
log(f"  (a) 全部72次试验合并         : n={len(all_c):>3}  MAE={mean(all_c):.4f} m")
log(f"  (b) 按8种声明异常类型分组再合并: n={len(type_maes):>3}  MAE={mean(type_maes):.4f} m")
dist_maes = []
for d in by_dist:
    dist_maes.extend([abs(fnum(t["distance_error_m"])) for t in by_dist[d]
                       if fnum(t["distance_error_m"]) is not None])
log(f"  (c) 按3个距离分组再合并       : n={len(dist_maes):>3}  MAE={mean(dist_maes):.4f} m")
log(f"  (d) statistics.csv 加权MAE    : "
    f"MAE={cat_results['C']['mae_m_from_statistics']:.4f} m")
log(f"  => (a)(b)(c)(d) 本质同一口径(按试验等权), 差异仅来自分组后平均方式")

# ============================================================================
# 8. 多异常场景
# ============================================================================

rule("8. 多异常场景 (类别E) 核查")

catE = [t for t in trials if t["category_code"] == "E"]
multi = [t for t in catE if t["mode"] == "multi"]
log(f"类别E 试验总数 {len(catE)}, 其中 mode=multi 的 {len(multi)}")
log()
by_cfg = defaultdict(list)
for t in catE:
    by_cfg[(t["config_code"], t["config_name"])].append(t)
for (cc, cn), grp in sorted(by_cfg.items()):
    det = [t for t in grp if t["detection_status"] == "detected"]
    exp = [int(fnum(t["expected_anomaly_count"], 0) or 0) for t in grp]
    cand = [int(fnum(t["candidate_count"], 0) or 0) for t in grp]
    extra = [int(fnum(t["extra_candidate_count"], 0) or 0) for t in grp]
    log(f"  {cc} {cn}")
    log(f"    试验 {len(grp)}  检出 {len(det)}  期望异常数(取首条) {exp[0] if exp else 0}  "
        f"候选数 {cand}  多余候选 {extra}")

# 从 candidates/expected_anomalies 交叉核查多异常匹配
cand_path = BASE / "measurements" / "candidates.csv"
exp_path = BASE / "measurements" / "expected_anomalies.csv"
if cand_path.exists() and exp_path.exists():
    cands = load_csv(cand_path)
    exps = load_csv(exp_path)
    log()
    log(f"candidates.csv 记录数         : {len(cands)}")
    log(f"expected_anomalies.csv 记录数 : {len(exps)}")
    log(f"manifest candidate_count      : {manifest['candidate_count']}")
    log("candidates.csv 字段: " + ", ".join(cands[0].keys()) if cands else "")
    log("expected_anomalies.csv 字段: " + ", ".join(exps[0].keys()) if exps else "")
    # 多异常试次的匹配统计
    multi_cfg_ids = set(t["configuration_id"] for t in multi)
    mc = [c for c in cands if c.get("configuration_id") in multi_cfg_ids]
    me = [e for e in exps if e.get("configuration_id") in multi_cfg_ids]
    log(f"  多异常配置对应的 candidates 记录 : {len(mc)}")
    log(f"  多异常配置对应的 expected 记录   : {len(me)}")
    if mc:
        log("  candidates 样例字段样例:")
        for k, v in list(mc[0].items()):
            log(f"    {k} = {v}")

    # 8.1 从 candidates.csv 计算多异常定位精度 (补齐报告"多异常定位误差"章节)
    log()
    log("8.1 多异常场景定位精度 (数据源: measurements/candidates.csv)")
    mc_loc = [c for c in cands if fnum(c["measured_distance_m"]) is not None]
    log(f"  含距离的候选记录数 : {len(mc_loc)}")
    if mc_loc:
        ce = [abs(fnum(c["distance_error_m"])) for c in mc_loc]
        log(f"  候选级 MAE  : {mean(ce):.4f} m ({mean(ce)*100:.2f} cm)")
        log(f"  候选级 中位 : {percentile(sorted(ce),0.5):.4f} m")
        log(f"  候选级 P95  : {percentile(sorted(ce),0.95):.4f} m")
        log(f"  候选级 最大 : {max(ce):.4f} m")
        log(f"  容差内      : {sum(1 for x in ce if x<=TOL)}/{len(ce)} = "
            f"{sum(1 for x in ce if x<=TOL)/len(ce)*100:.2f}%")
        ms = Counter(c["match_status"] for c in mc_loc)
        log(f"  match_status 分布 : {dict(ms)}")
        pc = [c for c in mc_loc if c["polarity_correct"] == "true"]
        log(f"  候选级极性正确 : {len(pc)}/{len(mc_loc)}")
    log()
    log("  按 config_code 汇总 (多异常配置):")
    bycfg_c = defaultdict(list)
    for c in mc_loc:
        bycfg_c[c["config_code"]].append(c)
    log(f"    {'配置':<8}{'候选数':>7}{'期望异常':>9}{'MAE(m)':>10}{'最大误差':>10}{'容差内':>9}")
    for cc in sorted(bycfg_c):
        grp = bycfg_c[cc]
        ee = [abs(fnum(c["distance_error_m"])) for c in grp]
        expn = int(fnum(grp[0].get("matched_anomaly_index"), 0) or 0)
        # 期望异常数从 trials.csv 取
        tt = [t for t in trials if t["config_code"] == cc]
        expn2 = int(fnum(tt[0]["expected_anomaly_count"], 0) or 0) if tt else 0
        log(f"    {cc:<8}{len(grp):>7}{expn2:>9}{mean(ee):>10.4f}{max(ee):>10.4f}"
            f"{sum(1 for x in ee if x<=TOL):>6}/{len(grp):<3}")
    # 多异常总体
    log()
    log(f"  多异常候选合并 MAE : {mean([abs(fnum(c['distance_error_m'])) for c in mc_loc]):.4f} m")

# 8.2 config_name 声明异常 vs 实际板件标称 矛盾核查
rule("8.2 配置名称声明值 vs 实际板件标称值 —— 矛盾核查")

board_by_code = {}
for b in boards:
    board_by_code[b["code"]] = b

# 从 config_name 抽取声明值
import re
DECL_RE = re.compile(r"(S|P)([\d.]+)")


def declared_type(cn):
    m = DECL_RE.search(cn)
    if not m:
        return None, None
    kind = "series" if m.group(1) == "S" else "shunt"
    return kind, float(m.group(2))


log(f"{'配置':<9}{'config_name声明':<24}{'声明值':>9}{'实际板':<8}{'板标称':>9}{'类型':>8}{'一致性':>10}")
log("-" * 82)
conflicts = []
for t in trials:
    if t["category_code"] not in ("C", "D"):
        continue
    cn = t["config_name"]
    dk, dv = declared_type(cn)
    if dv is None:
        continue
    bc = t["board_code"]
    b = board_by_code.get(bc)
    if not b:
        continue
    nom = b["nominal_ohm"]
    btype = b["board_type"]
    if nom is None:
        continue
    same_kind = (dk == "series" and btype == "series") or (dk == "shunt" and btype == "shunt")
    same_val = abs(dv - nom) < 0.5
    verdict = "一致" if (same_kind and same_val) else ("类型不符" if not same_kind else "阻值不符")
    if verdict != "一致":
        conflicts.append((t["config_code"], cn, dv, bc, b["name"], nom, btype, verdict))
    # 每个 config_code 只打一次
for c in sorted(set((x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7]) for x in conflicts)):
    log(f"{c[0]:<9}{c[1][:22]:<24}{c[2]:>9}{c[3]:<8}{str(c[5]):>9}{c[6]:>8}{c[7]:>10}")

log()
log(f"存在声明值与板件标称不符的配置数: {len(set(x[0] for x in conflicts))}")
log("说明: config_name 中的 Sxx/Pxxxx 来自原始 Excel 试验矩阵命名；")
log("      boards.json 中的板件标称值来自板卡登记。两者不一致时，")
log("      本审计以 boards.json 的 nominal_ohm 与 board_type 为准 (有 measured_ohm 佐证)。")

# ============================================================================
# 9. 重复性
# ============================================================================

rule("9. 重复性 / 连续测量 (类别F)")

catF = [t for t in trials if t["category_code"] == "F"]
log(f"类别F 试验总数: {len(catF)}")
by_cfgF = defaultdict(list)
for t in catF:
    by_cfgF[(t["config_code"], t["config_name"])].append(t)
for (cc, cn), grp in sorted(by_cfgF.items()):
    det = [t for t in grp if t["detection_status"] == "detected"]
    anom = [t for t in grp if t["mode"] != "normal"]
    e = [fnum(t["distance_error_m"]) for t in grp if fnum(t["distance_error_m"]) is not None]
    log()
    log(f"  {cc} {cn}")
    log(f"    试验 {len(grp)} (异常试验 {len(anom)})  检出 {len(det)}")
    if anom:
        log(f"    异常试验检出率 {len([t for t in anom if t['detection_status']=='detected'])}/{len(anom)}"
            f" = {len([t for t in anom if t['detection_status']=='detected'])/len(anom)*100:.2f}%")
    if e:
        sd_s = stdev(e)
        sd_txt = f"{sd_s:.4f}" if sd_s is not None else "n/a(n<2)"
        log(f"    误差均值 {mean(e):+.4f} m  标准差 {sd_txt} m  "
            f"min|err| {min(abs(x) for x in e):.4f}  max|err| {max(abs(x) for x in e):.4f}  "
            f"极差 {max(e)-min(e):.4f}")
    else:
        log("    无距离数据")

# 连续11次
seq = [t for t in catF if t["config_code"] == "PF05"]
if seq:
    seq = sorted(seq, key=lambda t: int(t["trial_index"]))
    e = [fnum(t["distance_error_m"]) for t in seq]
    log()
    log(f"  PF05 连续测量序列 (n={len(seq)}):")
    for t in seq:
        log(f"    idx{t['trial_index']:>3}  true={t['true_distance_m']:>6}  "
            f"meas={t['measured_distance_m']:>10}  err={fnum(t['distance_error_m']):+.4f}  "
            f"status={t['detection_status']}")
    if len(e) >= 2:
        log(f"    均值 {mean(e):+.4f} m  标准差 {stdev(e):.4f} m  极差 {max(e)-min(e):.4f} m")
    else:
        log(f"    均值 {mean(e):+.4f} m  (n<2, 标准差不适用)")

# ============================================================================
# 10. 测试板规格核验
# ============================================================================

rule("10. 测试板规格核验 (metadata/boards.json)")

log(f"boards.json 条目数: {len(boards)}")
if boards:
    log("字段: " + ", ".join(boards[0].keys()))
log()

# 汇总 trials.csv 中实际用到的板
used = defaultdict(lambda: {"trials": 0, "dists": set()})
for t in trials:
    bc = t["board_code"]
    used[bc]["trials"] += 1
    used[bc]["dists"].add(fnum(t["true_distance_m"]))

log("10.1 trials.csv 实际使用的板 vs boards.json 声明")
for bc in sorted(used):
    found = None
    for b in boards:
        if (b.get("board_code") or b.get("code")) == bc:
            found = b
            break
    name = found.get("board_name") if found else (used[bc].get("name") or "")
    log(f"  {bc:<7} 试验{used[bc]['trials']:>3}次  boards.json: {'找到' if found else '未找到'}  {name}")
    if found:
        for k, v in found.items():
            log(f"           {k} = {v}")

log()
log("10.2 理论反射系数复算 (集总参数模型)")
log("  模型假设: Z0 = 50Ω 基准; 串联电阻 Rs -> Z = Z0 + Rs;")
log("            并联电阻 Rp -> Z = Z0*Rp/(Z0+Rp);  Γ = (Z-Z0)/(Z+Z0)")
log("  注: 实际板件标称值以 boards.json 为准, 以下为报告附录所载值的复算:")

Z0 = 50.0
report_appendix = [
    ("T2", "2Ω 串联", "series", 2.0, 0.020),
    ("T4", "1Ω 串联", "series", 1.0, 0.010),
    ("T6", "4.3Ω 串联", "series", 4.3, 0.041),
    ("T9", "10Ω 串联", "series", 10.0, 0.091),
    ("T8", "220Ω 并联", "parallel", 220.0, -0.118),
    ("T7", "620Ω 并联", "parallel", 620.0, -0.064),
    ("T3", "1.2kΩ 并联", "parallel", 1200.0, -0.020),
    ("T5", "2.4kΩ 并联", "parallel", 2400.0, -0.010),
]
log(f"  {'板号':<5} {'类型':<10} {'R':>8} {'复算Γ':>10} {'报告Γ':>10} {'差值':>10} {'判定':>8}")
for bc, desc, kind, R, rep in report_appendix:
    if kind == "series":
        Z = Z0 + R
    else:
        Z = (Z0 * R) / (Z0 + R)
    g = (Z - Z0) / (Z + Z0)
    diff = g - rep
    verdict = "一致" if abs(diff) < 0.001 else ("接近" if abs(diff) < 0.005 else "不一致")
    log(f"  {bc:<5} {desc:<10} {R:>8.1f} {g:>10.4f} {rep:>10.3f} {diff:>+10.4f} {verdict:>8}")

log()
log("10.3 报告正文异常类型命名 vs boards.json 板名")
name_map = defaultdict(set)
for t in trials:
    name_map[t["board_code"]].add(t["board_name"])
for bc in sorted(name_map):
    log(f"  {bc:<7} -> {sorted(name_map[bc])}")

log()
log("10.4 标注为未验证的项:")
log("  [未验证] 报告中'27Ω串联'未在 boards.json 板名中找到对应板 (T8 板名为'220Ω并联异常')")
log("  [未验证] 实测反射系数与理论值的偏差 (trials.csv 未含 gamma 数值列)")
log("  [未验证] 各线缆实际特性阻抗是否为 50Ω (需 cable 元数据)")

# ============================================================================
# 11. 与 statistics.csv / summary.csv 交叉比对
# ============================================================================

rule("11. 与 statistics.csv / summary.csv 交叉比对")

has_data = [s for s in stats if s["data_status"] == "has_data"]
not_tested = [s for s in stats if s["data_status"] == "not_tested"]

log(f"statistics.csv: has_data {len(has_data)} 行, not_tested {len(not_tested)} 行, 合计 {len(stats)}")
log(f"manifest: configuration_count={manifest['configuration_count']}, "
    f"tested_configuration_count={manifest['tested_configuration_count']}")
log()

# 逐配置核对
mismatch_cfg = []
mismatch_trials = []
mismatch_det = []
for s in has_data:
    cid = s["config_id"]
    ct = [t for t in trials if t["configuration_id"] == cid]
    if len(ct) != int(fnum(s["total_trials"], 0) or 0):
        mismatch_trials.append((s["config_code"], len(ct), s["total_trials"]))
    anom = [t for t in ct if t["mode"] != "normal"]
    det = [t for t in anom if t["detection_status"] == "detected"]
    if len(det) != int(fnum(s["detected_count"], 0) or 0):
        mismatch_det.append((s["config_code"], len(det), s["detected_count"]))

log(f"total_trials 不一致的配置数    : {len(mismatch_trials)}")
for x in mismatch_trials[:10]:
    log(f"    {x}")
log(f"detected_count 不一致的配置数 : {len(mismatch_det)}")
for x in mismatch_det[:10]:
    log(f"    {x}")

# MAE 一致性
log()
log("MAE 一致性核对 (statistics.csv 的 mae_m 加权 vs trials.csv 重算)")
mae_diff = []
for s in has_data:
    cid = s["config_id"]
    ct = [t for t in trials if t["configuration_id"] == cid
          and fnum(t["measured_distance_m"]) is not None]
    if not ct:
        continue
    recalc = mean([abs(fnum(t["distance_error_m"])) for t in ct])
    rep = fnum(s["mae_m"])
    if rep is None:
        continue
    if abs(recalc - rep) > 0.005:
        mae_diff.append((s["config_code"], s["config_name"], rep, recalc))
log(f"  MAE 偏差 > 0.005m 的配置数 : {len(mae_diff)}")
for x in mae_diff:
    log(f"    {x[0]:<8} {x[1][:28]:<30} 报告={x[2]:.4f}  重算={x[3]:.4f}")

# summary.csv
log()
log("summary.csv 内容:")
for s in summary:
    log(f"  " + " | ".join(f"{k}={v}" for k, v in s.items()))

log()
log("summary.csv 关键比率复算与来源追溯:")
ov = [s for s in summary if s["summary_scope"] == "overall"]
if ov:
    o = ov[0]
    log(f"  summary.overall.detection_rate        = {o['detection_rate']}")
    log(f"    -> {float(o['detection_rate'])*100:.4f}%  = 183/184  (对应 trials.csv: detected=183, 异常试验=184)")
    log(f"  summary.overall.comprehensive_success_rate = {o['comprehensive_success_rate']}")
    log(f"    -> {float(o['comprehensive_success_rate'])*100:.4f}%  = 229/230  <== 报告'229/230=99.46%'的真正来源")
    log(f"  summary.overall.mae_m                 = {o['mae_m']}")
    log(f"    -> {float(o['mae_m'])*100:.4f} cm  (trials.csv 逐条重算 = {mae*100:.4f} cm)")
    log(f"  summary.overall.p95_abs_error_m       = {o['p95_abs_error_m']}")
    log(f"    -> trials.csv 逐条重算 P95 = {p95:.4f} m")
    log(f"  summary.overall.rmse_m                = {o['rmse_m']}")
    log(f"    -> trials.csv 逐条重算 RMSE = {rmse:.4f} m")

    # 复算综合成功率: 229/230 是什么?
    log()
    log("  复算 comprehensive_success_rate 的构成:")
    # 逐配置统计 comprehensive_success_count
    cs_sum = sum(int(fnum(s["comprehensive_success_count"], 0) or 0) for s in has_data)
    cs_trials = sum(int(fnum(s["total_trials"], 0) or 0) for s in has_data)
    log(f"    statistics.csv  Σcomprehensive_success_count = {cs_sum}")
    log(f"    statistics.csv  Σtotal_trials               = {cs_trials}")
    log(f"    -> {cs_sum}/{cs_trials} = {cs_sum/cs_trials*100:.4f}%  <== 与 summary 一致")

    # 从 trials.csv 独立判定 comprehensive success
    log()
    log("  从 trials.csv 独立判定'综合成功' (需同时满足: 检出 + 极性正确 + 定位在容差内):")
    success = 0
    fail_reasons = []
    for t in trials:
        if t["mode"] == "normal":
            # 正常试验: 未误报即为成功
            if t["detection_status"] == "normal":
                success += 1
            else:
                fail_reasons.append((t["trial_id"], "normal_misjudged"))
            continue
        ok = True
        reasons = []
        if t["detection_status"] != "detected":
            ok = False
            reasons.append("not_detected")
        if t["polarity_correct"] == "false":
            ok = False
            reasons.append("polarity_wrong")
        e = fnum(t["distance_error_m"])
        if e is not None and abs(e) > TOL:
            ok = False
            reasons.append("out_of_tolerance")
        if t["quality_usable"] == "false":
            ok = False
            reasons.append("edge_unusable")
        if ok:
            success += 1
        else:
            fail_reasons.append((t["config_code"], ",".join(reasons)))
    log(f"    独立重算综合成功数 = {success}/{len(trials)} = {success/len(trials)*100:.4f}%")
    log(f"    未成功的记录:")
    for fr in fail_reasons:
        log(f"      {fr[0]}: {fr[1]}")

# ============================================================================
# 12. 报告数值逐条比对表
# ============================================================================

rule("12. 报告数值 vs 独立计算 —— 差异表")

REPORT = [
    ("总体检出率", "99.46%", f"{n_det}/{n_anom} = {n_det/n_anom*100:.2f}%", n_anom,
     "分子分母标注错误; 比例本身在口径A下成立"),
    ("229/230 换算", "99.46%", f"229/230 = {229/230*100:.4f}%", 230,
     "基础算术错误, 正确值 99.57%"),
    ("总测量次数", "230", f"{len(trials)}", len(trials), "一致"),
    ("测试配置数", "82", f"{len(cfg_ids)}", len(cfg_ids), "一致"),
    ("误报率", "0.0%", f"{n_fa}/{len(normal_trials)} = {n_fa/len(normal_trials)*100:.2f}%",
     len(normal_trials), "一致"),
    ("极性准确率", "100%", f"{len(pol_true)}/{len(pol_checked)} = "
     f"{len(pol_true)/len(pol_checked)*100:.2f}%", len(pol_checked), "一致"),
    ("总体 MAE", "0.0855 m", f"{mae:.4f} m", len(loc_trials),
     "数值接近但口径与样本数需在报告中明示"),
    ("类别A 测量次数", "40", f"{len(catA_normal)}", len(catA_normal), "报告高估 9 次"),
    ("类别B 配置数", "28", f"{cat_results['B']['configs_from_trials_csv']}",
     cat_results['B']['configs_from_trials_csv'], "报告高估 12 组"),
    ("类别B 测量次数", "47", f"{cat_results['B']['trials_from_trials_csv']}",
     cat_results['B']['trials_from_trials_csv'], "报告高估 15 次"),
    ("类别B 检出率", "97.87%", f"{cat_results['B']['detection_rate_pct']:.2f}%",
     cat_results['B']['anomaly_trials'], "报告值偏高"),
    ("类别C 测量次数", "72", f"{cat_results['C']['trials_from_trials_csv']}",
     cat_results['C']['trials_from_trials_csv'], "一致"),
    ("类别C MAE", "0.130 m", f"{cat_results['C']['mae_m_from_trials']:.4f} m",
     cat_results['C']['located_trials'], "报告高估约 0.026 m"),
    ("类别D 测量次数", "48", f"{cat_results['D']['trials_from_trials_csv']}",
     cat_results['D']['trials_from_trials_csv'], "一致"),
    ("类别E 检出率", "100%", f"{cat_results['E']['detection_rate_pct']:.2f}%",
     cat_results['E']['anomaly_trials'], "报告未区分 normal/multi 的检出口径"),
    ("类别F 测量次数", "26", f"{cat_results['F']['trials_from_trials_csv']}",
     cat_results['F']['trials_from_trials_csv'], "报告高估 1 次"),
    ("各类别测量合计", "255", f"{tot_tri}", tot_tri, "报告内部不自洽"),
    ("各类别配置合计", "94", f"{tot_cfg}", tot_cfg, "报告内部不自洽"),
    ("P95 误差", "0.208 m", f"{p95:.4f} m", len(loc_trials), "需确认百分位算法"),
]

log()
log(f"{'指标':<18} {'报告值':<14} {'独立计算值':<26} {'n':>5}  说明")
log("-" * 110)
for name, rep, calc, n, note in REPORT:
    log(f"{name:<18} {rep:<14} {calc:<26} {n:>5}  {note}")

# ============================================================================
# 13. 报告每个数字的来源追溯
# ============================================================================

rule("13. 报告数值来源追溯（逐个数字定位到数据源）")

TRACE = [
    ("99.46%", "summary.overall.detection_rate = 0.9945652173913043",
     "183 detected / 184 异常试验 (mode != normal)",
     "比例正确，但报告标注为 '229/230' 属于分子分母张冠李戴"),
    ("229/230", "summary.overall.comprehensive_success_rate = 0.991304347826087",
     "228 综合成功 / 230 全部试验",
     "真正的分子分母是 228/230=99.13%；'229' 系笔误，'230' 是分母"),
    ("总测量 230", "trials.csv 行数", "230 行 trial 记录", "一致"),
    ("配置 82 组", "manifest.tested_configuration_count / statistics.csv has_data 行数",
     "82", "一致"),
    ("误报率 0.0%", "summary.overall.false_alarm_rate = 0.0",
     "46 次正常试验, 0 次误报", "一致"),
    ("极性 213 次", "statistics.csv Σpolarity_correct_count",
     "165 (trials 级) + 48 (candidates 级多异常) = 213",
     "数值一致；但 trials.csv 单独只有 165，报告未说明 213 含候选级判定"),
    ("极性准确率 100%", "summary.overall.polarity_accuracy = 1.0",
     "213/213", "一致"),
    ("MAE 8.55cm", "summary.overall.mae_m = 0.08554716981132086",
     "trials.csv 逐条重算 = 0.0860 m (8.60 cm)",
     "差异 0.04cm，源于 summary 与 trials 的聚合细节（见第5节）"),
    ("P95 0.208m", "summary.overall.p95_abs_error_m = 0.2079",
     "trials.csv 线性插值 P95 = 0.2249 m",
     "差异 0.017m，疑似百分位算法或样本集合不同"),
    ("RMSE 0.1095m", "summary.overall.rmse_m = 0.10952595109043409",
     "trials.csv 重算 = 0.1113 m", "差异 0.0018m"),
    ("类别C MAE 13.0cm", "（报告正文数字）",
     "trials.csv 重算 = 0.1042 m (10.42 cm)",
     "报告高估 2.58cm；statistics.csv 亦为 0.1042，报告与导出数据矛盾"),
]

log()
for rep, src, calc, note in TRACE:
    log(f"【{rep}】")
    log(f"  数据源 : {src}")
    log(f"  实际   : {calc}")
    log(f"  结论   : {note}")
    log()

# ============================================================================
# 14. 未验证项登记
# ============================================================================

rule("13. 未验证项登记")

UNVERIFIED = [
    "34m 短路失败的具体硬件机理 —— trials.csv notes 仅记录现象, 未附波形/信号分析",
    "实测反射系数 Gamma 数值 —— trials.csv 无该字段, 无法与理论值比对",
    "各测试线缆的特性阻抗是否为 50Ω —— 未见 cable 元数据佐证",
    "报告中'27Ω串联'异常对应哪个板件 —— boards.json 中无此标称",
    "多异常场景的距离定位精度 —— trials.csv 无 measured_distance_m, 需 candidates 表补充计算",
    "环境条件 (温度/湿度/EMI) —— 本次数据集不含相关字段",
    "第二批次 'FW63 V1.0 初验(Excel导入)' 的任何指标 —— 该批次 0 测量, 无数据可算",
    "配置覆盖率 50.9% 的合理性 —— 未测试配置的预期性能未验证",
]
for i, u in enumerate(UNVERIFIED, 1):
    log(f"  [{i}] [未验证] {u}")

# ============================================================================
# 保存输出
# ============================================================================

RESULT = {
    "audit_meta": {
        "authoritative_source": "measurements/trials.csv",
        "cross_check_sources": ["statistics/statistics.csv", "statistics/summary.csv",
                                 "manifest.json", "metadata/boards.json"],
        "trial_rows": len(trials),
        "tolerance_m": TOL,
        "statistics_rules": RULES,
        "script": "audit_v2.py",
        "dependencies": "Python标准库 only",
    },
    "distribution": {
        "detection_status": dict(status_ct),
        "mode": dict(mode_ct),
        "category_code": dict(cat_ct),
        "quality_usable": dict(usable_ct),
    },
    "detection_rate": {
        "filter": "mode != 'normal'",
        "numerator_detected": n_det,
        "denominator_anomaly_trials": n_anom,
        "rate_pct": n_det / n_anom * 100,
        "not_detected": n_nd,
        "variant_B_excluding_unusable": {
            "numerator": len(det_usable),
            "denominator": len(anom_usable),
            "rate_pct": len(det_usable) / len(anom_usable) * 100,
        },
        "variant_C_wrong_all_230_denominator": {
            "numerator": n_det, "denominator": len(trials),
            "rate_pct": n_det / len(trials) * 100,
        },
    },
    "false_alarm": {
        "filter": "mode == 'normal' AND (detection_status=='detected' OR candidate_count>0)",
        "normal_trials": len(normal_trials),
        "false_alarms": n_fa,
        "rate_pct": n_fa / len(normal_trials) * 100,
    },
    "polarity": {
        "filter": "polarity_correct 非空",
        "checked": len(pol_checked),
        "correct": len(pol_true),
        "wrong": len(pol_false),
        "accuracy_pct": len(pol_true) / len(pol_checked) * 100,
        "independent_polarity_mismatch": len(mismatch),
    },
    "location_accuracy": {
        "filter": "mode != 'normal' AND measured_distance_m 非空",
        "n": len(loc_trials),
        "mae_m": mae,
        "rmse_m": rmse,
        "median_abs_error_m": med,
        "p95_abs_error_m": p95,
        "max_abs_error_m": mx,
        "min_abs_error_m": mn,
        "signed_bias_m": bias,
        "std_error_m": sd,
        "within_tolerance": len(within),
        "within_tolerance_pct": len(within) / len(loc_trials) * 100,
        "mean_relative_error_pct": mean(rel) * 100,
    },
    "categories": cat_results,
    "totals": {
        "configs": tot_cfg,
        "trials": tot_tri,
        "anomaly_trials": n_anom,
        "normal_trials": len(normal_trials),
    },
    "report_vs_audit": [
        {"metric": n, "reported": rp, "recomputed": c, "n": n_, "note": nt}
        for n, rp, c, n_, nt in REPORT
    ],
    "unverified_items": UNVERIFIED,
}

(BASE / "审计结果_权威.json").write_text(
    json.dumps(RESULT, ensure_ascii=False, indent=2), encoding="utf-8")
(BASE / "审计结果_权威.txt").write_text("\n".join(LOG), encoding="utf-8")

rule("审计结束 —— 输出文件")
log("  审计结果_权威.json  (机器可读)")
log("  审计结果_权威.txt    (完整运行日志)")
log()
log("声明: 本脚本未修改任何原始数据; 未填补缺失记录;")
log("      statistics.csv 仅用于交叉比对, 未作为计算依据。")
