"""初始化数据库，可选导入内置 FW63 79 组初验矩阵。

用法（在项目根目录）：
    python scripts/bootstrap_db.py
    python scripts/bootstrap_db.py --import-sample
    python scripts/bootstrap_db.py --force --import-sample

本脚本不会创建任何模拟试次或虚假测量结果。
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tdr_studio import config  # noqa: E402
from tdr_studio.database import Database  # noqa: E402
from tdr_studio.services.excel_import import import_workbook  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="初始化 TDR Measurement Studio 数据库")
    parser.add_argument("--db", default=str(config.DB_PATH), help="数据库文件路径")
    parser.add_argument("--import-sample", action="store_true", help="导入内置 FW63 79 组测量矩阵")
    parser.add_argument("--force", action="store_true", help="若数据库已有实验配置仍继续导入（生成副本）")
    parser.add_argument("--workbook", default=str(config.DEFAULT_WORKBOOK), help="Excel 工作簿路径")
    args = parser.parse_args()

    db_path = Path(args.db).resolve()
    db = Database(db_path)
    db.initialize()
    print(f"数据库：{db_path}")
    print(f"已有实验配置：{db.scalar('SELECT COUNT(*) FROM experiment_configs')}")

    if args.import_sample:
        count = int(db.scalar("SELECT COUNT(*) FROM experiment_configs") or 0)
        if count and not args.force:
            print("数据库不是空配置库；为避免重复建组，未执行导入。需要时使用 --force。")
        else:
            report = import_workbook(db, args.workbook, allow_repeat=bool(count))
            print(
                f"导入完成：{report['imported_count']} 组配置，"
                f"计划试次 {report['planned_trials']}，警告 {report['warning_count']}，"
                f"错误 {report['error_count']}。"
            )
            print(f"导入报告：{report.get('report_path')}")
    print(f"测试板：{db.scalar('SELECT COUNT(*) FROM boards')}")
    print(f"试次：{db.scalar('SELECT COUNT(*) FROM trials')}")
    print("未创建任何模拟测量数据。")


if __name__ == "__main__":
    main()
