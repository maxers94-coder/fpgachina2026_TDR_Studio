"""命令行导入 Excel 测量矩阵。

用法：
    python scripts/import_excel.py "D:/path/matrix.xlsx"
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tdr_studio.database import Database  # noqa: E402
from tdr_studio.services.excel_import import import_workbook  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="导入 TDR 测量矩阵")
    parser.add_argument("workbook", help="Excel 文件路径")
    parser.add_argument("--allow-repeat", action="store_true", help="允许重复导入相同文件")
    args = parser.parse_args()
    db = Database()
    db.initialize()
    report = import_workbook(db, args.workbook, allow_repeat=args.allow_repeat)
    print(f"导入：{report.get('imported_count')}，跳过：{report.get('skipped_count')}，"
          f"警告：{report.get('warning_count')}，错误：{report.get('error_count')}")
    for warning in report.get("warnings", [])[:20]:
        print("警告：", warning)
    for error in report.get("errors", [])[:20]:
        print("错误：", error)
    print("报告：", report.get("report_path"))


if __name__ == "__main__":
    main()
