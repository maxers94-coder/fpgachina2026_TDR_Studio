"""环境与数据自检。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tdr_studio import config  # noqa: E402
from tdr_studio.database import Database  # noqa: E402

print("Python：", sys.version)
try:
    import tkinter

    print("Tkinter：", tkinter.TkVersion)
except Exception as exc:
    print("Tkinter：不可用", exc)
try:
    import openpyxl

    print("openpyxl：", openpyxl.__version__, "（vendor）")
except Exception as exc:
    print("openpyxl：不可用", exc)
try:
    import matplotlib

    print("matplotlib：", matplotlib.__version__)
except Exception as exc:
    print("matplotlib：不可用（图表功能会降级）", exc)

db = Database()
db.initialize()
print("数据库：", db.path)
print("数据目录：", config.DATA_DIR)
print("导出目录：", config.EXPORTS_DIR)
print("表数量：", len(db.query("SELECT name FROM sqlite_master WHERE type='table'")))
print("实验配置：", db.scalar("SELECT COUNT(*) FROM experiment_configs"))
print("试次：", db.scalar("SELECT COUNT(*) FROM trials"))
ok, message = db.integrity_check()
print("完整性：", message)
