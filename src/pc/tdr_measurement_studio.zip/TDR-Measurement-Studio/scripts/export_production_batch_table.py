"""导出当前生产批次配置表（用于人工/AI 审核），不修改数据库。

生成文件：exports/FW63_生产批次配置表_<批次代号>.xlsx
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tdr_studio import config  # noqa: E402  (注入 vendor/openpyxl)

from openpyxl import Workbook  # noqa: E402
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side  # noqa: E402
from openpyxl.utils import get_column_letter  # noqa: E402

from tdr_studio.database import Database  # noqa: E402
from tdr_studio.services.analytics import load_rules  # noqa: E402

FONT = "Microsoft YaHei UI"
HEADER_FILL = PatternFill("solid", fgColor="0F6E6E")
HEADER_FONT = Font(name=FONT, size=10, bold=True, color="FFFFFF")
TITLE_FONT = Font(name=FONT, size=16, bold=True, color="0B2B36")
BODY_FONT = Font(name=FONT, size=10)
BOLD_FONT = Font(name=FONT, size=10, bold=True)
WARN_FONT = Font(name=FONT, size=9, color="B42318")
MUTED_FONT = Font(name=FONT, size=9, color="63747D")
THIN = Side(style="thin", color="D9E1E5")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WARN_FILL = PatternFill("solid", fgColor="FFF4E5")
TITLE_FILL = PatternFill("solid", fgColor="E6F2F2")


def board_type_cn(value: str | None) -> str:
    return {"normal": "正常", "series": "串联", "shunt": "并联", "open": "开路",
            "short": "短路", "custom": "自定义"}.get(value or "", value or "")


def polarity_cn(value: str | None) -> str:
    return {"positive": "正", "negative": "负", "none": "无", "unknown": "不确定"}.get(value or "", value or "")


def mode_cn(value: str | None) -> str:
    return {"normal": "正常参考", "single": "单异常", "multi": "多异常"}.get(value or "", value or "")


def style_header(ws, row: int, columns: int):
    for cell in ws[row][:columns]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[row].height = 34


def auto_width(ws, min_width=9, max_width=48):
    for index, column_cells in enumerate(ws.columns, start=1):
        length = 0
        for cell in column_cells:
            if cell.value is not None:
                text = str(cell.value)
                length = max(length, min(len(text) * 1.25, max_width))
        ws.column_dimensions[get_column_letter(index)].width = max(min_width, length + 2)


def main():
    db = Database()
    batch = db.query_one("SELECT * FROM batches WHERE is_active=1 ORDER BY created_at DESC LIMIT 1")
    if not batch:
        raise SystemExit("没有当前批次")
    configs = db.query(
        """SELECT c.*, cat.code AS category_code, cat.name AS category_name,
                  bd.code AS board_code, bd.name AS board_name, bd.board_type,
                  bd.nominal_ohm, bd.measured_ohm, bd.gamma_nominal, bd.gamma_measured,
                  bd.polarity AS board_polarity, bd.status AS board_status,
                  bd.z0 AS board_z0, bd.notes AS board_notes
           FROM experiment_configs c
           JOIN experiment_categories cat ON cat.id=c.category_id
           LEFT JOIN boards bd ON bd.id=c.board_id
           WHERE c.batch_id=? ORDER BY c.sort_order, c.code""",
        (batch["id"],),
    )
    boards = db.query("SELECT * FROM boards ORDER BY code")
    settings = db.get_all_settings()
    rules = load_rules(db)
    board_by_id = {b["id"]: b for b in boards}
    trial_count = int(db.scalar("SELECT COUNT(*) FROM trials WHERE config_id IN (SELECT id FROM experiment_configs WHERE batch_id=?)", (batch["id"],), 0) or 0)
    planned = sum(int(c["planned_repeats"] or 0) for c in configs)
    now = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")

    wb = Workbook()
    ws = wb.active
    ws.title = "批次与说明"
    ws["A1"] = "FW63 生产批次配置表"
    ws["A1"].font = TITLE_FONT
    ws.merge_cells("A1:D1")
    ws["A2"] = "用于人工和 AI 检查实验计划；本表不含测量结果（试次为 0）。"
    ws["A2"].font = Font(name=FONT, size=10, color="B42318")
    ws.merge_cells("A2:D2")
    info = [
        ("批次名称", batch["name"]),
        ("批次代号", batch["code"]),
        ("固件版本", batch["firmware_version"]),
        ("模拟前端", batch["frontend"]),
        ("导出时间", now),
        ("配置数量", len(configs)),
        ("计划试次数", planned),
        ("实测试次数", trial_count),
        ("距离容差", f"{rules['distance_tolerance_m']:.3f} m"),
        ("最低检出率", f"{rules['min_detection_rate'] * 100:.1f}%"),
        ("正常误报率上限", f"{rules['max_false_alarm_rate'] * 100:.1f}%"),
        ("EDGE* 有效", "是" if rules["edge_as_valid"] else "否"),
        ("数据来源", "当前活动批次（data/tdr_studio.db）"),
    ]
    for i, (key, value) in enumerate(info, start=4):
        ws.cell(i, 1, key).font = BOLD_FONT
        ws.cell(i, 1).fill = TITLE_FILL
        ws.cell(i, 1).border = BORDER
        ws.cell(i, 2, value).font = BODY_FONT
        ws.cell(i, 2).border = BORDER
    note_row = 4 + len(info) + 1
    notes = [
        "本表是计划配置表，不是实测数据；当前该批次实测试次为 0。",
        "理论反射系数按理想集总电阻模型计算，不是仪器实测反射系数。",
        "“配置检查提示”列自动标出可疑点；本批次生成时为 0 条，仍建议人工复核。",
        "多异常配置的“预期真实异常”来自计划配置，需人工核对测试板映射。",
        "测量前建议在程序中关联健康参考；未关联时程序会提示。",
        "建议 AI 重点检查：距离/重复次数、测试板与预期极性、批量配置是否有遗漏或重复。",
    ]
    ws.cell(note_row, 1, "检查提示").font = Font(name=FONT, size=11, bold=True, color="B42318")
    for i, note in enumerate(notes, start=1):
        cell = ws.cell(note_row + i, 1, "• " + note)
        cell.font = WARN_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=note_row + i, start_column=1, end_row=note_row + i, end_column=4)
        ws.row_dimensions[note_row + i].height = 28
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 55
    ws.column_dimensions["C"].width = 26
    ws.column_dimensions["D"].width = 26

    # 配置表
    ws = wb.create_sheet("82组配置")
    headers = [
        "序号", "实验编号", "实验名称", "类别", "模式", "优先级", "测试板代号",
        "测试板名称", "板类型", "标称阻值Ω", "理论Γ(%)", "理论极性", "真值距离m",
        "真值表达式", "预期真实异常", "计划重复次数", "距离容差m", "状态",
        "参考标识", "配置检查提示", "备注",
    ]
    ws.append(headers)
    style_header(ws, 1, len(headers))
    for idx, c in enumerate(configs, start=1):
        expected = []
        try:
            expected_list = json.loads(c.get("expected_anomalies_json") or "[]")
        except Exception:
            expected_list = []
        for anomaly in expected_list:
            board = board_by_id.get(anomaly.get("board_id"))
            board_code = board["code"] if board else anomaly.get("board_code") or "?"
            expected.append(
                f"{board_code}@{anomaly.get('true_distance_m')}m"
                f"({polarity_cn(anomaly.get('expected_polarity'))})"
            )
        checks = []
        if c["board_code"] == "T8" and "串联" in (c["board_name"] or ""):
            checks.append("T8名称写串联但类型为并联，极性可能相反")
        if not c["board_code"] and c["mode"] != "multi":
            checks.append("单异常/正常配置未绑定测试板")
        if c["mode"] == "single" and c["distance_m"] is None:
            checks.append("单异常配置缺少真值距离")
        if c["mode"] == "multi" and not expected:
            checks.append("多异常配置缺少真实异常定义")
        ws.append([
            idx, c["code"], c["name"], c["category_name"], mode_cn(c["mode"]), c["priority"],
            c["board_code"] or "—", c["board_name"] or "—", board_type_cn(c["board_type"]),
            c["nominal_ohm"], (c["gamma_nominal"] * 100 if c["gamma_nominal"] is not None else None),
            polarity_cn(c["board_polarity"]), c["distance_m"], c["distance_expr"] or "",
            "；".join(expected), c["planned_repeats"], c["tolerance_m"],
            {"not_started": "未开始", "in_progress": "进行中", "completed": "已完成",
             "skipped": "已跳过", "failed": "失败"}.get(c["status"], c["status"]),
            c["reference_label"] or "", "；".join(checks), c["notes"] or "",
        ])
        if checks:
            for cell in ws[ws.max_row]:
                cell.fill = WARN_FILL
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            if cell.font is None or cell.font.name != FONT:
                cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    auto_width(ws)
    ws.column_dimensions["B"].width = 11
    ws.column_dimensions["C"].width = 32
    ws.column_dimensions["O"].width = 40
    ws.column_dimensions["T"].width = 38
    ws.column_dimensions["U"].width = 42

    # 多异常真实定义
    ws = wb.create_sheet("多异常真实定义")
    headers = ["实验编号", "实验名称", "异常序号", "测试板代号", "测试板名称", "真实距离m", "预期极性", "容差m", "备注"]
    ws.append(headers)
    style_header(ws, 1, len(headers))
    for c in configs:
        if c["mode"] != "multi":
            continue
        try:
            expected_list = json.loads(c.get("expected_anomalies_json") or "[]")
        except Exception:
            expected_list = []
        for i, anomaly in enumerate(expected_list, start=1):
            board = board_by_id.get(anomaly.get("board_id"))
            ws.append([
                c["code"], c["name"], i, board["code"] if board else anomaly.get("board_code", "—"),
                board["name"] if board else anomaly.get("board_name", "—"),
                anomaly.get("true_distance_m"), polarity_cn(anomaly.get("expected_polarity")),
                anomaly.get("tolerance_m") or c["tolerance_m"], anomaly.get("notes", ""),
            ])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    auto_width(ws)

    # 测试板
    ws = wb.create_sheet("当前测试板")
    headers = ["代号", "名称", "类型", "标称阻值Ω", "实测阻值Ω", "Z0Ω", "理论Γ", "理论Γ%", "极性", "状态", "备注"]
    ws.append(headers)
    style_header(ws, 1, len(headers))
    for b in boards:
        ws.append([
            b["code"], b["name"], board_type_cn(b["board_type"]), b["nominal_ohm"], b["measured_ohm"],
            b["z0"], b["gamma_nominal"], b["gamma_nominal"] * 100 if b["gamma_nominal"] is not None else None,
            polarity_cn(b["polarity"]), {"available": "可用", "pending": "待制作", "damaged": "损坏", "retired": "停用"}.get(b["status"], b["status"]),
            b["notes"],
        ])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    auto_width(ws)

    # 字段说明
    ws = wb.create_sheet("字段说明")
    ws.append(["字段/概念", "说明"])
    style_header(ws, 1, 2)
    dictionary = [
        ("实验编号", "生产批次内唯一编号；P 开头表示由初验配置复制到生产批次。"),
        ("模式", "正常参考、单异常、多异常。正常参考不需要距离和极性。"),
        ("理论Γ(%)", "按测试板标称/实测电阻计算的理想集总模型理论反射系数，以百分比显示，不是仪器实测值。"),
        ("真值距离m", "从 DUT 近端参考面到异常作用面的真实距离。"),
        ("真实异常定义", "多异常模式下，每个真实异常的位置、板、预期极性。"),
        ("计划重复次数", "该组计划完成的独立试次数；修改不会删除已录入数据。"),
        ("配置检查提示", "自动生成的可疑点提示，需人工确认，不代表已判定错误。"),
        ("实测试次", "当前生产批次为 0；本表不是测量结果。"),
    ]
    for key, value in dictionary:
        ws.append([key, value])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 95

    config.EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
    safe_code = str(batch["code"]).replace("/", "_")
    target = config.EXPORTS_DIR / f"FW63_生产批次配置表_{safe_code}.xlsx"
    wb.save(target)
    print(target)
    print(f"configs={len(configs)} planned={planned} trials={trial_count}")


if __name__ == "__main__":
    main()
