"""审计当前生产批次的 82 组配置，生成问题清单 Excel（只读数据库）。

重点检查：
* 配置标题中的旧测试板代号/阻值/类型是否与当前测试板资产一致；
* 多异常配置的预期板名/极性是否与当前测试板一致；
* 试次数、重复组合、未检出原因、自动判定；
* 统计口径异常（仅报告，不修改原始记录）。
"""
from __future__ import annotations

import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tdr_studio import config  # noqa: E402

from openpyxl import Workbook  # noqa: E402
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side  # noqa: E402
from openpyxl.utils import get_column_letter  # noqa: E402

from tdr_studio.database import Database  # noqa: E402
from tdr_studio.services.analytics import config_stats, load_rules  # noqa: E402
from tdr_studio.services.judgement import evaluate_judgement  # noqa: E402

FONT = "Microsoft YaHei UI"
TITLE_FONT = Font(name=FONT, size=16, bold=True, color="0B2B36")
HEADER_FILL = PatternFill("solid", fgColor="0F6E6E")
HEADER_FONT = Font(name=FONT, size=10, bold=True, color="FFFFFF")
BODY_FONT = Font(name=FONT, size=9)
BOLD_FONT = Font(name=FONT, size=9, bold=True)
THIN = Side(style="thin", color="D9E1E5")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
SEV_FILL = {
    "高": PatternFill("solid", fgColor="FDE2DF"),
    "中": PatternFill("solid", fgColor="FFF2CC"),
    "低": PatternFill("solid", fgColor="EAF4F4"),
}


def type_cn(t):
    return {"normal": "正常", "series": "串联", "shunt": "并联", "open": "开路",
            "short": "短路", "custom": "自定义"}.get(t or "", t or "")


def polarity_cn(p):
    return {"positive": "正", "negative": "负", "none": "无", "unknown": "不确定"}.get(p or "", p or "")


def mode_cn(m):
    return {"normal": "正常参考", "single": "单异常", "multi": "多异常"}.get(m or "", m or "")


def severity_rank(s):
    return {"高": 0, "中": 1, "低": 2}.get(s, 3)


def suggested_title(c, board, expected_boards):
    if c["mode"] == "multi":
        parts = [f"{b['code']}@{d:g}m" for b, d in expected_boards]
        return "多异常定位 | " + " + ".join(parts)
    if c["mode"] == "normal":
        dist = f"{c['distance_m']:g} m | " if c["distance_m"] is not None else ""
        return f"正常参考 | {dist}{board['code']} {board['name']}" if board else "正常参考"
    if board:
        return f"{c['distance_m']:g} m | {board['code']} {board['name']}"
    return c["name"]


def set_header(ws, row, count):
    for cell in ws[row][:count]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[row].height = 34


def auto_width(ws, max_width=45):
    for idx, col in enumerate(ws.columns, start=1):
        length = 0
        for cell in col:
            if cell.value is not None:
                length = max(length, min(len(str(cell.value)) * 1.2, max_width))
        ws.column_dimensions[get_column_letter(idx)].width = max(9, length + 2)


def main():
    db = Database()
    batch = db.query_one("SELECT * FROM batches WHERE is_active=1 ORDER BY created_at DESC LIMIT 1")
    if not batch:
        raise SystemExit("没有当前批次")
    configs = db.query(
        """SELECT c.*, cat.code AS category_code, cat.name AS category_name,
                  bd.code AS board_code, bd.name AS board_name, bd.board_type,
                  bd.nominal_ohm, bd.gamma_nominal, bd.polarity AS board_polarity
           FROM experiment_configs c
           JOIN experiment_categories cat ON cat.id=c.category_id
           LEFT JOIN boards bd ON bd.id=c.board_id
           WHERE c.batch_id=? ORDER BY c.sort_order, c.code""",
        (batch["id"],),
    )
    boards_by_id = {b["id"]: b for b in db.query("SELECT * FROM boards")}
    # group duplicates by mode + board + distance
    groups = defaultdict(list)
    for c in configs:
        if c["mode"] == "multi":
            try:
                expected_key = tuple(sorted(
                    (e.get("board_id"), e.get("true_distance_m"))
                    for e in __import__("json").loads(c.get("expected_anomalies_json") or "[]")
                ))
            except Exception:
                expected_key = (c["distance_m"],)
            key = ("multi", expected_key)
        else:
            key = (c["mode"], c["board_id"], c["distance_m"])
        groups[key].append(c["code"])
    duplicate_of = {}
    for key, codes in groups.items():
        if len(codes) > 1:
            for code in codes:
                duplicate_of[code] = codes

    rows = []
    for idx, c in enumerate(configs, start=1):
        stats = config_stats(db, c["id"])
        judgement = evaluate_judgement(
            stats, stats.get("rules") or load_rules(db),
            planned_trials=c["planned_repeats"] or 0,
        )
        expected = []
        for anomaly in c.get("expected_anomalies_json") and __import__("json").loads(c["expected_anomalies_json"]) or []:
            b = boards_by_id.get(anomaly.get("board_id"))
            expected.append((b, anomaly))
        issues = []
        board = boards_by_id.get(c["board_id"])
        name = c["name"] or ""
        # 1. old board identity in title (single)
        if c["mode"] == "single" and board:
            nums = re.findall(r"(?:S|P)\s*([0-9]+(?:\.[0-9]+)?)", name, flags=re.I)
            if nums:
                old_ohm = float(nums[0])
                actual = float(board["nominal_ohm"]) if board["nominal_ohm"] is not None else None
                if actual is not None and abs(old_ohm - actual) > max(0.01, actual * 0.01):
                    issues.append(("中", "标题旧阻值", f"标题写 {old_ohm:g}Ω，当前板实际 {actual:g}Ω"))
            if "串联" in name and board["board_type"] != "series":
                issues.append(("中", "标题旧类型", f"标题写串联，当前板类型为{type_cn(board['board_type'])}"))
            if "并联" in name and board["board_type"] != "shunt":
                issues.append(("中", "标题旧类型", f"标题写并联，当前板类型为{type_cn(board['board_type'])}"))
        if c["mode"] == "multi":
            issues.append(("中", "多异常旧标题", "标题仍使用旧 A/B/C/D 组合编号"))
            for b, anomaly in expected:
                if not b:
                    issues.append(("高", "多异常缺板", "预期异常找不到当前测试板"))
                    continue
                if anomaly.get("expected_polarity") != b["polarity"]:
                    issues.append((
                        "高", "多异常预期极性冲突",
                        f"{b['code']} 预期 {polarity_cn(anomaly.get('expected_polarity'))}，"
                        f"当前板 {polarity_cn(b['polarity'])}（{type_cn(b['board_type'])}）"
                    ))
                if anomaly.get("board_name") != b["name"]:
                    issues.append((
                        "中", "多异常预期板名旧",
                        f"预期定义写“{anomaly.get('board_name')}”，当前板名“{b['name']}”"
                    ))
        # normal old labels
        if c["mode"] == "normal" and ("Normal / N" in name or "N2" in name):
            issues.append(("低", "旧 Normal 标签", "标题仍用 Normal/N2，可改为当前 T1/T10"))
        # missing current code in title (low)
        if c["mode"] == "single" and board and board["code"] not in name:
            issues.append(("低", "标题缺少当前板代号", f"建议加入 {board['code']}"))
        # duplicates
        if c["code"] in duplicate_of:
            others = [x for x in duplicate_of[c["code"]] if x != c["code"]]
            issues.append(("低", "重复板+距离组合", "同模式/同板/同距离: " + ", ".join(others)))
        # planned vs actual
        actual = stats["total_trials"]
        if actual < c["planned_repeats"]:
            issues.append(("高", "试次不足", f"实际 {actual} / 计划 {c['planned_repeats']}"))
        elif actual > c["planned_repeats"]:
            issues.append(("低", "超出计划次数", f"实际 {actual} / 计划 {c['planned_repeats']}"))
        # invalid/missed setup note
        for t in db.query(
            """SELECT trial_index,detection_status,quality_flag,notes FROM trials
               WHERE config_id=? AND detection_status IN ('not_detected','invalid','rejected')""",
            (c["id"],),
        ):
            if t["detection_status"] == "not_detected":
                note = (t["notes"] or "").strip()
                if note and any(word in note for word in ("无法", "暂时", "没有", "只有", "接线", "条件")):
                    issues.append(("高", "可能应标无效", f"第{t['trial_index']}次未检出：{note}"))
        # summary issue text
        issue_text = "；".join(f"[{s}] {k}: {d}" for s, k, d in issues) if issues else "无明显问题"
        max_sev = "高" if any(s == "高" for s, _, _ in issues) else "中" if any(s == "中" for s, _, _ in issues) else "低" if issues else "—"
        expected_boards = [(b, anomaly.get("true_distance_m")) for b, anomaly in expected if b]
        rows.append({
            "idx": idx,
            "code": c["code"],
            "name": name,
            "suggested": suggested_title(c, board, expected_boards),
            "mode": mode_cn(c["mode"]),
            "category": c["category_name"],
            "board_code": c["board_code"] or "—",
            "board_name": c["board_name"] or ("多异常组合" if c["mode"] == "multi" else "未绑定"),
            "board_type": type_cn(c["board_type"]),
            "ohm": c["nominal_ohm"],
            "gamma": c["nominal_gamma"],
            "distance": c["distance_m"],
            "planned": c["planned_repeats"],
            "actual": actual,
            "detection": stats.get("detection_rate"),
            "polarity": stats.get("polarity_accuracy"),
            "location": stats.get("location_pass_rate"),
            "mae": stats["distance"].get("mae_m"),
            "judgement": judgement["label"],
            "max_severity": max_sev,
            "issues": issues,
            "issue_text": issue_text,
            "status": c["status"],
        })

    # summary counts
    sev_counter = Counter()
    type_counter = Counter()
    for r in rows:
        for sev, kind, _detail in r["issues"]:
            sev_counter[sev] += 1
            type_counter[kind] += 1
    total_trials = int(db.scalar("SELECT COUNT(*) FROM trials WHERE config_id IN (SELECT id FROM experiment_configs WHERE batch_id=?)", (batch["id"],), 0) or 0)
    aggregated_stats = None
    from tdr_studio.services.analytics import scope_stats
    overall, _ = scope_stats(db, batch_id=batch["id"])

    wb = Workbook()
    ws = wb.active
    ws.title = "审计摘要"
    ws["A1"] = "FW63 生产批次配置审计报告"
    ws["A1"].font = TITLE_FONT
    ws.merge_cells("A1:D1")
    ws["A2"] = "只读审计，未修改任何配置或测量记录。"
    ws["A2"].font = Font(name=FONT, size=10, color="B42318")
    ws.merge_cells("A2:D2")
    info = [
        ("批次", f"{batch['code']}｜{batch['name']}"),
        ("生成时间", datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")),
        ("配置数量", len(configs)),
        ("实测试次", total_trials),
        ("异常检出率", f"{overall.get('anomaly_detection_rate') * 100:.2f}%" if overall.get("anomaly_detection_rate") is not None else "不适用"),
        ("正常误报率", f"{overall.get('false_alarm_rate') * 100:.2f}%" if overall.get("false_alarm_rate") is not None else "不适用"),
        ("MAE", f"{overall['distance']['mae_m']:.4f} m" if overall['distance'].get('mae_m') is not None else "不适用"),
        ("P95", f"{overall['distance']['p95_abs_error_m']:.4f} m" if overall['distance'].get('p95_abs_error_m') is not None else "不适用"),
        ("严重问题条目", sev_counter["高"]),
        ("中等问题条目", sev_counter["中"]),
        ("提示条目", sev_counter["低"]),
    ]
    for i, (key, value) in enumerate(info, start=4):
        ws.cell(i, 1, key).font = BOLD_FONT
        ws.cell(i, 1).fill = PatternFill("solid", fgColor="E6F2F2")
        ws.cell(i, 1).border = BORDER
        ws.cell(i, 2, value).font = BODY_FONT
        ws.cell(i, 2).border = BORDER
    r = 4 + len(info) + 1
    ws.cell(r, 1, "重点发现").font = Font(name=FONT, size=12, bold=True, color="B42318")
    findings = [
        f"当前生产批次实际为 {len(configs)} 组，不是 81 组；其中单异常 59 组、正常 17 组、多异常 6 组。",
        "大量配置标题仍沿用旧测试板名称（S27/S4.7/P470/P1000/P2000 等），但实际绑定的是当前 T 板。标题不影响统计，但会误导人工和 AI 阅读。",
        "多异常 PE01/PE02/PE05/PE06 的预期定义仍把 T8 当作正极性串联板；当前 T8 资产是并联/负极性。请确认多点实验中 25 m 处实际使用的是哪块板，并修正预期定义。",
        "多异常配置标题仍写 D15 + A25 等旧编号，与当前 T3/T8 等实际板不一致。",
        "PB16（34 m 短路）唯一未检出记录的备注为“暂时只有4个直通连接器，无法接短路”，更像条件不具备，建议核实是否应改为“无效”，不要直接删除。",
        "PE06、PF05 实际试次超过计划；其余组均已达到计划次数。",
        "多异常组的总体定位/极性统计存在过代码缺陷，已修复；重启程序后按当前规则重算。",
    ]
    for i, text in enumerate(findings, start=1):
        cell = ws.cell(r + i, 1, "• " + text)
        cell.font = Font(name=FONT, size=9, color="7A271A")
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r + i, start_column=1, end_row=r + i, end_column=4)
        ws.row_dimensions[r + i].height = 30
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 55
    ws.column_dimensions["C"].width = 28
    ws.column_dimensions["D"].width = 28

    # Issue summary
    ws = wb.create_sheet("问题类型统计")
    ws.append(["问题级别", "问题类型", "条目数"])
    set_header(ws, 1, 3)
    for sev in ["高", "中", "低"]:
        for kind, count in sorted(type_counter.items()):
            if any(s == sev and k == kind for r in rows for s, k, _ in r["issues"]):
                ws.append([sev, kind, count])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.freeze_panes = "A2"
    auto_width(ws)

    # All config audit
    ws = wb.create_sheet("82组审计")
    headers = [
        "序号", "实验编号", "当前标题", "建议标题", "模式", "类别", "当前测试板",
        "板名称", "板类型", "标称Ω", "理论Γ(%)", "距离m", "计划", "实际",
        "检出率", "极性正确率", "定位合格率", "MAE m", "自动判定",
        "最高问题级别", "问题明细", "状态",
    ]
    ws.append(headers)
    set_header(ws, 1, len(headers))
    for row in sorted(rows, key=lambda x: (severity_rank(x["max_severity"]), x["idx"])):
        ws.append([
            row["idx"], row["code"], row["name"], row["suggested"], row["mode"],
            row["category"], row["board_code"], row["board_name"], row["board_type"],
            row["ohm"], (row["gamma"] * 100 if row["gamma"] is not None else None),
            row["distance"], row["planned"], row["actual"], row["detection"],
            row["polarity"], row["location"], row["mae"], row["judgement"],
            row["max_severity"], row["issue_text"], row["status"],
        ])
        if row["max_severity"] in SEV_FILL:
            for cell in ws[ws.max_row]:
                cell.fill = SEV_FILL[row["max_severity"]]
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for idx in [15, 16, 17]:
        for cell in ws.iter_cols(min_col=idx, max_col=idx, min_row=2):
            for c in cell:
                c.number_format = "0.00%"
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    ws.column_dimensions["C"].width = 34
    ws.column_dimensions["D"].width = 36
    ws.column_dimensions["U"].width = 55
    auto_width(ws)

    # Multi detail
    ws = wb.create_sheet("多异常定义核对")
    headers = ["配置编号", "配置标题", "异常序号", "预期板代号", "预期板名",
               "真实距离m", "预期极性", "当前板代号", "当前板名", "当前板类型",
               "当前板极性", "是否一致"]
    ws.append(headers)
    set_header(ws, 1, len(headers))
    for c in configs:
        if c["mode"] != "multi":
            continue
        try:
            expected = __import__("json").loads(c.get("expected_anomalies_json") or "[]")
        except Exception:
            expected = []
        for i, anomaly in enumerate(expected, start=1):
            b = boards_by_id.get(anomaly.get("board_id"))
            ok = bool(b and anomaly.get("expected_polarity") == b["polarity"] and anomaly.get("board_name") == b["name"])
            ws.append([
                c["code"], c["name"], i, anomaly.get("board_code"), anomaly.get("board_name"),
                anomaly.get("true_distance_m"), polarity_cn(anomaly.get("expected_polarity")),
                b["code"] if b else "—", b["name"] if b else "—", type_cn(b["board_type"] if b else None),
                polarity_cn(b["polarity"] if b else None), "一致" if ok else "需核对",
            ])
            if not ok:
                for cell in ws[ws.max_row]:
                    cell.fill = SEV_FILL["高"]
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    auto_width(ws)

    # data issues
    ws = wb.create_sheet("数据质量提示")
    ws.append(["实验编号", "试次", "状态", "备注", "建议"])
    set_header(ws, 1, 5)
    for c in configs:
        for t in db.query(
            """SELECT trial_index,detection_status,notes FROM trials
               WHERE config_id=? AND detection_status='not_detected'""",
            (c["id"],),
        ):
            note = (t["notes"] or "").strip()
            if note:
                ws.append([c["code"], t["trial_index"], "未检出", note, "核实是否属于条件不具备；如属实，可改为“无效”并保留原始记录。"])
    if ws.max_row == 1:
        ws.append(["无", "—", "—", "没有带备注的未检出记录", "—"])
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    auto_width(ws)

    target = config.EXPORTS_DIR / f"FW63_生产批次审计报告_{batch['code']}.xlsx"
    wb.save(target)
    print(target)
    print(f"configs={len(configs)} trials={total_trials} high={sev_counter['高']} mid={sev_counter['中']} low={sev_counter['低']}")
    print("types", type_counter.most_common())


if __name__ == "__main__":
    main()
