"""独立重算脚本：只使用导出的 JSON/ZIP，不导入本程序业务代码。

用法：
    python scripts/recompute_from_export.py path/to/full_dataset.json
    python scripts/recompute_from_export.py path/to/TDR_AI_数据包.zip

验证目标：
* 检出率 = detected / (detected + not_detected)
* MAE = 有效定位绝对误差均值
* P95 = 绝对误差 95% 分位数（线性插值）
* 与导出中的 statistics.per_configuration 对比，列出差异
"""
from __future__ import annotations

import argparse
import json
import math
import zipfile
from pathlib import Path


def load_dataset(path: Path) -> dict:
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as archive:
            names = [n for n in archive.namelist() if n.endswith("measurements/full_dataset.json")]
            if not names:
                raise SystemExit("ZIP 中找不到 measurements/full_dataset.json")
            return json.loads(archive.read(names[0]).decode("utf-8"))
    return json.loads(path.read_text(encoding="utf-8"))


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    if len(values) == 1:
        return values[0]
    pos = (len(values) - 1) * q
    low, high = math.floor(pos), math.ceil(pos)
    if low == high:
        return values[low]
    return values[low] + (values[high] - values[low]) * (pos - low)


def recompute(dataset: dict) -> dict[str, dict]:
    configs = {c["id"]: c for c in dataset.get("configurations", [])}
    trials = dataset.get("trials", [])
    candidates = dataset.get("detected_candidates", [])
    rules = (dataset.get("metadata", {}).get("statistics_rules") or {})
    edge_as_valid = bool(rules.get("edge_as_valid", False))
    by_trial = {t["trial_id"]: t for t in trials}
    result: dict[str, dict] = {}
    for config_id, config in configs.items():
        group = [t for t in trials if t["configuration_id"] == config_id]
        detected = [t for t in group if t["detection_status"] == "detected"]
        missed = [t for t in group if t["detection_status"] == "not_detected"]
        normal = [t for t in group if t["detection_status"] == "normal"]
        false_alarm = [t for t in group if t["detection_status"] == "false_alarm"]
        denom = len(detected) + len(missed)
        normal_denom = len(normal) + len(false_alarm)
        errors = []
        if config.get("mode") == "multi":
            for candidate in candidates:
                trial = by_trial.get(candidate.get("trial_id"))
                if not trial or trial.get("configuration_id") != config_id:
                    continue
                if candidate.get("true_distance_m") is None or candidate.get("distance_error_m") is None:
                    continue
                if candidate.get("quality_flag") in {"PN?", "OVERFLOW", "拒判"}:
                    continue
                if candidate.get("quality_flag") == "EDGE*" and not edge_as_valid:
                    continue
                errors.append(abs(float(candidate["distance_error_m"])))
        else:
            for trial in detected:
                if trial.get("measured_distance_m") is None or trial.get("distance_error_m") is None:
                    continue
                if not trial.get("quality_usable", True):
                    continue
                errors.append(abs(float(trial["distance_error_m"])))
        result[config_id] = {
            "config_code": config.get("code"),
            "mode": config.get("mode"),
            "total_trials": len(group),
            "detected": len(detected),
            "not_detected": len(missed),
            "detection_rate": (len(detected) / denom) if denom else None,
            "normal_count": len(normal),
            "false_alarm_count": len(false_alarm),
            "false_alarm_rate": (len(false_alarm) / normal_denom) if normal_denom else None,
            "located": len(errors),
            "mae_m": (sum(errors) / len(errors)) if errors else None,
            "p95_abs_error_m": percentile(errors, 0.95),
        }
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("path", help="full_dataset.json 或 AI 数据包 ZIP")
    args = parser.parse_args()
    path = Path(args.path)
    data = load_dataset(path)
    computed = recompute(data)
    stats = {
        s["config_id"]: s
        for s in data.get("statistics", {}).get("per_configuration", [])
    }
    print(f"数据文件：{path}")
    print(f"配置数：{len(computed)}，试次：{len(data.get('trials', []))}")
    print("\n配置         总/检出/未检出   检出率      MAE(m)     P95(m)     与导出统计差异")
    for config_id, row in computed.items():
        ref = stats.get(config_id, {})
        ref_distance = ref.get("distance") or {}
        diffs = []
        for key, ref_value in [
            ("detection_rate", ref.get("detection_rate")),
            ("mae_m", ref_distance.get("mae_m")),
            ("p95_abs_error_m", ref_distance.get("p95_abs_error_m")),
        ]:
            left, right = row.get(key), ref_value
            if left is None and right is None:
                continue
            if left is None or right is None or abs(float(left) - float(right)) > 1e-9:
                diffs.append(f"{key}: {left} vs {right}")
        detection_text = "—" if row["detection_rate"] is None else f"{row['detection_rate'] * 100:.2f}%"
        mae_text = "—" if row["mae_m"] is None else f"{row['mae_m']:.4f}"
        p95_text = "—" if row["p95_abs_error_m"] is None else f"{row['p95_abs_error_m']:.4f}"
        print(
            f"{row['config_code'] or config_id[:10]:<12} {row['total_trials']:>4}/{row['detected']:<4}/{row['not_detected']:<4}"
            f" {detection_text:>9} {mae_text:>9} {p95_text:>9}"
            f"  {'OK' if not diffs else '; '.join(diffs)}"
        )


if __name__ == "__main__":
    main()
